CREATE TABLE network_devices (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    mac_address VARCHAR(17) UNIQUE NOT NULL,
    ip_address INET,
    hostname VARCHAR(255),
    device_type VARCHAR(50),
    manufacturer VARCHAR(100),
    status VARCHAR(20) DEFAULT 'active',
    is_blocked BOOLEAN DEFAULT false,
    last_seen TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    wake_on_lan_enabled BOOLEAN DEFAULT false,
    bandwidth_limit INTEGER,
    client_group_id UUID,
    metadata JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);