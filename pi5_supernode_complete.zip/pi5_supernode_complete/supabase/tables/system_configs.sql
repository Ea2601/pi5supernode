-- System Configurations Table
-- Stores system-wide configuration settings with versioning support
CREATE TABLE system_configs (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    config_key VARCHAR(255) UNIQUE NOT NULL,
    config_value JSONB NOT NULL,
    config_type VARCHAR(100) NOT NULL DEFAULT 'general',
    description TEXT,
    version INTEGER DEFAULT 1,
    is_active BOOLEAN DEFAULT true,
    requires_restart BOOLEAN DEFAULT false,
    created_by UUID,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create index for efficient lookups
CREATE INDEX idx_system_configs_key ON system_configs(config_key);
CREATE INDEX idx_system_configs_type ON system_configs(config_type);
CREATE INDEX idx_system_configs_active ON system_configs(is_active);

-- Enable Row Level Security
ALTER TABLE system_configs ENABLE ROW LEVEL SECURITY;

-- Create policy for system configurations (allow all operations for authenticated users)
CREATE POLICY "Allow full access to system_configs for authenticated users" ON system_configs
    FOR ALL USING (auth.role() = 'authenticated');

-- Insert default system configurations
INSERT INTO system_configs (config_key, config_value, config_type, description) VALUES
('system_initialized', 'false', 'system', 'Whether the system has been initialized'),
('default_timezone', '"UTC"', 'system', 'Default system timezone'),
('auto_updates_enabled', 'true', 'system', 'Enable automatic system updates'),
('log_retention_days', '30', 'system', 'Number of days to retain system logs'),
('max_concurrent_connections', '1000', 'network', 'Maximum concurrent network connections'),
('session_timeout_minutes', '30', 'security', 'User session timeout in minutes');