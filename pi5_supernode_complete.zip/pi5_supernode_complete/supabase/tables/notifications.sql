-- Notifications Table
-- Stores system and user notifications
CREATE TABLE notifications (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    title VARCHAR(255),
    message TEXT NOT NULL,
    type VARCHAR(50) NOT NULL DEFAULT 'info',
    priority INTEGER DEFAULT 5, -- 1-10 scale, 10 being highest
    is_read BOOLEAN DEFAULT false,
    is_system BOOLEAN DEFAULT false,
    action_url TEXT,
    action_label VARCHAR(100),
    expires_at TIMESTAMP WITH TIME ZONE,
    metadata JSONB DEFAULT '{}'::jsonb,
    user_id UUID,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    read_at TIMESTAMP WITH TIME ZONE
);

-- Create indexes for efficient queries
CREATE INDEX idx_notifications_type ON notifications(type);
CREATE INDEX idx_notifications_is_read ON notifications(is_read);
CREATE INDEX idx_notifications_user_id ON notifications(user_id);
CREATE INDEX idx_notifications_created_at ON notifications(created_at);
CREATE INDEX idx_notifications_expires_at ON notifications(expires_at);
CREATE INDEX idx_notifications_priority ON notifications(priority);

-- Enable Row Level Security
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

-- Create policy for notifications (users can see their own notifications and system notifications)
CREATE POLICY "Users can view their own and system notifications" ON notifications
    FOR SELECT USING (
        user_id = auth.uid() OR 
        user_id IS NULL OR 
        is_system = true
    );

-- Create policy for inserting notifications (authenticated users can create notifications)
CREATE POLICY "Authenticated users can create notifications" ON notifications
    FOR INSERT WITH CHECK (auth.role() = 'authenticated');

-- Create policy for updating notifications (users can update their own notifications)
CREATE POLICY "Users can update their own notifications" ON notifications
    FOR UPDATE USING (
        user_id = auth.uid() OR 
        user_id IS NULL
    );

-- Create constraint for notification types
ALTER TABLE notifications ADD CONSTRAINT check_notification_type 
    CHECK (type IN ('info', 'success', 'warning', 'error', 'debug'));

-- Create constraint for priority range
ALTER TABLE notifications ADD CONSTRAINT check_notification_priority 
    CHECK (priority >= 1 AND priority <= 10);

-- Function to automatically set read_at when is_read is set to true
CREATE OR REPLACE FUNCTION set_notification_read_at()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.is_read = true AND OLD.is_read = false THEN
        NEW.read_at = NOW();
    ELSIF NEW.is_read = false THEN
        NEW.read_at = NULL;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for read_at timestamp
CREATE TRIGGER trigger_notification_read_at
    BEFORE UPDATE ON notifications
    FOR EACH ROW
    EXECUTE FUNCTION set_notification_read_at();