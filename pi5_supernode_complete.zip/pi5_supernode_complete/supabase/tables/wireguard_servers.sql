CREATE TABLE wireguard_servers (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    server_name VARCHAR(255) NOT NULL,
    public_key TEXT NOT NULL,
    private_key TEXT NOT NULL,
    listen_port INTEGER NOT NULL,
    endpoint VARCHAR(255),
    network CIDR NOT NULL,
    status VARCHAR(20) DEFAULT 'stopped',
    client_count INTEGER DEFAULT 0,
    max_clients INTEGER DEFAULT 100,
    created_by UUID,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);