CREATE TABLE network_speed_tests (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    connection_type VARCHAR(50) NOT NULL,
    connection_name VARCHAR(100) NOT NULL,
    download_speed_mbps DECIMAL(10,2),
    upload_speed_mbps DECIMAL(10,2),
    ping_ms DECIMAL(8,2),
    jitter_ms DECIMAL(8,2),
    packet_loss_percentage DECIMAL(5,2) DEFAULT 0,
    server_location VARCHAR(100),
    test_status VARCHAR(20) DEFAULT 'completed',
    error_message TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);