CREATE TABLE system_snapshots (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    snapshot_name VARCHAR(255) NOT NULL,
    description TEXT,
    backup_type VARCHAR(50) DEFAULT 'full',
    file_path TEXT,
    file_size BIGINT,
    checksum VARCHAR(64),
    backup_data JSONB,
    status VARCHAR(20) DEFAULT 'completed',
    created_by UUID,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);