CREATE TABLE speed_test_history (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    connection_type VARCHAR(50) NOT NULL,
    connection_name VARCHAR(100) NOT NULL,
    avg_download_mbps DECIMAL(10,2),
    avg_upload_mbps DECIMAL(10,2),
    avg_ping_ms DECIMAL(8,2),
    max_download_mbps DECIMAL(10,2),
    max_upload_mbps DECIMAL(10,2),
    min_ping_ms DECIMAL(8,2),
    test_count INTEGER DEFAULT 0,
    date_recorded DATE DEFAULT CURRENT_DATE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);