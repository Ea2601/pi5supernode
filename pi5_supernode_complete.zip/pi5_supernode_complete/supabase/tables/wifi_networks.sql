CREATE TABLE wifi_networks (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    ssid VARCHAR(255) NOT NULL,
    password_hash TEXT,
    security_type VARCHAR(20) DEFAULT 'WPA2',
    band VARCHAR(10) DEFAULT '2.4GHz',
    channel INTEGER,
    is_hidden BOOLEAN DEFAULT false,
    max_clients INTEGER DEFAULT 50,
    is_enabled BOOLEAN DEFAULT true,
    bandwidth_limit INTEGER,
    client_isolation BOOLEAN DEFAULT false,
    created_by UUID,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);