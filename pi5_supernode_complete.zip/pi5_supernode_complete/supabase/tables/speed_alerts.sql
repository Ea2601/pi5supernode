CREATE TABLE speed_alerts (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    connection_type VARCHAR(50) NOT NULL,
    connection_name VARCHAR(100) NOT NULL,
    alert_type VARCHAR(50) NOT NULL,
    threshold_value DECIMAL(10,2),
    current_value DECIMAL(10,2),
    alert_message TEXT,
    is_active BOOLEAN DEFAULT true,
    resolved_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);