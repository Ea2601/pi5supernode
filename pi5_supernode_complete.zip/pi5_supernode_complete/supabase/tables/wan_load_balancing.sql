CREATE TABLE wan_load_balancing (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    rule_name VARCHAR(100) NOT NULL,
    description TEXT,
    load_balancing_method VARCHAR(50) NOT NULL,
    failover_enabled BOOLEAN DEFAULT true,
    failover_threshold_seconds INTEGER DEFAULT 60,
    connection_weights JSONB,
    traffic_rules JSONB,
    is_enabled BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);