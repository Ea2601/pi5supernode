CREATE TABLE wireguard_clients (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    server_id UUID NOT NULL,
    client_name VARCHAR(255) NOT NULL,
    public_key TEXT NOT NULL,
    private_key TEXT NOT NULL,
    assigned_ip INET NOT NULL,
    allowed_ips TEXT[] DEFAULT '{}',
    preshared_key TEXT,
    is_active BOOLEAN DEFAULT true,
    last_handshake TIMESTAMP WITH TIME ZONE,
    bytes_received BIGINT DEFAULT 0,
    bytes_sent BIGINT DEFAULT 0,
    config_downloaded_at TIMESTAMP WITH TIME ZONE,
    created_by UUID,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);