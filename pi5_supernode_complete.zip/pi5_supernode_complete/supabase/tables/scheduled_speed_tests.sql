CREATE TABLE scheduled_speed_tests (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    connection_type VARCHAR(50) NOT NULL,
    connection_name VARCHAR(100) NOT NULL,
    test_frequency_minutes INTEGER DEFAULT 60,
    is_enabled BOOLEAN DEFAULT true,
    last_test_at TIMESTAMP WITH TIME ZONE,
    next_test_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);