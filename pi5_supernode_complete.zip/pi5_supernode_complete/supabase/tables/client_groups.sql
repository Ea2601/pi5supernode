CREATE TABLE client_groups (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    group_type VARCHAR(50),
    bandwidth_limit INTEGER,
    access_level VARCHAR(20) DEFAULT 'normal',
    allowed_protocols TEXT[],
    blocked_domains TEXT[],
    schedule JSONB,
    created_by UUID,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);