CREATE TABLE connection_quality_thresholds (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    connection_type VARCHAR(50) NOT NULL,
    quality_level VARCHAR(20) NOT NULL,
    min_download_mbps DECIMAL(10,2),
    max_download_mbps DECIMAL(10,2),
    min_upload_mbps DECIMAL(10,2),
    max_upload_mbps DECIMAL(10,2),
    max_ping_ms DECIMAL(8,2),
    max_packet_loss_percentage DECIMAL(5,2),
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);