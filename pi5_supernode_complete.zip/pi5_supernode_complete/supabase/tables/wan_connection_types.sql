CREATE TABLE wan_connection_types (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    type_name VARCHAR(50) NOT NULL UNIQUE,
    display_name VARCHAR(100) NOT NULL,
    description TEXT,
    requires_authentication BOOLEAN DEFAULT false,
    supports_cellular BOOLEAN DEFAULT false,
    supports_static_ip BOOLEAN DEFAULT true,
    supports_dhcp BOOLEAN DEFAULT true,
    default_mtu INTEGER DEFAULT 1500,
    configuration_template JSONB,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);