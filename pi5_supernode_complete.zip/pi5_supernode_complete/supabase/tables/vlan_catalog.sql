CREATE TABLE vlan_catalog (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    vlan_id INTEGER UNIQUE NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    subnet CIDR,
    gateway INET,
    dns_servers INET[],
    is_enabled BOOLEAN DEFAULT true,
    isolation_level VARCHAR(20) DEFAULT 'normal',
    created_by UUID,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);