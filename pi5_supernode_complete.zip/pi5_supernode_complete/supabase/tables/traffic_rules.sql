CREATE TABLE traffic_rules (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    rule_type VARCHAR(50) NOT NULL,
    source_group_id UUID,
    destination_group_id UUID,
    protocol VARCHAR(10),
    port_range VARCHAR(20),
    action VARCHAR(20) NOT NULL,
    priority INTEGER DEFAULT 100,
    is_enabled BOOLEAN DEFAULT true,
    schedule JSONB,
    created_by UUID,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);