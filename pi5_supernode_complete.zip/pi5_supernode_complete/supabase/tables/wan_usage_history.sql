CREATE TABLE wan_usage_history (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    connection_id UUID NOT NULL,
    date_recorded DATE DEFAULT CURRENT_DATE,
    total_upload_mb DECIMAL(15,2) DEFAULT 0,
    total_download_mb DECIMAL(15,2) DEFAULT 0,
    total_bytes BIGINT DEFAULT 0,
    average_latency_ms DECIMAL(8,2),
    max_latency_ms DECIMAL(8,2),
    min_latency_ms DECIMAL(8,2),
    uptime_percentage DECIMAL(5,2) DEFAULT 0,
    disconnection_count INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);