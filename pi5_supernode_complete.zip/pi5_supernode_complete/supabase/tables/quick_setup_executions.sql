-- Quick Setup Executions Table
-- Tracks quick setup wizard executions
CREATE TABLE quick_setup_executions (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    setup_name VARCHAR(255) NOT NULL,
    setup_configuration JSONB NOT NULL DEFAULT '{}'::jsonb,
    current_step INTEGER DEFAULT 0,
    total_steps INTEGER DEFAULT 0,
    status VARCHAR(50) NOT NULL DEFAULT 'pending',
    started_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    completed_at TIMESTAMP WITH TIME ZONE,
    estimated_duration INTEGER, -- in seconds
    actual_duration INTEGER, -- in seconds
    step_history JSONB DEFAULT '[]'::jsonb,
    error_details JSONB,
    success_message TEXT,
    requires_reboot BOOLEAN DEFAULT false,
    executed_by UUID,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for efficient queries
CREATE INDEX idx_quick_setup_executions_status ON quick_setup_executions(status);
CREATE INDEX idx_quick_setup_executions_started_at ON quick_setup_executions(started_at);
CREATE INDEX idx_quick_setup_executions_setup_name ON quick_setup_executions(setup_name);

-- Enable Row Level Security
ALTER TABLE quick_setup_executions ENABLE ROW LEVEL SECURITY;

-- Create policy for quick setup executions (allow all operations for authenticated users)
CREATE POLICY "Allow full access to quick_setup_executions for authenticated users" ON quick_setup_executions
    FOR ALL USING (auth.role() = 'authenticated');

-- Create constraint for status values
ALTER TABLE quick_setup_executions ADD CONSTRAINT check_quick_setup_status 
    CHECK (status IN ('pending', 'running', 'completed', 'failed', 'cancelled', 'requires_input'));

-- Function to automatically calculate actual duration
CREATE OR REPLACE FUNCTION calculate_quick_setup_duration()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.status = 'completed' AND NEW.completed_at IS NOT NULL AND OLD.status != 'completed' THEN
        NEW.actual_duration = EXTRACT(EPOCH FROM (NEW.completed_at - NEW.started_at))::INTEGER;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for duration calculation
CREATE TRIGGER trigger_quick_setup_duration
    BEFORE UPDATE ON quick_setup_executions
    FOR EACH ROW
    EXECUTE FUNCTION calculate_quick_setup_duration();