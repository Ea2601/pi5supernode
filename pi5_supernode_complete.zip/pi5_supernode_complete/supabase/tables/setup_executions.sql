-- Setup Executions Table
-- Tracks execution of system setup processes
CREATE TABLE setup_executions (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    setup_type VARCHAR(100) NOT NULL,
    configuration_applied JSONB NOT NULL,
    setup_steps JSONB NOT NULL DEFAULT '[]'::jsonb,
    status VARCHAR(50) NOT NULL DEFAULT 'pending',
    started_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    completed_at TIMESTAMP WITH TIME ZONE,
    total_duration INTEGER, -- in milliseconds
    error_message TEXT,
    executed_by UUID,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for efficient queries
CREATE INDEX idx_setup_executions_type ON setup_executions(setup_type);
CREATE INDEX idx_setup_executions_status ON setup_executions(status);
CREATE INDEX idx_setup_executions_started_at ON setup_executions(started_at);

-- Enable Row Level Security
ALTER TABLE setup_executions ENABLE ROW LEVEL SECURITY;

-- Create policy for setup executions (allow all operations for authenticated users)
CREATE POLICY "Allow full access to setup_executions for authenticated users" ON setup_executions
    FOR ALL USING (auth.role() = 'authenticated');

-- Create constraint for status values
ALTER TABLE setup_executions ADD CONSTRAINT check_setup_status 
    CHECK (status IN ('pending', 'running', 'completed', 'failed', 'cancelled'));