-- Migration: create_comprehensive_pi5_system
-- Created at: 1757159883

-- Create comprehensive Pi5 Supernode system tables

-- User Groups for Traffic Management
CREATE TABLE IF NOT EXISTS user_groups (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    group_name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    color_code VARCHAR(7) DEFAULT '#3B82F6',
    priority INTEGER DEFAULT 100,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Group Members (Users assigned to groups)
CREATE TABLE IF NOT EXISTS group_members (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    group_id UUID NOT NULL,
    device_mac_address VARCHAR(17) NOT NULL,
    device_ip VARCHAR(15),
    device_name VARCHAR(100),
    joined_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    is_active BOOLEAN DEFAULT true,
    UNIQUE(group_id, device_mac_address)
);

-- Traffic Types for Classification
CREATE TABLE IF NOT EXISTS traffic_types (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    type_name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    protocol VARCHAR(20),
    port_ranges TEXT[], -- Array of port ranges like ["80", "443", "8000-9000"]
    dpi_patterns TEXT[], -- Deep packet inspection patterns
    category VARCHAR(50) DEFAULT 'general', -- web, streaming, gaming, email, etc.
    bandwidth_priority INTEGER DEFAULT 5, -- 1-10 scale
    is_system_defined BOOLEAN DEFAULT false,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Network Paths (routing paths through the network)
CREATE TABLE IF NOT EXISTS network_paths (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    path_name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    gateway_ip VARCHAR(15) NOT NULL,
    interface_name VARCHAR(50) NOT NULL,
    path_type VARCHAR(50) DEFAULT 'standard', -- standard, failover, load_balance, priority
    bandwidth_limit_mbps INTEGER,
    latency_ms INTEGER,
    reliability_score INTEGER DEFAULT 100, -- 0-100
    cost_factor INTEGER DEFAULT 1, -- 1-10 for routing decisions
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tunnel Definitions (VPN tunnels, proxies, etc.)
CREATE TABLE IF NOT EXISTS tunnels (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    tunnel_name VARCHAR(100) NOT NULL UNIQUE,
    tunnel_type VARCHAR(50) NOT NULL, -- wireguard, openvpn, proxy, direct
    description TEXT,
    endpoint_host VARCHAR(255) NOT NULL,
    endpoint_port INTEGER NOT NULL,
    configuration JSONB DEFAULT '{}', -- Store tunnel-specific config
    status VARCHAR(20) DEFAULT 'inactive', -- active, inactive, error, connecting
    bandwidth_limit_mbps INTEGER,
    concurrent_connections_limit INTEGER DEFAULT 100,
    location_country VARCHAR(2), -- Country code
    location_city VARCHAR(100),
    ping_ms INTEGER,
    uptime_percentage DECIMAL(5,2) DEFAULT 100.00,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Advanced Traffic Rules (redesigned system)
DROP TABLE IF EXISTS traffic_rules CASCADE;
CREATE TABLE traffic_rules (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    rule_name VARCHAR(255) NOT NULL,
    description TEXT,
    
    -- Rule Components
    user_group_id UUID, -- Which user group
    traffic_type_id UUID, -- Which traffic type
    network_path_id UUID, -- Which network path
    tunnel_id UUID, -- Which tunnel (can be null for direct routing)
    
    -- Conditions
    time_conditions JSONB DEFAULT '{}', -- Schedule when rule applies
    bandwidth_conditions JSONB DEFAULT '{}', -- Bandwidth-based conditions
    location_conditions JSONB DEFAULT '{}', -- Geographic conditions
    device_conditions JSONB DEFAULT '{}', -- Device-specific conditions
    
    -- Actions
    action VARCHAR(50) NOT NULL DEFAULT 'route', -- route, block, limit, redirect
    bandwidth_limit_kbps INTEGER,
    priority INTEGER DEFAULT 100, -- Lower numbers = higher priority
    
    -- Monitoring and Stats
    packets_matched BIGINT DEFAULT 0,
    bytes_matched BIGINT DEFAULT 0,
    last_matched_at TIMESTAMP WITH TIME ZONE,
    
    -- Status
    is_enabled BOOLEAN DEFAULT true,
    is_testing BOOLEAN DEFAULT false, -- For rule testing mode
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- System Notifications
CREATE TABLE IF NOT EXISTS notifications (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    notification_type VARCHAR(50) NOT NULL, -- system, alert, info, warning, error
    severity VARCHAR(20) NOT NULL DEFAULT 'info', -- critical, high, medium, low, info
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    details JSONB DEFAULT '{}',
    
    -- Targeting
    target_users TEXT[], -- Array of user IDs or 'all' for broadcast
    target_roles TEXT[], -- Array of roles: admin, operator, user
    
    -- Delivery
    channels VARCHAR(50)[] DEFAULT '{web}', -- web, email, telegram, webhook
    is_persistent BOOLEAN DEFAULT true, -- Should persist in notification center
    expires_at TIMESTAMP WITH TIME ZONE,
    
    -- Actions
    action_buttons JSONB DEFAULT '[]', -- Array of action button definitions
    action_url VARCHAR(500), -- Optional action URL
    
    -- Status
    is_read BOOLEAN DEFAULT false,
    read_at TIMESTAMP WITH TIME ZONE,
    is_acknowledged BOOLEAN DEFAULT false,
    acknowledged_at TIMESTAMP WITH TIME ZONE,
    acknowledged_by VARCHAR(100),
    
    -- Metadata
    source_system VARCHAR(50) DEFAULT 'pi5_supernode',
    event_id VARCHAR(100), -- Reference to triggering event
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Quick Setup Configurations
CREATE TABLE IF NOT EXISTS quick_setup_profiles (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    profile_name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    category VARCHAR(50) NOT NULL, -- network, vpn, security, performance
    icon VARCHAR(50) DEFAULT 'settings',
    
    -- Configuration Steps
    setup_steps JSONB NOT NULL DEFAULT '[]', -- Array of setup step definitions
    estimated_time_minutes INTEGER DEFAULT 10,
    difficulty_level VARCHAR(20) DEFAULT 'easy', -- easy, medium, advanced
    
    -- Prerequisites and Requirements
    prerequisites JSONB DEFAULT '[]', -- Array of prerequisite checks
    required_permissions TEXT[] DEFAULT '{}',
    
    -- Automation
    can_auto_configure BOOLEAN DEFAULT false,
    auto_config_script TEXT, -- Shell script for automated setup
    
    -- Status and Usage
    usage_count INTEGER DEFAULT 0,
    success_rate DECIMAL(5,2) DEFAULT 100.00,
    average_completion_time_minutes INTEGER,
    
    -- Visibility
    is_featured BOOLEAN DEFAULT false,
    is_active BOOLEAN DEFAULT true,
    display_order INTEGER DEFAULT 100,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Quick Setup Executions (track setup attempts)
CREATE TABLE IF NOT EXISTS quick_setup_executions (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    profile_id UUID NOT NULL,
    session_id VARCHAR(100) NOT NULL, -- Frontend session identifier
    
    -- Execution Details
    status VARCHAR(20) NOT NULL DEFAULT 'started', -- started, in_progress, completed, failed, cancelled
    current_step INTEGER DEFAULT 1,
    total_steps INTEGER NOT NULL,
    progress_percentage INTEGER DEFAULT 0,
    
    -- Results
    configuration_applied JSONB DEFAULT '{}', -- The actual configuration that was applied
    error_messages TEXT[],
    warnings TEXT[],
    
    -- Timing
    started_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    completed_at TIMESTAMP WITH TIME ZONE,
    duration_seconds INTEGER,
    
    -- User Context
    user_agent VARCHAR(500),
    client_ip INET
);

-- Real-time System Status
CREATE TABLE IF NOT EXISTS system_status (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    component VARCHAR(50) NOT NULL, -- network, vpn, firewall, dns, etc.
    status VARCHAR(20) NOT NULL, -- healthy, warning, critical, unknown
    last_check_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    response_time_ms INTEGER,
    error_message TEXT,
    metrics JSONB DEFAULT '{}',
    uptime_percentage DECIMAL(5,2) DEFAULT 100.00,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(component)
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_traffic_rules_user_group ON traffic_rules(user_group_id);
CREATE INDEX IF NOT EXISTS idx_traffic_rules_traffic_type ON traffic_rules(traffic_type_id);
CREATE INDEX IF NOT EXISTS idx_traffic_rules_enabled ON traffic_rules(is_enabled);
CREATE INDEX IF NOT EXISTS idx_traffic_rules_priority ON traffic_rules(priority);

CREATE INDEX IF NOT EXISTS idx_notifications_type ON notifications(notification_type);
CREATE INDEX IF NOT EXISTS idx_notifications_severity ON notifications(severity);
CREATE INDEX IF NOT EXISTS idx_notifications_created_at ON notifications(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_notifications_unread ON notifications(is_read) WHERE is_read = false;

CREATE INDEX IF NOT EXISTS idx_group_members_group ON group_members(group_id);
CREATE INDEX IF NOT EXISTS idx_group_members_device ON group_members(device_mac_address);

CREATE INDEX IF NOT EXISTS idx_tunnels_status ON tunnels(status);
CREATE INDEX IF NOT EXISTS idx_tunnels_type ON tunnels(tunnel_type);

-- RLS Policies
ALTER TABLE user_groups ENABLE ROW LEVEL SECURITY;
ALTER TABLE group_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE traffic_types ENABLE ROW LEVEL SECURITY;
ALTER TABLE network_paths ENABLE ROW LEVEL SECURITY;
ALTER TABLE tunnels ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE quick_setup_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE quick_setup_executions ENABLE ROW LEVEL SECURITY;
ALTER TABLE system_status ENABLE ROW LEVEL SECURITY;

-- Allow authenticated users to access all tables
CREATE POLICY "Allow authenticated access to user_groups" ON user_groups FOR ALL USING (true);
CREATE POLICY "Allow authenticated access to group_members" ON group_members FOR ALL USING (true);
CREATE POLICY "Allow authenticated access to traffic_types" ON traffic_types FOR ALL USING (true);
CREATE POLICY "Allow authenticated access to network_paths" ON network_paths FOR ALL USING (true);
CREATE POLICY "Allow authenticated access to tunnels" ON tunnels FOR ALL USING (true);
CREATE POLICY "Allow authenticated access to notifications" ON notifications FOR ALL USING (true);
CREATE POLICY "Allow authenticated access to quick_setup_profiles" ON quick_setup_profiles FOR ALL USING (true);
CREATE POLICY "Allow authenticated access to quick_setup_executions" ON quick_setup_executions FOR ALL USING (true);
CREATE POLICY "Allow authenticated access to system_status" ON system_status FOR ALL USING (true);;