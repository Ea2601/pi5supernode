-- Comprehensive QoS and Traffic Management Module
-- Handles traffic shaping, bandwidth management, and quality of service

-- QoS Global Configuration
CREATE TABLE IF NOT EXISTS qos_global_config (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    is_enabled BOOLEAN DEFAULT false,
    default_class_id UUID,
    
    -- ECN (Explicit Congestion Notification)
    ecn_enabled BOOLEAN DEFAULT false,
    
    -- Overhead Calculation
    overhead_calculation_enabled BOOLEAN DEFAULT true,
    ethernet_overhead INTEGER DEFAULT 14,
    ip_overhead INTEGER DEFAULT 20,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- QoS Interface Configuration
CREATE TABLE IF NOT EXISTS qos_interfaces (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    interface_id UUID NOT NULL UNIQUE,
    is_enabled BOOLEAN DEFAULT false,
    
    -- Root Qdisc Configuration
    root_qdisc_type VARCHAR(30), -- htb, fq_codel, cake, pie, sfq
    root_qdisc_handle VARCHAR(20) DEFAULT '1:',
    root_qdisc_config JSONB DEFAULT '{}',
    
    -- Interface Limits
    uplink_bandwidth_kbps INTEGER,
    downlink_bandwidth_kbps INTEGER,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Traffic Classes
CREATE TABLE IF NOT EXISTS traffic_classes (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    interface_id UUID NOT NULL,
    class_name VARCHAR(100) NOT NULL,
    class_handle VARCHAR(20) NOT NULL,
    parent_class_id UUID, -- For hierarchical classes
    
    -- Class Type and Algorithm
    qdisc_type VARCHAR(30) NOT NULL, -- htb, fq_codel, cake, pie, sfq
    
    -- HTB Configuration
    htb_rate_kbps INTEGER, -- Guaranteed bandwidth
    htb_ceil_kbps INTEGER, -- Maximum bandwidth
    htb_burst_bytes INTEGER,
    htb_cburst_bytes INTEGER,
    htb_priority INTEGER DEFAULT 5,
    htb_quantum INTEGER,
    
    -- FQ_CoDel Configuration
    fq_codel_target_ms INTEGER DEFAULT 5,
    fq_codel_interval_ms INTEGER DEFAULT 100,
    fq_codel_quantum_bytes INTEGER DEFAULT 1514,
    fq_codel_limit_packets INTEGER DEFAULT 10240,
    fq_codel_flows INTEGER DEFAULT 1024,
    fq_codel_ecn_enabled BOOLEAN DEFAULT false,
    
    -- CAKE Configuration
    cake_bandwidth_kbps INTEGER,
    cake_rtt_ms INTEGER DEFAULT 100,
    cake_diffserv_mode VARCHAR(20) DEFAULT 'diffserv3', -- diffserv3, diffserv4, diffserv8
    cake_flowblind BOOLEAN DEFAULT false,
    cake_nat_enabled BOOLEAN DEFAULT false,
    cake_wash_enabled BOOLEAN DEFAULT false,
    cake_ack_filter VARCHAR(20) DEFAULT 'none', -- none, conservative, aggressive
    
    -- PIE Configuration
    pie_target_ms INTEGER DEFAULT 15,
    pie_limit_packets INTEGER DEFAULT 1000,
    pie_alpha DECIMAL(4,3) DEFAULT 0.125,
    pie_beta DECIMAL(4,3) DEFAULT 1.25,
    pie_ecn_enabled BOOLEAN DEFAULT false,
    
    -- SFQ Configuration
    sfq_quantum_bytes INTEGER DEFAULT 1514,
    sfq_perturb_seconds INTEGER DEFAULT 10,
    sfq_limit_packets INTEGER DEFAULT 127,
    sfq_divisor INTEGER DEFAULT 1024,
    sfq_flows INTEGER DEFAULT 127,
    
    -- Class Statistics
    packets_sent BIGINT DEFAULT 0,
    bytes_sent BIGINT DEFAULT 0,
    packets_dropped BIGINT DEFAULT 0,
    bytes_dropped BIGINT DEFAULT 0,
    overlimits BIGINT DEFAULT 0,
    requeues BIGINT DEFAULT 0,
    
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    UNIQUE(interface_id, class_handle)
);

-- Traffic Filters
CREATE TABLE IF NOT EXISTS traffic_filters (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    interface_id UUID NOT NULL,
    class_id UUID NOT NULL,
    filter_name VARCHAR(100),
    priority INTEGER NOT NULL DEFAULT 100,
    
    -- Filter Protocol
    protocol VARCHAR(20), -- ip, ipv6, arp, all
    
    -- Basic Matching
    source_ip CIDR,
    source_port_range VARCHAR(50),
    destination_ip CIDR,
    destination_port_range VARCHAR(50),
    
    -- Advanced Matching
    dscp_value INTEGER,
    tos_value INTEGER,
    packet_mark INTEGER,
    packet_length_range VARCHAR(20),
    mac_address VARCHAR(17),
    
    -- L7 Protocol Matching
    l7_protocol VARCHAR(50),
    l7_pattern TEXT,
    
    -- Actions
    action_type VARCHAR(30) DEFAULT 'classify', -- classify, police, drop, mark
    
    -- Classification Action
    target_class_id UUID,
    
    -- Policing Action
    police_rate_kbps INTEGER,
    police_burst_bytes INTEGER,
    police_action VARCHAR(20), -- drop, reclassify
    police_reclassify_class_id UUID,
    
    -- Marking Action
    mark_value INTEGER,
    dscp_mark_value INTEGER,
    
    -- Filter Statistics
    packets_matched BIGINT DEFAULT 0,
    bytes_matched BIGINT DEFAULT 0,
    
    is_enabled BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Layer 7 Protocol Definitions
CREATE TABLE IF NOT EXISTS l7_protocols (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    protocol_name VARCHAR(50) NOT NULL UNIQUE,
    description TEXT,
    category VARCHAR(50), -- web, streaming, gaming, voip, email, file_transfer, etc.
    
    -- Detection Patterns
    regex_patterns TEXT[],
    port_hints INTEGER[],
    
    -- Default QoS Settings
    default_priority INTEGER DEFAULT 5,
    default_dscp INTEGER,
    recommended_bandwidth_kbps INTEGER,
    
    -- Protocol Properties
    is_realtime BOOLEAN DEFAULT false,
    is_interactive BOOLEAN DEFAULT false,
    is_bulk_transfer BOOLEAN DEFAULT false,
    
    is_system_defined BOOLEAN DEFAULT false,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Traffic Shaping Profiles
CREATE TABLE IF NOT EXISTS traffic_shaping_profiles (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    profile_name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    profile_type VARCHAR(30) DEFAULT 'custom', -- gaming, video_streaming, business, custom
    
    -- Bandwidth Allocation
    total_bandwidth_kbps INTEGER NOT NULL,
    
    -- Class Definitions
    high_priority_percent INTEGER DEFAULT 20,
    medium_priority_percent INTEGER DEFAULT 50,
    low_priority_percent INTEGER DEFAULT 30,
    
    -- Latency Targets
    realtime_latency_target_ms INTEGER DEFAULT 10,
    interactive_latency_target_ms INTEGER DEFAULT 50,
    bulk_latency_target_ms INTEGER DEFAULT 200,
    
    -- Advanced Settings
    burst_allowance_percent INTEGER DEFAULT 150,
    queue_discipline VARCHAR(30) DEFAULT 'fq_codel',
    
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Bandwidth Monitoring
CREATE TABLE IF NOT EXISTS bandwidth_monitoring (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    interface_id UUID NOT NULL,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Overall Interface Statistics
    total_rx_bytes BIGINT,
    total_tx_bytes BIGINT,
    total_rx_packets BIGINT,
    total_tx_packets BIGINT,
    
    -- Rate Measurements
    rx_rate_kbps INTEGER,
    tx_rate_kbps INTEGER,
    rx_pps INTEGER, -- packets per second
    tx_pps INTEGER,
    
    -- Utilization
    rx_utilization_percent DECIMAL(5,2),
    tx_utilization_percent DECIMAL(5,2),
    
    -- Quality Metrics
    average_latency_ms DECIMAL(8,2),
    packet_loss_percent DECIMAL(5,2),
    jitter_ms DECIMAL(8,2),
    
    -- Top Protocols by Bandwidth
    top_protocols JSONB DEFAULT '{}',
    
    -- QoS Statistics
    qos_classes_stats JSONB DEFAULT '{}'
);

-- Per-Client Bandwidth Usage
CREATE TABLE IF NOT EXISTS client_bandwidth_usage (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    client_ip INET NOT NULL,
    client_mac VARCHAR(17),
    interface_id UUID NOT NULL,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Bandwidth Usage
    rx_bytes BIGINT DEFAULT 0,
    tx_bytes BIGINT DEFAULT 0,
    rx_packets BIGINT DEFAULT 0,
    tx_packets BIGINT DEFAULT 0,
    
    -- Rate Information
    rx_rate_kbps INTEGER DEFAULT 0,
    tx_rate_kbps INTEGER DEFAULT 0,
    
    -- Protocol Breakdown
    protocol_breakdown JSONB DEFAULT '{}',
    
    -- QoS Classification
    primary_traffic_class VARCHAR(50),
    dscp_distribution JSONB DEFAULT '{}',
    
    -- Connection Quality
    connection_quality_score INTEGER, -- 0-100
    packet_loss_percent DECIMAL(5,2) DEFAULT 0,
    average_rtt_ms DECIMAL(8,2)
);

-- QoS Performance Metrics
CREATE TABLE IF NOT EXISTS qos_performance_metrics (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    interface_id UUID NOT NULL,
    class_id UUID,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Throughput Metrics
    throughput_kbps DECIMAL(10,2),
    peak_throughput_kbps DECIMAL(10,2),
    
    -- Latency Metrics
    average_delay_ms DECIMAL(8,2),
    min_delay_ms DECIMAL(8,2),
    max_delay_ms DECIMAL(8,2),
    delay_variation_ms DECIMAL(8,2), -- jitter
    
    -- Queue Metrics
    queue_length_packets INTEGER,
    queue_length_bytes INTEGER,
    max_queue_length_packets INTEGER,
    
    -- Drop Statistics
    packets_dropped BIGINT,
    bytes_dropped BIGINT,
    drop_rate_percent DECIMAL(5,2),
    
    -- Congestion Indicators
    ecn_marked_packets BIGINT DEFAULT 0,
    congestion_events INTEGER DEFAULT 0,
    
    -- Fairness Metrics
    active_flows INTEGER,
    flow_fairness_index DECIMAL(4,3) -- 0-1, closer to 1 is more fair
);

-- Bandwidth Limits and Quotas
CREATE TABLE IF NOT EXISTS bandwidth_limits (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    limit_name VARCHAR(100) NOT NULL,
    description TEXT,
    
    -- Target Specification
    target_type VARCHAR(20) NOT NULL, -- client_ip, client_mac, user_group, interface
    target_value VARCHAR(255) NOT NULL,
    interface_id UUID,
    
    -- Bandwidth Limits
    download_limit_kbps INTEGER,
    upload_limit_kbps INTEGER,
    
    -- Time-based Limits
    daily_download_quota_mb INTEGER,
    daily_upload_quota_mb INTEGER,
    monthly_download_quota_gb INTEGER,
    monthly_upload_quota_gb INTEGER,
    
    -- Schedule
    is_scheduled BOOLEAN DEFAULT false,
    schedule_config JSONB DEFAULT '{}', -- time ranges, days of week
    
    -- Burst Allowance
    burst_download_kbps INTEGER,
    burst_upload_kbps INTEGER,
    burst_duration_seconds INTEGER DEFAULT 60,
    
    -- Actions on Quota Exceeded
    quota_exceed_action VARCHAR(30) DEFAULT 'throttle', -- throttle, block, notify
    throttle_download_kbps INTEGER,
    throttle_upload_kbps INTEGER,
    
    -- Current Usage Tracking
    current_daily_download_mb DECIMAL(10,2) DEFAULT 0,
    current_daily_upload_mb DECIMAL(10,2) DEFAULT 0,
    current_monthly_download_gb DECIMAL(10,2) DEFAULT 0,
    current_monthly_upload_gb DECIMAL(10,2) DEFAULT 0,
    
    -- Reset Counters
    last_daily_reset DATE DEFAULT CURRENT_DATE,
    last_monthly_reset DATE DEFAULT DATE_TRUNC('month', CURRENT_DATE),
    
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_qos_interfaces_interface_id ON qos_interfaces(interface_id);
CREATE INDEX IF NOT EXISTS idx_traffic_classes_interface_id ON traffic_classes(interface_id);
CREATE INDEX IF NOT EXISTS idx_traffic_classes_parent ON traffic_classes(parent_class_id);
CREATE INDEX IF NOT EXISTS idx_traffic_filters_interface_id ON traffic_filters(interface_id);
CREATE INDEX IF NOT EXISTS idx_traffic_filters_class_id ON traffic_filters(class_id);
CREATE INDEX IF NOT EXISTS idx_traffic_filters_priority ON traffic_filters(interface_id, priority);
CREATE INDEX IF NOT EXISTS idx_l7_protocols_name ON l7_protocols(protocol_name);
CREATE INDEX IF NOT EXISTS idx_l7_protocols_category ON l7_protocols(category);
CREATE INDEX IF NOT EXISTS idx_bandwidth_monitoring_interface_id ON bandwidth_monitoring(interface_id);
CREATE INDEX IF NOT EXISTS idx_bandwidth_monitoring_timestamp ON bandwidth_monitoring(timestamp);
CREATE INDEX IF NOT EXISTS idx_client_bandwidth_usage_client_ip ON client_bandwidth_usage(client_ip);
CREATE INDEX IF NOT EXISTS idx_client_bandwidth_usage_interface_id ON client_bandwidth_usage(interface_id);
CREATE INDEX IF NOT EXISTS idx_client_bandwidth_usage_timestamp ON client_bandwidth_usage(timestamp);
CREATE INDEX IF NOT EXISTS idx_qos_performance_metrics_interface_id ON qos_performance_metrics(interface_id);
CREATE INDEX IF NOT EXISTS idx_qos_performance_metrics_class_id ON qos_performance_metrics(class_id);
CREATE INDEX IF NOT EXISTS idx_qos_performance_metrics_timestamp ON qos_performance_metrics(timestamp);
CREATE INDEX IF NOT EXISTS idx_bandwidth_limits_target ON bandwidth_limits(target_type, target_value);
CREATE INDEX IF NOT EXISTS idx_bandwidth_limits_interface_id ON bandwidth_limits(interface_id);

-- Insert default L7 protocols
INSERT INTO l7_protocols (protocol_name, description, category, default_priority, is_realtime, is_interactive, is_system_defined) VALUES
('http', 'HTTP Web Traffic', 'web', 5, false, true, true),
('https', 'HTTPS Secure Web Traffic', 'web', 5, false, true, true),
('dns', 'Domain Name System', 'system', 1, false, true, true),
('ssh', 'Secure Shell', 'remote_access', 2, false, true, true),
('ftp', 'File Transfer Protocol', 'file_transfer', 7, false, false, true),
('smtp', 'Simple Mail Transfer Protocol', 'email', 6, false, false, true),
('pop3', 'Post Office Protocol v3', 'email', 6, false, false, true),
('imap', 'Internet Message Access Protocol', 'email', 6, false, false, true),
('sip', 'Session Initiation Protocol', 'voip', 1, true, true, true),
('rtp', 'Real-time Transport Protocol', 'voip', 1, true, true, true),
('bittorrent', 'BitTorrent P2P', 'file_transfer', 9, false, false, true),
('youtube', 'YouTube Video Streaming', 'streaming', 4, false, false, true),
('netflix', 'Netflix Video Streaming', 'streaming', 4, false, false, true),
('skype', 'Skype Voice/Video Calls', 'voip', 2, true, true, true),
('zoom', 'Zoom Video Conferencing', 'voip', 2, true, true, true),
('teams', 'Microsoft Teams', 'voip', 2, true, true, true),
('gaming', 'Online Gaming Traffic', 'gaming', 1, true, true, true),
('steam', 'Steam Gaming Platform', 'gaming', 3, false, false, true)
ON CONFLICT (protocol_name) DO NOTHING;

-- Create triggers for updated_at
CREATE TRIGGER update_qos_global_config_updated_at BEFORE UPDATE ON qos_global_config FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_qos_interfaces_updated_at BEFORE UPDATE ON qos_interfaces FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_traffic_classes_updated_at BEFORE UPDATE ON traffic_classes FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_traffic_filters_updated_at BEFORE UPDATE ON traffic_filters FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_l7_protocols_updated_at BEFORE UPDATE ON l7_protocols FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_traffic_shaping_profiles_updated_at BEFORE UPDATE ON traffic_shaping_profiles FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_bandwidth_limits_updated_at BEFORE UPDATE ON bandwidth_limits FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();