-- Migration: comprehensive_api_interface_management
-- Created at: 1758570762

-- Comprehensive Interface Management Module
-- Handles interface discovery, creation, configuration, and monitoring

-- Physical and Virtual Interface Registry
CREATE TABLE IF NOT EXISTS network_interfaces (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    interface_name VARCHAR(50) NOT NULL UNIQUE,
    interface_type VARCHAR(50) NOT NULL, -- physical, virtual, wireless, usb, pci, vlan, bridge, bond, tunnel, tap, tun
    interface_alias VARCHAR(100),
    description TEXT,
    uuid UUID DEFAULT gen_random_uuid() UNIQUE,
    
    -- Hardware Information
    vendor VARCHAR(100),
    model VARCHAR(100),
    serial_number VARCHAR(100),
    hardware_revision VARCHAR(50),
    firmware_version VARCHAR(50),
    driver_name VARCHAR(100),
    driver_version VARCHAR(50),
    bus_type VARCHAR(20), -- PCI, USB, etc
    bus_address VARCHAR(100),
    capabilities TEXT[],
    
    -- Physical Properties
    mac_address VARCHAR(17),
    permanent_mac VARCHAR(17),
    mtu_current INTEGER DEFAULT 1500,
    mtu_min INTEGER DEFAULT 68,
    mtu_max INTEGER DEFAULT 9000,
    
    -- State Information
    admin_state VARCHAR(20) DEFAULT 'down', -- up, down
    operational_state VARCHAR(20) DEFAULT 'down', -- up, down, unknown, dormant
    link_state VARCHAR(20) DEFAULT 'down', -- up, down, unknown
    last_state_change TIMESTAMP WITH TIME ZONE,
    uptime_seconds INTEGER DEFAULT 0,
    
    -- Speed and Duplex
    speed_current INTEGER, -- Mbps
    speeds_supported INTEGER[],
    duplex_current VARCHAR(20), -- full, half, unknown
    duplex_supported VARCHAR(50)[],
    autoneg_enabled BOOLEAN DEFAULT true,
    autoneg_advertised INTEGER[],
    autoneg_partner INTEGER[],
    
    -- Flow Control
    flowcontrol_rx BOOLEAN DEFAULT false,
    flowcontrol_tx BOOLEAN DEFAULT false,
    flowcontrol_autoneg BOOLEAN DEFAULT false,
    
    -- Advanced Features
    offload_features JSONB DEFAULT '{}',
    ring_buffer_settings JSONB DEFAULT '{}',
    interrupt_settings JSONB DEFAULT '{}',
    power_management JSONB DEFAULT '{}',
    
    -- VLAN Configuration
    vlan_enabled BOOLEAN DEFAULT false,
    vlan_trunk_enabled BOOLEAN DEFAULT false,
    vlan_trunk_allowed INTEGER[],
    vlan_native INTEGER,
    
    -- Timestamps
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    last_seen TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);;