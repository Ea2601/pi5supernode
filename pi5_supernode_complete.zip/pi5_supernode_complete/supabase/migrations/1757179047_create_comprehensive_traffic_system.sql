-- Migration: create_comprehensive_traffic_system
-- Created at: 1757179047

-- Enhanced Traffic Management System Tables

-- DHCP Pool Management
CREATE TABLE IF NOT EXISTS dhcp_pools (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    pool_name VARCHAR(100) NOT NULL UNIQUE,
    network_cidr VARCHAR(20) NOT NULL, -- e.g., "192.168.1.0/24"
    start_ip INET NOT NULL,
    end_ip INET NOT NULL,
    gateway_ip INET,
    dns_primary INET,
    dns_secondary INET,
    lease_time_hours INTEGER DEFAULT 24,
    vlan_id UUID,
    domain_name VARCHAR(255),
    ntp_servers TEXT[],
    static_routes JSONB DEFAULT '[]',
    dhcp_options JSONB DEFAULT '{}',
    is_enabled BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- DHCP Reservations (Static IP assignments)
CREATE TABLE IF NOT EXISTS dhcp_reservations (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    pool_id UUID NOT NULL,
    device_name VARCHAR(100) NOT NULL,
    mac_address VARCHAR(17) NOT NULL UNIQUE,
    reserved_ip INET NOT NULL,
    description TEXT,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- WiFi Networks Management
CREATE TABLE IF NOT EXISTS wifi_networks (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    ssid VARCHAR(32) NOT NULL,
    frequency_band VARCHAR(10) NOT NULL CHECK (frequency_band IN ('2.4GHz', '5GHz', 'dual')),
    security_type VARCHAR(20) NOT NULL DEFAULT 'wpa3' CHECK (security_type IN ('open', 'wep', 'wpa', 'wpa2', 'wpa3', 'wpa2-wpa3')),
    password VARCHAR(63),
    hidden BOOLEAN DEFAULT false,
    max_clients INTEGER DEFAULT 50,
    bandwidth_limit_mbps INTEGER,
    is_guest_network BOOLEAN DEFAULT false,
    guest_isolation BOOLEAN DEFAULT false,
    client_isolation BOOLEAN DEFAULT false,
    vlan_id UUID,
    access_schedule JSONB DEFAULT '{}', -- Time-based access control
    mac_filtering_enabled BOOLEAN DEFAULT false,
    allowed_mac_addresses TEXT[] DEFAULT '{}',
    blocked_mac_addresses TEXT[] DEFAULT '{}',
    channel_width INTEGER DEFAULT 80, -- MHz
    tx_power_dbm INTEGER DEFAULT 20,
    beacon_interval INTEGER DEFAULT 100,
    is_enabled BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- VLAN Management
CREATE TABLE IF NOT EXISTS vlans (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    vlan_id INTEGER NOT NULL UNIQUE CHECK (vlan_id BETWEEN 1 AND 4094),
    vlan_name VARCHAR(100) NOT NULL,
    description TEXT,
    network_cidr VARCHAR(20) NOT NULL, -- e.g., "192.168.10.0/24"
    gateway_ip INET,
    dns_servers INET[] DEFAULT '{}',
    dhcp_enabled BOOLEAN DEFAULT true,
    inter_vlan_routing BOOLEAN DEFAULT false,
    qos_priority INTEGER DEFAULT 0 CHECK (qos_priority BETWEEN 0 AND 7),
    bandwidth_limit_mbps INTEGER,
    port_assignments TEXT[] DEFAULT '{}', -- Physical ports assigned to this VLAN
    tagged_ports TEXT[] DEFAULT '{}',
    untagged_ports TEXT[] DEFAULT '{}',
    security_policies JSONB DEFAULT '{}',
    access_control_rules JSONB DEFAULT '[]',
    is_management_vlan BOOLEAN DEFAULT false,
    is_voice_vlan BOOLEAN DEFAULT false,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Multi-WAN Load Balancing Configuration
CREATE TABLE IF NOT EXISTS wan_load_balancing (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    config_name VARCHAR(100) NOT NULL DEFAULT 'Default Load Balancing',
    balancing_method VARCHAR(20) NOT NULL DEFAULT 'weighted_round_robin' 
        CHECK (balancing_method IN ('round_robin', 'weighted_round_robin', 'least_connections', 'failover', 'bandwidth_based')),
    health_check_enabled BOOLEAN DEFAULT true,
    health_check_interval_seconds INTEGER DEFAULT 30,
    health_check_timeout_seconds INTEGER DEFAULT 10,
    health_check_retries INTEGER DEFAULT 3,
    failover_enabled BOOLEAN DEFAULT true,
    failback_enabled BOOLEAN DEFAULT true,
    failback_delay_seconds INTEGER DEFAULT 60,
    traffic_distribution JSONB DEFAULT '{}', -- Connection weights and rules
    sticky_sessions BOOLEAN DEFAULT false,
    session_persistence_method VARCHAR(20) DEFAULT 'source_ip',
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- System Settings for comprehensive configuration
CREATE TABLE IF NOT EXISTS system_settings (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    setting_category VARCHAR(50) NOT NULL,
    setting_key VARCHAR(100) NOT NULL,
    setting_value JSONB NOT NULL,
    description TEXT,
    is_encrypted BOOLEAN DEFAULT false,
    requires_restart BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(setting_category, setting_key)
);

-- Backup Management
CREATE TABLE IF NOT EXISTS system_backups (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    backup_name VARCHAR(255) NOT NULL,
    backup_type VARCHAR(20) NOT NULL CHECK (backup_type IN ('manual', 'scheduled', 'automatic')),
    file_path VARCHAR(500),
    file_size_bytes BIGINT,
    backup_scope JSONB DEFAULT '{}', -- What was backed up
    status VARCHAR(20) NOT NULL DEFAULT 'created' CHECK (status IN ('created', 'uploading', 'completed', 'failed', 'deleted')),
    error_message TEXT,
    created_by VARCHAR(100),
    storage_location VARCHAR(100) DEFAULT 'local',
    retention_days INTEGER DEFAULT 30,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_dhcp_pools_enabled ON dhcp_pools(is_enabled);
CREATE INDEX IF NOT EXISTS idx_dhcp_reservations_mac ON dhcp_reservations(mac_address);
CREATE INDEX IF NOT EXISTS idx_wifi_networks_enabled ON wifi_networks(is_enabled);
CREATE INDEX IF NOT EXISTS idx_vlans_active ON vlans(is_active);
CREATE INDEX IF NOT EXISTS idx_vlans_id ON vlans(vlan_id);
CREATE INDEX IF NOT EXISTS idx_system_settings_category_key ON system_settings(setting_category, setting_key);;