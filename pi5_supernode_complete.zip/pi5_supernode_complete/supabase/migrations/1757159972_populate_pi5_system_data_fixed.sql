-- Migration: populate_pi5_system_data_fixed
-- Created at: 1757159972

-- Insert sample data for the Pi5 Supernode system (fixed)

-- User Groups
INSERT INTO user_groups (group_name, description, color_code, priority) VALUES
    ('Administrators', 'System administrators and power users', '#EF4444', 1),
    ('Family Members', 'Family devices with standard access', '#10B981', 50),
    ('Guests', 'Guest devices with limited access', '#F59E0B', 100),
    ('Gaming Devices', 'Gaming consoles and high-priority gaming traffic', '#8B5CF6', 20),
    ('IoT Devices', 'Smart home and IoT devices', '#06B6D4', 80),
    ('Work Devices', 'Work laptops and business traffic', '#3B82F6', 30);

-- Traffic Types
INSERT INTO traffic_types (type_name, description, protocol, port_ranges, category, bandwidth_priority) VALUES
    ('Web Browsing', 'HTTP/HTTPS web traffic', 'TCP', ARRAY['80', '443'], 'web', 5),
    ('Video Streaming', 'Netflix, YouTube, streaming services', 'TCP', ARRAY['80', '443', '1935', '8080'], 'streaming', 8),
    ('Gaming', 'Online gaming traffic', 'UDP', ARRAY['3478-3480', '27000-28000'], 'gaming', 9),
    ('Video Calls', 'Zoom, Teams, video conferencing', 'UDP', ARRAY['8801-8810', '3478-3481'], 'communication', 9),
    ('File Downloads', 'Large file downloads and P2P', 'TCP', ARRAY['6881-6999', '1337'], 'downloads', 2),
    ('Email', 'SMTP, IMAP, POP3 email traffic', 'TCP', ARRAY['25', '587', '993', '995'], 'email', 6),
    ('SSH/Remote Access', 'SSH, RDP, remote access protocols', 'TCP', ARRAY['22', '3389', '5900'], 'remote', 7),
    ('DNS', 'Domain name system queries', 'UDP', ARRAY['53'], 'system', 10),
    ('Social Media', 'Facebook, Twitter, Instagram apps', 'TCP', ARRAY['80', '443'], 'social', 4),
    ('Cloud Storage', 'Dropbox, Google Drive, OneDrive sync', 'TCP', ARRAY['80', '443'], 'cloud', 3);

-- Network Paths
INSERT INTO network_paths (path_name, description, gateway_ip, interface_name, path_type, bandwidth_limit_mbps, latency_ms, reliability_score) VALUES
    ('Primary ISP', 'Main internet connection via Fiber', '192.168.1.1', 'eth0', 'standard', 1000, 15, 98),
    ('Backup ISP', 'Secondary internet via Cable', '192.168.2.1', 'eth1', 'failover', 100, 25, 95),
    ('Local Network', 'Internal LAN routing', '192.168.0.1', 'br0', 'standard', 10000, 1, 100),
    ('Mobile Hotspot', 'Emergency mobile connection', '192.168.3.1', 'wwan0', 'emergency', 50, 80, 85),
    ('Starlink Backup', 'Satellite internet backup', '192.168.4.1', 'eth2', 'failover', 200, 40, 90);

-- Tunnels (fixed country codes to 2 characters)
INSERT INTO tunnels (tunnel_name, tunnel_type, description, endpoint_host, endpoint_port, status, bandwidth_limit_mbps, location_country, location_city, ping_ms, uptime_percentage) VALUES
    ('US East VPN', 'wireguard', 'WireGuard tunnel to US East Coast', 'us-east.vpn.example.com', 51820, 'active', 500, 'US', 'New York', 45, 99.8),
    ('EU Central VPN', 'wireguard', 'WireGuard tunnel to European servers', 'eu-central.vpn.example.com', 51820, 'active', 300, 'DE', 'Frankfurt', 85, 99.5),
    ('Asia Pacific VPN', 'wireguard', 'WireGuard tunnel to Asia Pacific', 'ap.vpn.example.com', 51820, 'inactive', 200, 'SG', 'Singapore', 180, 99.2),
    ('Gaming VPN', 'wireguard', 'Low-latency gaming optimized tunnel', 'gaming.vpn.example.com', 51820, 'active', 1000, 'US', 'Los Angeles', 25, 99.9),
    ('Privacy Proxy', 'proxy', 'HTTP/HTTPS privacy proxy', 'privacy.proxy.example.com', 8080, 'active', 100, 'CH', 'Zurich', 60, 99.0),
    ('Direct Connection', 'direct', 'Direct internet access (no tunnel)', 'direct', 0, 'active', 1000, '', 'Local', 0, 100.0);

-- System Status
INSERT INTO system_status (component, status, response_time_ms, uptime_percentage) VALUES
    ('network', 'healthy', 5, 99.9),
    ('vpn', 'healthy', 15, 99.5),
    ('firewall', 'healthy', 2, 100.0),
    ('dns', 'healthy', 8, 99.8),
    ('dhcp', 'healthy', 3, 100.0),
    ('monitoring', 'healthy', 12, 99.7);

-- Sample Notifications
INSERT INTO notifications (notification_type, severity, title, message, target_roles, channels) VALUES
    ('system', 'info', 'System Started Successfully', 'Pi5 Supernode system has started and all components are operational.', ARRAY['admin', 'operator'], ARRAY['web']),
    ('alert', 'warning', 'High Bandwidth Usage', 'Bandwidth usage has exceeded 80% of available capacity.', ARRAY['admin'], ARRAY['web']),
    ('system', 'info', 'VPN Server Ready', 'WireGuard VPN server is configured and ready for client connections.', ARRAY['admin'], ARRAY['web']);;