-- Migration: populate_system_data_with_correct_types
-- Created at: 1757179276

-- Populate WAN Connection Types
INSERT INTO wan_connection_types (type_name, display_name, description, configuration_template, is_active) VALUES
('static_ip', 'Static IP', 'Fixed IP address configuration with DNS settings', 
 '{"fields": ["ip_address", "subnet_mask", "gateway", "dns_primary", "dns_secondary", "mtu"]}', true),
('dhcp_client', 'DHCP Client', 'Automatic IP configuration with lease management', 
 '{"fields": ["hostname", "client_id", "vendor_class", "mtu"]}', true),
('pppoe', 'PPPoE', 'Point-to-Point Protocol over Ethernet with authentication', 
 '{"fields": ["username", "password", "service_name", "mtu", "lcp_echo_interval"]}', true),
('cellular_3g', '3G Cellular', 'Third generation cellular data connection', 
 '{"fields": ["apn", "username", "password", "pin", "dial_number"]}', true),
('cellular_4g', '4G/LTE', 'Fourth generation cellular data connection', 
 '{"fields": ["apn", "username", "password", "pin", "band_preference"]}', true),
('cellular_5g', '5G', 'Fifth generation cellular data connection', 
 '{"fields": ["apn", "username", "password", "pin", "band_preference", "slice_id"]}', true),
('satellite', 'Satellite Internet', 'Satellite internet connection (Starlink, Viasat, HughesNet)', 
 '{"fields": ["terminal_id", "beam_id", "elevation_angle", "azimuth_angle"]}', true),
('cable_docsis', 'Cable/DOCSIS', 'Cable modem DOCSIS configuration', 
 '{"fields": ["modem_model", "downstream_channels", "upstream_channels", "rf_levels"]}', true),
('dsl_adsl', 'DSL/ADSL', 'Digital Subscriber Line configuration with line testing', 
 '{"fields": ["username", "password", "vci", "vpi", "encapsulation", "line_profile"]}', true),
('dsl_vdsl', 'VDSL', 'Very-high-bit-rate Digital Subscriber Line', 
 '{"fields": ["username", "password", "vci", "vpi", "vectoring_enabled", "profile"]}', true),
('fiber_direct', 'Fiber Direct', 'Direct fiber optic connection configuration', 
 '{"fields": ["interface_type", "speed", "duplex", "flow_control", "jumbo_frames"]}', true)
ON CONFLICT (type_name) DO UPDATE SET
display_name = EXCLUDED.display_name,
description = EXCLUDED.description,
configuration_template = EXCLUDED.configuration_template;

-- Enhanced User Groups
INSERT INTO user_groups (group_name, description, color_code, priority) VALUES
('Local Network', 'All local network devices', '#3B82F6', 10),
('WireGuard Client 1', 'WireGuard VPN clients - Group 1', '#10B981', 20),
('WireGuard Client 2', 'WireGuard VPN clients - Group 2', '#F59E0B', 30),
('Family Members', 'Home family member devices', '#EF4444', 40),
('Guests', 'Guest network devices', '#8B5CF6', 50),
('IoT Devices', 'Internet of Things devices', '#06B6D4', 60),
('Work Devices', 'Work-related devices', '#84CC16', 70),
('Gaming Devices', 'Gaming consoles and devices', '#F97316', 80),
('Media Streaming', 'Smart TVs and streaming devices', '#EC4899', 90),
('Management', 'Network management devices', '#6B7280', 100)
ON CONFLICT (group_name) DO NOTHING;

-- Comprehensive Traffic Types
INSERT INTO traffic_types (type_name, description, protocol, port_ranges, category, bandwidth_priority, is_system_defined) VALUES
('Web Browsing', 'HTTP/HTTPS web traffic', 'tcp', ARRAY['80', '443', '8080', '8443'], 'web', 5, true),
('Video Streaming', 'Netflix, YouTube, streaming services', 'tcp', ARRAY['443', '80', '1935', '554'], 'streaming', 8, true),
('Video Conferencing', 'Zoom, Teams, WebRTC calls', 'udp', ARRAY['3478-3481', '8801-8810', '5060-5061'], 'communication', 9, true),
('VoIP Calls', 'Voice over IP telephone calls', 'udp', ARRAY['5060-5061', '10000-20000', '1719-1720'], 'communication', 10, true),
('Gaming Traffic', 'Online gaming protocols', 'udp', ARRAY['27015', '7777-7784', '3074', '53'], 'gaming', 9, true),
('P2P File Sharing', 'BitTorrent, peer-to-peer protocols', 'tcp', ARRAY['6881-6999', '51413'], 'p2p', 1, true),
('Email Services', 'SMTP, POP3, IMAP email', 'tcp', ARRAY['25', '110', '143', '993', '995', '587'], 'email', 6, true),
('DNS Queries', 'Domain name resolution', 'udp', ARRAY['53'], 'system', 10, true),
('Social Media', 'Facebook, Twitter, Instagram', 'tcp', ARRAY['443', '80'], 'social', 4, true),
('Cloud Backup', 'Automated cloud backup services', 'tcp', ARRAY['443', '80'], 'backup', 3, true),
('Remote Desktop', 'RDP, VNC, remote access', 'tcp', ARRAY['3389', '5900', '22'], 'remote', 7, true),
('File Transfer', 'FTP, SFTP, file uploads', 'tcp', ARRAY['21', '22', '989-990'], 'transfer', 5, true),
('System Updates', 'OS and software updates', 'tcp', ARRAY['443', '80'], 'system', 4, true),
('IoT Communication', 'Smart home device traffic', 'tcp', ARRAY['1883', '8883', '5683'], 'iot', 6, true),
('Live Streaming', 'Twitch, YouTube Live broadcast', 'tcp', ARRAY['1935', '443', '80'], 'streaming', 8, true),
('Music Streaming', 'Spotify, Apple Music streaming', 'tcp', ARRAY['443', '80', '4070'], 'streaming', 6, true)
ON CONFLICT (type_name) DO NOTHING;

-- Network Paths
INSERT INTO network_paths (path_name, description, gateway_ip, interface_name, path_type, bandwidth_limit_mbps, cost_factor) VALUES
('Primary ISP', 'Main internet service provider connection', '192.168.1.1', 'eth0', 'standard', 1000, 1),
('Secondary ISP', 'Backup internet connection', '192.168.2.1', 'eth1', 'failover', 500, 2),
('Local Network', 'Internal network routing', '192.168.0.1', 'br0', 'standard', NULL, 0),
('Guest Network', 'Isolated guest network path', '192.168.100.1', 'br1', 'standard', 100, 3),
('Management Network', 'Network management VLAN', '192.168.200.1', 'br2', 'priority', NULL, 1)
ON CONFLICT (path_name) DO NOTHING;

-- Enhanced Tunnels
INSERT INTO tunnels (tunnel_name, tunnel_type, description, endpoint_host, endpoint_port, status, location_country, location_city, bandwidth_limit_mbps, concurrent_connections_limit) VALUES
('Direct Connection', 'direct', 'No tunnel - direct routing', 'local', 0, 'active', NULL, NULL, NULL, NULL),
('WireGuard VPS 1', 'wireguard', 'Primary WireGuard VPN tunnel', 'vpn1.example.com', 51820, 'active', 'US', 'New York', 1000, 100),
('WireGuard VPS 2', 'wireguard', 'Secondary WireGuard VPN tunnel', 'vpn2.example.com', 51820, 'active', 'UK', 'London', 500, 50),
('OpenVPN Server', 'openvpn', 'OpenVPN tunnel for legacy clients', 'ovpn.example.com', 1194, 'inactive', 'DE', 'Frankfurt', 200, 25),
('SOCKS5 Proxy', 'proxy', 'SOCKS5 proxy tunnel', 'proxy.example.com', 1080, 'inactive', 'CA', 'Toronto', 100, 10),
('WireGuard Mobile', 'wireguard', 'Mobile WireGuard tunnel', 'mobile.vpn.example.com', 51821, 'active', 'SG', 'Singapore', 300, 30)
ON CONFLICT (tunnel_name) DO NOTHING;

-- Sample DHCP Pools (using correct column names and types)
INSERT INTO dhcp_pools (name, description, vlan_id, network_cidr, start_ip, end_ip, gateway_ip, dns_servers, lease_time) VALUES
('Main Network', 'Primary network DHCP pool', 1, '192.168.1.0/24'::inet, '192.168.1.100'::inet, '192.168.1.200'::inet, '192.168.1.1'::inet, ARRAY['192.168.1.1'::inet, '8.8.8.8'::inet], INTERVAL '24 hours'),
('Guest Network', 'Guest access DHCP pool', 100, '192.168.100.0/24'::inet, '192.168.100.10'::inet, '192.168.100.50'::inet, '192.168.100.1'::inet, ARRAY['8.8.8.8'::inet, '1.1.1.1'::inet], INTERVAL '4 hours'),
('IoT Network', 'Internet of Things DHCP pool', 50, '192.168.50.0/24'::inet, '192.168.50.10'::inet, '192.168.50.100'::inet, '192.168.50.1'::inet, ARRAY['192.168.1.1'::inet, '9.9.9.9'::inet], INTERVAL '48 hours'),
('Work Network', 'Business devices DHCP pool', 10, '192.168.10.0/24'::inet, '192.168.10.10'::inet, '192.168.10.50'::inet, '192.168.10.1'::inet, ARRAY['192.168.1.1'::inet, '8.8.4.4'::inet], INTERVAL '12 hours')
ON CONFLICT (name) DO NOTHING;

-- Default Load Balancing Configuration
INSERT INTO wan_load_balancing (config_name, balancing_method, health_check_enabled, traffic_distribution) VALUES
('Default Configuration', 'weighted_round_robin', true, '{"connection_weights": {"primary": 70, "secondary": 30}, "failover_priority": ["primary", "secondary"]}')
ON CONFLICT (config_name) DO NOTHING;

-- System Status Components
INSERT INTO system_status (component, status, metrics) VALUES
('network', 'healthy', '{"uptime": "99.9%", "latency": "12ms", "packet_loss": "0.1%"}'),
('vpn', 'healthy', '{"active_tunnels": 2, "clients_connected": 15, "throughput_mbps": 89}'),
('firewall', 'healthy', '{"rules_active": 25, "blocked_attempts": 156, "cpu_usage": "3%"}'),
('dns', 'healthy', '{"queries_per_second": 45, "cache_hit_rate": "89%", "blocked_queries": 23}'),
('dhcp', 'healthy', '{"leases_active": 23, "pool_utilization": "45%", "conflicts": 0}'),
('wifi', 'healthy', '{"networks_broadcasting": 3, "clients_connected": 18, "signal_strength": "-45dBm"}'),
('wan', 'healthy', '{"connections_active": 2, "primary_status": "connected", "backup_status": "standby"}'),
('storage', 'healthy', '{"disk_usage": "45%", "read_speed": "120MB/s", "write_speed": "85MB/s"}')
ON CONFLICT (component) DO NOTHING;;