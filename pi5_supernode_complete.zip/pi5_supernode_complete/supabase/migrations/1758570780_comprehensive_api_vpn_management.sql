-- Migration: comprehensive_api_vpn_management
-- Created at: 1758570780

-- Comprehensive VPN Management Module
-- Handles WireGuard, OpenVPN, IPSec, and advanced VPN features

-- WireGuard Interfaces
CREATE TABLE IF NOT EXISTS wireguard_interfaces (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    interface_name VARCHAR(50) NOT NULL UNIQUE,
    description TEXT,
    is_enabled BOOLEAN DEFAULT false,
    
    -- Keys
    private_key TEXT NOT NULL,
    public_key TEXT NOT NULL,
    preshared_key TEXT,
    
    -- Network Settings
    listen_port INTEGER,
    addresses INET[],
    mtu INTEGER DEFAULT 1420,
    
    -- Advanced Settings
    fwmark INTEGER,
    routing_table INTEGER,
    dns_servers INET[],
    
    -- Hooks/Scripts
    pre_up_script TEXT,
    post_up_script TEXT,
    pre_down_script TEXT,
    post_down_script TEXT,
    
    -- Status
    status VARCHAR(20) DEFAULT 'down', -- up, down, error
    last_handshake TIMESTAMP WITH TIME ZONE,
    bytes_rx BIGINT DEFAULT 0,
    bytes_tx BIGINT DEFAULT 0,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);;