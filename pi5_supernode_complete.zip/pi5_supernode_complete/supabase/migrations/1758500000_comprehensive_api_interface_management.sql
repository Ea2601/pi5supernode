-- Comprehensive Interface Management Module
-- Handles interface discovery, creation, configuration, and monitoring

-- Physical and Virtual Interface Registry
CREATE TABLE IF NOT EXISTS network_interfaces (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    interface_name VARCHAR(50) NOT NULL UNIQUE,
    interface_type VARCHAR(50) NOT NULL, -- physical, virtual, wireless, usb, pci, vlan, bridge, bond, tunnel, tap, tun
    interface_alias VARCHAR(100),
    description TEXT,
    uuid UUID DEFAULT gen_random_uuid() UNIQUE,
    
    -- Hardware Information
    vendor VARCHAR(100),
    model VARCHAR(100),
    serial_number VARCHAR(100),
    hardware_revision VARCHAR(50),
    firmware_version VARCHAR(50),
    driver_name VARCHAR(100),
    driver_version VARCHAR(50),
    bus_type VARCHAR(20), -- PCI, USB, etc
    bus_address VARCHAR(100),
    capabilities TEXT[],
    
    -- Physical Properties
    mac_address VARCHAR(17),
    permanent_mac VARCHAR(17),
    mtu_current INTEGER DEFAULT 1500,
    mtu_min INTEGER DEFAULT 68,
    mtu_max INTEGER DEFAULT 9000,
    
    -- State Information
    admin_state VARCHAR(20) DEFAULT 'down', -- up, down
    operational_state VARCHAR(20) DEFAULT 'down', -- up, down, unknown, dormant
    link_state VARCHAR(20) DEFAULT 'down', -- up, down, unknown
    last_state_change TIMESTAMP WITH TIME ZONE,
    uptime_seconds INTEGER DEFAULT 0,
    
    -- Speed and Duplex
    speed_current INTEGER, -- Mbps
    speeds_supported INTEGER[],
    duplex_current VARCHAR(20), -- full, half, unknown
    duplex_supported VARCHAR(50)[],
    autoneg_enabled BOOLEAN DEFAULT true,
    autoneg_advertised INTEGER[],
    autoneg_partner INTEGER[],
    
    -- Flow Control
    flowcontrol_rx BOOLEAN DEFAULT false,
    flowcontrol_tx BOOLEAN DEFAULT false,
    flowcontrol_autoneg BOOLEAN DEFAULT false,
    
    -- Advanced Features
    offload_features JSONB DEFAULT '{}',
    ring_buffer_settings JSONB DEFAULT '{}',
    interrupt_settings JSONB DEFAULT '{}',
    power_management JSONB DEFAULT '{}',
    
    -- VLAN Configuration
    vlan_enabled BOOLEAN DEFAULT false,
    vlan_trunk_enabled BOOLEAN DEFAULT false,
    vlan_trunk_allowed INTEGER[],
    vlan_native INTEGER,
    
    -- Timestamps
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    last_seen TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Interface IP Addresses (IPv4 and IPv6)
CREATE TABLE IF NOT EXISTS interface_addresses (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    interface_id UUID NOT NULL,
    address_family INTEGER NOT NULL, -- 4 for IPv4, 6 for IPv6
    ip_address INET NOT NULL,
    prefix_length INTEGER NOT NULL,
    scope VARCHAR(20), -- global, site, link, host
    label VARCHAR(100),
    is_primary BOOLEAN DEFAULT false,
    is_secondary BOOLEAN DEFAULT false,
    is_anycast BOOLEAN DEFAULT false,
    valid_lifetime INTEGER,
    preferred_lifetime INTEGER,
    flags TEXT[],
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Interface Statistics
CREATE TABLE IF NOT EXISTS interface_statistics (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    interface_id UUID NOT NULL,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- RX Statistics
    rx_packets_total BIGINT DEFAULT 0,
    rx_packets_unicast BIGINT DEFAULT 0,
    rx_packets_multicast BIGINT DEFAULT 0,
    rx_packets_broadcast BIGINT DEFAULT 0,
    rx_bytes_total BIGINT DEFAULT 0,
    rx_bytes_rate INTEGER DEFAULT 0, -- bytes/sec
    rx_bytes_peak INTEGER DEFAULT 0,
    rx_bytes_average INTEGER DEFAULT 0,
    
    -- TX Statistics
    tx_packets_total BIGINT DEFAULT 0,
    tx_packets_unicast BIGINT DEFAULT 0,
    tx_packets_multicast BIGINT DEFAULT 0,
    tx_packets_broadcast BIGINT DEFAULT 0,
    tx_bytes_total BIGINT DEFAULT 0,
    tx_bytes_rate INTEGER DEFAULT 0,
    tx_bytes_peak INTEGER DEFAULT 0,
    tx_bytes_average INTEGER DEFAULT 0,
    
    -- Error Statistics
    rx_errors_total BIGINT DEFAULT 0,
    rx_errors_crc BIGINT DEFAULT 0,
    rx_errors_frame BIGINT DEFAULT 0,
    rx_errors_fifo BIGINT DEFAULT 0,
    rx_errors_missed BIGINT DEFAULT 0,
    rx_errors_length BIGINT DEFAULT 0,
    rx_errors_over BIGINT DEFAULT 0,
    rx_dropped BIGINT DEFAULT 0,
    
    tx_errors_total BIGINT DEFAULT 0,
    tx_errors_aborted BIGINT DEFAULT 0,
    tx_errors_carrier BIGINT DEFAULT 0,
    tx_errors_fifo BIGINT DEFAULT 0,
    tx_errors_heartbeat BIGINT DEFAULT 0,
    tx_errors_window BIGINT DEFAULT 0,
    tx_dropped BIGINT DEFAULT 0,
    tx_collisions BIGINT DEFAULT 0,
    
    -- Advanced Statistics
    compressed_rx BIGINT DEFAULT 0,
    compressed_tx BIGINT DEFAULT 0,
    carrier_changes BIGINT DEFAULT 0,
    queue_length INTEGER DEFAULT 0,
    queue_drops BIGINT DEFAULT 0,
    interrupts BIGINT DEFAULT 0,
    cpu_usage_percent DECIMAL(5,2) DEFAULT 0.00,
    memory_usage_bytes BIGINT DEFAULT 0
);

-- ARP/Neighbor Discovery Tables
CREATE TABLE IF NOT EXISTS interface_neighbors (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    interface_id UUID NOT NULL,
    ip_address INET NOT NULL,
    mac_address VARCHAR(17),
    state VARCHAR(20), -- reachable, stale, delay, probe, incomplete, noarp, permanent
    neighbor_type VARCHAR(20), -- dynamic, static, local
    is_router BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    last_used TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- DHCP Configuration per Interface
CREATE TABLE IF NOT EXISTS interface_dhcp_config (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    interface_id UUID NOT NULL,
    
    -- IPv4 DHCP Client
    dhcp_enabled BOOLEAN DEFAULT false,
    dhcp_client_id VARCHAR(100),
    dhcp_hostname VARCHAR(100),
    dhcp_lease_info JSONB DEFAULT '{}',
    
    -- IPv6 DHCPv6
    dhcpv6_enabled BOOLEAN DEFAULT false,
    dhcpv6_mode VARCHAR(20), -- managed, assisted, disabled
    dhcpv6_pd_enabled BOOLEAN DEFAULT false,
    dhcpv6_lease_info JSONB DEFAULT '{}',
    
    -- Static Configuration
    static_enabled BOOLEAN DEFAULT false,
    static_gateway INET,
    static_dns_servers INET[],
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Bridge Configuration
CREATE TABLE IF NOT EXISTS bridge_interfaces (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    bridge_name VARCHAR(50) NOT NULL UNIQUE,
    interface_id UUID NOT NULL,
    
    -- STP Configuration
    stp_enabled BOOLEAN DEFAULT false,
    stp_protocol VARCHAR(20) DEFAULT 'rstp', -- stp, rstp, mstp
    stp_priority INTEGER DEFAULT 32768,
    stp_forward_delay INTEGER DEFAULT 15,
    stp_hello_time INTEGER DEFAULT 2,
    stp_max_age INTEGER DEFAULT 20,
    stp_root_id VARCHAR(50),
    stp_root_port VARCHAR(50),
    
    -- Bridge Settings
    aging_time INTEGER DEFAULT 300,
    multicast_snooping BOOLEAN DEFAULT true,
    vlan_filtering BOOLEAN DEFAULT false,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Bridge Ports
CREATE TABLE IF NOT EXISTS bridge_ports (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    bridge_id UUID NOT NULL,
    port_interface_id UUID NOT NULL,
    port_state VARCHAR(20) DEFAULT 'forwarding', -- disabled, listening, learning, forwarding, blocking
    port_role VARCHAR(20), -- root, designated, alternate, backup, disabled
    path_cost INTEGER DEFAULT 100,
    port_priority INTEGER DEFAULT 128,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Bridge Forwarding Database
CREATE TABLE IF NOT EXISTS bridge_fdb (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    bridge_id UUID NOT NULL,
    mac_address VARCHAR(17) NOT NULL,
    port_interface_id UUID NOT NULL,
    vlan_id INTEGER,
    entry_age INTEGER DEFAULT 0,
    is_local BOOLEAN DEFAULT false,
    is_static BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Bond/LAG Interfaces
CREATE TABLE IF NOT EXISTS bond_interfaces (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    bond_name VARCHAR(50) NOT NULL UNIQUE,
    interface_id UUID NOT NULL,
    
    -- Bonding Mode
    bond_mode VARCHAR(20) NOT NULL DEFAULT 'balance-rr', -- balance-rr, active-backup, balance-xor, broadcast, 802.3ad, balance-tlb, balance-alb
    
    -- Primary and Active Slave
    primary_slave_id UUID,
    active_slave_id UUID,
    
    -- Monitoring
    miimon_interval INTEGER DEFAULT 100,
    updelay INTEGER DEFAULT 0,
    downdelay INTEGER DEFAULT 0,
    arp_interval INTEGER DEFAULT 0,
    arp_targets INET[],
    
    -- Advanced Options
    xmit_hash_policy VARCHAR(30) DEFAULT 'layer2',
    lacp_rate VARCHAR(10) DEFAULT 'slow', -- slow, fast
    ad_select VARCHAR(20) DEFAULT 'stable', -- stable, bandwidth, count
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Bond Slaves
CREATE TABLE IF NOT EXISTS bond_slaves (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    bond_id UUID NOT NULL,
    slave_interface_id UUID NOT NULL,
    slave_state VARCHAR(20) DEFAULT 'down', -- active, backup, down
    is_active BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- VLAN Interfaces
CREATE TABLE IF NOT EXISTS vlan_interfaces (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    parent_interface_id UUID NOT NULL,
    vlan_id INTEGER NOT NULL CHECK (vlan_id >= 1 AND vlan_id <= 4094),
    vlan_interface_id UUID NOT NULL,
    
    -- VLAN Properties
    egress_policy VARCHAR(20) DEFAULT 'untagged',
    ingress_policy VARCHAR(20) DEFAULT 'accept',
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    UNIQUE(parent_interface_id, vlan_id)
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_interface_addresses_interface_id ON interface_addresses(interface_id);
CREATE INDEX IF NOT EXISTS idx_interface_statistics_interface_id ON interface_statistics(interface_id);
CREATE INDEX IF NOT EXISTS idx_interface_statistics_timestamp ON interface_statistics(timestamp);
CREATE INDEX IF NOT EXISTS idx_interface_neighbors_interface_id ON interface_neighbors(interface_id);
CREATE INDEX IF NOT EXISTS idx_interface_neighbors_ip ON interface_neighbors(ip_address);
CREATE INDEX IF NOT EXISTS idx_bridge_ports_bridge_id ON bridge_ports(bridge_id);
CREATE INDEX IF NOT EXISTS idx_bridge_fdb_bridge_id ON bridge_fdb(bridge_id);
CREATE INDEX IF NOT EXISTS idx_bridge_fdb_mac ON bridge_fdb(mac_address);
CREATE INDEX IF NOT EXISTS idx_bond_slaves_bond_id ON bond_slaves(bond_id);
CREATE INDEX IF NOT EXISTS idx_vlan_interfaces_parent ON vlan_interfaces(parent_interface_id);
CREATE INDEX IF NOT EXISTS idx_vlan_interfaces_vlan_id ON vlan_interfaces(vlan_id);

-- Create triggers for updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_network_interfaces_updated_at BEFORE UPDATE ON network_interfaces FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_interface_addresses_updated_at BEFORE UPDATE ON interface_addresses FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_interface_neighbors_updated_at BEFORE UPDATE ON interface_neighbors FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_interface_dhcp_config_updated_at BEFORE UPDATE ON interface_dhcp_config FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_bridge_interfaces_updated_at BEFORE UPDATE ON bridge_interfaces FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_bridge_ports_updated_at BEFORE UPDATE ON bridge_ports FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_bridge_fdb_updated_at BEFORE UPDATE ON bridge_fdb FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_bond_interfaces_updated_at BEFORE UPDATE ON bond_interfaces FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_bond_slaves_updated_at BEFORE UPDATE ON bond_slaves FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_vlan_interfaces_updated_at BEFORE UPDATE ON vlan_interfaces FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();