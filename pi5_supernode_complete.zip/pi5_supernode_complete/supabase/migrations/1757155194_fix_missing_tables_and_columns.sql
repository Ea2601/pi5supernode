-- Migration: fix_missing_tables_and_columns
-- Created at: 1757155194

-- Create missing device_configurations table
CREATE TABLE IF NOT EXISTS device_configurations (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    category VARCHAR(50) NOT NULL,
    config_key VARCHAR(100) NOT NULL,
    config_json JSONB NOT NULL DEFAULT '{}',
    description TEXT,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(category, config_key)
);

-- Add missing columns to audit_logs table
ALTER TABLE audit_logs 
ADD COLUMN IF NOT EXISTS title VARCHAR(255),
ADD COLUMN IF NOT EXISTS message TEXT,
ADD COLUMN IF NOT EXISTS acknowledged BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS acknowledged_at TIMESTAMP WITH TIME ZONE,
ADD COLUMN IF NOT EXISTS acknowledged_by UUID;

-- Add missing columns to system_metrics table
ALTER TABLE system_metrics
ADD COLUMN IF NOT EXISTS cpu_percent DECIMAL(5,2),
ADD COLUMN IF NOT EXISTS memory_percent DECIMAL(5,2),
ADD COLUMN IF NOT EXISTS disk_usage_percent DECIMAL(5,2),
ADD COLUMN IF NOT EXISTS temperature_celsius DECIMAL(5,2),
ADD COLUMN IF NOT EXISTS network_bytes_in BIGINT,
ADD COLUMN IF NOT EXISTS network_bytes_out BIGINT,
ADD COLUMN IF NOT EXISTS created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW();

-- Create missing network_traffic_data table
CREATE TABLE IF NOT EXISTS network_traffic_data (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    interface_name VARCHAR(50) NOT NULL,
    bytes_sent BIGINT NOT NULL DEFAULT 0,
    bytes_received BIGINT NOT NULL DEFAULT 0,
    packets_sent BIGINT NOT NULL DEFAULT 0,
    packets_received BIGINT NOT NULL DEFAULT 0,
    errors_in BIGINT NOT NULL DEFAULT 0,
    errors_out BIGINT NOT NULL DEFAULT 0,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    device_id VARCHAR(100),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_device_configurations_category ON device_configurations(category);
CREATE INDEX IF NOT EXISTS idx_audit_logs_event_type ON audit_logs(event_type);
CREATE INDEX IF NOT EXISTS idx_audit_logs_created_at ON audit_logs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_logs_severity ON audit_logs(severity);
CREATE INDEX IF NOT EXISTS idx_system_metrics_timestamp ON system_metrics(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_system_metrics_metric_type ON system_metrics(metric_type);
CREATE INDEX IF NOT EXISTS idx_network_traffic_timestamp ON network_traffic_data(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_network_traffic_interface ON network_traffic_data(interface_name);

-- RLS Policies for new tables
ALTER TABLE device_configurations ENABLE ROW LEVEL SECURITY;
ALTER TABLE network_traffic_data ENABLE ROW LEVEL SECURITY;

-- Allow authenticated users to access these tables
DROP POLICY IF EXISTS "Allow authenticated users to manage device configs" ON device_configurations;
CREATE POLICY "Allow authenticated users to manage device configs" ON device_configurations
    FOR ALL USING (auth.role() = 'authenticated');

DROP POLICY IF EXISTS "Allow authenticated users to view network traffic" ON network_traffic_data;
CREATE POLICY "Allow authenticated users to view network traffic" ON network_traffic_data
    FOR ALL USING (auth.role() = 'authenticated');;