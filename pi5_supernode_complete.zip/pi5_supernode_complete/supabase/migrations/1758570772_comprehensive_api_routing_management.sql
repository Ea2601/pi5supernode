-- Migration: comprehensive_api_routing_management
-- Created at: 1758570772

-- Comprehensive Routing Management Module
-- Handles routing tables, rules, BGP, OSPF, and advanced routing protocols

-- Routing Tables
CREATE TABLE IF NOT EXISTS routing_tables (
    id INTEGER PRIMARY KEY,
    table_name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    is_system_table BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Route Entries
CREATE TABLE IF NOT EXISTS route_entries (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    table_id INTEGER NOT NULL,
    destination CIDR NOT NULL,
    gateway INET,
    interface_id UUID,
    
    -- Route Properties
    route_type VARCHAR(30) DEFAULT 'unicast', -- unicast, broadcast, local, nat, unreachable, prohibit, blackhole
    scope VARCHAR(20) DEFAULT 'universe', -- universe, site, link, host
    protocol VARCHAR(30) DEFAULT 'static', -- kernel, boot, static, ra, dhcp, bird, zebra, bgp, ospf
    source VARCHAR(30) DEFAULT 'admin',
    
    -- Metrics
    metric INTEGER DEFAULT 100,
    priority INTEGER DEFAULT 100,
    weight INTEGER DEFAULT 1,
    preference INTEGER DEFAULT 100,
    
    -- Multipath Support
    is_multipath BOOLEAN DEFAULT false,
    multipath_algorithm VARCHAR(30) DEFAULT 'round_robin',
    
    -- Status
    is_enabled BOOLEAN DEFAULT true,
    age_seconds INTEGER DEFAULT 0,
    last_used TIMESTAMP WITH TIME ZONE,
    hit_count BIGINT DEFAULT 0,
    
    -- Flags
    flags TEXT[],
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);;