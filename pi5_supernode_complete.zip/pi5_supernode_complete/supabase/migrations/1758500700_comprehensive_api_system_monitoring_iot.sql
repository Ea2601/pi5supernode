-- Comprehensive System Monitoring & IoT Management Module
-- Handles system monitoring, performance metrics, IoT devices, and edge computing

-- System Performance Monitoring
CREATE TABLE IF NOT EXISTS system_performance_metrics (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- CPU Metrics
    cpu_usage_percent DECIMAL(5,2),
    cpu_load_1min DECIMAL(8,2),
    cpu_load_5min DECIMAL(8,2),
    cpu_load_15min DECIMAL(8,2),
    cpu_temperature_celsius DECIMAL(5,2),
    cpu_frequency_mhz INTEGER,
    
    -- Memory Metrics
    memory_total_mb INTEGER,
    memory_used_mb INTEGER,
    memory_free_mb INTEGER,
    memory_available_mb INTEGER,
    memory_cached_mb INTEGER,
    memory_buffer_mb INTEGER,
    swap_total_mb INTEGER,
    swap_used_mb INTEGER,
    
    -- Storage Metrics
    storage_metrics JSONB DEFAULT '{}', -- Per-filesystem metrics
    
    -- Network Interface Metrics
    network_metrics JSONB DEFAULT '{}', -- Per-interface metrics
    
    -- System Uptime
    uptime_seconds BIGINT,
    
    -- Process Metrics
    process_count INTEGER,
    thread_count INTEGER,
    zombie_process_count INTEGER DEFAULT 0,
    
    -- System Load
    context_switches_per_sec INTEGER,
    interrupts_per_sec INTEGER,
    
    -- Power Management (for Pi/embedded systems)
    power_consumption_watts DECIMAL(8,2),
    battery_level_percent DECIMAL(5,2),
    thermal_throttling BOOLEAN DEFAULT false
);

-- Network Performance Monitoring
CREATE TABLE IF NOT EXISTS network_performance_monitoring (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Overall Network Statistics
    total_interfaces INTEGER,
    active_interfaces INTEGER,
    total_bandwidth_mbps INTEGER,
    
    -- Traffic Summary
    total_rx_bytes_per_sec BIGINT,
    total_tx_bytes_per_sec BIGINT,
    total_packets_per_sec INTEGER,
    
    -- Connection Statistics
    active_tcp_connections INTEGER,
    active_udp_connections INTEGER,
    tcp_retransmissions_per_sec INTEGER,
    
    -- Quality Metrics
    average_latency_ms DECIMAL(8,2),
    packet_loss_percent DECIMAL(5,2),
    jitter_ms DECIMAL(8,2),
    
    -- Top Talkers
    top_source_ips JSONB DEFAULT '{}',
    top_destination_ips JSONB DEFAULT '{}',
    top_protocols JSONB DEFAULT '{}',
    
    -- Error Statistics
    interface_errors_per_sec INTEGER,
    dns_failures_per_sec INTEGER,
    
    -- Security Events
    firewall_blocks_per_sec INTEGER,
    intrusion_attempts_per_sec INTEGER
);

-- Application Performance Monitoring
CREATE TABLE IF NOT EXISTS application_performance_monitoring (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Service Status
    service_status JSONB DEFAULT '{}', -- Status of various services
    
    -- Web Server Metrics (if applicable)
    http_requests_per_sec INTEGER,
    http_response_time_ms DECIMAL(8,2),
    http_error_rate_percent DECIMAL(5,2),
    
    -- Database Performance (if applicable)
    db_connections_active INTEGER,
    db_query_time_ms DECIMAL(8,2),
    db_slow_queries_per_sec INTEGER,
    
    -- VPN Performance
    vpn_active_connections INTEGER,
    vpn_throughput_mbps DECIMAL(10,2),
    vpn_latency_ms DECIMAL(8,2),
    
    -- DNS Performance
    dns_queries_per_sec INTEGER,
    dns_response_time_ms DECIMAL(8,2),
    dns_cache_hit_rate_percent DECIMAL(5,2),
    
    -- DHCP Performance
    dhcp_leases_active INTEGER,
    dhcp_lease_utilization_percent DECIMAL(5,2),
    dhcp_requests_per_sec INTEGER
);

-- System Alerts and Thresholds
CREATE TABLE IF NOT EXISTS system_alert_thresholds (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    alert_name VARCHAR(100) NOT NULL UNIQUE,
    metric_type VARCHAR(50) NOT NULL, -- cpu, memory, disk, network, temperature, etc.
    metric_name VARCHAR(100) NOT NULL,
    
    -- Threshold Configuration
    warning_threshold DECIMAL(10,2),
    critical_threshold DECIMAL(10,2),
    threshold_operator VARCHAR(10) DEFAULT '>', -- >, <, >=, <=, =
    
    -- Alert Behavior
    check_interval_seconds INTEGER DEFAULT 60,
    alert_interval_seconds INTEGER DEFAULT 300, -- Minimum time between alerts
    consecutive_failures_required INTEGER DEFAULT 3,
    
    -- Notification Settings
    email_enabled BOOLEAN DEFAULT false,
    email_addresses TEXT[],
    webhook_enabled BOOLEAN DEFAULT false,
    webhook_url TEXT,
    
    -- Auto-resolution
    auto_resolve BOOLEAN DEFAULT true,
    resolve_threshold DECIMAL(10,2),
    
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- System Alerts Log
CREATE TABLE IF NOT EXISTS system_alerts (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    alert_threshold_id UUID NOT NULL,
    
    -- Alert Information
    severity VARCHAR(20) NOT NULL, -- warning, critical
    alert_message TEXT NOT NULL,
    metric_value DECIMAL(10,2),
    
    -- Alert Status
    status VARCHAR(20) DEFAULT 'active', -- active, acknowledged, resolved
    acknowledged_at TIMESTAMP WITH TIME ZONE,
    acknowledged_by VARCHAR(255),
    resolved_at TIMESTAMP WITH TIME ZONE,
    
    -- Notification Status
    email_sent BOOLEAN DEFAULT false,
    webhook_sent BOOLEAN DEFAULT false,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- IoT Device Registry
CREATE TABLE IF NOT EXISTS iot_devices (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    device_id VARCHAR(100) NOT NULL UNIQUE, -- Unique device identifier
    device_name VARCHAR(255) NOT NULL,
    device_type VARCHAR(50) NOT NULL, -- sensor, actuator, gateway, camera, etc.
    manufacturer VARCHAR(100),
    model VARCHAR(100),
    firmware_version VARCHAR(50),
    
    -- Network Information
    mac_address VARCHAR(17),
    ip_address INET,
    network_interface_id UUID, -- Which network interface it's connected to
    
    -- Communication Protocols
    primary_protocol VARCHAR(30), -- mqtt, coap, http, lorawan, zigbee, etc.
    secondary_protocols VARCHAR(30)[],
    
    -- MQTT Configuration
    mqtt_topic_prefix VARCHAR(255),
    mqtt_client_id VARCHAR(100),
    mqtt_username VARCHAR(100),
    mqtt_password_hash VARCHAR(255),
    
    -- CoAP Configuration
    coap_endpoint VARCHAR(255),
    coap_resources TEXT[],
    
    -- LoRaWAN Configuration
    lorawan_dev_eui VARCHAR(16),
    lorawan_app_eui VARCHAR(16),
    lorawan_dev_addr VARCHAR(8),
    lorawan_app_key VARCHAR(32),
    lorawan_net_session_key VARCHAR(32),
    lorawan_app_session_key VARCHAR(32),
    
    -- Device Capabilities
    capabilities JSONB DEFAULT '{}',
    supported_commands TEXT[],
    sensor_types TEXT[],
    
    -- Location Information
    location_description TEXT,
    latitude DECIMAL(10,8),
    longitude DECIMAL(11,8),
    altitude_meters DECIMAL(8,2),
    
    -- Device Status
    status VARCHAR(20) DEFAULT 'unknown', -- online, offline, unknown, error
    last_seen TIMESTAMP WITH TIME ZONE,
    last_heartbeat TIMESTAMP WITH TIME ZONE,
    
    -- Security
    security_level VARCHAR(20) DEFAULT 'medium', -- low, medium, high
    encryption_enabled BOOLEAN DEFAULT false,
    certificate TEXT, -- Device certificate for TLS
    
    -- Power Management
    power_source VARCHAR(30) DEFAULT 'unknown', -- battery, ac, solar, poe
    battery_level_percent DECIMAL(5,2),
    power_consumption_watts DECIMAL(8,2),
    
    -- Management
    owner VARCHAR(255),
    group_name VARCHAR(100),
    tags TEXT[],
    
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- IoT Device Data/Telemetry
CREATE TABLE IF NOT EXISTS iot_device_data (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    device_id UUID NOT NULL,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Data Type
    data_type VARCHAR(50) NOT NULL, -- sensor_reading, status_update, command_response, etc.
    
    -- Raw Data
    raw_data JSONB NOT NULL,
    
    -- Processed/Normalized Data
    temperature_celsius DECIMAL(8,2),
    humidity_percent DECIMAL(5,2),
    pressure_hpa DECIMAL(8,2),
    light_lux DECIMAL(10,2),
    motion_detected BOOLEAN,
    door_open BOOLEAN,
    
    -- Generic Sensor Values
    sensor_values JSONB DEFAULT '{}',
    
    -- Device Health
    signal_strength_dbm INTEGER,
    battery_voltage DECIMAL(5,2),
    
    -- Data Quality
    data_quality_score INTEGER, -- 0-100
    validation_errors TEXT[],
    
    -- Processing Status
    processed BOOLEAN DEFAULT false,
    processing_errors TEXT[]
);

-- IoT Device Commands
CREATE TABLE IF NOT EXISTS iot_device_commands (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    device_id UUID NOT NULL,
    command_type VARCHAR(50) NOT NULL,
    command_data JSONB NOT NULL,
    
    -- Command Status
    status VARCHAR(20) DEFAULT 'pending', -- pending, sent, acknowledged, completed, failed
    priority INTEGER DEFAULT 5, -- 1-10, lower is higher priority
    
    -- Timing
    scheduled_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    sent_at TIMESTAMP WITH TIME ZONE,
    acknowledged_at TIMESTAMP WITH TIME ZONE,
    completed_at TIMESTAMP WITH TIME ZONE,
    expires_at TIMESTAMP WITH TIME ZONE,
    
    -- Response
    response_data JSONB,
    error_message TEXT,
    
    -- Metadata
    initiated_by VARCHAR(255),
    correlation_id VARCHAR(100),
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- MQTT Broker Configuration
CREATE TABLE IF NOT EXISTS mqtt_broker_config (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    is_enabled BOOLEAN DEFAULT false,
    
    -- Broker Settings
    listen_port INTEGER DEFAULT 1883,
    listen_port_ssl INTEGER DEFAULT 8883,
    max_connections INTEGER DEFAULT 1000,
    
    -- Authentication
    allow_anonymous BOOLEAN DEFAULT false,
    require_certificate BOOLEAN DEFAULT false,
    
    -- SSL/TLS
    ssl_enabled BOOLEAN DEFAULT false,
    ca_certificate TEXT,
    server_certificate TEXT,
    server_private_key TEXT,
    
    -- Message Limits
    max_message_size_bytes INTEGER DEFAULT 1048576, -- 1MB
    max_inflight_messages INTEGER DEFAULT 20,
    message_timeout_seconds INTEGER DEFAULT 60,
    
    -- Persistence
    persistence_enabled BOOLEAN DEFAULT true,
    persistence_location VARCHAR(255) DEFAULT '/var/lib/mosquitto',
    
    -- Logging
    log_level VARCHAR(20) DEFAULT 'info',
    connection_messages BOOLEAN DEFAULT true,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- MQTT Topics and Access Control
CREATE TABLE IF NOT EXISTS mqtt_topic_acl (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    client_id VARCHAR(100), -- NULL means applies to all clients
    username VARCHAR(100),
    topic_pattern VARCHAR(255) NOT NULL,
    
    -- Permissions
    read_permission BOOLEAN DEFAULT false,
    write_permission BOOLEAN DEFAULT false,
    
    -- Topic Properties
    retain_allowed BOOLEAN DEFAULT true,
    qos_max INTEGER DEFAULT 2,
    
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- LoRaWAN Gateway Configuration
CREATE TABLE IF NOT EXISTS lorawan_gateway_config (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    is_enabled BOOLEAN DEFAULT false,
    
    -- Gateway Identity
    gateway_eui VARCHAR(16) NOT NULL UNIQUE,
    gateway_id VARCHAR(100),
    
    -- Network Server Configuration
    network_server_url VARCHAR(255),
    network_server_port INTEGER DEFAULT 1700,
    
    -- Radio Configuration
    frequency_plan VARCHAR(50) DEFAULT 'EU868', -- EU868, US915, AS923, etc.
    tx_power_dbm INTEGER DEFAULT 14,
    antenna_gain_dbi DECIMAL(4,1) DEFAULT 2.0,
    
    -- GPS Configuration
    gps_enabled BOOLEAN DEFAULT false,
    latitude DECIMAL(10,8),
    longitude DECIMAL(11,8),
    altitude_meters DECIMAL(8,2),
    
    -- Statistics
    packets_received BIGINT DEFAULT 0,
    packets_forwarded BIGINT DEFAULT 0,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Edge Computing Containers
CREATE TABLE IF NOT EXISTS edge_containers (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    container_name VARCHAR(100) NOT NULL UNIQUE,
    image_name VARCHAR(255) NOT NULL,
    image_tag VARCHAR(50) DEFAULT 'latest',
    
    -- Container Configuration
    cpu_limit DECIMAL(5,2), -- CPU cores
    memory_limit_mb INTEGER,
    storage_limit_mb INTEGER,
    
    -- Network Configuration
    network_mode VARCHAR(30) DEFAULT 'bridge', -- bridge, host, none
    port_mappings JSONB DEFAULT '[]',
    
    -- Environment
    environment_variables JSONB DEFAULT '{}',
    volumes JSONB DEFAULT '[]',
    
    -- Container Status
    status VARCHAR(20) DEFAULT 'stopped', -- running, stopped, error, updating
    restart_policy VARCHAR(20) DEFAULT 'unless-stopped',
    
    -- Resource Usage
    cpu_usage_percent DECIMAL(5,2),
    memory_usage_mb INTEGER,
    storage_usage_mb INTEGER,
    
    -- Health Check
    health_check_enabled BOOLEAN DEFAULT false,
    health_check_command TEXT,
    health_check_interval_seconds INTEGER DEFAULT 30,
    health_status VARCHAR(20) DEFAULT 'unknown', -- healthy, unhealthy, unknown
    
    -- Auto-update
    auto_update_enabled BOOLEAN DEFAULT false,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_system_performance_metrics_timestamp ON system_performance_metrics(timestamp);
CREATE INDEX IF NOT EXISTS idx_network_performance_monitoring_timestamp ON network_performance_monitoring(timestamp);
CREATE INDEX IF NOT EXISTS idx_application_performance_monitoring_timestamp ON application_performance_monitoring(timestamp);
CREATE INDEX IF NOT EXISTS idx_system_alerts_threshold_id ON system_alerts(alert_threshold_id);
CREATE INDEX IF NOT EXISTS idx_system_alerts_status ON system_alerts(status);
CREATE INDEX IF NOT EXISTS idx_system_alerts_created_at ON system_alerts(created_at);
CREATE INDEX IF NOT EXISTS idx_iot_devices_device_id ON iot_devices(device_id);
CREATE INDEX IF NOT EXISTS idx_iot_devices_device_type ON iot_devices(device_type);
CREATE INDEX IF NOT EXISTS idx_iot_devices_status ON iot_devices(status);
CREATE INDEX IF NOT EXISTS idx_iot_devices_last_seen ON iot_devices(last_seen);
CREATE INDEX IF NOT EXISTS idx_iot_device_data_device_id ON iot_device_data(device_id);
CREATE INDEX IF NOT EXISTS idx_iot_device_data_timestamp ON iot_device_data(timestamp);
CREATE INDEX IF NOT EXISTS idx_iot_device_data_data_type ON iot_device_data(data_type);
CREATE INDEX IF NOT EXISTS idx_iot_device_commands_device_id ON iot_device_commands(device_id);
CREATE INDEX IF NOT EXISTS idx_iot_device_commands_status ON iot_device_commands(status);
CREATE INDEX IF NOT EXISTS idx_iot_device_commands_scheduled_at ON iot_device_commands(scheduled_at);
CREATE INDEX IF NOT EXISTS idx_mqtt_topic_acl_client_id ON mqtt_topic_acl(client_id);
CREATE INDEX IF NOT EXISTS idx_mqtt_topic_acl_username ON mqtt_topic_acl(username);
CREATE INDEX IF NOT EXISTS idx_mqtt_topic_acl_topic_pattern ON mqtt_topic_acl(topic_pattern);
CREATE INDEX IF NOT EXISTS idx_edge_containers_status ON edge_containers(status);

-- Create triggers for updated_at
CREATE TRIGGER update_system_alert_thresholds_updated_at BEFORE UPDATE ON system_alert_thresholds FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_iot_devices_updated_at BEFORE UPDATE ON iot_devices FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_mqtt_broker_config_updated_at BEFORE UPDATE ON mqtt_broker_config FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_mqtt_topic_acl_updated_at BEFORE UPDATE ON mqtt_topic_acl FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_lorawan_gateway_config_updated_at BEFORE UPDATE ON lorawan_gateway_config FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_edge_containers_updated_at BEFORE UPDATE ON edge_containers FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();