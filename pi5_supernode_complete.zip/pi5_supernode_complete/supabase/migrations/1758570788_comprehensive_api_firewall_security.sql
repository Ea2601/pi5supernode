-- Migration: comprehensive_api_firewall_security
-- Created at: 1758570788

-- Comprehensive Firewall & Security Module
-- Handles iptables/netfilter, NAT, connection tracking, and security policies

-- Firewall Tables (iptables tables)
CREATE TABLE IF NOT EXISTS firewall_tables (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    table_name VARCHAR(30) NOT NULL UNIQUE, -- filter, nat, mangle, raw, security
    description TEXT,
    is_system_table BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Firewall Chains
CREATE TABLE IF NOT EXISTS firewall_chains (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    table_id UUID NOT NULL,
    chain_name VARCHAR(50) NOT NULL,
    chain_type VARCHAR(20) NOT NULL DEFAULT 'user', -- built-in, user
    hook_point VARCHAR(30), -- PREROUTING, INPUT, FORWARD, OUTPUT, POSTROUTING
    priority INTEGER DEFAULT 0,
    
    -- Default Policy
    default_policy VARCHAR(20) DEFAULT 'ACCEPT', -- ACCEPT, DROP, REJECT
    
    -- Chain Statistics
    packet_count BIGINT DEFAULT 0,
    byte_count BIGINT DEFAULT 0,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    UNIQUE(table_id, chain_name)
);;