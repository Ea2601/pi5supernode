-- Migration: create_enhanced_traffic_management_tables
-- Created at: 1757179008

-- Enhanced Traffic Management System Tables

-- DHCP Pool Management
CREATE TABLE IF NOT EXISTS dhcp_pools (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    pool_name VARCHAR(100) NOT NULL UNIQUE,
    network_cidr VARCHAR(20) NOT NULL, -- e.g., "192.168.1.0/24"
    start_ip INET NOT NULL,
    end_ip INET NOT NULL,
    gateway_ip INET,
    dns_primary INET,
    dns_secondary INET,
    lease_time_hours INTEGER DEFAULT 24,
    vlan_id UUID,
    domain_name VARCHAR(255),
    ntp_servers TEXT[],
    static_routes JSONB DEFAULT '[]',
    dhcp_options JSONB DEFAULT '{}',
    is_enabled BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- DHCP Reservations (Static IP assignments)
CREATE TABLE IF NOT EXISTS dhcp_reservations (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    pool_id UUID NOT NULL,
    device_name VARCHAR(100) NOT NULL,
    mac_address VARCHAR(17) NOT NULL UNIQUE,
    reserved_ip INET NOT NULL,
    description TEXT,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- WiFi Networks Management
CREATE TABLE IF NOT EXISTS wifi_networks (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    ssid VARCHAR(32) NOT NULL,
    frequency_band VARCHAR(10) NOT NULL CHECK (frequency_band IN ('2.4GHz', '5GHz', 'dual')),
    security_type VARCHAR(20) NOT NULL DEFAULT 'wpa3' CHECK (security_type IN ('open', 'wep', 'wpa', 'wpa2', 'wpa3', 'wpa2-wpa3')),
    password VARCHAR(63),
    hidden BOOLEAN DEFAULT false,
    max_clients INTEGER DEFAULT 50,
    bandwidth_limit_mbps INTEGER,
    is_guest_network BOOLEAN DEFAULT false,
    guest_isolation BOOLEAN DEFAULT false,
    client_isolation BOOLEAN DEFAULT false,
    vlan_id UUID,
    access_schedule JSONB DEFAULT '{}', -- Time-based access control
    mac_filtering_enabled BOOLEAN DEFAULT false,
    allowed_mac_addresses TEXT[] DEFAULT '{}',
    blocked_mac_addresses TEXT[] DEFAULT '{}',
    channel_width INTEGER DEFAULT 80, -- MHz
    tx_power_dbm INTEGER DEFAULT 20,
    beacon_interval INTEGER DEFAULT 100,
    is_enabled BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- VLAN Management
CREATE TABLE IF NOT EXISTS vlans (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    vlan_id INTEGER NOT NULL UNIQUE CHECK (vlan_id BETWEEN 1 AND 4094),
    vlan_name VARCHAR(100) NOT NULL,
    description TEXT,
    network_cidr VARCHAR(20) NOT NULL, -- e.g., "192.168.10.0/24"
    gateway_ip INET,
    dns_servers INET[] DEFAULT '{}',
    dhcp_enabled BOOLEAN DEFAULT true,
    inter_vlan_routing BOOLEAN DEFAULT false,
    qos_priority INTEGER DEFAULT 0 CHECK (qos_priority BETWEEN 0 AND 7),
    bandwidth_limit_mbps INTEGER,
    port_assignments TEXT[] DEFAULT '{}', -- Physical ports assigned to this VLAN
    tagged_ports TEXT[] DEFAULT '{}',
    untagged_ports TEXT[] DEFAULT '{}',
    security_policies JSONB DEFAULT '{}',
    access_control_rules JSONB DEFAULT '[]',
    is_management_vlan BOOLEAN DEFAULT false,
    is_voice_vlan BOOLEAN DEFAULT false,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enhanced WAN Connection Types (expanding existing)
INSERT INTO wan_connection_types (type_name, display_name, description, configuration_schema, is_active, display_order) VALUES
('static_ip', 'Static IP', 'Fixed IP address configuration with DNS settings', 
 '{"fields": ["ip_address", "subnet_mask", "gateway", "dns_primary", "dns_secondary", "mtu"]}', true, 1),
('dhcp_client', 'DHCP Client', 'Automatic IP configuration with lease management', 
 '{"fields": ["hostname", "client_id", "vendor_class", "mtu"]}', true, 2),
('pppoe', 'PPPoE', 'Point-to-Point Protocol over Ethernet with authentication', 
 '{"fields": ["username", "password", "service_name", "mtu", "lcp_echo_interval"]}', true, 3),
('cellular_3g', '3G Cellular', 'Third generation cellular data connection', 
 '{"fields": ["apn", "username", "password", "pin", "dial_number"]}', true, 4),
('cellular_4g', '4G/LTE', 'Fourth generation cellular data connection', 
 '{"fields": ["apn", "username", "password", "pin", "band_preference"]}', true, 5),
('cellular_5g', '5G', 'Fifth generation cellular data connection', 
 '{"fields": ["apn", "username", "password", "pin", "band_preference", "slice_id"]}', true, 6),
('satellite', 'Satellite Internet', 'Satellite internet connection (Starlink, Viasat, HughesNet)', 
 '{"fields": ["terminal_id", "beam_id", "elevation_angle", "azimuth_angle"]}', true, 7),
('cable_docsis', 'Cable/DOCSIS', 'Cable modem DOCSIS configuration', 
 '{"fields": ["modem_model", "downstream_channels", "upstream_channels", "rf_levels"]}', true, 8),
('dsl_adsl', 'DSL/ADSL', 'Digital Subscriber Line configuration with line testing', 
 '{"fields": ["username", "password", "vci", "vpi", "encapsulation", "line_profile"]}', true, 9),
('dsl_vdsl', 'VDSL', 'Very-high-bit-rate Digital Subscriber Line', 
 '{"fields": ["username", "password", "vci", "vpi", "vectoring_enabled", "profile"]}', true, 10),
('fiber_direct', 'Fiber Direct', 'Direct fiber optic connection configuration', 
 '{"fields": ["interface_type", "speed", "duplex", "flow_control", "jumbo_frames"]}', true, 11)
ON CONFLICT (type_name) DO UPDATE SET
display_name = EXCLUDED.display_name,
description = EXCLUDED.description,
configuration_schema = EXCLUDED.configuration_schema,
updated_at = NOW();

-- Multi-WAN Load Balancing Configuration
CREATE TABLE IF NOT EXISTS wan_load_balancing (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    config_name VARCHAR(100) NOT NULL DEFAULT 'Default Load Balancing',
    balancing_method VARCHAR(20) NOT NULL DEFAULT 'weighted_round_robin' 
        CHECK (balancing_method IN ('round_robin', 'weighted_round_robin', 'least_connections', 'failover', 'bandwidth_based')),
    health_check_enabled BOOLEAN DEFAULT true,
    health_check_interval_seconds INTEGER DEFAULT 30,
    health_check_timeout_seconds INTEGER DEFAULT 10,
    health_check_retries INTEGER DEFAULT 3,
    failover_enabled BOOLEAN DEFAULT true,
    failback_enabled BOOLEAN DEFAULT true,
    failback_delay_seconds INTEGER DEFAULT 60,
    traffic_distribution JSONB DEFAULT '{}', -- Connection weights and rules
    sticky_sessions BOOLEAN DEFAULT false,
    session_persistence_method VARCHAR(20) DEFAULT 'source_ip',
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- User Groups (enhanced from existing)
INSERT INTO user_groups (group_name, description, color_code, priority) VALUES
('Local Network', 'All local network devices', '#3B82F6', 10),
('WireGuard Client 1', 'WireGuard VPN clients - Group 1', '#10B981', 20),
('WireGuard Client 2', 'WireGuard VPN clients - Group 2', '#F59E0B', 30),
('Family Members', 'Home family member devices', '#EF4444', 40),
('Guests', 'Guest network devices', '#8B5CF6', 50),
('IoT Devices', 'Internet of Things devices', '#06B6D4', 60),
('Work Devices', 'Work-related devices', '#84CC16', 70),
('Gaming Devices', 'Gaming consoles and devices', '#F97316', 80)
ON CONFLICT (group_name) DO NOTHING;

-- Traffic Types (comprehensive classification)
INSERT INTO traffic_types (type_name, description, protocol, port_ranges, category, bandwidth_priority, is_system_defined) VALUES
('Web Browsing', 'HTTP/HTTPS web traffic', 'tcp', ARRAY['80', '443', '8080', '8443'], 'web', 5, true),
('Video Streaming', 'Netflix, YouTube, streaming services', 'tcp', ARRAY['443', '80', '1935', '554'], 'streaming', 8, true),
('Video Conferencing', 'Zoom, Teams, WebRTC calls', 'udp', ARRAY['3478-3481', '8801-8810', '5060-5061'], 'communication', 9, true),
('VoIP Calls', 'Voice over IP telephone calls', 'udp', ARRAY['5060-5061', '10000-20000', '1719-1720'], 'communication', 10, true),
('Gaming Traffic', 'Online gaming protocols', 'udp', ARRAY['27015', '7777-7784', '3074', '53'], 'gaming', 9, true),
('P2P File Sharing', 'BitTorrent, peer-to-peer protocols', 'tcp', ARRAY['6881-6999', '51413'], 'p2p', 1, true),
('Email Services', 'SMTP, POP3, IMAP email', 'tcp', ARRAY['25', '110', '143', '993', '995', '587'], 'email', 6, true),
('DNS Queries', 'Domain name resolution', 'udp', ARRAY['53'], 'system', 10, true),
('Social Media', 'Facebook, Twitter, Instagram', 'tcp', ARRAY['443', '80'], 'social', 4, true),
('Cloud Backup', 'Automated cloud backup services', 'tcp', ARRAY['443', '80'], 'backup', 3, true),
('Remote Desktop', 'RDP, VNC, remote access', 'tcp', ARRAY['3389', '5900', '22'], 'remote', 7, true),
('File Transfer', 'FTP, SFTP, file uploads', 'tcp', ARRAY['21', '22', '989-990'], 'transfer', 5, true),
('System Updates', 'OS and software updates', 'tcp', ARRAY['443', '80'], 'system', 4, true),
('IoT Communication', 'Smart home device traffic', 'tcp', ARRAY['1883', '8883', '5683'], 'iot', 6, true)
ON CONFLICT (type_name) DO NOTHING;

-- Network Paths (routing options)
INSERT INTO network_paths (path_name, description, gateway_ip, interface_name, path_type, bandwidth_limit_mbps, cost_factor) VALUES
('Primary ISP', 'Main internet service provider connection', '192.168.1.1', 'eth0', 'standard', 1000, 1),
('Secondary ISP', 'Backup internet connection', '192.168.2.1', 'eth1', 'failover', 500, 2),
('Local Network', 'Internal network routing', '192.168.0.1', 'br0', 'standard', NULL, 0),
('Guest Network', 'Isolated guest network path', '192.168.100.1', 'br1', 'standard', 100, 3)
ON CONFLICT (path_name) DO NOTHING;

-- Tunnels (VPN and proxy options)
INSERT INTO tunnels (tunnel_name, tunnel_type, description, endpoint_host, endpoint_port, status, location_country, location_city) VALUES
('Direct Connection', 'direct', 'No tunnel - direct routing', 'local', 0, 'active', NULL, NULL),
('WireGuard VPS 1', 'wireguard', 'Primary WireGuard VPN tunnel', 'vpn1.example.com', 51820, 'active', 'US', 'New York'),
('WireGuard VPS 2', 'wireguard', 'Secondary WireGuard VPN tunnel', 'vpn2.example.com', 51820, 'active', 'UK', 'London'),
('OpenVPN Server', 'openvpn', 'OpenVPN tunnel for legacy clients', 'ovpn.example.com', 1194, 'inactive', 'DE', 'Frankfurt'),
('SOCKS5 Proxy', 'proxy', 'SOCKS5 proxy tunnel', 'proxy.example.com', 1080, 'inactive', 'CA', 'Toronto')
ON CONFLICT (tunnel_name) DO NOTHING;

-- System Status Components
INSERT INTO system_status (component, status, metrics) VALUES
('network', 'healthy', '{"uptime": "99.9%", "latency": "12ms"}'),
('vpn', 'healthy', '{"active_tunnels": 2, "clients_connected": 15}'),
('firewall', 'healthy', '{"rules_active": 25, "blocked_attempts": 156}'),
('dns', 'healthy', '{"queries_per_second": 45, "cache_hit_rate": "89%"}'),
('dhcp', 'healthy', '{"leases_active": 23, "pool_utilization": "45%"}'),
('wifi', 'healthy', '{"networks_broadcasting": 3, "clients_connected": 18}')
ON CONFLICT (component) DO NOTHING;

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_dhcp_pools_enabled ON dhcp_pools(is_enabled);
CREATE INDEX IF NOT EXISTS idx_dhcp_reservations_mac ON dhcp_reservations(mac_address);
CREATE INDEX IF NOT EXISTS idx_wifi_networks_enabled ON wifi_networks(is_enabled);
CREATE INDEX IF NOT EXISTS idx_vlans_active ON vlans(is_active);
CREATE INDEX IF NOT EXISTS idx_vlans_id ON vlans(vlan_id);;