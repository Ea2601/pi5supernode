-- Comprehensive Routing Management Module
-- Handles routing tables, rules, BGP, OSPF, and advanced routing protocols

-- Routing Tables
CREATE TABLE IF NOT EXISTS routing_tables (
    id INTEGER PRIMARY KEY,
    table_name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    is_system_table BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Route Entries
CREATE TABLE IF NOT EXISTS route_entries (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    table_id INTEGER NOT NULL,
    destination CIDR NOT NULL,
    gateway INET,
    interface_id UUID,
    
    -- Route Properties
    route_type VARCHAR(30) DEFAULT 'unicast', -- unicast, broadcast, local, nat, unreachable, prohibit, blackhole
    scope VARCHAR(20) DEFAULT 'universe', -- universe, site, link, host
    protocol VARCHAR(30) DEFAULT 'static', -- kernel, boot, static, ra, dhcp, bird, zebra, bgp, ospf
    source VARCHAR(30) DEFAULT 'admin',
    
    -- Metrics
    metric INTEGER DEFAULT 100,
    priority INTEGER DEFAULT 100,
    weight INTEGER DEFAULT 1,
    preference INTEGER DEFAULT 100,
    
    -- Multipath Support
    is_multipath BOOLEAN DEFAULT false,
    multipath_algorithm VARCHAR(30) DEFAULT 'round_robin',
    
    -- Status
    is_enabled BOOLEAN DEFAULT true,
    age_seconds INTEGER DEFAULT 0,
    last_used TIMESTAMP WITH TIME ZONE,
    hit_count BIGINT DEFAULT 0,
    
    -- Flags
    flags TEXT[],
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Multipath Route Paths
CREATE TABLE IF NOT EXISTS multipath_routes (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    route_id UUID NOT NULL,
    gateway INET NOT NULL,
    interface_id UUID,
    weight INTEGER DEFAULT 1,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Policy-Based Routing Rules
CREATE TABLE IF NOT EXISTS routing_rules (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    priority INTEGER NOT NULL UNIQUE,
    rule_name VARCHAR(100),
    description TEXT,
    
    -- Match Criteria - Source
    match_source_address CIDR,
    match_source_prefix_length INTEGER,
    match_source_interface_id UUID,
    match_source_port INTEGER,
    match_source_not BOOLEAN DEFAULT false,
    
    -- Match Criteria - Destination
    match_dest_address CIDR,
    match_dest_prefix_length INTEGER,
    match_dest_port INTEGER,
    match_dest_not BOOLEAN DEFAULT false,
    
    -- Match Criteria - Advanced
    match_fwmark INTEGER,
    match_fwmark_mask INTEGER,
    match_tos INTEGER,
    match_protocol VARCHAR(10),
    match_uid INTEGER,
    match_gid INTEGER,
    
    -- Actions
    action_type VARCHAR(30) NOT NULL DEFAULT 'lookup', -- lookup, goto, blackhole, unreachable, prohibit
    action_table_id INTEGER,
    action_goto_priority INTEGER,
    
    -- Statistics
    match_count BIGINT DEFAULT 0,
    bytes_processed BIGINT DEFAULT 0,
    packets_processed BIGINT DEFAULT 0,
    
    -- Logging
    logging_enabled BOOLEAN DEFAULT false,
    logging_level VARCHAR(20) DEFAULT 'info',
    
    -- Status
    is_enabled BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- BGP Configuration
CREATE TABLE IF NOT EXISTS bgp_configuration (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    is_enabled BOOLEAN DEFAULT false,
    as_number INTEGER NOT NULL,
    router_id INET NOT NULL,
    cluster_id INET,
    
    -- Timers
    keepalive_timer INTEGER DEFAULT 60,
    hold_timer INTEGER DEFAULT 180,
    connect_retry_timer INTEGER DEFAULT 120,
    min_as_origination_interval INTEGER DEFAULT 15,
    min_route_advertisement_interval INTEGER DEFAULT 30,
    
    -- Advanced Features
    confederation_enabled BOOLEAN DEFAULT false,
    confederation_identifier INTEGER,
    confederation_peers INTEGER[],
    route_reflector_enabled BOOLEAN DEFAULT false,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- BGP Peers/Neighbors
CREATE TABLE IF NOT EXISTS bgp_peers (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    peer_name VARCHAR(100) NOT NULL UNIQUE,
    remote_as INTEGER NOT NULL,
    remote_ip INET NOT NULL,
    local_ip INET,
    local_as INTEGER, -- For AS override
    description TEXT,
    
    -- Authentication
    password_enabled BOOLEAN DEFAULT false,
    password_hash VARCHAR(255), -- Encrypted password
    ttl_security_enabled BOOLEAN DEFAULT false,
    ttl_security_hops INTEGER DEFAULT 1,
    
    -- Session Properties
    is_enabled BOOLEAN DEFAULT true,
    session_state VARCHAR(30) DEFAULT 'idle', -- idle, connect, active, opensent, openconfirm, established
    uptime_seconds INTEGER DEFAULT 0,
    last_reset_time TIMESTAMP WITH TIME ZONE,
    last_error_code INTEGER,
    last_error_subcode INTEGER,
    last_error_message TEXT,
    
    -- Statistics
    prefixes_received INTEGER DEFAULT 0,
    prefixes_sent INTEGER DEFAULT 0,
    prefixes_filtered INTEGER DEFAULT 0,
    messages_total INTEGER DEFAULT 0,
    messages_updates INTEGER DEFAULT 0,
    messages_keepalives INTEGER DEFAULT 0,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- BGP Routes
CREATE TABLE IF NOT EXISTS bgp_routes (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    prefix CIDR NOT NULL,
    next_hop INET NOT NULL,
    peer_id UUID NOT NULL,
    
    -- Path Attributes
    as_path INTEGER[],
    origin VARCHAR(20), -- igp, egp, incomplete
    med INTEGER,
    local_preference INTEGER DEFAULT 100,
    atomic_aggregate BOOLEAN DEFAULT false,
    aggregator_as INTEGER,
    aggregator_router_id INET,
    communities INTEGER[],
    extended_communities TEXT[],
    
    -- Route Status
    is_best BOOLEAN DEFAULT false,
    is_valid BOOLEAN DEFAULT true,
    is_selected BOOLEAN DEFAULT false,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- BGP Filters
CREATE TABLE IF NOT EXISTS bgp_prefix_lists (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    list_name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS bgp_prefix_list_entries (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    list_id UUID NOT NULL,
    sequence_number INTEGER NOT NULL,
    action VARCHAR(10) NOT NULL, -- permit, deny
    prefix CIDR NOT NULL,
    prefix_length_min INTEGER,
    prefix_length_max INTEGER,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- OSPF Configuration
CREATE TABLE IF NOT EXISTS ospf_configuration (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    is_enabled BOOLEAN DEFAULT false,
    router_id INET NOT NULL,
    reference_bandwidth INTEGER DEFAULT 100, -- Mbps
    abr_type VARCHAR(20) DEFAULT 'standard', -- standard, shortcut, cisco
    opaque_lsa_enabled BOOLEAN DEFAULT false,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- OSPF Areas
CREATE TABLE IF NOT EXISTS ospf_areas (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    area_id INET NOT NULL UNIQUE,
    area_type VARCHAR(20) DEFAULT 'normal', -- normal, stub, nssa, totally-stub, totally-nssa
    is_stub BOOLEAN DEFAULT false,
    is_nssa BOOLEAN DEFAULT false,
    default_cost INTEGER DEFAULT 1,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- OSPF Interfaces
CREATE TABLE IF NOT EXISTS ospf_interfaces (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    interface_id UUID NOT NULL,
    area_id UUID NOT NULL,
    is_enabled BOOLEAN DEFAULT true,
    
    -- Interface Properties
    interface_type VARCHAR(20) DEFAULT 'broadcast', -- broadcast, point-to-point, nbma, point-to-multipoint
    cost INTEGER DEFAULT 10,
    priority INTEGER DEFAULT 1,
    
    -- Timers
    hello_interval INTEGER DEFAULT 10,
    dead_interval INTEGER DEFAULT 40,
    retransmit_interval INTEGER DEFAULT 5,
    transmit_delay INTEGER DEFAULT 1,
    
    -- Authentication
    auth_type VARCHAR(20) DEFAULT 'none', -- none, simple, md5
    auth_key VARCHAR(255),
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- OSPF Neighbors
CREATE TABLE IF NOT EXISTS ospf_neighbors (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    router_id INET NOT NULL,
    neighbor_address INET NOT NULL,
    interface_id UUID NOT NULL,
    
    -- Neighbor State
    state VARCHAR(20) DEFAULT 'down', -- down, attempt, init, 2way, exstart, exchange, loading, full
    priority INTEGER DEFAULT 1,
    dr_address INET,
    bdr_address INET,
    
    -- Statistics
    last_hello_received TIMESTAMP WITH TIME ZONE,
    dead_timer_expiry TIMESTAMP WITH TIME ZONE,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- OSPF LSA Database
CREATE TABLE IF NOT EXISTS ospf_lsa_database (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    lsa_type INTEGER NOT NULL, -- 1=Router, 2=Network, 3=Summary, 4=ASBR-Summary, 5=AS-External
    link_state_id INET NOT NULL,
    advertising_router INET NOT NULL,
    area_id UUID,
    
    -- LSA Properties
    sequence_number INTEGER NOT NULL,
    checksum INTEGER NOT NULL,
    age INTEGER NOT NULL,
    length INTEGER NOT NULL,
    lsa_data JSONB,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_route_entries_table_id ON route_entries(table_id);
CREATE INDEX IF NOT EXISTS idx_route_entries_destination ON route_entries USING GIST(destination);
CREATE INDEX IF NOT EXISTS idx_route_entries_gateway ON route_entries(gateway);
CREATE INDEX IF NOT EXISTS idx_multipath_routes_route_id ON multipath_routes(route_id);
CREATE INDEX IF NOT EXISTS idx_routing_rules_priority ON routing_rules(priority);
CREATE INDEX IF NOT EXISTS idx_bgp_peers_remote_ip ON bgp_peers(remote_ip);
CREATE INDEX IF NOT EXISTS idx_bgp_routes_prefix ON bgp_routes USING GIST(prefix);
CREATE INDEX IF NOT EXISTS idx_bgp_routes_peer_id ON bgp_routes(peer_id);
CREATE INDEX IF NOT EXISTS idx_ospf_interfaces_interface_id ON ospf_interfaces(interface_id);
CREATE INDEX IF NOT EXISTS idx_ospf_neighbors_router_id ON ospf_neighbors(router_id);
CREATE INDEX IF NOT EXISTS idx_ospf_lsa_type_area ON ospf_lsa_database(lsa_type, area_id);

-- Insert default routing table
INSERT INTO routing_tables (id, table_name, description, is_system_table) VALUES
(254, 'main', 'Main routing table', true),
(255, 'local', 'Local routing table', true),
(0, 'unspec', 'Unspecified routing table', true)
ON CONFLICT (id) DO NOTHING;

-- Create triggers for updated_at
CREATE TRIGGER update_routing_tables_updated_at BEFORE UPDATE ON routing_tables FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_route_entries_updated_at BEFORE UPDATE ON route_entries FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_multipath_routes_updated_at BEFORE UPDATE ON multipath_routes FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_routing_rules_updated_at BEFORE UPDATE ON routing_rules FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_bgp_configuration_updated_at BEFORE UPDATE ON bgp_configuration FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_bgp_peers_updated_at BEFORE UPDATE ON bgp_peers FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_bgp_routes_updated_at BEFORE UPDATE ON bgp_routes FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_ospf_configuration_updated_at BEFORE UPDATE ON ospf_configuration FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_ospf_areas_updated_at BEFORE UPDATE ON ospf_areas FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_ospf_interfaces_updated_at BEFORE UPDATE ON ospf_interfaces FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_ospf_neighbors_updated_at BEFORE UPDATE ON ospf_neighbors FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_ospf_lsa_database_updated_at BEFORE UPDATE ON ospf_lsa_database FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();