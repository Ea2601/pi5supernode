-- Migration: populate_traffic_rules_and_setup_fixed
-- Created at: 1757160036

-- Continue populating sample data (fixed device types)

-- Advanced Traffic Rules
INSERT INTO traffic_rules (rule_name, description, user_group_id, traffic_type_id, network_path_id, tunnel_id, action, priority, bandwidth_limit_kbps) VALUES
    ('Admin Priority Access', 
     'Administrators get direct high-priority access', 
     (SELECT id FROM user_groups WHERE group_name = 'Administrators'), 
     NULL, 
     (SELECT id FROM network_paths WHERE path_name = 'Primary ISP'), 
     (SELECT id FROM tunnels WHERE tunnel_name = 'Direct Connection'), 
     'route', 1, NULL),
    
    ('Gaming Traffic Optimization', 
     'Route gaming traffic through gaming-optimized VPN', 
     (SELECT id FROM user_groups WHERE group_name = 'Gaming Devices'), 
     (SELECT id FROM traffic_types WHERE type_name = 'Gaming'), 
     (SELECT id FROM network_paths WHERE path_name = 'Primary ISP'), 
     (SELECT id FROM tunnels WHERE tunnel_name = 'Gaming VPN'), 
     'route', 10, NULL),
    
    ('Family Streaming Priority', 
     'Family devices get priority for streaming', 
     (SELECT id FROM user_groups WHERE group_name = 'Family Members'), 
     (SELECT id FROM traffic_types WHERE type_name = 'Video Streaming'), 
     (SELECT id FROM network_paths WHERE path_name = 'Primary ISP'), 
     (SELECT id FROM tunnels WHERE tunnel_name = 'Direct Connection'), 
     'route', 20, NULL),
    
    ('Guest Bandwidth Limit', 
     'Limit guest device bandwidth', 
     (SELECT id FROM user_groups WHERE group_name = 'Guests'), 
     NULL, 
     (SELECT id FROM network_paths WHERE path_name = 'Primary ISP'), 
     (SELECT id FROM tunnels WHERE tunnel_name = 'Direct Connection'), 
     'limit', 90, 10240),
    
    ('Work VPN Routing', 
     'Route work traffic through EU VPN for security', 
     (SELECT id FROM user_groups WHERE group_name = 'Work Devices'), 
     NULL, 
     (SELECT id FROM network_paths WHERE path_name = 'Primary ISP'), 
     (SELECT id FROM tunnels WHERE tunnel_name = 'EU Central VPN'), 
     'route', 30, NULL),
    
    ('IoT Device Isolation', 
     'Isolate IoT devices with bandwidth limits', 
     (SELECT id FROM user_groups WHERE group_name = 'IoT Devices'), 
     NULL, 
     (SELECT id FROM network_paths WHERE path_name = 'Local Network'), 
     (SELECT id FROM tunnels WHERE tunnel_name = 'Direct Connection'), 
     'limit', 70, 2048);

-- Quick Setup Profiles
INSERT INTO quick_setup_profiles (profile_name, description, category, icon, estimated_time_minutes, difficulty_level, can_auto_configure, setup_steps) VALUES
    ('Basic Network Setup', 
     'Configure basic network settings, DHCP, and DNS', 
     'network', 
     'network',
     15, 'easy', true,
     '[
       {"step": 1, "title": "Network Interface Configuration", "description": "Configure primary network interface", "type": "form", "fields": ["interface", "ip_address", "subnet_mask", "gateway"]},
       {"step": 2, "title": "DHCP Setup", "description": "Configure DHCP server settings", "type": "form", "fields": ["dhcp_range_start", "dhcp_range_end", "lease_time"]},
       {"step": 3, "title": "DNS Configuration", "description": "Set DNS servers and local DNS", "type": "form", "fields": ["primary_dns", "secondary_dns", "local_domain"]}
     ]'::jsonb),
    
    ('VPN Server Setup', 
     'Set up WireGuard VPN server for remote access', 
     'vpn', 
     'shield',
     20, 'medium', true,
     '[
       {"step": 1, "title": "Generate Keys", "description": "Generate WireGuard public/private keys", "type": "automated", "action": "generate_keys"},
       {"step": 2, "title": "Server Configuration", "description": "Configure VPN server settings", "type": "form", "fields": ["server_name", "listen_port", "network_range"]},
       {"step": 3, "title": "Firewall Rules", "description": "Configure firewall for VPN access", "type": "automated", "action": "setup_firewall"},
       {"step": 4, "title": "Start VPN Service", "description": "Start and enable VPN service", "type": "automated", "action": "start_service"}
     ]'::jsonb),
    
    ('Guest Network', 
     'Create isolated guest network with bandwidth limits', 
     'network', 
     'users',
     25, 'medium', false,
     '[
       {"step": 1, "title": "VLAN Creation", "description": "Create guest VLAN", "type": "form", "fields": ["vlan_id", "vlan_name", "ip_range"]},
       {"step": 2, "title": "WiFi Setup", "description": "Configure guest WiFi network", "type": "form", "fields": ["ssid", "password", "security_type"]},
       {"step": 3, "title": "Firewall Rules", "description": "Set up guest network isolation", "type": "automated", "action": "setup_guest_firewall"},
       {"step": 4, "title": "Bandwidth Limits", "description": "Configure bandwidth limitations", "type": "form", "fields": ["download_limit", "upload_limit"]}
     ]'::jsonb);

-- Sample data for existing network_devices table if they don't exist (using correct enum values)
INSERT INTO network_devices (mac_address, ip_address, device_name, device_type, device_brand, is_active, last_seen)
SELECT * FROM (VALUES 
    ('00:11:22:33:44:55', '192.168.1.100', 'Admin Laptop', 'PC'::device_type_enum, 'Dell', true, NOW()),
    ('aa:bb:cc:dd:ee:ff', '192.168.1.101', 'Gaming PC', 'PC'::device_type_enum, 'Custom Build', true, NOW()),
    ('11:22:33:44:55:66', '192.168.1.102', 'Smart TV', 'IoT'::device_type_enum, 'Samsung', true, NOW()),
    ('77:88:99:aa:bb:cc', '192.168.1.103', 'iPhone', 'Mobile'::device_type_enum, 'Apple', true, NOW()),
    ('dd:ee:ff:00:11:22', '192.168.1.104', 'Smart Thermostat', 'IoT'::device_type_enum, 'Nest', true, NOW())
) AS v(mac_address, ip_address, device_name, device_type, device_brand, is_active, last_seen)
WHERE NOT EXISTS (SELECT 1 FROM network_devices WHERE mac_address = v.mac_address);

-- Assign devices to groups
INSERT INTO group_members (group_id, device_mac_address, device_ip, device_name) VALUES
    ((SELECT id FROM user_groups WHERE group_name = 'Administrators'), '00:11:22:33:44:55', '192.168.1.100', 'Admin Laptop'),
    ((SELECT id FROM user_groups WHERE group_name = 'Gaming Devices'), 'aa:bb:cc:dd:ee:ff', '192.168.1.101', 'Gaming PC'),
    ((SELECT id FROM user_groups WHERE group_name = 'Family Members'), '11:22:33:44:55:66', '192.168.1.102', 'Smart TV'),
    ((SELECT id FROM user_groups WHERE group_name = 'Family Members'), '77:88:99:aa:bb:cc', '192.168.1.103', 'iPhone'),
    ((SELECT id FROM user_groups WHERE group_name = 'IoT Devices'), 'dd:ee:ff:00:11:22', '192.168.1.104', 'Smart Thermostat');;