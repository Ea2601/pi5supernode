-- Comprehensive WiFi Management Module
-- Handles wireless access points, client management, security, and monitoring

-- Wireless Interfaces
CREATE TABLE IF NOT EXISTS wireless_interfaces (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    interface_name VARCHAR(50) NOT NULL UNIQUE,
    physical_device VARCHAR(50), -- phy0, phy1, etc.
    interface_type VARCHAR(30) DEFAULT 'ap', -- ap, sta, monitor, mesh, ibss
    
    -- Hardware Information
    driver VARCHAR(50),
    chipset VARCHAR(100),
    supported_bands VARCHAR(20)[], -- 2.4GHz, 5GHz, 6GHz
    supported_modes VARCHAR(30)[], -- 802.11a/b/g/n/ac/ax
    max_power_dbm INTEGER,
    antenna_count INTEGER DEFAULT 1,
    
    -- Current Configuration
    is_enabled BOOLEAN DEFAULT false,
    current_channel INTEGER,
    current_frequency INTEGER, -- MHz
    current_bandwidth INTEGER DEFAULT 20, -- 20, 40, 80, 160 MHz
    current_power_dbm INTEGER,
    
    -- Regulatory Domain
    country_code VARCHAR(2) DEFAULT 'US',
    regulatory_rules JSONB DEFAULT '{}',
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Wireless Access Points
CREATE TABLE IF NOT EXISTS wireless_access_points (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    interface_id UUID NOT NULL,
    ssid VARCHAR(32) NOT NULL,
    bssid VARCHAR(17), -- MAC address of the AP
    
    -- Basic Configuration
    is_enabled BOOLEAN DEFAULT true,
    is_hidden BOOLEAN DEFAULT false,
    max_clients INTEGER DEFAULT 50,
    
    -- Wireless Settings
    channel INTEGER NOT NULL,
    channel_width INTEGER DEFAULT 20, -- 20, 40, 80, 160 MHz
    band VARCHAR(10) NOT NULL, -- 2.4GHz, 5GHz, 6GHz
    wireless_mode VARCHAR(20) DEFAULT '802.11ac', -- 802.11a/b/g/n/ac/ax
    
    -- Power and Coverage
    tx_power_dbm INTEGER DEFAULT 20,
    beacon_interval INTEGER DEFAULT 100, -- milliseconds
    dtim_period INTEGER DEFAULT 2,
    rts_threshold INTEGER DEFAULT 2347,
    fragmentation_threshold INTEGER DEFAULT 2346,
    
    -- Security Configuration
    security_mode VARCHAR(30) DEFAULT 'WPA2-PSK', -- Open, WEP, WPA-PSK, WPA2-PSK, WPA3-SAE, WPA2-Enterprise
    encryption VARCHAR(20), -- TKIP, AES, TKIP+AES
    passphrase TEXT,
    wps_enabled BOOLEAN DEFAULT false,
    wps_pin VARCHAR(8),
    
    -- Enterprise Security (802.1X)
    radius_server_ip INET,
    radius_server_port INTEGER DEFAULT 1812,
    radius_secret TEXT,
    radius_accounting_enabled BOOLEAN DEFAULT false,
    radius_accounting_port INTEGER DEFAULT 1813,
    
    -- Advanced Features
    wmm_enabled BOOLEAN DEFAULT true, -- Wi-Fi Multimedia
    ap_isolation BOOLEAN DEFAULT false,
    band_steering BOOLEAN DEFAULT false,
    load_balancing BOOLEAN DEFAULT false,
    fast_roaming_enabled BOOLEAN DEFAULT false, -- 802.11r
    
    -- Quality of Service
    qos_enabled BOOLEAN DEFAULT false,
    bandwidth_limit_down_mbps INTEGER,
    bandwidth_limit_up_mbps INTEGER,
    
    -- Guest Network
    is_guest_network BOOLEAN DEFAULT false,
    guest_isolation BOOLEAN DEFAULT true,
    guest_bandwidth_limit INTEGER,
    guest_access_schedule JSONB DEFAULT '{}',
    
    -- Status and Statistics
    status VARCHAR(20) DEFAULT 'down', -- up, down, error
    client_count INTEGER DEFAULT 0,
    total_rx_bytes BIGINT DEFAULT 0,
    total_tx_bytes BIGINT DEFAULT 0,
    noise_level_dbm INTEGER,
    channel_utilization_percent DECIMAL(5,2),
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Wireless Clients
CREATE TABLE IF NOT EXISTS wireless_clients (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    ap_id UUID NOT NULL,
    mac_address VARCHAR(17) NOT NULL,
    hostname VARCHAR(255),
    device_name VARCHAR(255),
    
    -- Connection Information
    ip_address INET,
    connected_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    last_seen TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    connection_duration INTEGER DEFAULT 0, -- seconds
    
    -- Wireless Properties
    signal_strength_dbm INTEGER,
    noise_level_dbm INTEGER,
    snr_db INTEGER, -- Signal-to-Noise Ratio
    link_quality_percent DECIMAL(5,2),
    
    -- Connection Details
    channel INTEGER,
    frequency INTEGER, -- MHz
    tx_rate_mbps DECIMAL(8,2),
    rx_rate_mbps DECIMAL(8,2),
    
    -- Capabilities
    wireless_standard VARCHAR(20), -- 802.11a/b/g/n/ac/ax
    supported_rates TEXT[],
    ht_capabilities JSONB,
    vht_capabilities JSONB,
    he_capabilities JSONB,
    
    -- Security
    authentication_method VARCHAR(30),
    encryption_method VARCHAR(20),
    
    -- Traffic Statistics
    rx_packets BIGINT DEFAULT 0,
    tx_packets BIGINT DEFAULT 0,
    rx_bytes BIGINT DEFAULT 0,
    tx_bytes BIGINT DEFAULT 0,
    rx_dropped BIGINT DEFAULT 0,
    tx_dropped BIGINT DEFAULT 0,
    rx_errors BIGINT DEFAULT 0,
    tx_errors BIGINT DEFAULT 0,
    
    -- QoS and Bandwidth
    bandwidth_limit_down_mbps INTEGER,
    bandwidth_limit_up_mbps INTEGER,
    priority_level INTEGER DEFAULT 3, -- 1-5 (1=highest)
    
    -- Device Classification
    device_type VARCHAR(50), -- smartphone, laptop, tablet, iot, etc.
    vendor VARCHAR(100),
    os_fingerprint VARCHAR(100),
    
    -- Status
    status VARCHAR(20) DEFAULT 'connected', -- connected, disconnected, blocked
    disconnect_reason VARCHAR(100),
    
    -- Access Control
    is_blocked BOOLEAN DEFAULT false,
    block_reason TEXT,
    blocked_until TIMESTAMP WITH TIME ZONE,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    UNIQUE(ap_id, mac_address)
);

-- Wireless Scanning Results
CREATE TABLE IF NOT EXISTS wireless_scan_results (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    interface_id UUID NOT NULL,
    scan_timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Network Information
    ssid VARCHAR(32),
    bssid VARCHAR(17) NOT NULL,
    channel INTEGER NOT NULL,
    frequency INTEGER NOT NULL,
    signal_strength_dbm INTEGER NOT NULL,
    
    -- Network Properties
    encryption VARCHAR(50),
    authentication VARCHAR(50),
    wireless_mode VARCHAR(20),
    channel_width INTEGER,
    
    -- Extended Information
    beacon_interval INTEGER,
    capabilities TEXT[],
    vendor VARCHAR(100),
    country_code VARCHAR(2),
    
    -- Classification
    network_type VARCHAR(20) DEFAULT 'infrastructure', -- infrastructure, adhoc, mesh
    is_hidden BOOLEAN DEFAULT false,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Wireless Security Profiles
CREATE TABLE IF NOT EXISTS wireless_security_profiles (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    profile_name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    
    -- Security Configuration
    security_mode VARCHAR(30) NOT NULL,
    encryption_method VARCHAR(20),
    
    -- PSK Configuration
    passphrase_policy JSONB DEFAULT '{}', -- min_length, complexity_rules, etc.
    passphrase_rotation_days INTEGER,
    
    -- Enterprise Configuration
    eap_method VARCHAR(30), -- PEAP, EAP-TLS, EAP-TTLS, etc.
    radius_servers JSONB DEFAULT '[]',
    certificate_authority TEXT,
    server_certificate TEXT,
    
    -- Additional Security Features
    mac_filtering_enabled BOOLEAN DEFAULT false,
    mac_filtering_mode VARCHAR(10) DEFAULT 'deny', -- allow, deny
    rate_limiting JSONB DEFAULT '{}',
    
    -- Access Control
    time_restrictions JSONB DEFAULT '{}',
    bandwidth_limits JSONB DEFAULT '{}',
    
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- MAC Address Filtering
CREATE TABLE IF NOT EXISTS wireless_mac_filters (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    ap_id UUID NOT NULL,
    mac_address VARCHAR(17) NOT NULL,
    filter_type VARCHAR(10) NOT NULL, -- allow, deny
    device_name VARCHAR(255),
    description TEXT,
    
    -- Schedule
    is_scheduled BOOLEAN DEFAULT false,
    schedule_start TIMESTAMP WITH TIME ZONE,
    schedule_end TIMESTAMP WITH TIME ZONE,
    
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    UNIQUE(ap_id, mac_address)
);

-- Wireless Performance Metrics
CREATE TABLE IF NOT EXISTS wireless_performance_metrics (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    ap_id UUID NOT NULL,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Signal and RF Metrics
    channel_utilization_percent DECIMAL(5,2),
    noise_floor_dbm INTEGER,
    interference_level VARCHAR(20), -- low, medium, high
    
    -- Throughput Metrics
    throughput_rx_mbps DECIMAL(10,2),
    throughput_tx_mbps DECIMAL(10,2),
    packet_loss_percent DECIMAL(5,2),
    
    -- Client Metrics
    active_clients INTEGER,
    avg_signal_strength_dbm INTEGER,
    avg_snr_db INTEGER,
    
    -- Error Metrics
    crc_errors BIGINT DEFAULT 0,
    phy_errors BIGINT DEFAULT 0,
    retry_count BIGINT DEFAULT 0,
    
    -- Airtime Utilization
    airtime_utilization_percent DECIMAL(5,2),
    beacon_airtime_percent DECIMAL(5,2),
    data_airtime_percent DECIMAL(5,2),
    management_airtime_percent DECIMAL(5,2)
);

-- Wireless Channel Analysis
CREATE TABLE IF NOT EXISTS wireless_channel_analysis (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    interface_id UUID NOT NULL,
    analysis_timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Channel Information
    channel INTEGER NOT NULL,
    frequency INTEGER NOT NULL,
    bandwidth INTEGER NOT NULL,
    
    -- Usage Statistics
    utilization_percent DECIMAL(5,2),
    noise_level_dbm INTEGER,
    interference_sources INTEGER,
    
    -- Network Density
    detected_networks INTEGER,
    overlapping_networks INTEGER,
    hidden_networks INTEGER,
    
    -- Quality Metrics
    channel_score INTEGER, -- 0-100 quality score
    recommendation VARCHAR(20), -- avoid, caution, good, excellent
    
    -- Interference Analysis
    microwave_interference BOOLEAN DEFAULT false,
    bluetooth_interference BOOLEAN DEFAULT false,
    radar_interference BOOLEAN DEFAULT false,
    other_interference TEXT[]
);

-- Wireless Events and Alerts
CREATE TABLE IF NOT EXISTS wireless_events (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    event_type VARCHAR(50) NOT NULL,
    severity VARCHAR(20) NOT NULL, -- info, warning, error, critical
    
    -- Associated Objects
    ap_id UUID,
    client_mac VARCHAR(17),
    interface_id UUID,
    
    -- Event Details
    event_description TEXT NOT NULL,
    event_data JSONB,
    
    -- Location and Context
    channel INTEGER,
    signal_strength_dbm INTEGER,
    
    -- Actions
    auto_action_taken VARCHAR(100),
    manual_action_required BOOLEAN DEFAULT false,
    
    -- Resolution
    is_resolved BOOLEAN DEFAULT false,
    resolved_at TIMESTAMP WITH TIME ZONE,
    resolution_notes TEXT,
    
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_wireless_access_points_interface_id ON wireless_access_points(interface_id);
CREATE INDEX IF NOT EXISTS idx_wireless_access_points_ssid ON wireless_access_points(ssid);
CREATE INDEX IF NOT EXISTS idx_wireless_access_points_channel ON wireless_access_points(channel);
CREATE INDEX IF NOT EXISTS idx_wireless_clients_ap_id ON wireless_clients(ap_id);
CREATE INDEX IF NOT EXISTS idx_wireless_clients_mac_address ON wireless_clients(mac_address);
CREATE INDEX IF NOT EXISTS idx_wireless_clients_connected_at ON wireless_clients(connected_at);
CREATE INDEX IF NOT EXISTS idx_wireless_scan_results_interface_id ON wireless_scan_results(interface_id);
CREATE INDEX IF NOT EXISTS idx_wireless_scan_results_timestamp ON wireless_scan_results(scan_timestamp);
CREATE INDEX IF NOT EXISTS idx_wireless_scan_results_bssid ON wireless_scan_results(bssid);
CREATE INDEX IF NOT EXISTS idx_wireless_mac_filters_ap_id ON wireless_mac_filters(ap_id);
CREATE INDEX IF NOT EXISTS idx_wireless_performance_metrics_ap_id ON wireless_performance_metrics(ap_id);
CREATE INDEX IF NOT EXISTS idx_wireless_performance_metrics_timestamp ON wireless_performance_metrics(timestamp);
CREATE INDEX IF NOT EXISTS idx_wireless_channel_analysis_interface_id ON wireless_channel_analysis(interface_id);
CREATE INDEX IF NOT EXISTS idx_wireless_channel_analysis_channel ON wireless_channel_analysis(channel);
CREATE INDEX IF NOT EXISTS idx_wireless_events_timestamp ON wireless_events(timestamp);
CREATE INDEX IF NOT EXISTS idx_wireless_events_type_severity ON wireless_events(event_type, severity);
CREATE INDEX IF NOT EXISTS idx_wireless_events_ap_id ON wireless_events(ap_id);

-- Create triggers for updated_at
CREATE TRIGGER update_wireless_interfaces_updated_at BEFORE UPDATE ON wireless_interfaces FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_wireless_access_points_updated_at BEFORE UPDATE ON wireless_access_points FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_wireless_clients_updated_at BEFORE UPDATE ON wireless_clients FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_wireless_security_profiles_updated_at BEFORE UPDATE ON wireless_security_profiles FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_wireless_mac_filters_updated_at BEFORE UPDATE ON wireless_mac_filters FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();