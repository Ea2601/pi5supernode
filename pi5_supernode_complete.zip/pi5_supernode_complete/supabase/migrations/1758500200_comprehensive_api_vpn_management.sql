-- Comprehensive VPN Management Module
-- Handles WireGuard, OpenVPN, IPSec, and advanced VPN features

-- WireGuard Interfaces
CREATE TABLE IF NOT EXISTS wireguard_interfaces (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    interface_name VARCHAR(50) NOT NULL UNIQUE,
    description TEXT,
    is_enabled BOOLEAN DEFAULT false,
    
    -- Keys
    private_key TEXT NOT NULL,
    public_key TEXT NOT NULL,
    preshared_key TEXT,
    
    -- Network Settings
    listen_port INTEGER,
    addresses INET[],
    mtu INTEGER DEFAULT 1420,
    
    -- Advanced Settings
    fwmark INTEGER,
    routing_table INTEGER,
    dns_servers INET[],
    
    -- Hooks/Scripts
    pre_up_script TEXT,
    post_up_script TEXT,
    pre_down_script TEXT,
    post_down_script TEXT,
    
    -- Status
    status VARCHAR(20) DEFAULT 'down', -- up, down, error
    last_handshake TIMESTAMP WITH TIME ZONE,
    bytes_rx BIGINT DEFAULT 0,
    bytes_tx BIGINT DEFAULT 0,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- WireGuard Peers
CREATE TABLE IF NOT EXISTS wireguard_peers (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    interface_id UUID NOT NULL,
    public_key TEXT NOT NULL UNIQUE,
    preshared_key TEXT,
    
    -- Peer Identity
    peer_name VARCHAR(100),
    description TEXT,
    
    -- Network Configuration
    endpoint_host VARCHAR(255),
    endpoint_port INTEGER,
    allowed_ips CIDR[],
    persistent_keepalive INTEGER,
    
    -- Status and Statistics
    is_enabled BOOLEAN DEFAULT true,
    status VARCHAR(20) DEFAULT 'disconnected', -- connected, disconnected, error
    last_handshake TIMESTAMP WITH TIME ZONE,
    handshake_age_seconds INTEGER DEFAULT 0,
    bytes_rx BIGINT DEFAULT 0,
    bytes_tx BIGINT DEFAULT 0,
    packets_rx BIGINT DEFAULT 0,
    packets_tx BIGINT DEFAULT 0,
    
    -- Connection Quality
    latency_ms INTEGER,
    packet_loss_percent DECIMAL(5,2) DEFAULT 0.00,
    connection_uptime_seconds INTEGER DEFAULT 0,
    
    -- Configuration Export
    config_format VARCHAR(20) DEFAULT 'standard',
    qr_code_size INTEGER DEFAULT 256,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- WireGuard Mesh Networks
CREATE TABLE IF NOT EXISTS wireguard_mesh_networks (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    mesh_name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    network_cidr CIDR NOT NULL,
    
    -- Mesh Configuration
    auto_routing BOOLEAN DEFAULT true,
    optimization_enabled BOOLEAN DEFAULT true,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- WireGuard Mesh Nodes
CREATE TABLE IF NOT EXISTS wireguard_mesh_nodes (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    mesh_id UUID NOT NULL,
    node_name VARCHAR(100) NOT NULL,
    peer_id UUID NOT NULL,
    node_ip INET NOT NULL,
    
    -- Node Properties
    is_hub BOOLEAN DEFAULT false,
    priority INTEGER DEFAULT 100,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- WireGuard Road Warrior Configuration
CREATE TABLE IF NOT EXISTS wireguard_roadwarrior (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    interface_id UUID NOT NULL,
    
    -- IP Pool Management
    ip_pool_start INET NOT NULL,
    ip_pool_end INET NOT NULL,
    ip_pool_subnet CIDR NOT NULL,
    
    -- DNS Configuration
    dns_servers INET[],
    dns_domain VARCHAR(255),
    
    -- Client Configuration
    default_allowed_ips CIDR[] DEFAULT '{"0.0.0.0/0", "::/0"}',
    default_persistent_keepalive INTEGER DEFAULT 25,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- WireGuard Site-to-Site Connections
CREATE TABLE IF NOT EXISTS wireguard_site_to_site (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    connection_name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    
    -- Local Site
    local_interface_id UUID NOT NULL,
    local_networks CIDR[],
    
    -- Remote Site
    remote_endpoint VARCHAR(255) NOT NULL,
    remote_port INTEGER NOT NULL,
    remote_public_key TEXT NOT NULL,
    remote_networks CIDR[],
    
    -- Failover Configuration
    failover_enabled BOOLEAN DEFAULT false,
    backup_endpoints TEXT[],
    health_check_interval INTEGER DEFAULT 30,
    
    -- Status
    connection_status VARCHAR(20) DEFAULT 'down',
    last_health_check TIMESTAMP WITH TIME ZONE,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- OpenVPN Servers
CREATE TABLE IF NOT EXISTS openvpn_servers (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    server_name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    is_enabled BOOLEAN DEFAULT false,
    
    -- Network Configuration
    protocol VARCHAR(10) DEFAULT 'udp', -- udp, tcp
    port INTEGER DEFAULT 1194,
    server_network CIDR NOT NULL,
    server_netmask INET NOT NULL,
    
    -- Encryption
    cipher VARCHAR(50) DEFAULT 'AES-256-GCM',
    auth_algorithm VARCHAR(50) DEFAULT 'SHA256',
    key_size INTEGER DEFAULT 2048,
    
    -- TLS Configuration
    ca_cert TEXT,
    server_cert TEXT,
    server_key TEXT,
    dh_params TEXT,
    tls_auth_key TEXT,
    
    -- Client Configuration
    client_to_client BOOLEAN DEFAULT false,
    duplicate_cn BOOLEAN DEFAULT false,
    compress VARCHAR(20) DEFAULT 'lz4',
    
    -- DNS and Routing
    push_dns_servers INET[],
    push_routes CIDR[],
    redirect_gateway BOOLEAN DEFAULT false,
    
    -- Status
    status VARCHAR(20) DEFAULT 'stopped',
    connected_clients INTEGER DEFAULT 0,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- OpenVPN Clients
CREATE TABLE IF NOT EXISTS openvpn_clients (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    server_id UUID NOT NULL,
    client_name VARCHAR(100) NOT NULL,
    
    -- Client Configuration
    client_cert TEXT,
    client_key TEXT,
    
    -- Connection Info
    assigned_ip INET,
    real_address INET,
    virtual_address INET,
    
    -- Status
    status VARCHAR(20) DEFAULT 'disconnected',
    connected_since TIMESTAMP WITH TIME ZONE,
    bytes_rx BIGINT DEFAULT 0,
    bytes_tx BIGINT DEFAULT 0,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    UNIQUE(server_id, client_name)
);

-- IPSec Connections
CREATE TABLE IF NOT EXISTS ipsec_connections (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    connection_name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    connection_type VARCHAR(30) DEFAULT 'site-to-site', -- site-to-site, road-warrior, host-to-host
    
    -- Local Configuration
    local_subnet CIDR,
    local_gateway INET,
    local_id VARCHAR(255),
    
    -- Remote Configuration
    remote_subnet CIDR,
    remote_gateway INET NOT NULL,
    remote_id VARCHAR(255),
    
    -- IKE Configuration
    ike_version INTEGER DEFAULT 2, -- 1 or 2
    ike_encryption VARCHAR(50) DEFAULT 'aes256',
    ike_integrity VARCHAR(50) DEFAULT 'sha256',
    ike_dh_group INTEGER DEFAULT 14,
    ike_lifetime INTEGER DEFAULT 28800,
    
    -- ESP Configuration
    esp_encryption VARCHAR(50) DEFAULT 'aes256',
    esp_integrity VARCHAR(50) DEFAULT 'sha256',
    esp_dh_group INTEGER DEFAULT 14,
    esp_lifetime INTEGER DEFAULT 3600,
    
    -- Authentication
    auth_method VARCHAR(30) DEFAULT 'psk', -- psk, cert, eap
    preshared_key TEXT,
    local_cert TEXT,
    local_key TEXT,
    ca_cert TEXT,
    
    -- Advanced Options
    dpd_enabled BOOLEAN DEFAULT true,
    dpd_interval INTEGER DEFAULT 30,
    dpd_timeout INTEGER DEFAULT 120,
    nat_traversal BOOLEAN DEFAULT true,
    
    -- Status
    status VARCHAR(20) DEFAULT 'down',
    last_established TIMESTAMP WITH TIME ZONE,
    bytes_rx BIGINT DEFAULT 0,
    bytes_tx BIGINT DEFAULT 0,
    
    is_enabled BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- VPN Performance Monitoring
CREATE TABLE IF NOT EXISTS vpn_performance_metrics (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    vpn_type VARCHAR(20) NOT NULL, -- wireguard, openvpn, ipsec
    vpn_connection_id UUID NOT NULL,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Throughput Metrics
    throughput_rx_mbps DECIMAL(10,2),
    throughput_tx_mbps DECIMAL(10,2),
    
    -- Latency Metrics
    latency_avg_ms DECIMAL(8,2),
    latency_min_ms DECIMAL(8,2),
    latency_max_ms DECIMAL(8,2),
    
    -- Packet Loss
    packet_loss_percent DECIMAL(5,2),
    
    -- Connection Quality
    jitter_ms DECIMAL(8,2),
    connection_stability_score INTEGER, -- 0-100
    
    -- Resource Usage
    cpu_usage_percent DECIMAL(5,2),
    memory_usage_bytes BIGINT,
    
    -- Error Counts
    handshake_failures INTEGER DEFAULT 0,
    authentication_failures INTEGER DEFAULT 0,
    encryption_errors INTEGER DEFAULT 0
);

-- VPN Key Rotation Management
CREATE TABLE IF NOT EXISTS vpn_key_rotation (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    vpn_type VARCHAR(20) NOT NULL,
    vpn_connection_id UUID NOT NULL,
    
    -- Rotation Settings
    rotation_enabled BOOLEAN DEFAULT false,
    rotation_interval_hours INTEGER DEFAULT 24,
    next_rotation TIMESTAMP WITH TIME ZONE,
    
    -- Key History
    current_key_id VARCHAR(100),
    previous_keys JSONB DEFAULT '[]',
    
    -- Status
    last_rotation TIMESTAMP WITH TIME ZONE,
    rotation_status VARCHAR(20) DEFAULT 'idle', -- idle, in_progress, completed, failed
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- VPN User Sessions
CREATE TABLE IF NOT EXISTS vpn_user_sessions (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    vpn_type VARCHAR(20) NOT NULL,
    vpn_connection_id UUID NOT NULL,
    user_identifier VARCHAR(255), -- username, cert CN, or peer name
    
    -- Session Information
    session_start TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    session_end TIMESTAMP WITH TIME ZONE,
    duration_seconds INTEGER,
    
    -- Connection Details
    client_ip INET,
    assigned_ip INET,
    user_agent TEXT,
    
    -- Data Transfer
    bytes_uploaded BIGINT DEFAULT 0,
    bytes_downloaded BIGINT DEFAULT 0,
    
    -- Session Status
    status VARCHAR(20) DEFAULT 'active', -- active, disconnected, expired, terminated
    disconnect_reason VARCHAR(100),
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_wireguard_peers_interface_id ON wireguard_peers(interface_id);
CREATE INDEX IF NOT EXISTS idx_wireguard_peers_public_key ON wireguard_peers(public_key);
CREATE INDEX IF NOT EXISTS idx_wireguard_mesh_nodes_mesh_id ON wireguard_mesh_nodes(mesh_id);
CREATE INDEX IF NOT EXISTS idx_openvpn_clients_server_id ON openvpn_clients(server_id);
CREATE INDEX IF NOT EXISTS idx_ipsec_connections_remote_gateway ON ipsec_connections(remote_gateway);
CREATE INDEX IF NOT EXISTS idx_vpn_performance_metrics_timestamp ON vpn_performance_metrics(timestamp);
CREATE INDEX IF NOT EXISTS idx_vpn_performance_metrics_connection ON vpn_performance_metrics(vpn_type, vpn_connection_id);
CREATE INDEX IF NOT EXISTS idx_vpn_user_sessions_vpn_connection ON vpn_user_sessions(vpn_type, vpn_connection_id);
CREATE INDEX IF NOT EXISTS idx_vpn_user_sessions_user ON vpn_user_sessions(user_identifier);
CREATE INDEX IF NOT EXISTS idx_vpn_user_sessions_start_time ON vpn_user_sessions(session_start);

-- Create triggers for updated_at
CREATE TRIGGER update_wireguard_interfaces_updated_at BEFORE UPDATE ON wireguard_interfaces FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_wireguard_peers_updated_at BEFORE UPDATE ON wireguard_peers FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_wireguard_mesh_networks_updated_at BEFORE UPDATE ON wireguard_mesh_networks FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_wireguard_mesh_nodes_updated_at BEFORE UPDATE ON wireguard_mesh_nodes FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_wireguard_roadwarrior_updated_at BEFORE UPDATE ON wireguard_roadwarrior FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_wireguard_site_to_site_updated_at BEFORE UPDATE ON wireguard_site_to_site FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_openvpn_servers_updated_at BEFORE UPDATE ON openvpn_servers FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_openvpn_clients_updated_at BEFORE UPDATE ON openvpn_clients FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_ipsec_connections_updated_at BEFORE UPDATE ON ipsec_connections FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_vpn_key_rotation_updated_at BEFORE UPDATE ON vpn_key_rotation FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();