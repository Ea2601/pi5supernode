-- Comprehensive DNS & DHCP Services Module
-- Handles DNS server, DHCP server, dynamic DNS, and zone management

-- DHCP Server Global Configuration
CREATE TABLE IF NOT EXISTS dhcp_server_config (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    is_enabled BOOLEAN DEFAULT false,
    server_mode VARCHAR(20) DEFAULT 'authoritative', -- authoritative, relay, disabled
    
    -- Global DHCP Settings
    default_lease_time INTEGER DEFAULT 86400, -- 24 hours
    max_lease_time INTEGER DEFAULT 172800, -- 48 hours
    min_lease_time INTEGER DEFAULT 3600, -- 1 hour
    
    -- Server Behavior
    ping_check_enabled BOOLEAN DEFAULT true,
    ping_timeout_ms INTEGER DEFAULT 1000,
    one_lease_per_client BOOLEAN DEFAULT false,
    deny_unknown_clients BOOLEAN DEFAULT false,
    
    -- DDNS Integration
    ddns_update_enabled BOOLEAN DEFAULT false,
    ddns_update_style VARCHAR(20) DEFAULT 'standard', -- standard, interim, none
    ddns_domainname VARCHAR(255),
    
    -- Logging
    log_facility VARCHAR(20) DEFAULT 'daemon',
    log_level VARCHAR(20) DEFAULT 'info',
    
    -- Advanced Options
    authoritative BOOLEAN DEFAULT true,
    boot_unknown_clients BOOLEAN DEFAULT true,
    always_reply_rfc1048 BOOLEAN DEFAULT true,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- DHCP Pools/Scopes
CREATE TABLE IF NOT EXISTS dhcp_pools (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    pool_name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    interface_id UUID, -- Interface this pool serves
    
    -- Network Configuration
    network CIDR NOT NULL,
    start_ip INET NOT NULL,
    end_ip INET NOT NULL,
    
    -- Gateway and DNS
    gateway INET,
    dns_servers INET[],
    dns_domain VARCHAR(255),
    
    -- Lease Settings
    default_lease_time INTEGER, -- Inherits from global if NULL
    max_lease_time INTEGER,
    min_lease_time INTEGER,
    
    -- Advanced Options
    allow_unknown_clients BOOLEAN DEFAULT true,
    allow_bootp BOOLEAN DEFAULT true,
    allow_booting BOOLEAN DEFAULT true,
    
    -- DHCP Options
    domain_name VARCHAR(255),
    domain_search VARCHAR(255)[],
    ntp_servers INET[],
    tftp_server VARCHAR(255),
    boot_filename VARCHAR(255),
    
    -- Network Boot (PXE)
    pxe_enabled BOOLEAN DEFAULT false,
    pxe_server INET,
    pxe_filename VARCHAR(255),
    
    -- Statistics
    total_addresses INTEGER,
    allocated_addresses INTEGER DEFAULT 0,
    available_addresses INTEGER,
    utilization_percent DECIMAL(5,2) DEFAULT 0,
    
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- DHCP Reservations
CREATE TABLE IF NOT EXISTS dhcp_reservations (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    pool_id UUID NOT NULL,
    mac_address VARCHAR(17) NOT NULL UNIQUE,
    ip_address INET NOT NULL,
    hostname VARCHAR(255),
    description TEXT,
    
    -- Client Identification
    client_id VARCHAR(255),
    vendor_class VARCHAR(255),
    
    -- Custom DHCP Options
    custom_options JSONB DEFAULT '{}',
    
    -- Lease Override
    lease_time_override INTEGER,
    
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- DHCP Leases
CREATE TABLE IF NOT EXISTS dhcp_leases (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    pool_id UUID NOT NULL,
    mac_address VARCHAR(17) NOT NULL,
    ip_address INET NOT NULL,
    hostname VARCHAR(255),
    
    -- Client Information
    client_id VARCHAR(255),
    vendor_class VARCHAR(255),
    vendor_name VARCHAR(255),
    hardware_type INTEGER DEFAULT 1, -- 1 = Ethernet
    
    -- Lease Information
    lease_start TIMESTAMP WITH TIME ZONE NOT NULL,
    lease_end TIMESTAMP WITH TIME ZONE NOT NULL,
    lease_duration INTEGER, -- seconds
    
    -- Lease State
    state VARCHAR(20) DEFAULT 'active', -- active, expired, released, declined
    binding_state VARCHAR(20) DEFAULT 'active', -- active, free, backup, abandoned
    
    -- Client Fingerprinting
    dhcp_fingerprint VARCHAR(255),
    user_agent VARCHAR(255),
    
    -- Location and Context
    relay_agent_ip INET,
    circuit_id VARCHAR(255),
    remote_id VARCHAR(255),
    
    -- Statistics
    request_count INTEGER DEFAULT 1,
    last_request TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    UNIQUE(ip_address, lease_start)
);

-- DNS Server Configuration
CREATE TABLE IF NOT EXISTS dns_server_config (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    is_enabled BOOLEAN DEFAULT false,
    
    -- Server Settings
    listen_addresses INET[] DEFAULT '{"0.0.0.0"}',
    listen_port INTEGER DEFAULT 53,
    
    -- Forwarders
    forwarders INET[],
    forward_first BOOLEAN DEFAULT false,
    forward_only BOOLEAN DEFAULT false,
    
    -- Recursion
    recursion_enabled BOOLEAN DEFAULT true,
    allow_recursion CIDR[] DEFAULT '{"192.168.0.0/16", "10.0.0.0/8", "172.16.0.0/12"}',
    
    -- Query Restrictions
    allow_query CIDR[] DEFAULT '{"any"}',
    allow_transfer CIDR[],
    blackhole CIDR[],
    
    -- Cache Settings
    cache_enabled BOOLEAN DEFAULT true,
    max_cache_size VARCHAR(20) DEFAULT '100M',
    max_cache_ttl INTEGER DEFAULT 86400,
    min_cache_ttl INTEGER DEFAULT 60,
    
    -- DNSSEC
    dnssec_enabled BOOLEAN DEFAULT false,
    dnssec_validation VARCHAR(20) DEFAULT 'auto', -- yes, no, auto
    
    -- Logging
    query_logging BOOLEAN DEFAULT false,
    log_level VARCHAR(20) DEFAULT 'info',
    
    -- Advanced Options
    notify_enabled BOOLEAN DEFAULT true,
    empty_zones_enable BOOLEAN DEFAULT true,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- DNS Zones
CREATE TABLE IF NOT EXISTS dns_zones (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    zone_name VARCHAR(255) NOT NULL UNIQUE,
    zone_type VARCHAR(20) NOT NULL DEFAULT 'primary', -- primary, secondary, stub, forward
    zone_class VARCHAR(10) DEFAULT 'IN', -- IN, CH, HS
    
    -- Zone Configuration
    zone_file VARCHAR(255),
    
    -- SOA Record Information
    primary_ns VARCHAR(255),
    admin_email VARCHAR(255),
    serial_number BIGINT,
    refresh_interval INTEGER DEFAULT 3600,
    retry_interval INTEGER DEFAULT 900,
    expire_interval INTEGER DEFAULT 1209600,
    minimum_ttl INTEGER DEFAULT 3600,
    
    -- Secondary Zone Configuration
    master_servers INET[],
    
    -- Transfer Settings
    allow_transfer CIDR[],
    also_notify INET[],
    
    -- DNSSEC
    dnssec_enabled BOOLEAN DEFAULT false,
    auto_dnssec VARCHAR(20) DEFAULT 'off', -- off, allow, maintain
    
    -- Dynamic Updates
    allow_update CIDR[],
    update_policy TEXT,
    
    -- Statistics
    record_count INTEGER DEFAULT 0,
    last_loaded TIMESTAMP WITH TIME ZONE,
    
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- DNS Records
CREATE TABLE IF NOT EXISTS dns_records (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    zone_id UUID NOT NULL,
    record_name VARCHAR(255) NOT NULL,
    record_type VARCHAR(10) NOT NULL, -- A, AAAA, CNAME, MX, NS, PTR, TXT, SRV, etc.
    record_class VARCHAR(10) DEFAULT 'IN',
    
    -- Record Data
    record_data TEXT NOT NULL,
    ttl INTEGER DEFAULT 3600,
    priority INTEGER, -- For MX, SRV records
    weight INTEGER, -- For SRV records
    port INTEGER, -- For SRV records
    
    -- Record Metadata
    comment TEXT,
    
    -- Dynamic Record Properties
    is_dynamic BOOLEAN DEFAULT false,
    dynamic_source VARCHAR(50), -- dhcp, manual, api
    
    -- DNSSEC
    dnssec_signed BOOLEAN DEFAULT false,
    
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    UNIQUE(zone_id, record_name, record_type)
);

-- DNS Query Log
CREATE TABLE IF NOT EXISTS dns_query_log (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Query Information
    client_ip INET NOT NULL,
    client_port INTEGER,
    query_name VARCHAR(255) NOT NULL,
    query_type VARCHAR(10) NOT NULL,
    query_class VARCHAR(10) DEFAULT 'IN',
    
    -- Response Information
    response_code VARCHAR(20), -- NOERROR, NXDOMAIN, REFUSED, etc.
    answer_count INTEGER DEFAULT 0,
    authority_count INTEGER DEFAULT 0,
    additional_count INTEGER DEFAULT 0,
    
    -- Query Flags
    recursive_query BOOLEAN DEFAULT false,
    authoritative_answer BOOLEAN DEFAULT false,
    
    -- Performance
    query_time_ms DECIMAL(8,3),
    
    -- Security
    blocked BOOLEAN DEFAULT false,
    block_reason VARCHAR(100),
    
    -- Geolocation
    client_country VARCHAR(2),
    client_city VARCHAR(100)
);

-- Dynamic DNS Configuration
CREATE TABLE IF NOT EXISTS ddns_config (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    is_enabled BOOLEAN DEFAULT false,
    
    -- Update Method
    update_method VARCHAR(20) DEFAULT 'rfc2136', -- rfc2136, nsupdate, api
    
    -- Security
    require_authentication BOOLEAN DEFAULT true,
    allowed_keys TEXT[],
    
    -- Update Policies
    allow_reverse_updates BOOLEAN DEFAULT true,
    conflict_resolution VARCHAR(20) DEFAULT 'replace', -- replace, append, deny
    
    -- TTL Settings
    default_ttl INTEGER DEFAULT 300,
    max_ttl INTEGER DEFAULT 3600,
    min_ttl INTEGER DEFAULT 60,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- DDNS Update Log
CREATE TABLE IF NOT EXISTS ddns_update_log (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Update Information
    client_ip INET NOT NULL,
    update_type VARCHAR(20) NOT NULL, -- add, delete, replace
    record_name VARCHAR(255) NOT NULL,
    record_type VARCHAR(10) NOT NULL,
    record_data TEXT,
    
    -- Authentication
    authenticated BOOLEAN DEFAULT false,
    auth_method VARCHAR(20), -- key, password, none
    key_name VARCHAR(100),
    
    -- Result
    update_status VARCHAR(20) NOT NULL, -- success, failed, denied
    error_message TEXT,
    
    -- Context
    hostname VARCHAR(255),
    user_agent VARCHAR(255)
);

-- DNS Statistics
CREATE TABLE IF NOT EXISTS dns_statistics (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Query Statistics
    total_queries INTEGER DEFAULT 0,
    successful_queries INTEGER DEFAULT 0,
    failed_queries INTEGER DEFAULT 0,
    recursive_queries INTEGER DEFAULT 0,
    
    -- Query Types
    a_queries INTEGER DEFAULT 0,
    aaaa_queries INTEGER DEFAULT 0,
    mx_queries INTEGER DEFAULT 0,
    ptr_queries INTEGER DEFAULT 0,
    txt_queries INTEGER DEFAULT 0,
    srv_queries INTEGER DEFAULT 0,
    other_queries INTEGER DEFAULT 0,
    
    -- Response Codes
    noerror_responses INTEGER DEFAULT 0,
    nxdomain_responses INTEGER DEFAULT 0,
    refused_responses INTEGER DEFAULT 0,
    servfail_responses INTEGER DEFAULT 0,
    
    -- Performance
    average_query_time_ms DECIMAL(8,3),
    cache_hit_rate_percent DECIMAL(5,2),
    
    -- Security
    blocked_queries INTEGER DEFAULT 0,
    malware_domains_blocked INTEGER DEFAULT 0,
    
    -- Top Queried Domains
    top_domains JSONB DEFAULT '{}',
    top_clients JSONB DEFAULT '{}'
);

-- DNS Blacklist/Blocklist
CREATE TABLE IF NOT EXISTS dns_blocklist (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    domain_pattern VARCHAR(255) NOT NULL,
    block_type VARCHAR(20) DEFAULT 'exact', -- exact, wildcard, regex
    category VARCHAR(50), -- malware, ads, tracking, adult, social, etc.
    
    -- Block Configuration
    block_action VARCHAR(20) DEFAULT 'nxdomain', -- nxdomain, redirect, refuse
    redirect_ip INET, -- For redirect action
    
    -- Source Information
    source VARCHAR(100), -- manual, blacklist_feed, security_report
    source_url TEXT,
    
    -- Metadata
    description TEXT,
    severity VARCHAR(20) DEFAULT 'medium', -- low, medium, high, critical
    
    -- Statistics
    hit_count BIGINT DEFAULT 0,
    last_hit TIMESTAMP WITH TIME ZONE,
    
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_dhcp_pools_interface_id ON dhcp_pools(interface_id);
CREATE INDEX IF NOT EXISTS idx_dhcp_pools_network ON dhcp_pools USING GIST(network);
CREATE INDEX IF NOT EXISTS idx_dhcp_reservations_pool_id ON dhcp_reservations(pool_id);
CREATE INDEX IF NOT EXISTS idx_dhcp_reservations_mac ON dhcp_reservations(mac_address);
CREATE INDEX IF NOT EXISTS idx_dhcp_reservations_ip ON dhcp_reservations(ip_address);
CREATE INDEX IF NOT EXISTS idx_dhcp_leases_pool_id ON dhcp_leases(pool_id);
CREATE INDEX IF NOT EXISTS idx_dhcp_leases_mac ON dhcp_leases(mac_address);
CREATE INDEX IF NOT EXISTS idx_dhcp_leases_ip ON dhcp_leases(ip_address);
CREATE INDEX IF NOT EXISTS idx_dhcp_leases_state ON dhcp_leases(state);
CREATE INDEX IF NOT EXISTS idx_dhcp_leases_end_time ON dhcp_leases(lease_end);
CREATE INDEX IF NOT EXISTS idx_dns_zones_name ON dns_zones(zone_name);
CREATE INDEX IF NOT EXISTS idx_dns_zones_type ON dns_zones(zone_type);
CREATE INDEX IF NOT EXISTS idx_dns_records_zone_id ON dns_records(zone_id);
CREATE INDEX IF NOT EXISTS idx_dns_records_name ON dns_records(record_name);
CREATE INDEX IF NOT EXISTS idx_dns_records_type ON dns_records(record_type);
CREATE INDEX IF NOT EXISTS idx_dns_records_name_type ON dns_records(zone_id, record_name, record_type);
CREATE INDEX IF NOT EXISTS idx_dns_query_log_timestamp ON dns_query_log(timestamp);
CREATE INDEX IF NOT EXISTS idx_dns_query_log_client_ip ON dns_query_log(client_ip);
CREATE INDEX IF NOT EXISTS idx_dns_query_log_query_name ON dns_query_log(query_name);
CREATE INDEX IF NOT EXISTS idx_ddns_update_log_timestamp ON ddns_update_log(timestamp);
CREATE INDEX IF NOT EXISTS idx_ddns_update_log_client_ip ON ddns_update_log(client_ip);
CREATE INDEX IF NOT EXISTS idx_dns_statistics_timestamp ON dns_statistics(timestamp);
CREATE INDEX IF NOT EXISTS idx_dns_blocklist_domain ON dns_blocklist(domain_pattern);
CREATE INDEX IF NOT EXISTS idx_dns_blocklist_category ON dns_blocklist(category);

-- Create triggers for updated_at
CREATE TRIGGER update_dhcp_server_config_updated_at BEFORE UPDATE ON dhcp_server_config FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_dhcp_pools_updated_at BEFORE UPDATE ON dhcp_pools FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_dhcp_reservations_updated_at BEFORE UPDATE ON dhcp_reservations FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_dhcp_leases_updated_at BEFORE UPDATE ON dhcp_leases FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_dns_server_config_updated_at BEFORE UPDATE ON dns_server_config FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_dns_zones_updated_at BEFORE UPDATE ON dns_zones FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_dns_records_updated_at BEFORE UPDATE ON dns_records FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_ddns_config_updated_at BEFORE UPDATE ON ddns_config FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_dns_blocklist_updated_at BEFORE UPDATE ON dns_blocklist FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();