-- Migration: populate_pi5_system_data
-- Created at: 1757159941

-- Insert sample data for the Pi5 Supernode system

-- User Groups
INSERT INTO user_groups (group_name, description, color_code, priority) VALUES
    ('Administrators', 'System administrators and power users', '#EF4444', 1),
    ('Family Members', 'Family devices with standard access', '#10B981', 50),
    ('Guests', 'Guest devices with limited access', '#F59E0B', 100),
    ('Gaming Devices', 'Gaming consoles and high-priority gaming traffic', '#8B5CF6', 20),
    ('IoT Devices', 'Smart home and IoT devices', '#06B6D4', 80),
    ('Work Devices', 'Work laptops and business traffic', '#3B82F6', 30);

-- Traffic Types
INSERT INTO traffic_types (type_name, description, protocol, port_ranges, category, bandwidth_priority) VALUES
    ('Web Browsing', 'HTTP/HTTPS web traffic', 'TCP', ARRAY['80', '443'], 'web', 5),
    ('Video Streaming', 'Netflix, YouTube, streaming services', 'TCP', ARRAY['80', '443', '1935', '8080'], 'streaming', 8),
    ('Gaming', 'Online gaming traffic', 'UDP', ARRAY['3478-3480', '27000-28000'], 'gaming', 9),
    ('Video Calls', 'Zoom, Teams, video conferencing', 'UDP', ARRAY['8801-8810', '3478-3481'], 'communication', 9),
    ('File Downloads', 'Large file downloads and P2P', 'TCP', ARRAY['6881-6999', '1337'], 'downloads', 2),
    ('Email', 'SMTP, IMAP, POP3 email traffic', 'TCP', ARRAY['25', '587', '993', '995'], 'email', 6),
    ('SSH/Remote Access', 'SSH, RDP, remote access protocols', 'TCP', ARRAY['22', '3389', '5900'], 'remote', 7),
    ('DNS', 'Domain name system queries', 'UDP', ARRAY['53'], 'system', 10),
    ('Social Media', 'Facebook, Twitter, Instagram apps', 'TCP', ARRAY['80', '443'], 'social', 4),
    ('Cloud Storage', 'Dropbox, Google Drive, OneDrive sync', 'TCP', ARRAY['80', '443'], 'cloud', 3);

-- Network Paths
INSERT INTO network_paths (path_name, description, gateway_ip, interface_name, path_type, bandwidth_limit_mbps, latency_ms, reliability_score) VALUES
    ('Primary ISP', 'Main internet connection via Fiber', '192.168.1.1', 'eth0', 'standard', 1000, 15, 98),
    ('Backup ISP', 'Secondary internet via Cable', '192.168.2.1', 'eth1', 'failover', 100, 25, 95),
    ('Local Network', 'Internal LAN routing', '192.168.0.1', 'br0', 'standard', 10000, 1, 100),
    ('Mobile Hotspot', 'Emergency mobile connection', '192.168.3.1', 'wwan0', 'emergency', 50, 80, 85),
    ('Starlink Backup', 'Satellite internet backup', '192.168.4.1', 'eth2', 'failover', 200, 40, 90);

-- Tunnels
INSERT INTO tunnels (tunnel_name, tunnel_type, description, endpoint_host, endpoint_port, status, bandwidth_limit_mbps, location_country, location_city, ping_ms, uptime_percentage) VALUES
    ('US East VPN', 'wireguard', 'WireGuard tunnel to US East Coast', 'us-east.vpn.example.com', 51820, 'active', 500, 'US', 'New York', 45, 99.8),
    ('EU Central VPN', 'wireguard', 'WireGuard tunnel to European servers', 'eu-central.vpn.example.com', 51820, 'active', 300, 'DE', 'Frankfurt', 85, 99.5),
    ('Asia Pacific VPN', 'wireguard', 'WireGuard tunnel to Asia Pacific', 'ap.vpn.example.com', 51820, 'inactive', 200, 'SG', 'Singapore', 180, 99.2),
    ('Gaming VPN', 'wireguard', 'Low-latency gaming optimized tunnel', 'gaming.vpn.example.com', 51820, 'active', 1000, 'US', 'Los Angeles', 25, 99.9),
    ('Privacy Proxy', 'proxy', 'HTTP/HTTPS privacy proxy', 'privacy.proxy.example.com', 8080, 'active', 100, 'CH', 'Zurich', 60, 99.0),
    ('Direct Connection', 'direct', 'Direct internet access (no tunnel)', 'direct', 0, 'active', 1000, 'LOCAL', 'Local', 0, 100.0);

-- Advanced Traffic Rules
INSERT INTO traffic_rules (rule_name, description, user_group_id, traffic_type_id, network_path_id, tunnel_id, action, priority, bandwidth_limit_kbps) VALUES
    ('Admin Priority Access', 
     'Administrators get direct high-priority access', 
     (SELECT id FROM user_groups WHERE group_name = 'Administrators'), 
     NULL, 
     (SELECT id FROM network_paths WHERE path_name = 'Primary ISP'), 
     (SELECT id FROM tunnels WHERE tunnel_name = 'Direct Connection'), 
     'route', 1, NULL),
    
    ('Gaming Traffic Optimization', 
     'Route gaming traffic through gaming-optimized VPN', 
     (SELECT id FROM user_groups WHERE group_name = 'Gaming Devices'), 
     (SELECT id FROM traffic_types WHERE type_name = 'Gaming'), 
     (SELECT id FROM network_paths WHERE path_name = 'Primary ISP'), 
     (SELECT id FROM tunnels WHERE tunnel_name = 'Gaming VPN'), 
     'route', 10, NULL),
    
    ('Family Streaming Priority', 
     'Family devices get priority for streaming', 
     (SELECT id FROM user_groups WHERE group_name = 'Family Members'), 
     (SELECT id FROM traffic_types WHERE type_name = 'Video Streaming'), 
     (SELECT id FROM network_paths WHERE path_name = 'Primary ISP'), 
     (SELECT id FROM tunnels WHERE tunnel_name = 'Direct Connection'), 
     'route', 20, NULL),
    
    ('Guest Bandwidth Limit', 
     'Limit guest device bandwidth', 
     (SELECT id FROM user_groups WHERE group_name = 'Guests'), 
     NULL, 
     (SELECT id FROM network_paths WHERE path_name = 'Primary ISP'), 
     (SELECT id FROM tunnels WHERE tunnel_name = 'Direct Connection'), 
     'limit', 90, 10240),
    
    ('Work VPN Routing', 
     'Route work traffic through EU VPN for security', 
     (SELECT id FROM user_groups WHERE group_name = 'Work Devices'), 
     NULL, 
     (SELECT id FROM network_paths WHERE path_name = 'Primary ISP'), 
     (SELECT id FROM tunnels WHERE tunnel_name = 'EU Central VPN'), 
     'route', 30, NULL),
    
    ('IoT Device Isolation', 
     'Isolate IoT devices with bandwidth limits', 
     (SELECT id FROM user_groups WHERE group_name = 'IoT Devices'), 
     NULL, 
     (SELECT id FROM network_paths WHERE path_name = 'Local Network'), 
     (SELECT id FROM tunnels WHERE tunnel_name = 'Direct Connection'), 
     'limit', 70, 2048);

-- Quick Setup Profiles
INSERT INTO quick_setup_profiles (profile_name, description, category, icon, setup_steps, estimated_time_minutes, difficulty_level, can_auto_configure) VALUES
    ('Basic Network Setup', 
     'Configure basic network settings, DHCP, and DNS', 
     'network', 
     'network',
     '[
       {"step": 1, "title": "Network Interface Configuration", "description": "Configure primary network interface", "type": "form", "fields": ["interface", "ip_address", "subnet_mask", "gateway"]},
       {"step": 2, "title": "DHCP Setup", "description": "Configure DHCP server settings", "type": "form", "fields": ["dhcp_range_start", "dhcp_range_end", "lease_time"]},
       {"step": 3, "title": "DNS Configuration", "description": "Set DNS servers and local DNS", "type": "form", "fields": ["primary_dns", "secondary_dns", "local_domain"]}
     ]'::jsonb,
     15, 'easy', true),
    
    ('VPN Server Setup', 
     'Set up WireGuard VPN server for remote access', 
     'vpn', 
     'shield',
     '[
       {"step": 1, "title": "Generate Keys", "description": "Generate WireGuard public/private keys", "type": "automated", "action": "generate_keys"},
       {"step": 2, "title": "Server Configuration", "description": "Configure VPN server settings", "type": "form", "fields": ["server_name", "listen_port", "network_range"]},
       {"step": 3, "title": "Firewall Rules", "description": "Configure firewall for VPN access", "type": "automated", "action": "setup_firewall"},
       {"step": 4, "title": "Start VPN Service", "description": "Start and enable VPN service", "type": "automated", "action": "start_service"}
     ]'::jsonb,
     20, 'medium', true),
    
    ('Guest Network', 
     'Create isolated guest network with bandwidth limits', 
     'network', 
     'users',
     '[
       {"step": 1, "title": "VLAN Creation", "description": "Create guest VLAN", "type": "form", "fields": ["vlan_id", "vlan_name", "ip_range"]},
       {"step": 2, "title": "WiFi Setup", "description": "Configure guest WiFi network", "type": "form", "fields": ["ssid", "password", "security_type"]},
       {"step": 3, "title": "Firewall Rules", "description": "Set up guest network isolation", "type": "automated", "action": "setup_guest_firewall"},
       {"step": 4, "title": "Bandwidth Limits", "description": "Configure bandwidth limitations", "type": "form", "fields": ["download_limit", "upload_limit"]}
     ]'::jsonb,
     25, 'medium', false),
    
    ('Security Hardening', 
     'Apply security best practices and hardening', 
     'security', 
     'lock',
     '[
       {"step": 1, "title": "Firewall Configuration", "description": "Enable and configure firewall", "type": "automated", "action": "enable_firewall"},
       {"step": 2, "title": "SSH Security", "description": "Harden SSH configuration", "type": "form", "fields": ["ssh_port", "disable_root_login", "key_auth_only"]},
       {"step": 3, "title": "Fail2Ban Setup", "description": "Install and configure Fail2Ban", "type": "automated", "action": "setup_fail2ban"},
       {"step": 4, "title": "Update System", "description": "Update system packages", "type": "automated", "action": "system_update"}
     ]'::jsonb,
     30, 'advanced', true),
    
    ('Performance Optimization', 
     'Optimize system performance and network settings', 
     'performance', 
     'activity',
     '[
       {"step": 1, "title": "CPU Governor", "description": "Set CPU governor for performance", "type": "automated", "action": "set_cpu_governor"},
       {"step": 2, "title": "Network Tuning", "description": "Optimize network buffer sizes", "type": "automated", "action": "tune_network"},
       {"step": 3, "title": "Memory Settings", "description": "Configure memory management", "type": "form", "fields": ["swappiness", "cache_pressure"]},
       {"step": 4, "title": "Disk I/O", "description": "Optimize disk I/O scheduler", "type": "automated", "action": "optimize_io"}
     ]'::jsonb,
     15, 'advanced', true);

-- System Status
INSERT INTO system_status (component, status, response_time_ms, uptime_percentage) VALUES
    ('network', 'healthy', 5, 99.9),
    ('vpn', 'healthy', 15, 99.5),
    ('firewall', 'healthy', 2, 100.0),
    ('dns', 'healthy', 8, 99.8),
    ('dhcp', 'healthy', 3, 100.0),
    ('monitoring', 'healthy', 12, 99.7);

-- Sample Notifications
INSERT INTO notifications (notification_type, severity, title, message, target_roles, channels, action_buttons) VALUES
    ('system', 'info', 'System Started Successfully', 'Pi5 Supernode system has started and all components are operational.', ARRAY['admin', 'operator'], ARRAY['web'], '[]'::jsonb),
    ('alert', 'warning', 'High Bandwidth Usage', 'Bandwidth usage has exceeded 80% of available capacity.', ARRAY['admin'], ARRAY['web', 'email'], '[{"label": "View Details", "action": "view_bandwidth"}, {"label": "Dismiss", "action": "dismiss"}]'::jsonb),
    ('system', 'info', 'VPN Server Ready', 'WireGuard VPN server is configured and ready for client connections.', ARRAY['admin'], ARRAY['web'], '[{"label": "Download Config", "action": "download_vpn_config"}]'::jsonb);

-- Sample data for existing network_devices table
INSERT INTO network_devices (mac_address, ip_address, device_name, device_type, device_brand, is_active, last_seen) VALUES
    ('00:11:22:33:44:55', '192.168.1.100', 'Admin Laptop', 'laptop', 'Dell', true, NOW()),
    ('aa:bb:cc:dd:ee:ff', '192.168.1.101', 'Gaming PC', 'desktop', 'Custom Build', true, NOW()),
    ('11:22:33:44:55:66', '192.168.1.102', 'Smart TV', 'smart_tv', 'Samsung', true, NOW()),
    ('77:88:99:aa:bb:cc', '192.168.1.103', 'iPhone', 'smartphone', 'Apple', true, NOW()),
    ('dd:ee:ff:00:11:22', '192.168.1.104', 'Smart Thermostat', 'iot', 'Nest', true, NOW());

-- Assign devices to groups
INSERT INTO group_members (group_id, device_mac_address, device_ip, device_name) VALUES
    ((SELECT id FROM user_groups WHERE group_name = 'Administrators'), '00:11:22:33:44:55', '192.168.1.100', 'Admin Laptop'),
    ((SELECT id FROM user_groups WHERE group_name = 'Gaming Devices'), 'aa:bb:cc:dd:ee:ff', '192.168.1.101', 'Gaming PC'),
    ((SELECT id FROM user_groups WHERE group_name = 'Family Members'), '11:22:33:44:55:66', '192.168.1.102', 'Smart TV'),
    ((SELECT id FROM user_groups WHERE group_name = 'Family Members'), '77:88:99:aa:bb:cc', '192.168.1.103', 'iPhone'),
    ((SELECT id FROM user_groups WHERE group_name = 'IoT Devices'), 'dd:ee:ff:00:11:22', '192.168.1.104', 'Smart Thermostat');;