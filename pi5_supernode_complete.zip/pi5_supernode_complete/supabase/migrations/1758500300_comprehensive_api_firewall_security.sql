-- Comprehensive Firewall & Security Module
-- Handles iptables/netfilter, NAT, connection tracking, and security policies

-- Firewall Tables (iptables tables)
CREATE TABLE IF NOT EXISTS firewall_tables (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    table_name VARCHAR(30) NOT NULL UNIQUE, -- filter, nat, mangle, raw, security
    description TEXT,
    is_system_table BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Firewall Chains
CREATE TABLE IF NOT EXISTS firewall_chains (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    table_id UUID NOT NULL,
    chain_name VARCHAR(50) NOT NULL,
    chain_type VARCHAR(20) NOT NULL DEFAULT 'user', -- built-in, user
    hook_point VARCHAR(30), -- PREROUTING, INPUT, FORWARD, OUTPUT, POSTROUTING
    priority INTEGER DEFAULT 0,
    
    -- Default Policy
    default_policy VARCHAR(20) DEFAULT 'ACCEPT', -- ACCEPT, DROP, REJECT
    
    -- Chain Statistics
    packet_count BIGINT DEFAULT 0,
    byte_count BIGINT DEFAULT 0,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    UNIQUE(table_id, chain_name)
);

-- Firewall Rules
CREATE TABLE IF NOT EXISTS firewall_rules (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    chain_id UUID NOT NULL,
    rule_number INTEGER NOT NULL,
    rule_name VARCHAR(255),
    description TEXT,
    is_enabled BOOLEAN DEFAULT true,
    
    -- Basic Match Criteria
    protocol VARCHAR(20), -- tcp, udp, icmp, all
    source_ip CIDR,
    source_port_range VARCHAR(50), -- "80", "80:90", "80,443,8080"
    source_mac VARCHAR(17),
    source_not BOOLEAN DEFAULT false,
    
    destination_ip CIDR,
    destination_port_range VARCHAR(50),
    destination_not BOOLEAN DEFAULT false,
    
    -- Interface Matching
    in_interface VARCHAR(50),
    out_interface VARCHAR(50),
    physdev_in VARCHAR(50),
    physdev_out VARCHAR(50),
    
    -- TCP-specific matching
    tcp_flags VARCHAR(50), -- SYN,ACK,FIN,RST,PSH,URG
    tcp_flags_mask VARCHAR(50),
    tcp_syn BOOLEAN,
    tcp_established BOOLEAN,
    tcp_mss_range VARCHAR(20),
    tcp_window_range VARCHAR(20),
    
    -- UDP-specific matching
    udp_length_range VARCHAR(20),
    
    -- ICMP-specific matching
    icmp_type INTEGER,
    icmp_code INTEGER,
    
    -- Connection State Matching
    conn_state VARCHAR(100), -- NEW,ESTABLISHED,RELATED,INVALID
    conn_state_new BOOLEAN,
    conn_state_established BOOLEAN,
    conn_state_related BOOLEAN,
    conn_state_invalid BOOLEAN,
    
    -- Advanced Matching
    packet_mark INTEGER,
    packet_mark_mask INTEGER,
    dscp_value INTEGER,
    tos_value INTEGER,
    ttl_value INTEGER,
    packet_length_range VARCHAR(20),
    
    -- Time-based Matching
    time_start TIME,
    time_stop TIME,
    time_days VARCHAR(20), -- Mon,Tue,Wed,Thu,Fri,Sat,Sun
    time_monthdays VARCHAR(100), -- 1,2,3,4,5
    time_utc BOOLEAN DEFAULT false,
    
    -- Rate Limiting
    rate_limit VARCHAR(50), -- "10/minute", "100/hour"
    rate_burst INTEGER,
    rate_mode VARCHAR(20), -- srcip, dstip, srcip-dstip
    
    -- Connection Limiting
    connlimit_above INTEGER,
    connlimit_mask INTEGER,
    connlimit_saddr BOOLEAN DEFAULT false,
    
    -- String Matching
    string_algorithm VARCHAR(20), -- bm, kmp
    string_pattern TEXT,
    string_hex TEXT,
    string_offset INTEGER,
    
    -- Layer 7 Protocol Matching
    l7_protocol VARCHAR(50),
    l7_pattern TEXT,
    
    -- GeoIP Matching
    geoip_src_country VARCHAR(2),
    geoip_dst_country VARCHAR(2),
    geoip_not BOOLEAN DEFAULT false,
    
    -- Action/Target
    action_target VARCHAR(30) NOT NULL, -- ACCEPT, DROP, REJECT, LOG, MARK, DNAT, SNAT, etc.
    
    -- Reject-specific
    reject_type VARCHAR(30), -- icmp-net-unreachable, icmp-host-unreachable, etc.
    
    -- Jump/Goto actions
    jump_target_chain_id UUID,
    goto_target_chain_id UUID,
    
    -- Logging actions
    log_enabled BOOLEAN DEFAULT false,
    log_level VARCHAR(20) DEFAULT 'info',
    log_prefix VARCHAR(100),
    nflog_enabled BOOLEAN DEFAULT false,
    nflog_group INTEGER,
    
    -- Marking actions
    mark_set_value INTEGER,
    mark_save BOOLEAN DEFAULT false,
    mark_restore BOOLEAN DEFAULT false,
    mark_xor_value INTEGER,
    
    -- Connection Tracking actions
    ct_state_set VARCHAR(50),
    ct_mark_set INTEGER,
    ct_zone_set INTEGER,
    ct_helper VARCHAR(50),
    ct_timeout_set INTEGER,
    
    -- DSCP/TOS actions
    dscp_set_value INTEGER,
    dscp_set_class VARCHAR(20),
    tos_set_value INTEGER,
    tos_and_value INTEGER,
    tos_or_value INTEGER,
    tos_xor_value INTEGER,
    
    -- TTL actions
    ttl_set_value INTEGER,
    ttl_increment INTEGER,
    ttl_decrement INTEGER,
    
    -- TCP actions
    tcp_mss_set INTEGER,
    tcp_mss_clamp BOOLEAN DEFAULT false,
    tcp_window_set INTEGER,
    
    -- Rate limiting actions
    hashlimit_rate VARCHAR(50),
    hashlimit_burst INTEGER,
    hashlimit_mode VARCHAR(30),
    
    -- Queue actions
    queue_number INTEGER,
    queue_bypass BOOLEAN DEFAULT false,
    
    -- Rule Statistics
    hit_count BIGINT DEFAULT 0,
    byte_count BIGINT DEFAULT 0,
    last_hit TIMESTAMP WITH TIME ZONE,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    UNIQUE(chain_id, rule_number)
);

-- NAT Rules (Source NAT, Destination NAT, Masquerade, Redirect)
CREATE TABLE IF NOT EXISTS nat_rules (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    rule_type VARCHAR(20) NOT NULL, -- SNAT, DNAT, MASQUERADE, REDIRECT
    rule_name VARCHAR(255),
    description TEXT,
    is_enabled BOOLEAN DEFAULT true,
    
    -- Source matching (for all NAT types)
    source_ip CIDR,
    source_port_range VARCHAR(50),
    
    -- Destination matching (for DNAT/REDIRECT)
    destination_ip CIDR,
    destination_port_range VARCHAR(50),
    
    -- Interface matching
    in_interface VARCHAR(50),
    out_interface VARCHAR(50),
    
    -- SNAT specific
    snat_to_source INET,
    snat_to_port_range VARCHAR(50),
    snat_persistent BOOLEAN DEFAULT false,
    snat_random BOOLEAN DEFAULT false,
    
    -- DNAT specific
    dnat_to_destination INET,
    dnat_to_port_range VARCHAR(50),
    dnat_persistent BOOLEAN DEFAULT false,
    dnat_random BOOLEAN DEFAULT false,
    
    -- MASQUERADE specific
    masq_to_ports VARCHAR(50),
    masq_random BOOLEAN DEFAULT false,
    
    -- REDIRECT specific
    redirect_to_ports VARCHAR(50),
    redirect_random BOOLEAN DEFAULT false,
    
    -- Statistics
    hit_count BIGINT DEFAULT 0,
    byte_count BIGINT DEFAULT 0,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Connection Tracking Table
CREATE TABLE IF NOT EXISTS conntrack_entries (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    
    -- Connection Identification
    protocol VARCHAR(10) NOT NULL,
    connection_id VARCHAR(100) UNIQUE,
    
    -- Original Direction
    orig_src_ip INET NOT NULL,
    orig_src_port INTEGER,
    orig_dst_ip INET NOT NULL,
    orig_dst_port INTEGER,
    
    -- Reply Direction
    reply_src_ip INET NOT NULL,
    reply_src_port INTEGER,
    reply_dst_ip INET NOT NULL,
    reply_dst_port INTEGER,
    
    -- Connection State
    state VARCHAR(30) NOT NULL, -- NEW, ESTABLISHED, RELATED, INVALID
    tcp_state VARCHAR(30), -- SYN_SENT, SYN_RECV, ESTABLISHED, FIN_WAIT, etc.
    
    -- Timeouts
    timeout_value INTEGER NOT NULL,
    expires_at TIMESTAMP WITH TIME ZONE,
    
    -- Marking and Zones
    connection_mark INTEGER DEFAULT 0,
    connection_zone INTEGER DEFAULT 0,
    connection_labels TEXT[],
    
    -- Statistics
    orig_packets BIGINT DEFAULT 0,
    orig_bytes BIGINT DEFAULT 0,
    reply_packets BIGINT DEFAULT 0,
    reply_bytes BIGINT DEFAULT 0,
    
    -- Timestamps
    first_seen TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    last_seen TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Connection Tracking Configuration
CREATE TABLE IF NOT EXISTS conntrack_config (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    
    -- Global Settings
    max_connections INTEGER DEFAULT 65536,
    hash_buckets INTEGER DEFAULT 16384,
    checksum_enabled BOOLEAN DEFAULT true,
    timestamp_enabled BOOLEAN DEFAULT false,
    
    -- Timeout Settings
    timeout_generic INTEGER DEFAULT 600,
    timeout_tcp_syn_sent INTEGER DEFAULT 120,
    timeout_tcp_syn_recv INTEGER DEFAULT 60,
    timeout_tcp_established INTEGER DEFAULT 432000,
    timeout_tcp_fin_wait INTEGER DEFAULT 120,
    timeout_tcp_close_wait INTEGER DEFAULT 60,
    timeout_tcp_last_ack INTEGER DEFAULT 30,
    timeout_tcp_time_wait INTEGER DEFAULT 120,
    timeout_tcp_close INTEGER DEFAULT 10,
    timeout_udp_stream INTEGER DEFAULT 180,
    timeout_udp_unreplied INTEGER DEFAULT 30,
    timeout_icmp INTEGER DEFAULT 30,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Connection Tracking Helpers
CREATE TABLE IF NOT EXISTS conntrack_helpers (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    helper_name VARCHAR(50) NOT NULL UNIQUE,
    helper_protocol VARCHAR(10) NOT NULL,
    helper_ports INTEGER[] NOT NULL,
    is_enabled BOOLEAN DEFAULT true,
    description TEXT,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Security Policies
CREATE TABLE IF NOT EXISTS security_policies (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    policy_name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    policy_type VARCHAR(30) NOT NULL, -- intrusion_prevention, ddos_protection, access_control
    
    -- Policy Configuration
    is_enabled BOOLEAN DEFAULT true,
    severity_level VARCHAR(20) DEFAULT 'medium', -- low, medium, high, critical
    
    -- Intrusion Prevention
    block_suspicious_traffic BOOLEAN DEFAULT true,
    block_known_bad_ips BOOLEAN DEFAULT true,
    rate_limit_enabled BOOLEAN DEFAULT true,
    max_connections_per_ip INTEGER DEFAULT 100,
    
    -- DDoS Protection
    syn_flood_protection BOOLEAN DEFAULT true,
    connection_limit_per_ip INTEGER DEFAULT 50,
    packet_rate_limit INTEGER DEFAULT 1000, -- packets per second
    
    -- Access Control
    geo_blocking_enabled BOOLEAN DEFAULT false,
    blocked_countries VARCHAR(2)[],
    allowed_countries VARCHAR(2)[],
    
    -- Logging and Alerting
    log_violations BOOLEAN DEFAULT true,
    alert_on_violations BOOLEAN DEFAULT true,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Security Events/Violations
CREATE TABLE IF NOT EXISTS security_events (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    event_type VARCHAR(50) NOT NULL,
    severity VARCHAR(20) NOT NULL,
    source_ip INET NOT NULL,
    destination_ip INET,
    source_port INTEGER,
    destination_port INTEGER,
    protocol VARCHAR(10),
    
    -- Event Details
    rule_id UUID, -- Related firewall rule that triggered
    policy_id UUID, -- Related security policy
    event_description TEXT NOT NULL,
    event_data JSONB,
    
    -- Action Taken
    action_taken VARCHAR(50), -- blocked, logged, alerted
    blocked_duration INTEGER, -- seconds
    
    -- Geolocation
    source_country VARCHAR(2),
    source_city VARCHAR(100),
    
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- IP Blacklist/Whitelist
CREATE TABLE IF NOT EXISTS ip_access_lists (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    list_type VARCHAR(20) NOT NULL, -- blacklist, whitelist
    ip_address CIDR NOT NULL,
    reason TEXT,
    source VARCHAR(50), -- manual, auto_detected, threat_feed
    
    -- Auto-detection details
    violation_count INTEGER DEFAULT 0,
    last_violation TIMESTAMP WITH TIME ZONE,
    
    -- Expiration
    expires_at TIMESTAMP WITH TIME ZONE,
    is_permanent BOOLEAN DEFAULT false,
    
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_firewall_chains_table_id ON firewall_chains(table_id);
CREATE INDEX IF NOT EXISTS idx_firewall_rules_chain_id ON firewall_rules(chain_id);
CREATE INDEX IF NOT EXISTS idx_firewall_rules_rule_number ON firewall_rules(chain_id, rule_number);
CREATE INDEX IF NOT EXISTS idx_nat_rules_type ON nat_rules(rule_type);
CREATE INDEX IF NOT EXISTS idx_conntrack_entries_protocol ON conntrack_entries(protocol);
CREATE INDEX IF NOT EXISTS idx_conntrack_entries_orig_src ON conntrack_entries(orig_src_ip);
CREATE INDEX IF NOT EXISTS idx_conntrack_entries_state ON conntrack_entries(state);
CREATE INDEX IF NOT EXISTS idx_conntrack_entries_expires ON conntrack_entries(expires_at);
CREATE INDEX IF NOT EXISTS idx_security_events_timestamp ON security_events(timestamp);
CREATE INDEX IF NOT EXISTS idx_security_events_source_ip ON security_events(source_ip);
CREATE INDEX IF NOT EXISTS idx_security_events_severity ON security_events(severity);
CREATE INDEX IF NOT EXISTS idx_ip_access_lists_ip ON ip_access_lists USING GIST(ip_address);
CREATE INDEX IF NOT EXISTS idx_ip_access_lists_type ON ip_access_lists(list_type);

-- Insert default firewall tables
INSERT INTO firewall_tables (table_name, description) VALUES
('filter', 'Default filtering table for firewall rules'),
('nat', 'Network Address Translation table'),
('mangle', 'Packet mangling table'),
('raw', 'Raw packet processing table'),
('security', 'SELinux security table')
ON CONFLICT (table_name) DO NOTHING;

-- Insert default conntrack helpers
INSERT INTO conntrack_helpers (helper_name, helper_protocol, helper_ports, description) VALUES
('ftp', 'tcp', '{21}', 'FTP connection tracking helper'),
('tftp', 'udp', '{69}', 'TFTP connection tracking helper'),
('irc', 'tcp', '{6667,6668,6669}', 'IRC connection tracking helper'),
('sip', 'udp', '{5060}', 'SIP connection tracking helper'),
('h323', 'tcp', '{1720}', 'H.323 connection tracking helper')
ON CONFLICT (helper_name) DO NOTHING;

-- Create triggers for updated_at
CREATE TRIGGER update_firewall_tables_updated_at BEFORE UPDATE ON firewall_tables FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_firewall_chains_updated_at BEFORE UPDATE ON firewall_chains FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_firewall_rules_updated_at BEFORE UPDATE ON firewall_rules FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_nat_rules_updated_at BEFORE UPDATE ON nat_rules FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_conntrack_config_updated_at BEFORE UPDATE ON conntrack_config FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_conntrack_helpers_updated_at BEFORE UPDATE ON conntrack_helpers FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_security_policies_updated_at BEFORE UPDATE ON security_policies FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_ip_access_lists_updated_at BEFORE UPDATE ON ip_access_lists FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();