-- Migration: insert_sample_data_fixed
-- Created at: 1757155235

-- Insert initial configuration data
INSERT INTO device_configurations (category, config_key, config_json, description) VALUES
('telegram', 'bot_settings', '{"bot_token": "", "default_chat_id": "", "enabled": false}', 'Telegram bot configuration for notifications'),
('system', 'monitoring', '{"enabled": true, "interval": 60, "retention_days": 30}', 'System monitoring configuration'),
('network', 'discovery', '{"enabled": true, "scan_interval": 300, "ip_range": "192.168.1.0/24"}', 'Network device discovery settings')
ON CONFLICT (category, config_key) DO NOTHING;

-- Update existing audit_logs with missing data
UPDATE audit_logs SET 
    title = CASE 
        WHEN event_type = 'alert' AND severity = 'warning' THEN 'System Alert'
        WHEN event_type = 'alert' AND severity = 'critical' THEN 'Critical Alert'
        WHEN event_type = 'alert' AND severity = 'info' THEN 'System Info'
        ELSE 'System Event'
    END,
    message = CASE 
        WHEN event_type = 'alert' THEN 'System monitoring detected an event requiring attention'
        ELSE 'System event logged for audit purposes'
    END,
    action = CASE
        WHEN action IS NULL THEN 'system_alert'
        ELSE action
    END
WHERE title IS NULL OR action IS NULL;

-- Insert sample audit logs for alerts with required action field
INSERT INTO audit_logs (event_type, event_category, severity, action, title, message, details, created_at) VALUES
('alert', 'system', 'warning', 'cpu_threshold_exceeded', 'High CPU Usage', 'CPU usage has exceeded 80% for more than 5 minutes', '{"cpu_percent": 85.2, "duration": 300}', NOW() - INTERVAL '1 hour'),
('alert', 'network', 'info', 'device_discovered', 'New Device Detected', 'A new device has connected to the network', '{"mac_address": "aa:bb:cc:dd:ee:ff", "ip": "192.168.1.100"}', NOW() - INTERVAL '2 hours'),
('alert', 'system', 'critical', 'storage_low', 'Storage Space Low', 'Available disk space is below 10%', '{"disk_usage": 92.5, "available_gb": 2.1}', NOW() - INTERVAL '30 minutes'),
('alert', 'network', 'warning', 'traffic_high', 'High Network Traffic', 'Network traffic exceeded normal thresholds', '{"bytes_per_sec": 50000000, "interface": "eth0"}', NOW() - INTERVAL '15 minutes')
ON CONFLICT DO NOTHING;

-- Insert sample system metrics
INSERT INTO system_metrics (metric_name, metric_type, value, unit, cpu_percent, memory_percent, temperature_celsius, timestamp, device_id) VALUES
('cpu_usage', 'cpu', 65.5, 'percent', 65.5, NULL, NULL, NOW() - INTERVAL '5 minutes', gen_random_uuid()),
('memory_usage', 'memory', 78.2, 'percent', NULL, 78.2, NULL, NOW() - INTERVAL '5 minutes', gen_random_uuid()),
('cpu_temp', 'temperature', 45.8, 'celsius', NULL, NULL, 45.8, NOW() - INTERVAL '5 minutes', gen_random_uuid()),
('cpu_usage', 'cpu', 62.1, 'percent', 62.1, NULL, NULL, NOW() - INTERVAL '10 minutes', gen_random_uuid()),
('memory_usage', 'memory', 75.9, 'percent', NULL, 75.9, NULL, NOW() - INTERVAL '10 minutes', gen_random_uuid()),
('cpu_temp', 'temperature', 44.2, 'celsius', NULL, NULL, 44.2, NOW() - INTERVAL '10 minutes', gen_random_uuid()),
('cpu_usage', 'cpu', 58.7, 'percent', 58.7, NULL, NULL, NOW() - INTERVAL '15 minutes', gen_random_uuid()),
('memory_usage', 'memory', 73.1, 'percent', NULL, 73.1, NULL, NOW() - INTERVAL '15 minutes', gen_random_uuid()),
('cpu_temp', 'temperature', 43.5, 'celsius', NULL, NULL, 43.5, NOW() - INTERVAL '15 minutes', gen_random_uuid())
ON CONFLICT DO NOTHING;

-- Insert sample network traffic data
INSERT INTO network_traffic_data (interface_name, bytes_sent, bytes_received, packets_sent, packets_received, timestamp) VALUES
('eth0', 15678234, 45234567, 12456, 34567, NOW() - INTERVAL '5 minutes'),
('eth0', 14234567, 43567890, 11890, 33245, NOW() - INTERVAL '10 minutes'),
('eth0', 16789012, 47890123, 13234, 35678, NOW() - INTERVAL '15 minutes'),
('wlan0', 8234567, 23456789, 6789, 18234, NOW() - INTERVAL '5 minutes'),
('wlan0', 7890123, 22345678, 6234, 17456, NOW() - INTERVAL '10 minutes'),
('wlan0', 8567890, 24567890, 7123, 19345, NOW() - INTERVAL '15 minutes')
ON CONFLICT DO NOTHING;;