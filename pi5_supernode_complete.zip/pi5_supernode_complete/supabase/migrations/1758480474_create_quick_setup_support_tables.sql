-- Migration: create_quick_setup_support_tables
-- Created at: 1758480474

-- Migration: Create Quick Setup Support Tables
-- Created at: $(date +%s)
-- Description: Creates tables required for modem mode setup and notification system

-- System Configurations Table
-- Stores system-wide configuration settings with versioning support
CREATE TABLE IF NOT EXISTS system_configs (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    config_key VARCHAR(255) UNIQUE NOT NULL,
    config_value JSONB NOT NULL,
    config_type VARCHAR(100) NOT NULL DEFAULT 'general',
    description TEXT,
    version INTEGER DEFAULT 1,
    is_active BOOLEAN DEFAULT true,
    requires_restart BOOLEAN DEFAULT false,
    created_by UUID,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create index for efficient lookups
CREATE INDEX IF NOT EXISTS idx_system_configs_key ON system_configs(config_key);
CREATE INDEX IF NOT EXISTS idx_system_configs_type ON system_configs(config_type);
CREATE INDEX IF NOT EXISTS idx_system_configs_active ON system_configs(is_active);

-- Enable Row Level Security
ALTER TABLE system_configs ENABLE ROW LEVEL SECURITY;

-- Create policy for system configurations (allow all operations for authenticated users)
DROP POLICY IF EXISTS "Allow full access to system_configs for authenticated users" ON system_configs;
CREATE POLICY "Allow full access to system_configs for authenticated users" ON system_configs
    FOR ALL USING (true);

-- Setup Executions Table
-- Tracks execution of system setup processes
CREATE TABLE IF NOT EXISTS setup_executions (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    setup_type VARCHAR(100) NOT NULL,
    configuration_applied JSONB NOT NULL,
    setup_steps JSONB NOT NULL DEFAULT '[]'::jsonb,
    status VARCHAR(50) NOT NULL DEFAULT 'pending',
    started_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    completed_at TIMESTAMP WITH TIME ZONE,
    total_duration INTEGER, -- in milliseconds
    error_message TEXT,
    executed_by UUID,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for efficient queries
CREATE INDEX IF NOT EXISTS idx_setup_executions_type ON setup_executions(setup_type);
CREATE INDEX IF NOT EXISTS idx_setup_executions_status ON setup_executions(status);
CREATE INDEX IF NOT EXISTS idx_setup_executions_started_at ON setup_executions(started_at);

-- Enable Row Level Security
ALTER TABLE setup_executions ENABLE ROW LEVEL SECURITY;

-- Create policy for setup executions
DROP POLICY IF EXISTS "Allow full access to setup_executions for authenticated users" ON setup_executions;
CREATE POLICY "Allow full access to setup_executions for authenticated users" ON setup_executions
    FOR ALL USING (true);

-- Add constraint for status values (only if not exists)
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.table_constraints 
        WHERE constraint_name = 'check_setup_status' 
        AND table_name = 'setup_executions'
    ) THEN
        ALTER TABLE setup_executions ADD CONSTRAINT check_setup_status 
            CHECK (status IN ('pending', 'running', 'completed', 'failed', 'cancelled'));
    END IF;
END $$;

-- Notifications Table
-- Stores system and user notifications
CREATE TABLE IF NOT EXISTS notifications (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    title VARCHAR(255),
    message TEXT NOT NULL,
    type VARCHAR(50) NOT NULL DEFAULT 'info',
    priority INTEGER DEFAULT 5, -- 1-10 scale, 10 being highest
    is_read BOOLEAN DEFAULT false,
    is_system BOOLEAN DEFAULT false,
    action_url TEXT,
    action_label VARCHAR(100),
    expires_at TIMESTAMP WITH TIME ZONE,
    metadata JSONB DEFAULT '{}'::jsonb,
    user_id UUID,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    read_at TIMESTAMP WITH TIME ZONE
);

-- Create indexes for efficient queries
CREATE INDEX IF NOT EXISTS idx_notifications_type ON notifications(type);
CREATE INDEX IF NOT EXISTS idx_notifications_is_read ON notifications(is_read);
CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_notifications_created_at ON notifications(created_at);
CREATE INDEX IF NOT EXISTS idx_notifications_expires_at ON notifications(expires_at);
CREATE INDEX IF NOT EXISTS idx_notifications_priority ON notifications(priority);

-- Enable Row Level Security
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

-- Create policies for notifications
DROP POLICY IF EXISTS "Users can view their own and system notifications" ON notifications;
CREATE POLICY "Users can view their own and system notifications" ON notifications
    FOR SELECT USING (true);

DROP POLICY IF EXISTS "Authenticated users can create notifications" ON notifications;
CREATE POLICY "Authenticated users can create notifications" ON notifications
    FOR INSERT WITH CHECK (true);

DROP POLICY IF EXISTS "Users can update their own notifications" ON notifications;
CREATE POLICY "Users can update their own notifications" ON notifications
    FOR UPDATE USING (true);

-- Add constraints for notification types and priority (only if not exists)
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.table_constraints 
        WHERE constraint_name = 'check_notification_type' 
        AND table_name = 'notifications'
    ) THEN
        ALTER TABLE notifications ADD CONSTRAINT check_notification_type 
            CHECK (type IN ('info', 'success', 'warning', 'error', 'debug'));
    END IF;
END $$;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.table_constraints 
        WHERE constraint_name = 'check_notification_priority' 
        AND table_name = 'notifications'
    ) THEN
        ALTER TABLE notifications ADD CONSTRAINT check_notification_priority 
            CHECK (priority >= 1 AND priority <= 10);
    END IF;
END $$;

-- Function to automatically set read_at when is_read is set to true
CREATE OR REPLACE FUNCTION set_notification_read_at()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.is_read = true AND OLD.is_read = false THEN
        NEW.read_at = NOW();
    ELSIF NEW.is_read = false THEN
        NEW.read_at = NULL;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for read_at timestamp
DROP TRIGGER IF EXISTS trigger_notification_read_at ON notifications;
CREATE TRIGGER trigger_notification_read_at
    BEFORE UPDATE ON notifications
    FOR EACH ROW
    EXECUTE FUNCTION set_notification_read_at();

-- Quick Setup Executions Table
-- Tracks quick setup wizard executions
CREATE TABLE IF NOT EXISTS quick_setup_executions (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    setup_name VARCHAR(255) NOT NULL,
    setup_configuration JSONB NOT NULL DEFAULT '{}'::jsonb,
    current_step INTEGER DEFAULT 0,
    total_steps INTEGER DEFAULT 0,
    status VARCHAR(50) NOT NULL DEFAULT 'pending',
    started_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    completed_at TIMESTAMP WITH TIME ZONE,
    estimated_duration INTEGER, -- in seconds
    actual_duration INTEGER, -- in seconds
    step_history JSONB DEFAULT '[]'::jsonb,
    error_details JSONB,
    success_message TEXT,
    requires_reboot BOOLEAN DEFAULT false,
    executed_by UUID,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for efficient queries
CREATE INDEX IF NOT EXISTS idx_quick_setup_executions_status ON quick_setup_executions(status);
CREATE INDEX IF NOT EXISTS idx_quick_setup_executions_started_at ON quick_setup_executions(started_at);
CREATE INDEX IF NOT EXISTS idx_quick_setup_executions_setup_name ON quick_setup_executions(setup_name);

-- Enable Row Level Security
ALTER TABLE quick_setup_executions ENABLE ROW LEVEL SECURITY;

-- Create policy for quick setup executions
DROP POLICY IF EXISTS "Allow full access to quick_setup_executions for authenticated users" ON quick_setup_executions;
CREATE POLICY "Allow full access to quick_setup_executions for authenticated users" ON quick_setup_executions
    FOR ALL USING (true);

-- Add constraint for status values (only if not exists)
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.table_constraints 
        WHERE constraint_name = 'check_quick_setup_status' 
        AND table_name = 'quick_setup_executions'
    ) THEN
        ALTER TABLE quick_setup_executions ADD CONSTRAINT check_quick_setup_status 
            CHECK (status IN ('pending', 'running', 'completed', 'failed', 'cancelled', 'requires_input'));
    END IF;
END $$;

-- Function to automatically calculate actual duration
CREATE OR REPLACE FUNCTION calculate_quick_setup_duration()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.status = 'completed' AND NEW.completed_at IS NOT NULL AND OLD.status != 'completed' THEN
        NEW.actual_duration = EXTRACT(EPOCH FROM (NEW.completed_at - NEW.started_at))::INTEGER;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for duration calculation
DROP TRIGGER IF EXISTS trigger_quick_setup_duration ON quick_setup_executions;
CREATE TRIGGER trigger_quick_setup_duration
    BEFORE UPDATE ON quick_setup_executions
    FOR EACH ROW
    EXECUTE FUNCTION calculate_quick_setup_duration();

-- Insert default system configurations
INSERT INTO system_configs (config_key, config_value, config_type, description) VALUES
('system_initialized', 'false', 'system', 'Whether the system has been initialized'),
('default_timezone', '"UTC"', 'system', 'Default system timezone'),
('auto_updates_enabled', 'true', 'system', 'Enable automatic system updates'),
('log_retention_days', '30', 'system', 'Number of days to retain system logs'),
('max_concurrent_connections', '1000', 'network', 'Maximum concurrent network connections'),
('session_timeout_minutes', '30', 'security', 'User session timeout in minutes')
ON CONFLICT (config_key) DO NOTHING;;