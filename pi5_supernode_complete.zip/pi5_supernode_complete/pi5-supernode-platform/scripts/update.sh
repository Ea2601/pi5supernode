#!/bin/bash

# Pi5 Supernode - Update Script
# Version: 1.0.0
# Description: Update existing Pi5 Supernode installation

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Configuration
INSTALL_DIR="/opt/pi5-supernode"
SERVICE_NAME="pi5-supernode"
BACKUP_DIR="/opt/pi5-supernode-backup-$(date +%Y%m%d-%H%M%S)"

print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Function to create backup
create_backup() {
    print_status "Creating backup..."
    
    if [[ -d "$INSTALL_DIR" ]]; then
        sudo cp -r "$INSTALL_DIR" "$BACKUP_DIR"
        print_success "Backup created at $BACKUP_DIR"
    else
        print_error "Installation directory not found: $INSTALL_DIR"
        exit 1
    fi
}

# Function to stop services
stop_services() {
    print_status "Stopping services..."
    
    sudo systemctl stop "$SERVICE_NAME" || true
    
    cd "$INSTALL_DIR"
    docker-compose down || true
    
    print_success "Services stopped"
}

# Function to update repository
update_repository() {
    print_status "Updating repository..."
    
    cd "$INSTALL_DIR"
    
    # Stash any local changes
    git stash push -m "Auto-stash before update $(date)"
    
    # Pull latest changes
    git pull origin main
    
    print_success "Repository updated"
}

# Function to update dependencies
update_dependencies() {
    print_status "Updating dependencies..."
    
    cd "$INSTALL_DIR/pi5-supernode-platform"
    
    # Update frontend dependencies
    pnpm install --frozen-lockfile
    
    # Rebuild frontend
    pnpm run build:prod
    
    print_success "Dependencies updated"
}

# Function to update Docker containers
update_containers() {
    print_status "Updating Docker containers..."
    
    cd "$INSTALL_DIR"
    
    # Pull latest images
    docker-compose pull
    
    print_success "Containers updated"
}

# Function to restart services
restart_services() {
    print_status "Restarting services..."
    
    cd "$INSTALL_DIR"
    
    # Start Docker services
    docker-compose up -d
    
    # Wait for services to be ready
    sleep 15
    
    # Start main service
    sudo systemctl start "$SERVICE_NAME"
    
    print_success "Services restarted"
}

# Function to verify update
verify_update() {
    print_status "Verifying update..."
    
    # Check service status
    if sudo systemctl is-active --quiet "$SERVICE_NAME"; then
        print_success "Service is running"
    else
        print_error "Service is not running"
        return 1
    fi
    
    # Check web interface
    if curl -sf http://localhost:3000 > /dev/null; then
        print_success "Web interface is accessible"
    else
        print_warning "Web interface may not be ready yet"
    fi
    
    print_success "Update verification completed"
}

# Main update function
main() {
    print_status "Starting Pi5 Supernode update..."
    
    create_backup
    stop_services
    update_repository
    update_dependencies
    update_containers
    restart_services
    verify_update
    
    print_success "Update completed successfully!"
    print_status "Backup available at: $BACKUP_DIR"
}

# Check if running as root or with sudo access
if [[ $EUID -eq 0 ]]; then
    print_error "Do not run this script as root"
    exit 1
fi

if ! sudo -n true 2>/dev/null; then
    print_error "This script requires sudo access"
    exit 1
fi

# Run main function
main "$@"
