# Pi5 Supernode Installation Scripts

This directory contains automated installation and deployment scripts for the Pi5 Supernode Enterprise Network Management Platform.

## Quick Installation

### One-Command Installation

For a complete automated installation on a Raspberry Pi 5:

```bash
# Remote installation (recommended)
curl -fsSL https://raw.githubusercontent.com/your-repo/pi5-supernode/main/scripts/pi5-auto-install.sh | bash -s -- --host 192.168.1.100 --domain pi5.local

# Local installation
./scripts/pi5-auto-install.sh --host 192.168.1.100 --user pi --domain pi5.local
```

### Installation Options

| Option | Description | Required | Default |
|--------|-------------|----------|----------|
| `--host` | IP address or hostname of Pi5 | ✅ | - |
| `--user` | SSH username | ❌ | `pi` |
| `--domain` | Domain name for SSL setup | ❌ | - |
| `--repo` | Git repository URL | ❌ | Default repo |
| `--help` | Show help message | ❌ | - |

## Prerequisites

### Pi5 Requirements

- **Hardware**: Raspberry Pi 5 with minimum 4GB RAM
- **Storage**: Minimum 8GB available disk space
- **Network**: Ethernet or WiFi connection
- **OS**: Raspberry Pi OS (64-bit) or Ubuntu 22.04+

### Host Machine Requirements

- SSH client
- Internet connection
- Network access to Pi5

### Pi5 Preparation

1. **Enable SSH**:
   ```bash
   sudo systemctl enable ssh
   sudo systemctl start ssh
   ```

2. **Set up SSH key authentication** (recommended):
   ```bash
   # On your host machine
   ssh-keygen -t rsa -b 4096 -C "your_email@example.com"
   ssh-copy-id pi@192.168.1.100
   ```

3. **Alternative: Enable password authentication**:
   ```bash
   # On Pi5
   sudo nano /etc/ssh/sshd_config
   # Set: PasswordAuthentication yes
   sudo systemctl restart ssh
   ```

## Installation Process

The installation script performs the following steps:

### 1. System Validation
- Tests SSH connectivity
- Validates hardware requirements
- Checks available disk space and memory

### 2. System Updates
- Updates package repositories
- Upgrades existing packages
- Installs essential dependencies

### 3. Runtime Installation
- Docker and Docker Compose
- Node.js 20.x LTS
- pnpm package manager
- Nginx web server

### 4. Application Deployment
- Clones Pi5 Supernode repository
- Sets up environment configuration
- Installs frontend dependencies
- Builds production assets

### 5. Database Setup
- PostgreSQL 15 (Docker)
- Redis cache (Docker)
- Database schema initialization
- Connection testing

### 6. Monitoring Stack
- Prometheus metrics collection
- Grafana dashboards
- System health monitoring

### 7. Security Configuration
- UFW firewall setup
- SSL certificate generation (if domain provided)
- Nginx reverse proxy configuration
- Service hardening

### 8. Service Management
- Systemd service creation
- Automatic startup configuration
- Health check validation
- Service orchestration

## Post-Installation

### Accessing the System

- **Web Interface**: `http://PI5_IP:3000` or `https://DOMAIN`
- **Grafana Dashboard**: `http://PI5_IP:3001`
- **Prometheus Metrics**: `http://PI5_IP:9090`

### Essential Configuration

1. **Update Supabase Credentials**:
   ```bash
   ssh pi@PI5_IP
   cd /opt/pi5-supernode
   nano .env
   # Update SUPABASE_* variables
   sudo systemctl restart pi5-supernode
   ```

2. **Configure Network Settings**:
   - Update network interface settings
   - Configure DHCP range
   - Set DNS servers

3. **Set up VPN Server**:
   - Generate WireGuard keys
   - Configure client access
   - Set up port forwarding

### Service Management

```bash
# Check service status
sudo systemctl status pi5-supernode

# View logs
sudo journalctl -u pi5-supernode -f

# Restart service
sudo systemctl restart pi5-supernode

# Stop service
sudo systemctl stop pi5-supernode

# Check Docker containers
cd /opt/pi5-supernode
docker-compose ps

# View container logs
docker-compose logs -f
```

## Troubleshooting

### Common Issues

1. **SSH Connection Failed**:
   - Verify Pi5 IP address
   - Check SSH service status
   - Ensure firewall allows SSH
   - Verify user credentials

2. **Insufficient Resources**:
   - Check available disk space: `df -h`
   - Check memory usage: `free -h`
   - Ensure Pi5 has adequate cooling

3. **Docker Issues**:
   - Check Docker service: `sudo systemctl status docker`
   - Restart Docker: `sudo systemctl restart docker`
   - Check container logs: `docker-compose logs`

4. **Database Connection Issues**:
   - Verify PostgreSQL container: `docker ps | grep postgres`
   - Check database logs: `docker logs pi5-postgres`
   - Test connection: `docker exec pi5-postgres pg_isready`

5. **SSL Certificate Issues**:
   - Ensure domain points to Pi5 IP
   - Check port 80/443 accessibility
   - Verify Certbot installation
   - Check nginx configuration: `sudo nginx -t`

### Debug Mode

To run the installation with verbose output:

```bash
# Enable debug mode
bash -x ./scripts/pi5-auto-install.sh --host 192.168.1.100
```

### Manual Cleanup

To remove a failed installation:

```bash
# On Pi5
sudo systemctl stop pi5-supernode
sudo systemctl disable pi5-supernode
sudo rm /etc/systemd/system/pi5-supernode.service
sudo rm -rf /opt/pi5-supernode
docker-compose down -v
docker system prune -a
```

## Advanced Configuration

### Custom Repository

```bash
./scripts/pi5-auto-install.sh \
  --host 192.168.1.100 \
  --repo https://github.com/your-fork/pi5-supernode.git
```

### Environment Customization

After installation, customize `/opt/pi5-supernode/.env`:

```bash
# Network Configuration
NETWORK_INTERFACE=wlan0
DHCP_RANGE_START=192.168.1.100
DHCP_RANGE_END=192.168.1.200

# VPN Configuration
WIREGUARD_PORT=51820
VPN_NETWORK=10.0.0.0/24

# Monitoring
GRAFANA_ADMIN_PASSWORD=your_secure_password
PROMETHEUS_RETENTION=30d
```

### Performance Tuning

For optimal performance on Pi5:

```bash
# Increase GPU memory split
echo 'gpu_mem=256' | sudo tee -a /boot/config.txt

# Enable performance governor
echo 'performance' | sudo tee /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor

# Optimize Docker
echo '{
  "log-driver": "json-file",
  "log-opts": {
    "max-size": "10m",
    "max-file": "3"
  }
}' | sudo tee /etc/docker/daemon.json
```

## Support

For installation support:

1. Check the troubleshooting section
2. Review installation logs
3. Verify system requirements
4. Submit an issue with detailed logs

## Contributing

To improve the installation script:

1. Fork the repository
2. Create a feature branch
3. Test on a clean Pi5 installation
4. Submit a pull request

---

**Note**: This script is designed specifically for Raspberry Pi 5. For other ARM64 devices, modifications may be required.
