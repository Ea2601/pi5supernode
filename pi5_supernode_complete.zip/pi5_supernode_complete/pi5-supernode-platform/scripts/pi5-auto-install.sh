#!/bin/bash

# Pi5 Supernode - One-Command Installation Script
# Version: 2.1.0
# Description: Complete automated deployment for Raspberry Pi 5

set -e  # Exit on any error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration variables
PI5_HOST=""
PI5_USER="pi"
DOMAIN=""
REPO_URL="https://github.com/your-repo/pi5-supernode.git"
INSTALL_DIR="/opt/pi5-supernode"
SERVICE_NAME="pi5-supernode"
LOG_FILE="/tmp/pi5-install.log"

# Function to print colored output
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Function to show usage
show_usage() {
    cat << EOF
Pi5 Supernode - One-Command Installation Script

Usage: $0 --host PI5_IP_ADDRESS [OPTIONS]

Required:
  --host HOST        IP address or hostname of Raspberry Pi 5

Optional:
  --user USER        SSH username (default: pi)
  --domain DOMAIN    Domain name for SSL setup
  --repo URL         Git repository URL
  --help             Show this help message

Example:
  $0 --host 192.168.1.100 --user pi --domain pi5.local

Remote installation (curl method):
  curl -fsSL https://raw.githubusercontent.com/your-repo/pi5-supernode/main/scripts/pi5-auto-install.sh | bash -s -- --host 192.168.1.100

EOF
}

# Function to parse command line arguments
parse_args() {
    while [[ $# -gt 0 ]]; do
        case $1 in
            --host)
                PI5_HOST="$2"
                shift 2
                ;;
            --user)
                PI5_USER="$2"
                shift 2
                ;;
            --domain)
                DOMAIN="$2"
                shift 2
                ;;
            --repo)
                REPO_URL="$2"
                shift 2
                ;;
            --help)
                show_usage
                exit 0
                ;;
            *)
                print_error "Unknown option: $1"
                show_usage
                exit 1
                ;;
        esac
    done
}

# Parse command line arguments
parse_args "$@"

# Validate required parameters
if [[ -z "$PI5_HOST" ]]; then
    print_error "Pi5 host address is required"
    show_usage
    exit 1
fi

# Function to test SSH connection
test_ssh_connection() {
    print_status "Testing SSH connection to $PI5_USER@$PI5_HOST..."
    
    if ssh -o ConnectTimeout=10 -o BatchMode=yes "$PI5_USER@$PI5_HOST" 'echo "SSH connection successful"' 2>/dev/null; then
        print_success "SSH connection established"
        return 0
    else
        print_error "Cannot establish SSH connection to $PI5_USER@$PI5_HOST"
        print_warning "Please ensure:"
        echo "  1. Pi5 is powered on and connected to network"
        echo "  2. SSH is enabled on Pi5"
        echo "  3. SSH key authentication is set up or password authentication is enabled"
        echo "  4. User '$PI5_USER' exists on Pi5"
        return 1
    fi
}

# Function to check Pi5 system requirements
check_system_requirements() {
    print_status "Checking Pi5 system requirements..."
    
    ssh "$PI5_USER@$PI5_HOST" << 'EOF'
set -e

# Check if running on Raspberry Pi
if ! grep -q "Raspberry Pi" /proc/cpuinfo; then
    echo "ERROR: This script is designed for Raspberry Pi systems"
    exit 1
fi

# Check available disk space (minimum 8GB)
AVAIL_SPACE=$(df / | tail -1 | awk '{print $4}')
REQUIRED_SPACE=8388608  # 8GB in KB

if [[ $AVAIL_SPACE -lt $REQUIRED_SPACE ]]; then
    echo "ERROR: Insufficient disk space. Required: 8GB, Available: $(( AVAIL_SPACE / 1024 / 1024 ))GB"
    exit 1
fi

# Check memory (minimum 4GB for Pi5)
MEM_TOTAL=$(grep MemTotal /proc/meminfo | awk '{print $2}')
REQUIRED_MEM=3932160  # ~4GB in KB

if [[ $MEM_TOTAL -lt $REQUIRED_MEM ]]; then
    echo "ERROR: Insufficient memory. Required: 4GB, Available: $(( MEM_TOTAL / 1024 / 1024 ))GB"
    exit 1
fi

echo "System requirements check passed"
EOF
    
    print_success "System requirements satisfied"
}

# Function to update system packages
update_system() {
    print_status "Updating Pi5 system packages..."
    
    ssh "$PI5_USER@$PI5_HOST" << 'EOF'
set -e

# Update package lists
sudo apt update

# Upgrade existing packages
sudo apt upgrade -y

# Install essential packages
sudo apt install -y \
    curl \
    wget \
    git \
    htop \
    vim \
    unzip \
    software-properties-common \
    apt-transport-https \
    ca-certificates \
    gnupg \
    lsb-release \
    build-essential \
    python3 \
    python3-pip \
    nodejs \
    npm \
    nginx \
    ufw

echo "System update completed"
EOF
    
    print_success "System packages updated"
}

# Function to install Docker
install_docker() {
    print_status "Installing Docker and Docker Compose..."
    
    ssh "$PI5_USER@$PI5_HOST" << 'EOF'
set -e

# Check if Docker is already installed
if command -v docker &> /dev/null; then
    echo "Docker is already installed, skipping..."
else
    # Install Docker
    curl -fsSL https://get.docker.com -o get-docker.sh
    sudo sh get-docker.sh
    rm get-docker.sh
    
    # Add user to docker group
    sudo usermod -aG docker $USER
fi

# Install Docker Compose
if ! command -v docker-compose &> /dev/null; then
    sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    sudo chmod +x /usr/local/bin/docker-compose
fi

# Start and enable Docker service
sudo systemctl start docker
sudo systemctl enable docker

echo "Docker installation completed"
EOF
    
    print_success "Docker and Docker Compose installed"
}

# Function to install Node.js and pnpm
install_nodejs() {
    print_status "Installing Node.js and pnpm..."
    
    ssh "$PI5_USER@$PI5_HOST" << 'EOF'
set -e

# Install Node.js 20.x LTS
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# Install pnpm
npm install -g pnpm

# Verify installations
node --version
npm --version
pnpm --version

echo "Node.js and pnpm installation completed"
EOF
    
    print_success "Node.js and pnpm installed"
}

# Function to clone repository
clone_repository() {
    print_status "Cloning Pi5 Supernode repository..."
    
    ssh "$PI5_USER@$PI5_HOST" << EOF
set -e

# Remove existing installation if present
if [[ -d "$INSTALL_DIR" ]]; then
    sudo rm -rf "$INSTALL_DIR"
fi

# Create installation directory
sudo mkdir -p "$INSTALL_DIR"
sudo chown -R $USER:$USER "$INSTALL_DIR"

# Clone repository
git clone "$REPO_URL" "$INSTALL_DIR"

echo "Repository cloned successfully"
EOF
    
    print_success "Repository cloned to $INSTALL_DIR"
}

# Function to setup environment variables
setup_environment() {
    print_status "Setting up environment configuration..."
    
    ssh "$PI5_USER@$PI5_HOST" << EOF
set -e

cd "$INSTALL_DIR"

# Create .env file
cat > .env << ENV_EOF
# Pi5 Supernode Environment Configuration
# Generated on: \$(date)

# Application
NODE_ENV=production
PORT=3000
HOST=0.0.0.0

# Database
DATABASE_URL=postgresql://supernode:supernode@localhost:5432/pi5_supernode
REDIS_URL=redis://localhost:6379

# Supabase (Use your actual Supabase credentials)
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_ANON_KEY=your-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key

# Network Configuration
NETWORK_INTERFACE=eth0
DHCP_RANGE_START=192.168.1.100
DHCP_RANGE_END=192.168.1.200
DNS_SERVER=8.8.8.8

# VPN Configuration
WIREGUARD_PORT=51820
VPN_NETWORK=10.0.0.0/24

# Security
JWT_SECRET=\$(openssl rand -base64 32)
ENCRYPTION_KEY=\$(openssl rand -base64 32)

# Monitoring
GRAFANA_ADMIN_PASSWORD=\$(openssl rand -base64 16)
PROMETHEUS_RETENTION=15d

# SSL/TLS
SSL_ENABLED=false
DOMAIN=$DOMAIN

ENV_EOF

echo "Environment configuration created"
EOF
    
    print_success "Environment variables configured"
}

# Function to install dependencies
install_dependencies() {
    print_status "Installing application dependencies..."
    
    ssh "$PI5_USER@$PI5_HOST" << EOF
set -e

cd "$INSTALL_DIR"

# Install frontend dependencies
cd pi5-supernode-platform
pnpm install --frozen-lockfile

# Build frontend for production
pnpm run build:prod

echo "Dependencies installed and frontend built"
EOF
    
    print_success "Application dependencies installed"
}

# Function to setup database
setup_database() {
    print_status "Setting up database with Docker..."
    
    ssh "$PI5_USER@$PI5_HOST" << EOF
set -e

cd "$INSTALL_DIR"

# Create docker-compose.yml for services
cat > docker-compose.yml << DOCKER_EOF
version: '3.8'

services:
  postgres:
    image: postgres:15-alpine
    container_name: pi5-postgres
    environment:
      POSTGRES_DB: pi5_supernode
      POSTGRES_USER: supernode
      POSTGRES_PASSWORD: supernode
    volumes:
      - postgres_data:/var/lib/postgresql/data
      - ./supabase/tables:/docker-entrypoint-initdb.d
    ports:
      - "5432:5432"
    restart: unless-stopped
    networks:
      - pi5-network

  redis:
    image: redis:7-alpine
    container_name: pi5-redis
    ports:
      - "6379:6379"
    restart: unless-stopped
    networks:
      - pi5-network

  prometheus:
    image: prom/prometheus:latest
    container_name: pi5-prometheus
    ports:
      - "9090:9090"
    volumes:
      - ./monitoring/prometheus.yml:/etc/prometheus/prometheus.yml
      - prometheus_data:/prometheus
    restart: unless-stopped
    networks:
      - pi5-network

  grafana:
    image: grafana/grafana:latest
    container_name: pi5-grafana
    ports:
      - "3001:3000"
    environment:
      - GF_SECURITY_ADMIN_PASSWORD=\${GRAFANA_ADMIN_PASSWORD}
    volumes:
      - grafana_data:/var/lib/grafana
      - ./monitoring/grafana/dashboards:/etc/grafana/provisioning/dashboards
    restart: unless-stopped
    networks:
      - pi5-network

volumes:
  postgres_data:
  prometheus_data:
  grafana_data:

networks:
  pi5-network:
    driver: bridge

DOCKER_EOF

# Start database services
docker-compose up -d postgres redis

# Wait for database to be ready
echo "Waiting for database to be ready..."
sleep 30

echo "Database setup completed"
EOF
    
    print_success "Database services started"
}

# Function to configure firewall
configure_firewall() {
    print_status "Configuring firewall (UFW)..."
    
    ssh "$PI5_USER@$PI5_HOST" << 'EOF'
set -e

# Reset UFW to defaults
sudo ufw --force reset

# Set default policies
sudo ufw default deny incoming
sudo ufw default allow outgoing

# Allow SSH
sudo ufw allow ssh

# Allow HTTP and HTTPS
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp

# Allow application ports
sudo ufw allow 3000/tcp  # Main application
sudo ufw allow 3001/tcp  # Grafana
sudo ufw allow 9090/tcp  # Prometheus

# Allow WireGuard VPN
sudo ufw allow 51820/udp

# Enable UFW
sudo ufw --force enable

# Show status
sudo ufw status verbose

echo "Firewall configuration completed"
EOF
    
    print_success "Firewall configured"
}

# Function to setup SSL certificates
setup_ssl() {
    if [[ -z "$DOMAIN" ]]; then
        print_warning "No domain specified, skipping SSL setup"
        return 0
    fi
    
    print_status "Setting up SSL certificates for $DOMAIN..."
    
    ssh "$PI5_USER@$PI5_HOST" << EOF
set -e

# Install Certbot
sudo apt install -y certbot python3-certbot-nginx

# Stop nginx temporarily
sudo systemctl stop nginx

# Get SSL certificate
sudo certbot certonly --standalone -d "$DOMAIN" --non-interactive --agree-tos --email admin@$DOMAIN

# Configure nginx with SSL
sudo tee /etc/nginx/sites-available/pi5-supernode << NGINX_EOF
server {
    listen 80;
    server_name $DOMAIN;
    return 301 https://\\\$server_name\\\$request_uri;
}

server {
    listen 443 ssl http2;
    server_name $DOMAIN;

    ssl_certificate /etc/letsencrypt/live/$DOMAIN/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/$DOMAIN/privkey.pem;
    
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers ECDHE-RSA-AES256-GCM-SHA512:DHE-RSA-AES256-GCM-SHA512:ECDHE-RSA-AES256-GCM-SHA384:DHE-RSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-SHA384;
    ssl_prefer_server_ciphers off;
    ssl_session_cache shared:SSL:10m;
    
    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \\\$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \\\$host;
        proxy_set_header X-Real-IP \\\$remote_addr;
        proxy_set_header X-Forwarded-For \\\$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \\\$scheme;
        proxy_cache_bypass \\\$http_upgrade;
    }
}
NGINX_EOF

# Enable site
sudo ln -sf /etc/nginx/sites-available/pi5-supernode /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default

# Test nginx configuration
sudo nginx -t

# Update environment for SSL
cd "$INSTALL_DIR"
sed -i 's/SSL_ENABLED=false/SSL_ENABLED=true/' .env

echo "SSL certificates configured"
EOF
    
    print_success "SSL certificates configured for $DOMAIN"
}

# Function to create systemd service
create_systemd_service() {
    print_status "Creating systemd service..."
    
    ssh "$PI5_USER@$PI5_HOST" << EOF
set -e

# Create systemd service file
sudo tee /etc/systemd/system/$SERVICE_NAME.service << SERVICE_EOF
[Unit]
Description=Pi5 Supernode Enterprise Network Management Platform
After=network.target docker.service
Requires=docker.service

[Service]
Type=simple
User=$PI5_USER
WorkingDirectory=$INSTALL_DIR
EnvironmentFile=$INSTALL_DIR/.env
ExecStartPre=/usr/local/bin/docker-compose up -d
ExecStart=/usr/bin/node pi5-supernode-platform/dist/server.js
ExecStop=/usr/local/bin/docker-compose down
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
SERVICE_EOF

# Reload systemd and enable service
sudo systemctl daemon-reload
sudo systemctl enable $SERVICE_NAME

echo "Systemd service created"
EOF
    
    print_success "Systemd service configured"
}

# Function to perform health checks
perform_health_checks() {
    print_status "Performing system health checks..."
    
    ssh "$PI5_USER@$PI5_HOST" << EOF
set -e

cd "$INSTALL_DIR"

# Check database connectivity
echo "Checking database connection..."
if docker exec pi5-postgres pg_isready -U supernode -d pi5_supernode; then
    echo "✓ Database connection successful"
else
    echo "✗ Database connection failed"
    exit 1
fi

# Check Redis connectivity
echo "Checking Redis connection..."
if docker exec pi5-redis redis-cli ping | grep -q PONG; then
    echo "✓ Redis connection successful"
else
    echo "✗ Redis connection failed"
    exit 1
fi

# Check disk space
echo "Checking disk space..."
df -h /

# Check memory usage
echo "Checking memory usage..."
free -h

# Check Docker status
echo "Checking Docker containers..."
docker-compose ps

echo "Health checks completed successfully"
EOF
    
    print_success "All health checks passed"
}

# Function to start services
start_services() {
    print_status "Starting Pi5 Supernode services..."
    
    ssh "$PI5_USER@$PI5_HOST" << EOF
set -e

cd "$INSTALL_DIR"

# Start all Docker services
docker-compose up -d

# Wait for services to be ready
echo "Waiting for services to start..."
sleep 15

# Start main application service
sudo systemctl start $SERVICE_NAME

# Start nginx
sudo systemctl start nginx
sudo systemctl enable nginx

echo "All services started successfully"
EOF
    
    print_success "All services are running"
}

# Function to display final information
show_completion_info() {
    print_success "Pi5 Supernode installation completed successfully!"
    
    echo ""
    echo "=== INSTALLATION SUMMARY ==="
    echo "Host: $PI5_USER@$PI5_HOST"
    echo "Installation Directory: $INSTALL_DIR"
    echo "Service Name: $SERVICE_NAME"
    
    if [[ -n "$DOMAIN" ]]; then
        echo "Web Interface: https://$DOMAIN"
    else
        echo "Web Interface: http://$PI5_HOST:3000"
    fi
    
    echo "Grafana Dashboard: http://$PI5_HOST:3001"
    echo "Prometheus Metrics: http://$PI5_HOST:9090"
    echo ""
    
    echo "=== USEFUL COMMANDS ==="
    echo "Check service status: ssh $PI5_USER@$PI5_HOST 'sudo systemctl status $SERVICE_NAME'"
    echo "View service logs: ssh $PI5_USER@$PI5_HOST 'sudo journalctl -u $SERVICE_NAME -f'"
    echo "Restart services: ssh $PI5_USER@$PI5_HOST 'sudo systemctl restart $SERVICE_NAME'"
    echo "Check Docker containers: ssh $PI5_USER@$PI5_HOST 'cd $INSTALL_DIR && docker-compose ps'"
    echo ""
    
    echo "=== NEXT STEPS ==="
    echo "1. Access the web interface and complete initial setup"
    echo "2. Configure Supabase credentials in .env file"
    echo "3. Set up automation rules and network policies"
    echo "4. Configure monitoring alerts in Grafana"
    echo "5. Review firewall settings and security policies"
    echo ""
    
    print_warning "Please update the Supabase credentials in $INSTALL_DIR/.env before full operation"
}

# Main installation function
main() {
    clear
    cat << 'EOF'

   ____  _ ____    ____                                     _      
  |  _ \(_) ___|  / ___| _   _ _ __   ___ _ __ _ __   ___   __| | ___ 
  | |_) | |___ \  \___ \| | | | '_ \ / _ \ '__| '_ \ / _ \ / _` |/ _ \
  |  __/| |___) |  ___) | |_| | |_) |  __/ |  | | | | (_) | (_| |  __/
  |_|   |_|____/  |____/ \__,_| .__/ \___|_|  |_| |_|\___/ \__,_|\___|
                              |_|                                   

  Enterprise Network Management Platform - Automated Installer
  Version 2.1.0

EOF
    
    print_status "Starting Pi5 Supernode installation..."
    print_status "Target: $PI5_USER@$PI5_HOST"
    
    if [[ -n "$DOMAIN" ]]; then
        print_status "Domain: $DOMAIN"
    fi
    
    echo ""
    
    # Execute installation steps
    test_ssh_connection || exit 1
    check_system_requirements
    update_system
    install_docker
    install_nodejs
    clone_repository
    setup_environment
    install_dependencies
    setup_database
    configure_firewall
    setup_ssl
    create_systemd_service
    perform_health_checks
    start_services
    
    # Show completion information
    show_completion_info
}

# Handle script interruption
trap 'print_error "Installation interrupted"; exit 1' INT TERM

# Check if script is being piped from curl
if [[ -p /dev/stdin ]]; then
    # Save script to temporary file when piped from curl
    TEMP_SCRIPT=$(mktemp)
    cat > "$TEMP_SCRIPT"
    chmod +x "$TEMP_SCRIPT"
    exec "$TEMP_SCRIPT" "$@"
else
    # Run directly
    main "$@"
fi
