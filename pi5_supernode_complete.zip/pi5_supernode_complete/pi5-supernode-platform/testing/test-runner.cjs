#!/usr/bin/env node
/**
 * Automated system validation test runner
 * Tests core functionality without requiring the full application to be running
 */

const fs = require('fs');
const path = require('path');

// Test configuration
const TEST_CONFIG = {
  timeout: 30000,
  retries: 3,
  baseUrl: process.env.TEST_BASE_URL || 'http://localhost:3000'
};

// Test results collector
const testResults = {
  passed: 0,
  failed: 0,
  warnings: 0,
  tests: []
};

// Utility functions
function log(message, type = 'info') {
  const timestamp = new Date().toISOString();
  const prefix = {
    info: '📋',
    success: '✅',
    warning: '⚠️',
    error: '❌'
  }[type] || '📋';
  
  console.log(`${prefix} [${timestamp}] ${message}`);
}

function addTestResult(name, status, message, details = null) {
  const result = { name, status, message, details, timestamp: new Date().toISOString() };
  testResults.tests.push(result);
  
  switch(status) {
    case 'PASS': testResults.passed++; break;
    case 'FAIL': testResults.failed++; break;
    case 'WARN': testResults.warnings++; break;
  }
  
  log(`${name}: ${message}`, status === 'PASS' ? 'success' : status === 'FAIL' ? 'error' : 'warning');
}

// Test functions
async function testFileStructure() {
  log('Testing file structure and organization...');
  
  const requiredFiles = [
    'src/lib/services/index.ts',
    'src/lib/services/networkService.ts',
    'src/lib/services/deviceService.ts',
    'src/lib/services/vpnService.ts',
    'src/lib/types/forms.ts',
    'src/lib/utils/validation.ts',
    'src/lib/hooks/useForm.ts',
    'src/lib/constants/index.ts',
    'src/components/views/network.tsx',
    'src/components/views/dashboard.tsx',
    'src/components/views/vpn.tsx',
    'scripts/pi5-auto-install.sh'
  ];
  
  let missingFiles = [];
  let presentFiles = [];
  
  for (const file of requiredFiles) {
    const fullPath = path.join(process.cwd(), file);
    if (fs.existsSync(fullPath)) {
      presentFiles.push(file);
    } else {
      missingFiles.push(file);
    }
  }
  
  if (missingFiles.length === 0) {
    addTestResult('File Structure', 'PASS', `All ${requiredFiles.length} required files present`);
  } else {
    addTestResult('File Structure', 'FAIL', `Missing ${missingFiles.length} files: ${missingFiles.join(', ')}`);
  }
}

async function testServiceIntegration() {
  log('Testing service layer integration...');
  
  try {
    // Check if services can be imported
    const servicesIndexPath = path.join(process.cwd(), 'src/lib/services/index.ts');
    const servicesContent = fs.readFileSync(servicesIndexPath, 'utf8');
    
    const requiredExports = [
      'DeviceService',
      'NetworkService', 
      'VPNService',
      'AutomationService',
      'ObservabilityService',
      'StorageService'
    ];
    
    let missingExports = [];
    for (const exportName of requiredExports) {
      if (!servicesContent.includes(exportName)) {
        missingExports.push(exportName);
      }
    }
    
    if (missingExports.length === 0) {
      addTestResult('Service Integration', 'PASS', 'All required services exported properly');
    } else {
      addTestResult('Service Integration', 'FAIL', `Missing service exports: ${missingExports.join(', ')}`);
    }
    
  } catch (error) {
    addTestResult('Service Integration', 'FAIL', `Error reading services: ${error.message}`);
  }
}

async function testMockDataRemoval() {
  log('Verifying mock data removal...');
  
  try {
    const srcDir = path.join(process.cwd(), 'src');
    let mockReferences = [];
    
    function scanDirectory(dir) {
      const files = fs.readdirSync(dir);
      
      for (const file of files) {
        const filePath = path.join(dir, file);
        const stat = fs.statSync(filePath);
        
        if (stat.isDirectory()) {
          scanDirectory(filePath);
        } else if (file.endsWith('.tsx') || file.endsWith('.ts')) {
          const content = fs.readFileSync(filePath, 'utf8');
          
          // Check for mock patterns
          const mockPatterns = [
            /import.*mock/i,
            /mockData/i,
            /mock.*Service/i,
            /setTimeout.*resolve/,
            /simulate.*discovery/i
          ];
          
          for (const pattern of mockPatterns) {
            if (pattern.test(content)) {
              const relativePath = path.relative(srcDir, filePath);
              mockReferences.push(`${relativePath}: ${pattern}`);
            }
          }
        }
      }
    }
    
    scanDirectory(srcDir);
    
    if (mockReferences.length === 0) {
      addTestResult('Mock Data Removal', 'PASS', 'No mock data references found');
    } else {
      addTestResult('Mock Data Removal', 'WARN', `Found ${mockReferences.length} potential mock references`, mockReferences);
    }
    
  } catch (error) {
    addTestResult('Mock Data Removal', 'FAIL', `Error scanning for mock data: ${error.message}`);
  }
}

async function testDropdownStyling() {
  log('Testing dropdown styling consistency...');
  
  try {
    const cssPath = path.join(process.cwd(), 'src/index.css');
    const cssContent = fs.readFileSync(cssPath, 'utf8');
    
    // Check for updated enterprise-input class
    const enterpriseInputPattern = /\.enterprise-input\s*\{[^}]*bg-gray-800[^}]*\}/s;
    
    if (enterpriseInputPattern.test(cssContent)) {
      addTestResult('Dropdown Styling', 'PASS', 'Enterprise-input class updated with gray theme');
    } else {
      addTestResult('Dropdown Styling', 'FAIL', 'Enterprise-input class not updated to gray theme');
    }
    
  } catch (error) {
    addTestResult('Dropdown Styling', 'FAIL', `Error checking CSS: ${error.message}`);
  }
}

async function testCodeConsolidation() {
  log('Testing code consolidation...');
  
  try {
    const consolidatedFiles = [
      'src/lib/types/forms.ts',
      'src/lib/utils/validation.ts', 
      'src/lib/hooks/useForm.ts',
      'src/lib/constants/index.ts'
    ];
    
    let consolidationScore = 0;
    let details = [];
    
    for (const file of consolidatedFiles) {
      const fullPath = path.join(process.cwd(), file);
      if (fs.existsSync(fullPath)) {
        const content = fs.readFileSync(fullPath, 'utf8');
        if (content.length > 500) { // Basic check for substantial content
          consolidationScore++;
          details.push(`${file}: ${content.length} characters`);
        }
      }
    }
    
    if (consolidationScore >= 3) {
      addTestResult('Code Consolidation', 'PASS', `${consolidationScore}/4 consolidation files created with substantial content`, details);
    } else {
      addTestResult('Code Consolidation', 'WARN', `Only ${consolidationScore}/4 consolidation files found`, details);
    }
    
  } catch (error) {
    addTestResult('Code Consolidation', 'FAIL', `Error checking consolidation: ${error.message}`);
  }
}

async function testInstallationScript() {
  log('Testing installation script...');
  
  try {
    const scriptPath = path.join(process.cwd(), 'scripts/pi5-auto-install.sh');
    
    if (!fs.existsSync(scriptPath)) {
      addTestResult('Installation Script', 'FAIL', 'Installation script not found');
      return;
    }
    
    const scriptContent = fs.readFileSync(scriptPath, 'utf8');
    
    // Check for key components in the script
    const requiredComponents = [
      'parse_args',
      'install_dependencies',
      'clone_repo',
      'setup_env',
      'docker',
      'git'
    ];
    
    let missingComponents = [];
    for (const component of requiredComponents) {
      if (!scriptContent.includes(component)) {
        missingComponents.push(component);
      }
    }
    
    if (missingComponents.length === 0) {
      addTestResult('Installation Script', 'PASS', 'Installation script contains all required components');
    } else {
      addTestResult('Installation Script', 'WARN', `Missing components: ${missingComponents.join(', ')}`);
    }
    
  } catch (error) {
    addTestResult('Installation Script', 'FAIL', `Error checking script: ${error.message}`);
  }
}

// Main test execution
async function runTests() {
  log('Starting Pi5 Supernode System Validation', 'info');
  log(`Test configuration: ${JSON.stringify(TEST_CONFIG)}`, 'info');
  
  try {
    await testFileStructure();
    await testServiceIntegration();
    await testMockDataRemoval();
    await testDropdownStyling();
    await testCodeConsolidation();
    await testInstallationScript();
    
    // Generate summary
    log('\n=== TEST SUMMARY ===', 'info');
    log(`Total Tests: ${testResults.tests.length}`, 'info');
    log(`Passed: ${testResults.passed}`, 'success');
    log(`Warnings: ${testResults.warnings}`, 'warning');
    log(`Failed: ${testResults.failed}`, 'error');
    
    // Save detailed results
    const resultsPath = path.join(process.cwd(), 'testing/test-results.json');
    fs.writeFileSync(resultsPath, JSON.stringify(testResults, null, 2));
    log(`Detailed results saved to: ${resultsPath}`, 'info');
    
    // Generate markdown report
    generateMarkdownReport();
    
    // Exit with appropriate code
    process.exit(testResults.failed > 0 ? 1 : 0);
    
  } catch (error) {
    log(`Test execution failed: ${error.message}`, 'error');
    process.exit(1);
  }
}

function generateMarkdownReport() {
  log('Generating markdown report...');
  
  let report = `# Pi5 Supernode System Validation Report\n\n`;
  report += `**Generated:** ${new Date().toISOString()}\n\n`;
  report += `## Summary\n\n`;
  report += `- **Total Tests:** ${testResults.tests.length}\n`;
  report += `- **Passed:** ✅ ${testResults.passed}\n`;
  report += `- **Warnings:** ⚠️ ${testResults.warnings}\n`;
  report += `- **Failed:** ❌ ${testResults.failed}\n\n`;
  
  report += `## Detailed Results\n\n`;
  
  for (const test of testResults.tests) {
    const statusIcon = {
      'PASS': '✅',
      'WARN': '⚠️', 
      'FAIL': '❌'
    }[test.status] || '❓';
    
    report += `### ${statusIcon} ${test.name}\n\n`;
    report += `**Status:** ${test.status}\n\n`;
    report += `**Message:** ${test.message}\n\n`;
    
    if (test.details) {
      report += `**Details:**\n\`\`\`\n${Array.isArray(test.details) ? test.details.join('\n') : test.details}\n\`\`\`\n\n`;
    }
    
    report += `**Timestamp:** ${test.timestamp}\n\n`;
    report += `---\n\n`;
  }
  
  const reportPath = path.join(process.cwd(), 'testing/validation-report.md');
  fs.writeFileSync(reportPath, report);
  log(`Markdown report saved to: ${reportPath}`, 'info');
}

// Run tests if this script is executed directly
if (require.main === module) {
  runTests();
}

module.exports = { runTests, testResults };
