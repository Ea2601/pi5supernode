/** @type {import('tailwindcss').Config} */
export default {
  darkMode: ['class'],
  content: [
    './pages/**/*.{ts,tsx}',
    './components/**/*.{ts,tsx}',
    './app/**/*.{ts,tsx}',
    './src/**/*.{ts,tsx}',
  ],
  prefix: '',
  theme: {
    container: {
      center: true,
      padding: {
        DEFAULT: '1rem',
        sm: '1.5rem',
        lg: '2rem',
      },
      screens: {
        sm: '640px',
        md: '768px',
        lg: '1024px',
        xl: '1280px',
        '2xl': '1400px',
      },
    },
    screens: {
      xs: '320px',
      sm: '640px',
      md: '768px',
      lg: '1024px',
      xl: '1280px',
      '2xl': '1536px',
    },
    extend: {
      colors: {
        border: 'hsl(var(--border))',
        input: 'hsl(var(--input))',
        ring: 'hsl(var(--ring))',
        background: 'hsl(var(--background))',
        foreground: 'hsl(var(--foreground))',
        primary: {
          DEFAULT: 'hsl(var(--primary))',
          foreground: 'hsl(var(--primary-foreground))',
        },
        secondary: {
          DEFAULT: 'hsl(var(--secondary))',
          foreground: 'hsl(var(--secondary-foreground))',
        },
        destructive: {
          DEFAULT: 'hsl(var(--destructive))',
          foreground: 'hsl(var(--destructive-foreground))',
        },
        muted: {
          DEFAULT: 'hsl(var(--muted))',
          foreground: 'hsl(var(--muted-foreground))',
        },
        accent: {
          DEFAULT: 'hsl(var(--accent))',
          foreground: 'hsl(var(--accent-foreground))',
        },
        popover: {
          DEFAULT: 'hsl(var(--popover))',
          foreground: 'hsl(var(--popover-foreground))',
        },
        card: {
          DEFAULT: 'hsl(var(--card))',
          foreground: 'hsl(var(--card-foreground))',
        },
        // Phosphorescent Blue-Green-Turquoise Theme
        'phosphor': {
          'dark': '#0B0E1A',
          'darker': '#070B14',
          'navy': '#0F1419',
          'navy-light': '#1A2332',
          'navy-lighter': '#2A3441',
          'turquoise': '#00CED1',
          'turquoise-light': '#40E0D0',
          'turquoise-glow': '#7FECEF',
          'blue': '#0099CC',
          'blue-dark': '#0077BE',
          'blue-glow': '#33B5E5',
          'green': '#00FF7F',
          'green-dark': '#32CD32',
          'green-glow': '#7FFF9F',
          'success': '#00FF7F',
          'warning': '#FFD700',
          'danger': '#FF4757',
          'info': '#40E0D0'
        }
      },
      borderRadius: {
        lg: 'var(--radius)',
        md: 'calc(var(--radius) - 2px)',
        sm: 'calc(var(--radius) - 4px)',
      },
      keyframes: {
        'accordion-down': {
          from: { height: '0' },
          to: { height: 'var(--radix-accordion-content-height)' },
        },
        'accordion-up': {
          from: { height: 'var(--radix-accordion-content-height)' },
          to: { height: '0' },
        },
        'pulse-phosphor': {
          '0%, 100%': { 
            boxShadow: '0 0 5px #00CED1, 0 0 10px #00CED1, 0 0 15px #00CED1, 0 0 20px #00CED1',
            textShadow: '0 0 5px #00CED1, 0 0 10px #00CED1'
          },
          '50%': { 
            boxShadow: '0 0 10px #40E0D0, 0 0 20px #40E0D0, 0 0 30px #40E0D0, 0 0 40px #40E0D0',
            textShadow: '0 0 10px #40E0D0, 0 0 20px #40E0D0'
          }
        },
        'pulse-green': {
          '0%, 100%': { 
            boxShadow: '0 0 5px #00FF7F, 0 0 10px #00FF7F, 0 0 15px #00FF7F',
            textShadow: '0 0 5px #00FF7F'
          },
          '50%': { 
            boxShadow: '0 0 10px #32CD32, 0 0 20px #32CD32, 0 0 30px #32CD32',
            textShadow: '0 0 10px #32CD32'
          }
        },
        'pulse-blue': {
          '0%, 100%': { 
            boxShadow: '0 0 5px #0099CC, 0 0 10px #0099CC, 0 0 15px #0099CC',
            textShadow: '0 0 5px #0099CC'
          },
          '50%': { 
            boxShadow: '0 0 10px #0077BE, 0 0 20px #0077BE, 0 0 30px #0077BE',
            textShadow: '0 0 10px #0077BE'
          }
        },
        'glow-rotate': {
          '0%': { filter: 'hue-rotate(0deg)' },
          '100%': { filter: 'hue-rotate(360deg)' }
        },
        'slide-in': {
          '0%': { transform: 'translateX(-100%)', opacity: '0' },
          '100%': { transform: 'translateX(0)', opacity: '1' }
        },
        'fade-in': {
          '0%': { opacity: '0', transform: 'translateY(10px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' }
        },
        'phosphor-float': {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-5px)' }
        }
      },
      animation: {
        'accordion-down': 'accordion-down 0.2s ease-out',
        'accordion-up': 'accordion-up 0.2s ease-out',
        'pulse-phosphor': 'pulse-phosphor 2s ease-in-out infinite',
        'pulse-green': 'pulse-green 2.5s ease-in-out infinite',
        'pulse-blue': 'pulse-blue 3s ease-in-out infinite',
        'glow-rotate': 'glow-rotate 4s linear infinite',
        'slide-in': 'slide-in 0.5s ease-out',
        'fade-in': 'fade-in 0.3s ease-out',
        'phosphor-float': 'phosphor-float 3s ease-in-out infinite'
      },
      backdropBlur: {
        'xs': '2px',
      },
      backgroundImage: {
        'gradient-radial': 'radial-gradient(var(--tw-gradient-stops))',
        'gradient-conic': 'conic-gradient(from 180deg at 50% 50%, var(--tw-gradient-stops))',
        'phosphor-mesh': 'linear-gradient(135deg, rgba(0,206,209,0.15) 0%, rgba(11,14,26,0.9) 25%, rgba(64,224,208,0.1) 50%, rgba(15,20,25,0.9) 75%, rgba(0,153,204,0.15) 100%)',
        'phosphor-glow': 'radial-gradient(circle, rgba(0,206,209,0.2) 0%, rgba(64,224,208,0.1) 30%, transparent 70%)',
        'green-glow': 'radial-gradient(circle, rgba(0,255,127,0.2) 0%, rgba(50,205,50,0.1) 30%, transparent 70%)',
        'blue-glow': 'radial-gradient(circle, rgba(0,153,204,0.2) 0%, rgba(0,119,190,0.1) 30%, transparent 70%)'
      }
    },
  },
  plugins: [require('tailwindcss-animate')],
}