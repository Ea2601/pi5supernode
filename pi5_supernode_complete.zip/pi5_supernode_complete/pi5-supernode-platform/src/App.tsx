import React, { useEffect, useState, Suspense } from 'react'
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { supabase } from '@/lib/supabase'
import { useAuthStore, useUIStore } from '@/lib/store'
import Layout from '@/components/layout'
import LoadingSpinner from '@/components/ui/loading-spinner'

// Lazy load route components for better performance
const Dashboard = React.lazy(() => import('@/components/views/dashboard'))
const SpeedTesting = React.lazy(() => import('@/components/views/speed-testing'))
const TrafficRules = React.lazy(() => import('@/components/views/traffic-rules'))


const Network = React.lazy(() => import('@/components/views/network'))
const Devices = React.lazy(() => import('@/components/views/devices'))
const Observability = React.lazy(() => import('@/components/views/observability'))
const Storage = React.lazy(() => import('@/components/views/storage'))

// System Management Routes
const WANSettings = React.lazy(() => import('@/components/views/wan-settings'))
const VPNManagement = React.lazy(() => import('@/components/views/vpn-management'))
const VPN = React.lazy(() => import('@/components/views/vpn'))
const Automations = React.lazy(() => import('@/components/views/automations'))

// Documentation Routes
const Documentation = React.lazy(() => import('@/components/views/documentation'))

// Settings Routes
const SettingsMain = React.lazy(() => import('@/components/views/settings/settings-main'))
const SettingsSystem = React.lazy(() => import('@/components/views/settings/settings-system'))
const SettingsSecurity = React.lazy(() => import('@/components/views/settings/settings-security'))
const SettingsBackup = React.lazy(() => import('@/components/views/settings/settings-backup'))
const SettingsUsers = React.lazy(() => import('@/components/views/settings/settings-users'))
const SettingsAdvanced = React.lazy(() => import('@/components/views/settings/settings-advanced'))

// Create a stable query client
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 5, // 5 minutes
      refetchOnWindowFocus: false,
    },
  },
})

function App() {
  const { user, setUser, setSession, setLoading } = useAuthStore()
  const { currentView } = useUIStore()
  const [initializing, setInitializing] = useState(true)

  useEffect(() => {
    // Get initial session
    const getInitialSession = async () => {
      setLoading(true)
      try {
        const { data: { session }, error } = await supabase.auth.getSession()
        if (error) {
          console.error('Error getting session:', error)
        } else {
          setSession(session)
          setUser(session?.user || null)
        }
      } catch (error) {
        console.error('Error during initialization:', error)
      } finally {
        setLoading(false)
        setInitializing(false)
      }
    }

    getInitialSession()

    // Set up auth listener
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (_event, session) => {
        setSession(session)
        setUser(session?.user || null)
        setLoading(false)
      }
    )

    return () => subscription.unsubscribe()
  }, [])



  if (initializing) {
    return (
      <div className="min-h-screen bg-phosphor-dark flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-2 border-phosphor-turquoise border-t-transparent mx-auto mb-4" />
          <p className="text-white text-lg">Initializing Pi5 Supernode...</p>
        </div>
      </div>
    )
  }

  return (
    <QueryClientProvider client={queryClient}>
      <Router>
        <div className="App">
          <Layout>
            <Suspense fallback={<LoadingSpinner />}>
              <Routes>
                {/* Main Routes */}
                <Route path="/" element={<Navigate to="/dashboard" replace />} />
                <Route path="/dashboard" element={<Dashboard />} />
                <Route path="/speed-testing" element={<SpeedTesting />} />
                <Route path="/traffic-rules" element={<TrafficRules />} />
                

                <Route path="/network" element={<Network />} />
                <Route path="/devices" element={<Devices />} />
                <Route path="/observability" element={<Observability />} />
                <Route path="/storage" element={<Storage />} />
                
                {/* System Management Routes */}
                <Route path="/wan-settings" element={<WANSettings />} />
                <Route path="/vpn-management" element={<VPNManagement />} />
                <Route path="/vpn" element={<VPN />} />
                <Route path="/automations" element={<Automations />} />
                
                {/* Documentation Routes */}
                <Route path="/documentation" element={<Documentation />} />
                
                {/* Settings Routes - Nested structure */}
                <Route path="/settings" element={<SettingsMain />}>
                  <Route path="system" element={<SettingsSystem />} />
                  <Route path="security" element={<SettingsSecurity />} />
                  <Route path="backup" element={<SettingsBackup />} />
                  <Route path="users" element={<SettingsUsers />} />
                  <Route path="advanced" element={<SettingsAdvanced />} />
                </Route>
                
                {/* Fallback */}
                <Route path="*" element={<Navigate to="/dashboard" replace />} />
              </Routes>
            </Suspense>
          </Layout>
        </div>
      </Router>
    </QueryClientProvider>
  )
}

export default App