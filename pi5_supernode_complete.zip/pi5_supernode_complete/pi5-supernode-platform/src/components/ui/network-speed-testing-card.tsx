import React, { useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Wifi,
  TrendingUp,
  TrendingDown,
  RefreshCw,
  Activity,
  Clock,
  AlertTriangle,
  CheckCircle,
  Timer,
  BarChart3,
  Signal,
  Download,
  Upload,
  Zap
} from 'lucide-react'
import { Card, CardHeader, CardTitle, CardContent } from './card'
import { Button } from './button'
import { supabase } from '@/lib/supabase'
import { cn } from '@/lib/utils'

interface SpeedTestResult {
  id: string
  connection_type: string
  connection_name: string
  download_speed_mbps: number
  upload_speed_mbps: number
  ping_ms: number
  jitter_ms: number
  packet_loss_percentage: number
  server_location: string
  test_status: string
  created_at: string
}

interface ConnectionStatus {
  connectionType: string
  connectionName: string
  latestTest: SpeedTestResult | null
  quality: 'excellent' | 'good' | 'poor' | 'unknown'
  lastTested: string | null
}

interface HistoricalData {
  date_recorded: string
  avg_download_mbps: number
  avg_upload_mbps: number
  avg_ping_ms: number
  test_count: number
}

const NetworkSpeedTestingCard: React.FC = () => {
  const [connections, setConnections] = useState<ConnectionStatus[]>([])
  const [selectedConnection, setSelectedConnection] = useState<string>('local')
  const [loading, setLoading] = useState(false)
  const [testingConnection, setTestingConnection] = useState<string | null>(null)
  const [historicalData, setHistoricalData] = useState<HistoricalData[]>([])
  const [showChart, setShowChart] = useState(false)
  const [autoTesting, setAutoTesting] = useState(true)

  useEffect(() => {
    loadConnectionsStatus()
    loadHistoricalData()
    
    // Auto-refresh every 30 seconds
    const interval = setInterval(() => {
      if (!testingConnection) {
        loadConnectionsStatus()
      }
    }, 30000)
    
    return () => clearInterval(interval)
  }, [])

  const loadConnectionsStatus = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('network-speed-testing', {
        body: { action: 'get_all_connections_status' }
      })

      if (error) throw error
      setConnections(data.data.connections || [])
    } catch (error) {
      console.error('Error loading connections status:', error)
    }
  }

  const loadHistoricalData = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('network-speed-testing', {
        body: { 
          action: 'get_historical_data',
          connectionType: selectedConnection,
          testConfig: { days: 7 }
        }
      })

      if (error) throw error
      setHistoricalData(data.data.history || [])
    } catch (error) {
      console.error('Error loading historical data:', error)
    }
  }

  const runSpeedTest = async (connectionType: string, connectionName: string) => {
    setTestingConnection(connectionType)
    setLoading(true)
    
    try {
      const { data, error } = await supabase.functions.invoke('network-speed-testing', {
        body: {
          action: 'run_speed_test',
          connectionType,
          connectionName,
          testConfig: {}
        }
      })

      if (error) throw error
      
      // Update the connections status
      await loadConnectionsStatus()
      if (connectionType === selectedConnection) {
        await loadHistoricalData()
      }
    } catch (error) {
      console.error('Error running speed test:', error)
    } finally {
      setTestingConnection(null)
      setLoading(false)
    }
  }

  const getQualityColor = (quality: string) => {
    switch (quality) {
      case 'excellent': return 'text-green-400'
      case 'good': return 'text-yellow-400'
      case 'poor': return 'text-red-400'
      default: return 'text-gray-400'
    }
  }

  const getQualityIcon = (quality: string) => {
    switch (quality) {
      case 'excellent': return CheckCircle
      case 'good': return Activity
      case 'poor': return AlertTriangle
      default: return Timer
    }
  }

  const selectedConnectionData = connections.find(c => c.connectionType === selectedConnection)
  const latestTest = selectedConnectionData?.latestTest

  const formatSpeed = (speed: number) => {
    return speed > 1000 ? `${(speed / 1000).toFixed(2)} Gbps` : `${speed.toFixed(1)} Mbps`
  }

  const formatLastTested = (timestamp: string | null) => {
    if (!timestamp) return 'Never'
    const date = new Date(timestamp)
    const now = new Date()
    const diffMs = now.getTime() - date.getTime()
    const diffMins = Math.floor(diffMs / 60000)
    
    if (diffMins < 1) return 'Just now'
    if (diffMins < 60) return `${diffMins}m ago`
    const diffHours = Math.floor(diffMins / 60)
    if (diffHours < 24) return `${diffHours}h ago`
    const diffDays = Math.floor(diffHours / 24)
    return `${diffDays}d ago`
  }

  return (
    <Card className="bg-white/5 border-white/10">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Wifi className="h-5 w-5 text-enterprise-neon" />
            <span>Network Speed Testing</span>
            {autoTesting && (
              <div className="flex items-center space-x-1 px-2 py-1 bg-green-500/20 text-green-400 text-xs rounded-full">
                <div className="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse" />
                <span>Auto</span>
              </div>
            )}
          </div>
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowChart(!showChart)}
            >
              <BarChart3 className="h-4 w-4 mr-1" />
              {showChart ? 'Hide' : 'Chart'}
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={loadConnectionsStatus}
              disabled={loading}
            >
              <RefreshCw className={cn('h-4 w-4', loading && 'animate-spin')} />
            </Button>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Connection Selector */}
        <div className="flex flex-wrap gap-2">
          {connections.map((connection) => {
            const QualityIcon = getQualityIcon(connection.quality)
            const isTesting = testingConnection === connection.connectionType
            
            return (
              <button
                key={connection.connectionType}
                onClick={() => {
                  setSelectedConnection(connection.connectionType)
                  loadHistoricalData()
                }}
                className={cn(
                  'flex items-center space-x-2 px-3 py-2 rounded-lg border transition-all',
                  selectedConnection === connection.connectionType
                    ? 'bg-enterprise-neon/20 border-enterprise-neon text-enterprise-neon'
                    : 'bg-white/5 border-white/10 text-gray-300 hover:bg-white/10'
                )}
                disabled={isTesting}
              >
                {isTesting ? (
                  <RefreshCw className="h-4 w-4 animate-spin" />
                ) : (
                  <QualityIcon className={cn('h-4 w-4', getQualityColor(connection.quality))} />
                )}
                <span className="text-sm font-medium">
                  {connection.connectionName}
                </span>
              </button>
            )
          })}
        </div>

        {/* Current Speed Display */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <Download className="h-5 w-5 text-green-400" />
              <span className="text-sm font-medium text-gray-300">Download</span>
            </div>
            <div className="text-3xl font-bold text-white">
              {latestTest ? formatSpeed(latestTest.download_speed_mbps) : '-- Mbps'}
            </div>
            {latestTest && (
              <div className="w-full bg-gray-700 rounded-full h-2">
                <motion.div 
                  className="bg-green-400 h-2 rounded-full"
                  initial={{ width: 0 }}
                  animate={{ width: `${Math.min((latestTest.download_speed_mbps / 200) * 100, 100)}%` }}
                  transition={{ duration: 1, ease: 'easeOut' }}
                />
              </div>
            )}
          </div>

          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <Upload className="h-5 w-5 text-blue-400" />
              <span className="text-sm font-medium text-gray-300">Upload</span>
            </div>
            <div className="text-3xl font-bold text-white">
              {latestTest ? formatSpeed(latestTest.upload_speed_mbps) : '-- Mbps'}
            </div>
            {latestTest && (
              <div className="w-full bg-gray-700 rounded-full h-2">
                <motion.div 
                  className="bg-blue-400 h-2 rounded-full"
                  initial={{ width: 0 }}
                  animate={{ width: `${Math.min((latestTest.upload_speed_mbps / 100) * 100, 100)}%` }}
                  transition={{ duration: 1, ease: 'easeOut' }}
                />
              </div>
            )}
          </div>

          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <Zap className="h-5 w-5 text-yellow-400" />
              <span className="text-sm font-medium text-gray-300">Ping</span>
            </div>
            <div className="text-3xl font-bold text-white">
              {latestTest ? `${latestTest.ping_ms.toFixed(1)} ms` : '-- ms'}
            </div>
            {latestTest && (
              <div className="flex items-center space-x-2">
                <span className="text-sm text-gray-400">Jitter: {latestTest.jitter_ms.toFixed(1)} ms</span>
                <span className="text-sm text-gray-400">Loss: {latestTest.packet_loss_percentage.toFixed(2)}%</span>
              </div>
            )}
          </div>
        </div>

        {/* Quality Indicator and Details */}
        <div className="flex items-center justify-between p-4 bg-white/5 rounded-lg">
          <div className="flex items-center space-x-3">
            {selectedConnectionData && (
              <>
                {React.createElement(getQualityIcon(selectedConnectionData.quality), {
                  className: cn('h-6 w-6', getQualityColor(selectedConnectionData.quality))
                })}
                <div>
                  <div className={cn('font-semibold text-lg', getQualityColor(selectedConnectionData.quality))}>
                    {selectedConnectionData.quality.charAt(0).toUpperCase() + selectedConnectionData.quality.slice(1)}
                  </div>
                  <div className="text-sm text-gray-400">
                    Last tested: {formatLastTested(selectedConnectionData.lastTested)}
                  </div>
                </div>
              </>
            )}
          </div>
          
          <div className="flex items-center space-x-2">
            <div className="text-right text-sm text-gray-400">
              {latestTest && (
                <div>Server: {latestTest.server_location}</div>
              )}
            </div>
            
            <Button
              onClick={() => selectedConnectionData && runSpeedTest(selectedConnectionData.connectionType, selectedConnectionData.connectionName)}
              disabled={!selectedConnectionData || testingConnection === selectedConnection}
              className="bg-enterprise-neon hover:bg-enterprise-neon/80"
            >
              {testingConnection === selectedConnection ? (
                <>
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  Testing...
                </>
              ) : (
                <>
                  <Activity className="h-4 w-4 mr-2" />
                  Run Test
                </>
              )}
            </Button>
          </div>
        </div>

        {/* Historical Chart */}
        <AnimatePresence>
          {showChart && historicalData.length > 0 && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.3 }}
              className="space-y-4"
            >
              <h4 className="text-lg font-semibold text-white flex items-center space-x-2">
                <TrendingUp className="h-5 w-5 text-enterprise-neon" />
                <span>7-Day Performance History</span>
              </h4>
              
              <div className="bg-white/5 rounded-lg p-4">
                <div className="space-y-4">
                  {historicalData.map((day, index) => {
                    const maxDownload = Math.max(...historicalData.map(d => d.avg_download_mbps))
                    const maxUpload = Math.max(...historicalData.map(d => d.avg_upload_mbps))
                    
                    return (
                      <div key={day.date_recorded} className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-300">
                            {new Date(day.date_recorded).toLocaleDateString()}
                          </span>
                          <span className="text-gray-400">
                            {day.test_count} tests
                          </span>
                        </div>
                        
                        <div className="space-y-1">
                          <div className="flex items-center space-x-2">
                            <div className="w-16 text-xs text-gray-400">Download</div>
                            <div className="flex-1 bg-gray-700 rounded-full h-2 relative">
                              <motion.div
                                className="bg-green-400 h-2 rounded-full"
                                initial={{ width: 0 }}
                                animate={{ width: `${(day.avg_download_mbps / maxDownload) * 100}%` }}
                                transition={{ duration: 0.8, delay: index * 0.1 }}
                              />
                            </div>
                            <div className="w-16 text-xs text-white text-right">
                              {day.avg_download_mbps.toFixed(1)} Mbps
                            </div>
                          </div>
                          
                          <div className="flex items-center space-x-2">
                            <div className="w-16 text-xs text-gray-400">Upload</div>
                            <div className="flex-1 bg-gray-700 rounded-full h-2 relative">
                              <motion.div
                                className="bg-blue-400 h-2 rounded-full"
                                initial={{ width: 0 }}
                                animate={{ width: `${(day.avg_upload_mbps / maxUpload) * 100}%` }}
                                transition={{ duration: 0.8, delay: index * 0.1 + 0.1 }}
                              />
                            </div>
                            <div className="w-16 text-xs text-white text-right">
                              {day.avg_upload_mbps.toFixed(1)} Mbps
                            </div>
                          </div>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Quick Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center p-3 bg-white/5 rounded-lg">
            <div className="text-sm text-gray-400">Active Tests</div>
            <div className="text-lg font-bold text-white">
              {connections.filter(c => c.latestTest).length}/{connections.length}
            </div>
          </div>
          
          <div className="text-center p-3 bg-white/5 rounded-lg">
            <div className="text-sm text-gray-400">Excellent</div>
            <div className="text-lg font-bold text-green-400">
              {connections.filter(c => c.quality === 'excellent').length}
            </div>
          </div>
          
          <div className="text-center p-3 bg-white/5 rounded-lg">
            <div className="text-sm text-gray-400">Good</div>
            <div className="text-lg font-bold text-yellow-400">
              {connections.filter(c => c.quality === 'good').length}
            </div>
          </div>
          
          <div className="text-center p-3 bg-white/5 rounded-lg">
            <div className="text-sm text-gray-400">Poor</div>
            <div className="text-lg font-bold text-red-400">
              {connections.filter(c => c.quality === 'poor').length}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

export default NetworkSpeedTestingCard