import React, { useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Zap,
  Play,
  Check,
  X,
  Clock,
  Settings,
  Network,
  Shield,
  Users,
  Activity,
  ChevronRight,
  RefreshCw,
  AlertTriangle,
  CheckCircle,
  Loader2
} from 'lucide-react'
import { Button } from './button'
import { Card, CardHeader, CardTitle, CardContent } from './card'
import { supabase } from '@/lib/supabase'
import { cn } from '@/lib/utils'

interface QuickSetupProfile {
  id: string
  profile_name: string
  description: string
  category: string
  icon: string
  setup_steps: any[]
  estimated_time_minutes: number
  difficulty_level: string
  can_auto_configure: boolean
  is_featured: boolean
  display_order: number
}

interface QuickSetupExecution {
  id: string
  profile_id: string
  session_id: string
  status: string
  current_step: number
  total_steps: number
  progress_percentage: number
  error_messages: string[]
  warnings: string[]
  started_at: string
  completed_at?: string
}

const QuickSetup: React.FC = () => {
  const [profiles, setProfiles] = useState<QuickSetupProfile[]>([])
  const [loading, setLoading] = useState(true)
  const [activeExecution, setActiveExecution] = useState<QuickSetupExecution | null>(null)
  const [currentStep, setCurrentStep] = useState<any>(null)
  const [stepData, setStepData] = useState<Record<string, any>>({})
  const [executionId, setExecutionId] = useState<string | null>(null)
  const [showStepModal, setShowStepModal] = useState(false)
  const [filter, setFilter] = useState<string>('all')

  useEffect(() => {
    loadProfiles()
  }, [filter])

  const loadProfiles = async () => {
    try {
      setLoading(true)
      const { data, error } = await supabase.functions.invoke('quick-setup-system', {
        body: {
          action: 'get_profiles',
          category: filter !== 'all' ? filter : undefined,
          featured: false
        }
      })

      if (error) throw error
      setProfiles(data.data.profiles || [])
    } catch (error) {
      console.error('Error loading setup profiles:', error)
    } finally {
      setLoading(false)
    }
  }

  const startSetup = async (profileId: string) => {
    try {
      const sessionId = `session_${Date.now()}_${Math.random().toString(36).substring(2)}`
      
      const { data, error } = await supabase.functions.invoke('quick-setup-system', {
        body: {
          action: 'start_setup',
          profileId,
          sessionId
        }
      })

      if (error) throw error
      
      setActiveExecution(data.data.execution)
      setCurrentStep(data.data.nextStep)
      setExecutionId(data.data.execution.id)
      setShowStepModal(true)
    } catch (error) {
      console.error('Error starting setup:', error)
    }
  }

  const executeStep = async () => {
    if (!executionId || !currentStep) return

    try {
      const { data, error } = await supabase.functions.invoke('quick-setup-system', {
        body: {
          action: 'execute_step',
          executionId,
          stepNumber: activeExecution?.current_step || 1,
          stepData
        }
      })

      if (error) throw error
      
      const result = data.data
      setActiveExecution(prev => prev ? {
        ...prev,
        current_step: result.isComplete ? prev.total_steps : prev.current_step + 1,
        progress_percentage: result.progress,
        status: result.status,
        error_messages: result.errors,
        warnings: result.warnings
      } : null)

      if (result.nextStep) {
        setCurrentStep(result.nextStep)
        setStepData({})
      } else {
        // Setup complete
        setShowStepModal(false)
        setActiveExecution(null)
        setCurrentStep(null)
        setExecutionId(null)
      }
    } catch (error) {
      console.error('Error executing step:', error)
    }
  }

  const cancelSetup = async () => {
    if (!executionId) return

    try {
      await supabase.functions.invoke('quick-setup-system', {
        body: {
          action: 'cancel_setup',
          executionId
        }
      })
      
      setShowStepModal(false)
      setActiveExecution(null)
      setCurrentStep(null)
      setExecutionId(null)
    } catch (error) {
      console.error('Error canceling setup:', error)
    }
  }

  const getIconComponent = (iconName: string) => {
    const icons: Record<string, any> = {
      network: Network,
      shield: Shield,
      users: Users,
      activity: Activity,
      settings: Settings,
      lock: Shield
    }
    const IconComponent = icons[iconName] || Settings
    return <IconComponent className="h-6 w-6" />
  }

  const getDifficultyColor = (level: string) => {
    switch (level) {
      case 'easy':
        return 'text-green-600 bg-green-100'
      case 'medium':
        return 'text-yellow-600 bg-yellow-100'
      case 'advanced':
        return 'text-red-600 bg-red-100'
      default:
        return 'text-gray-600 bg-gray-100'
    }
  }

  const renderStepForm = () => {
    if (!currentStep) return null

    if (currentStep.type === 'automated') {
      return (
        <div className="p-6 text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto text-blue-600" />
          <h3 className="text-lg font-medium text-gray-900 mt-4">{currentStep.title}</h3>
          <p className="text-gray-600 mt-2">{currentStep.description}</p>
          <p className="text-sm text-gray-500 mt-4">This step will be completed automatically...</p>
        </div>
      )
    }

    return (
      <div className="p-6">
        <h3 className="text-lg font-medium text-gray-900 mb-4">{currentStep.title}</h3>
        <p className="text-gray-600 mb-6">{currentStep.description}</p>
        
        <div className="space-y-4">
          {currentStep.fields?.map((field: string) => (
            <div key={field}>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {field.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
              </label>
              <input
                type="text"
                value={stepData[field] || ''}
                onChange={(e) => setStepData(prev => ({ ...prev, [field]: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder={`Enter ${field.replace(/_/g, ' ')}`}
              />
            </div>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white flex items-center space-x-2">
            <Zap className="h-6 w-6 text-enterprise-neon" />
            <span>Quick Setup</span>
          </h2>
          <p className="text-gray-400 mt-1">Automated configuration wizards for common tasks</p>
        </div>
        
        <Button onClick={loadProfiles} disabled={loading}>
          <RefreshCw className={cn("h-4 w-4 mr-2", loading && "animate-spin")} />
          Refresh
        </Button>
      </div>

      {/* Category Filter */}
      <div className="flex space-x-2">
        {['all', 'network', 'vpn', 'security', 'performance'].map((category) => (
          <button
            key={category}
            onClick={() => setFilter(category)}
            className={cn(
              "px-4 py-2 rounded-lg text-sm font-medium transition-colors",
              filter === category
                ? "bg-enterprise-neon text-black"
                : "bg-white/5 text-gray-400 hover:bg-white/10 hover:text-white"
            )}
          >
            {category.charAt(0).toUpperCase() + category.slice(1)}
          </button>
        ))}
      </div>

      {/* Setup Profiles Grid */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-6">
                <div className="h-4 bg-gray-300 rounded w-3/4 mb-4"></div>
                <div className="h-3 bg-gray-300 rounded w-full mb-2"></div>
                <div className="h-3 bg-gray-300 rounded w-2/3"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {profiles.map((profile) => (
            <motion.div
              key={profile.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              whileHover={{ y: -4 }}
              className="group"
            >
              <Card className="h-full bg-white/5 border-white/10 hover:bg-white/10 transition-all duration-300 cursor-pointer"
                    onClick={() => startSetup(profile.id)}>
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-12 h-12 rounded-lg bg-enterprise-neon/20 flex items-center justify-center text-enterprise-neon">
                        {getIconComponent(profile.icon)}
                      </div>
                      <div>
                        <h3 className="font-semibold text-white group-hover:text-enterprise-neon transition-colors">
                          {profile.profile_name}
                        </h3>
                        <span className={cn(
                          "inline-block px-2 py-1 rounded-full text-xs font-medium",
                          getDifficultyColor(profile.difficulty_level)
                        )}>
                          {profile.difficulty_level}
                        </span>
                      </div>
                    </div>
                    {profile.can_auto_configure && (
                      <div className="w-6 h-6 rounded-full bg-green-500/20 flex items-center justify-center">
                        <CheckCircle className="h-4 w-4 text-green-400" />
                      </div>
                    )}
                  </div>
                  
                  <p className="text-gray-400 text-sm mb-4 line-clamp-2">
                    {profile.description}
                  </p>
                  
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center space-x-4 text-gray-500">
                      <div className="flex items-center space-x-1">
                        <Clock className="h-4 w-4" />
                        <span>{profile.estimated_time_minutes}m</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Settings className="h-4 w-4" />
                        <span>{profile.setup_steps?.length || 0} steps</span>
                      </div>
                    </div>
                    
                    <ChevronRight className="h-4 w-4 text-gray-400 group-hover:text-enterprise-neon transition-colors" />
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      )}

      {/* Setup Execution Modal */}
      <AnimatePresence>
        {showStepModal && activeExecution && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto"
            >
              {/* Modal Header */}
              <div className="p-6 border-b border-gray-200">
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-semibold text-gray-900">Quick Setup in Progress</h2>
                  <Button variant="outline" size="sm" onClick={cancelSetup}>
                    <X className="h-4 w-4" />
                  </Button>
                </div>
                
                {/* Progress Bar */}
                <div className="mt-4">
                  <div className="flex items-center justify-between text-sm text-gray-600 mb-2">
                    <span>Step {activeExecution.current_step} of {activeExecution.total_steps}</span>
                    <span>{activeExecution.progress_percentage}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${activeExecution.progress_percentage}%` }}
                    />
                  </div>
                </div>
              </div>

              {/* Step Content */}
              {renderStepForm()}

              {/* Modal Footer */}
              <div className="p-6 border-t border-gray-200">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    {activeExecution.error_messages && activeExecution.error_messages.length > 0 && (
                      <div className="flex items-center space-x-2 text-red-600">
                        <AlertTriangle className="h-4 w-4" />
                        <span className="text-sm">Errors occurred</span>
                      </div>
                    )}
                    {activeExecution.warnings && activeExecution.warnings.length > 0 && (
                      <div className="flex items-center space-x-2 text-yellow-600">
                        <AlertTriangle className="h-4 w-4" />
                        <span className="text-sm">Warnings</span>
                      </div>
                    )}
                  </div>
                  
                  <div className="flex space-x-2">
                    <Button variant="outline" onClick={cancelSetup}>
                      Cancel
                    </Button>
                    <Button onClick={executeStep}>
                      {currentStep?.type === 'automated' ? (
                        <>
                          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                          Processing...
                        </>
                      ) : (
                        <>
                          <Play className="h-4 w-4 mr-2" />
                          {activeExecution.current_step >= activeExecution.total_steps ? 'Complete' : 'Next Step'}
                        </>
                      )}
                    </Button>
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

export default QuickSetup