import React, { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Router,
  Wifi,
  Settings,
  Shield,
  Network,
  CheckCircle,
  X,
  ArrowRight,
  ArrowLeft,
  Loader2,
  AlertTriangle,
  Info,
  Zap,
  Globe,
  Lock,
  Save
} from 'lucide-react'
import { Button } from './button'
import { Card, CardHeader, CardTitle, CardContent } from './card'
import { supabase } from '@/lib/supabase'
import { cn } from '@/lib/utils'

interface ModemModeSetupProps {
  isOpen: boolean
  onClose: () => void
  onSuccess?: () => void
}

interface NetworkInterface {
  name: string
  type: string
  status: string
  ip: string | null
  gateway: string | null
}

interface ModemConfig {
  mode: 'bridge' | 'router' | 'passthrough'
  wan: {
    interface: string
    type: 'dhcp' | 'static' | 'pppoe'
    ip?: string
    gateway?: string
    dns?: string[]
    username?: string
    password?: string
  }
  lan: {
    interface: string
    subnet: string
    dhcp_enabled: boolean
    dhcp_range_start?: string
    dhcp_range_end?: string
  }
  security: {
    firewall_enabled: boolean
    nat_enabled: boolean
    port_forwarding: Array<{
      name: string
      external_port: number
      internal_port: number
      internal_ip: string
      protocol: 'tcp' | 'udp' | 'both'
    }>
  }
  advanced: {
    mtu: number
    dns_forwarding: boolean
    upnp_enabled: boolean
    quality_of_service: boolean
  }
}

const ModemModeSetup: React.FC<ModemModeSetupProps> = ({ isOpen, onClose, onSuccess }) => {
  const [currentStep, setCurrentStep] = useState(0)
  const [loading, setLoading] = useState(false)
  const [networkInterfaces, setNetworkInterfaces] = useState<NetworkInterface[]>([])
  const [modemConfig, setModemConfig] = useState<ModemConfig>({
    mode: 'router',
    wan: {
      interface: '',
      type: 'dhcp',
      dns: ['1.1.1.1', '8.8.8.8']
    },
    lan: {
      interface: '',
      subnet: '192.168.100.0/24',
      dhcp_enabled: true,
      dhcp_range_start: '192.168.100.100',
      dhcp_range_end: '192.168.100.200'
    },
    security: {
      firewall_enabled: true,
      nat_enabled: true,
      port_forwarding: []
    },
    advanced: {
      mtu: 1500,
      dns_forwarding: true,
      upnp_enabled: true,
      quality_of_service: false
    }
  })
  const [setupResult, setSetupResult] = useState<any>(null)
  const [errors, setErrors] = useState<string[]>([])

  const steps = [
    { title: 'Mode Selection', icon: Router, description: 'Choose modem operation mode' },
    { title: 'Network Detection', icon: Network, description: 'Detect network interfaces' },
    { title: 'WAN Configuration', icon: Globe, description: 'Configure internet connection' },
    { title: 'LAN Configuration', icon: Wifi, description: 'Configure local network' },
    { title: 'Security Settings', icon: Shield, description: 'Configure security options' },
    { title: 'Apply Configuration', icon: CheckCircle, description: 'Apply and test settings' }
  ]

  useEffect(() => {
    if (currentStep === 1) {
      detectNetworkInterfaces()
    }
  }, [currentStep])

  const detectNetworkInterfaces = async () => {
    setLoading(true)
    setErrors([])
    try {
      const { data, error } = await supabase.functions.invoke('modem-mode-setup', {
        body: { action: 'detect_interfaces' }
      })

      if (error) throw error

      const interfaces = data.interfaces || []
      setNetworkInterfaces(interfaces)
      
      // Auto-select interfaces based on recommendations
      const recommended = data.recommended_config
      if (recommended) {
        setModemConfig(prev => ({
          ...prev,
          wan: {
            ...prev.wan,
            interface: recommended.wan_interface
          },
          lan: {
            ...prev.lan,
            interface: recommended.lan_interface
          }
        }))
      }
    } catch (error) {
      console.error('Network detection failed:', error)
      setErrors(['Failed to detect network interfaces. Please check your connections.'])
    } finally {
      setLoading(false)
    }
  }

  const applyModemConfiguration = async () => {
    setLoading(true)
    setErrors([])
    try {
      // First validate the configuration
      const { data: validationData, error: validationError } = await supabase.functions.invoke('modem-mode-setup', {
        body: {
          action: 'validate_config',
          configuration: {
            mode: modemConfig.mode,
            wan: modemConfig.wan,
            lan: modemConfig.lan,
            security: modemConfig.security,
            advanced: modemConfig.advanced
          }
        }
      })

      if (validationError) throw validationError

      if (!validationData.validation.valid) {
        setErrors(validationData.validation.errors)
        return
      }

      // Show warnings if any
      if (validationData.validation.warnings.length > 0) {
        console.warn('Configuration warnings:', validationData.validation.warnings)
      }

      // Apply the actual configuration
      const { data: configData, error: configError } = await supabase.functions.invoke('modem-mode-setup', {
        body: {
          action: 'apply_config',
          configuration: {
            mode: modemConfig.mode,
            wan: modemConfig.wan,
            lan: modemConfig.lan,
            security: modemConfig.security,
            advanced: modemConfig.advanced
          }
        }
      })

      if (configError) throw configError

      setSetupResult(configData)
      setCurrentStep(5) // Move to completion step
      
      // Call success callback
      if (onSuccess) {
        onSuccess()
      }
    } catch (error) {
      console.error('Configuration application failed:', error)
      setErrors([`Configuration failed: ${error.message}`])
    } finally {
      setLoading(false)
    }
  }

  const nextStep = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1)
    } else if (currentStep === 4) {
      applyModemConfiguration()
    }
  }

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1)
    }
  }

  const renderStepContent = () => {
    switch (currentStep) {
      case 0: // Mode Selection
        return (
          <div className="space-y-6">
            <div className="text-center">
              <Router className="mx-auto w-16 h-16 text-enterprise-neon mb-4" />
              <h2 className="text-xl font-bold text-white mb-2">Modem Mode Selection</h2>
              <p className="text-gray-400">Choose how your Pi5 Supernode will operate</p>
            </div>
            
            <div className="grid gap-4">
              {[
                {
                  mode: 'router' as const,
                  title: 'Router Mode',
                  description: 'Full routing with NAT, DHCP, and firewall (Recommended)',
                  icon: Router,
                  color: 'enterprise-neon'
                },
                {
                  mode: 'bridge' as const,
                  title: 'Bridge Mode',
                  description: 'Transparent bridging between WAN and LAN',
                  icon: Network,
                  color: 'blue'
                },
                {
                  mode: 'passthrough' as const,
                  title: 'Passthrough Mode',
                  description: 'Direct passthrough with minimal processing',
                  icon: Globe,
                  color: 'purple'
                }
              ].map((option) => {
                const IconComponent = option.icon
                return (
                  <Card
                    key={option.mode}
                    className={cn(
                      "cursor-pointer transition-all duration-300 border-2 p-4",
                      modemConfig.mode === option.mode
                        ? `border-${option.color}-400 bg-${option.color}-500/10`
                        : "border-gray-600 bg-gray-800/50 hover:bg-gray-700/50"
                    )}
                    onClick={() => setModemConfig(prev => ({ ...prev, mode: option.mode }))}
                  >
                    <div className="flex items-center space-x-4">
                      <div className={cn(
                        "p-3 rounded-lg",
                        modemConfig.mode === option.mode
                          ? `bg-${option.color}-500/20`
                          : "bg-gray-700"
                      )}>
                        <IconComponent className={cn(
                          "h-6 w-6",
                          modemConfig.mode === option.mode
                            ? `text-${option.color}-400`
                            : "text-gray-400"
                        )} />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold text-white">{option.title}</h3>
                        <p className="text-sm text-gray-400">{option.description}</p>
                      </div>
                      {modemConfig.mode === option.mode && (
                        <CheckCircle className={`h-5 w-5 text-${option.color}-400`} />
                      )}
                    </div>
                  </Card>
                )
              })}
            </div>
          </div>
        )

      case 1: // Network Detection
        return (
          <div className="space-y-6">
            <div className="text-center">
              <Network className="mx-auto w-16 h-16 text-blue-400 mb-4" />
              <h2 className="text-xl font-bold text-white mb-2">Network Interface Detection</h2>
              <p className="text-gray-400">Detecting available network interfaces...</p>
            </div>
            
            {loading ? (
              <div className="text-center">
                <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4 text-blue-400" />
                <p className="text-gray-400">Scanning network interfaces...</p>
              </div>
            ) : (
              <div className="space-y-4">
                {networkInterfaces.map((iface) => (
                  <Card key={iface.name} className="bg-gray-800/50 p-4">
                    <div className="flex justify-between items-center">
                      <div>
                        <h3 className="font-semibold text-white">{iface.name}</h3>
                        <p className="text-sm text-gray-400 capitalize">{iface.type}</p>
                      </div>
                      <div className="text-right">
                        <span className={cn(
                          "px-2 py-1 rounded text-xs",
                          iface.status === 'connected' ? 'bg-green-500/20 text-green-400' :
                          iface.status === 'available' ? 'bg-yellow-500/20 text-yellow-400' :
                          'bg-red-500/20 text-red-400'
                        )}>
                          {iface.status}
                        </span>
                        {iface.ip && <p className="text-sm text-gray-400 mt-1">{iface.ip}</p>}
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </div>
        )

      case 2: // WAN Configuration
        return (
          <div className="space-y-6">
            <div className="text-center">
              <Globe className="mx-auto w-16 h-16 text-green-400 mb-4" />
              <h2 className="text-xl font-bold text-white mb-2">WAN Configuration</h2>
              <p className="text-gray-400">Configure internet connection settings</p>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">WAN Interface</label>
                <select
                  className="w-full bg-gray-800/50 border border-gray-600 rounded-lg px-3 py-2 text-white"
                  value={modemConfig.wan.interface}
                  onChange={(e) => setModemConfig(prev => ({
                    ...prev,
                    wan: { ...prev.wan, interface: e.target.value }
                  }))}
                >
                  <option value="">Select WAN Interface</option>
                  {networkInterfaces
                    .filter(iface => iface.status === 'connected')
                    .map(iface => (
                    <option key={iface.name} value={iface.name}>{iface.name} ({iface.type})</option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Connection Type</label>
                <select
                  className="w-full bg-gray-800/50 border border-gray-600 rounded-lg px-3 py-2 text-white"
                  value={modemConfig.wan.type}
                  onChange={(e) => setModemConfig(prev => ({
                    ...prev,
                    wan: { ...prev.wan, type: e.target.value as 'dhcp' | 'static' | 'pppoe' }
                  }))}
                >
                  <option value="dhcp">DHCP (Automatic)</option>
                  <option value="static">Static IP</option>
                  <option value="pppoe">PPPoE</option>
                </select>
              </div>
              
              {modemConfig.wan.type === 'static' && (
                <>
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">Static IP Address</label>
                    <input
                      type="text"
                      className="w-full bg-gray-800/50 border border-gray-600 rounded-lg px-3 py-2 text-white"
                      placeholder="192.168.1.100"
                      value={modemConfig.wan.ip || ''}
                      onChange={(e) => setModemConfig(prev => ({
                        ...prev,
                        wan: { ...prev.wan, ip: e.target.value }
                      }))}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">Gateway</label>
                    <input
                      type="text"
                      className="w-full bg-gray-800/50 border border-gray-600 rounded-lg px-3 py-2 text-white"
                      placeholder="192.168.1.1"
                      value={modemConfig.wan.gateway || ''}
                      onChange={(e) => setModemConfig(prev => ({
                        ...prev,
                        wan: { ...prev.wan, gateway: e.target.value }
                      }))}
                    />
                  </div>
                </>
              )}
              
              {modemConfig.wan.type === 'pppoe' && (
                <>
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">Username</label>
                    <input
                      type="text"
                      className="w-full bg-gray-800/50 border border-gray-600 rounded-lg px-3 py-2 text-white"
                      value={modemConfig.wan.username || ''}
                      onChange={(e) => setModemConfig(prev => ({
                        ...prev,
                        wan: { ...prev.wan, username: e.target.value }
                      }))}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">Password</label>
                    <input
                      type="password"
                      className="w-full bg-gray-800/50 border border-gray-600 rounded-lg px-3 py-2 text-white"
                      value={modemConfig.wan.password || ''}
                      onChange={(e) => setModemConfig(prev => ({
                        ...prev,
                        wan: { ...prev.wan, password: e.target.value }
                      }))}
                    />
                  </div>
                </>
              )}
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">DNS Servers</label>
                <input
                  type="text"
                  className="w-full bg-gray-800/50 border border-gray-600 rounded-lg px-3 py-2 text-white"
                  placeholder="1.1.1.1,8.8.8.8"
                  value={modemConfig.wan.dns?.join(',') || ''}
                  onChange={(e) => setModemConfig(prev => ({
                    ...prev,
                    wan: {
                      ...prev.wan,
                      dns: e.target.value.split(',').map(dns => dns.trim()).filter(Boolean)
                    }
                  }))}
                />
              </div>
            </div>
          </div>
        )

      case 3: // LAN Configuration
        return (
          <div className="space-y-6">
            <div className="text-center">
              <Wifi className="mx-auto w-16 h-16 text-purple-400 mb-4" />
              <h2 className="text-xl font-bold text-white mb-2">LAN Configuration</h2>
              <p className="text-gray-400">Configure local network settings</p>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">LAN Interface</label>
                <select
                  className="w-full bg-gray-800/50 border border-gray-600 rounded-lg px-3 py-2 text-white"
                  value={modemConfig.lan.interface}
                  onChange={(e) => setModemConfig(prev => ({
                    ...prev,
                    lan: { ...prev.lan, interface: e.target.value }
                  }))}
                >
                  <option value="">Select LAN Interface</option>
                  {networkInterfaces
                    .filter(iface => iface.name !== modemConfig.wan.interface)
                    .map(iface => (
                    <option key={iface.name} value={iface.name}>{iface.name} ({iface.type})</option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">LAN Subnet</label>
                <input
                  type="text"
                  className="w-full bg-gray-800/50 border border-gray-600 rounded-lg px-3 py-2 text-white"
                  placeholder="192.168.100.0/24"
                  value={modemConfig.lan.subnet}
                  onChange={(e) => setModemConfig(prev => ({
                    ...prev,
                    lan: { ...prev.lan, subnet: e.target.value }
                  }))}
                />
              </div>
              
              <div className="flex items-center justify-between py-3">
                <div>
                  <h3 className="font-medium text-white">Enable DHCP Server</h3>
                  <p className="text-sm text-gray-400">Automatically assign IP addresses</p>
                </div>
                <input
                  type="checkbox"
                  checked={modemConfig.lan.dhcp_enabled}
                  onChange={(e) => setModemConfig(prev => ({
                    ...prev,
                    lan: { ...prev.lan, dhcp_enabled: e.target.checked }
                  }))}
                  className="w-5 h-5"
                />
              </div>
              
              {modemConfig.lan.dhcp_enabled && (
                <>
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">DHCP Range Start</label>
                    <input
                      type="text"
                      className="w-full bg-gray-800/50 border border-gray-600 rounded-lg px-3 py-2 text-white"
                      placeholder="192.168.100.100"
                      value={modemConfig.lan.dhcp_range_start || ''}
                      onChange={(e) => setModemConfig(prev => ({
                        ...prev,
                        lan: { ...prev.lan, dhcp_range_start: e.target.value }
                      }))}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">DHCP Range End</label>
                    <input
                      type="text"
                      className="w-full bg-gray-800/50 border border-gray-600 rounded-lg px-3 py-2 text-white"
                      placeholder="192.168.100.200"
                      value={modemConfig.lan.dhcp_range_end || ''}
                      onChange={(e) => setModemConfig(prev => ({
                        ...prev,
                        lan: { ...prev.lan, dhcp_range_end: e.target.value }
                      }))}
                    />
                  </div>
                </>
              )}
            </div>
          </div>
        )

      case 4: // Security Settings
        return (
          <div className="space-y-6">
            <div className="text-center">
              <Shield className="mx-auto w-16 h-16 text-red-400 mb-4" />
              <h2 className="text-xl font-bold text-white mb-2">Security Configuration</h2>
              <p className="text-gray-400">Configure security and firewall settings</p>
            </div>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between py-3">
                <div>
                  <h3 className="font-medium text-white">Enable Firewall</h3>
                  <p className="text-sm text-gray-400">Block unauthorized network access</p>
                </div>
                <input
                  type="checkbox"
                  checked={modemConfig.security.firewall_enabled}
                  onChange={(e) => setModemConfig(prev => ({
                    ...prev,
                    security: { ...prev.security, firewall_enabled: e.target.checked }
                  }))}
                  className="w-5 h-5"
                />
              </div>
              
              <div className="flex items-center justify-between py-3">
                <div>
                  <h3 className="font-medium text-white">Enable NAT</h3>
                  <p className="text-sm text-gray-400">Network Address Translation</p>
                </div>
                <input
                  type="checkbox"
                  checked={modemConfig.security.nat_enabled}
                  onChange={(e) => setModemConfig(prev => ({
                    ...prev,
                    security: { ...prev.security, nat_enabled: e.target.checked }
                  }))}
                  className="w-5 h-5"
                />
              </div>
              
              <div className="flex items-center justify-between py-3">
                <div>
                  <h3 className="font-medium text-white">Enable UPnP</h3>
                  <p className="text-sm text-gray-400">Universal Plug and Play</p>
                </div>
                <input
                  type="checkbox"
                  checked={modemConfig.advanced.upnp_enabled}
                  onChange={(e) => setModemConfig(prev => ({
                    ...prev,
                    advanced: { ...prev.advanced, upnp_enabled: e.target.checked }
                  }))}
                  className="w-5 h-5"
                />
              </div>
              
              <div className="flex items-center justify-between py-3">
                <div>
                  <h3 className="font-medium text-white">Quality of Service (QoS)</h3>
                  <p className="text-sm text-gray-400">Prioritize network traffic</p>
                </div>
                <input
                  type="checkbox"
                  checked={modemConfig.advanced.quality_of_service}
                  onChange={(e) => setModemConfig(prev => ({
                    ...prev,
                    advanced: { ...prev.advanced, quality_of_service: e.target.checked }
                  }))}
                  className="w-5 h-5"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">MTU Size</label>
                <input
                  type="number"
                  className="w-full bg-gray-800/50 border border-gray-600 rounded-lg px-3 py-2 text-white"
                  placeholder="1500"
                  value={modemConfig.advanced.mtu}
                  onChange={(e) => setModemConfig(prev => ({
                    ...prev,
                    advanced: { ...prev.advanced, mtu: parseInt(e.target.value) || 1500 }
                  }))}
                />
              </div>
            </div>
          </div>
        )

      case 5: // Apply Configuration
        return (
          <div className="space-y-6">
            <div className="text-center">
              {setupResult ? (
                <>
                  <CheckCircle className="mx-auto w-16 h-16 text-green-400 mb-4" />
                  <h2 className="text-xl font-bold text-green-400 mb-2">Modem Mode Setup Complete!</h2>
                  <p className="text-gray-400">Your Pi5 Supernode is now configured in modem mode</p>
                </>
              ) : (
                <>
                  <Loader2 className="mx-auto w-16 h-16 animate-spin text-blue-400 mb-4" />
                  <h2 className="text-xl font-bold text-white mb-2">Applying Configuration</h2>
                  <p className="text-gray-400">Please wait while we configure your system...</p>
                </>
              )}
            </div>
            
            {setupResult && (
              <div className="bg-gray-800/50 rounded-lg p-6">
                <h3 className="font-semibold text-white mb-4">Applied Configuration Summary</h3>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-300">Mode:</span>
                    <span className="text-white capitalize">{modemConfig.mode}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-300">WAN Interface:</span>
                    <span className="text-white">{modemConfig.wan.interface} ({modemConfig.wan.type})</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-300">LAN Interface:</span>
                    <span className="text-white">{modemConfig.lan.interface}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-300">LAN Subnet:</span>
                    <span className="text-white">{modemConfig.lan.subnet}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-300">DHCP:</span>
                    <span className={cn(
                      "font-medium",
                      modemConfig.lan.dhcp_enabled ? "text-green-400" : "text-red-400"
                    )}>
                      {modemConfig.lan.dhcp_enabled ? 'Enabled' : 'Disabled'}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-300">Firewall:</span>
                    <span className={cn(
                      "font-medium",
                      modemConfig.security.firewall_enabled ? "text-green-400" : "text-red-400"
                    )}>
                      {modemConfig.security.firewall_enabled ? 'Enabled' : 'Disabled'}
                    </span>
                  </div>
                </div>
              </div>
            )}
            
            {setupResult && (
              <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-4">
                <div className="flex items-start space-x-3">
                  <Info className="h-5 w-5 text-green-400 mt-0.5" />
                  <div>
                    <h3 className="font-semibold text-green-400 mb-2">Next Steps</h3>
                    <ul className="text-sm text-gray-300 space-y-1">
                      <li>• Your modem mode configuration has been applied successfully</li>
                      <li>• Network services will restart automatically</li>
                      <li>• You can monitor the system status from the dashboard</li>
                      <li>• Advanced settings can be configured from the Network panel</li>
                    </ul>
                  </div>
                </div>
              </div>
            )}
          </div>
        )

      default:
        return null
    }
  }

  if (!isOpen) return null

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="bg-gray-900 border border-gray-700 rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-hidden"
        >
          {/* Header */}
          <div className="bg-gray-800 px-6 py-4 border-b border-gray-700">
            <div className="flex justify-between items-center">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-enterprise-neon/20 rounded-lg">
                  <Zap className="h-6 w-6 text-enterprise-neon" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-white">Modem Mode Quick Setup</h1>
                  <p className="text-sm text-gray-400">Configure your Pi5 Supernode for modem operation</p>
                </div>
              </div>
              <Button variant="outline" size="sm" onClick={onClose}>
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Progress */}
          <div className="px-6 py-4 bg-gray-800 border-b border-gray-700">
            <div className="flex justify-between items-center mb-3">
              <span className="text-sm text-gray-400">
                Step {currentStep + 1} of {steps.length}
              </span>
              <div className="w-48 bg-gray-700 rounded-full h-2">
                <div 
                  className="bg-enterprise-neon h-2 rounded-full transition-all duration-300" 
                  style={{ width: `${((currentStep + 1) / steps.length) * 100}%` }}
                />
              </div>
            </div>
            <div className="flex justify-between">
              {steps.map((step, index) => {
                const StepIcon = step.icon
                return (
                  <div 
                    key={index}
                    className={cn(
                      "flex flex-col items-center space-y-2 text-center",
                      index <= currentStep ? 'text-enterprise-neon' : 'text-gray-500'
                    )}
                  >
                    <div className={cn(
                      "p-2 rounded-full",
                      index <= currentStep ? 'bg-enterprise-neon/20' : 'bg-gray-700'
                    )}>
                      <StepIcon className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-xs font-medium">{step.title}</span>
                      <p className="text-xs text-gray-500">{step.description}</p>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>

          {/* Content */}
          <div className="px-6 py-8 overflow-y-auto" style={{ maxHeight: 'calc(90vh - 300px)' }}>
            {renderStepContent()}
            
            {/* Error Display */}
            {errors.length > 0 && (
              <div className="mt-6 bg-red-500/10 border border-red-500/30 rounded-lg p-4">
                <div className="flex items-start space-x-3">
                  <AlertTriangle className="h-5 w-5 text-red-400 mt-0.5" />
                  <div>
                    <h3 className="font-semibold text-red-400 mb-2">Configuration Errors</h3>
                    <ul className="text-sm text-gray-300 space-y-1">
                      {errors.map((error, index) => (
                        <li key={index}>• {error}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="bg-gray-800 px-6 py-4 border-t border-gray-700">
            <div className="flex justify-between">
              <Button 
                variant="outline" 
                onClick={prevStep} 
                disabled={currentStep === 0 || loading}
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Previous
              </Button>
              
              <div className="space-x-3">
                <Button 
                  variant="outline" 
                  onClick={onClose}
                  disabled={loading}
                >
                  Cancel
                </Button>
                
                {currentStep === steps.length - 1 && setupResult ? (
                  <Button onClick={onClose}>
                    <CheckCircle className="w-4 h-4 mr-2" />
                    Finish
                  </Button>
                ) : currentStep === 4 ? (
                  <Button 
                    onClick={nextStep} 
                    disabled={loading || errors.length > 0}
                  >
                    {loading ? (
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <Save className="w-4 h-4 mr-2" />
                    )}
                    Apply Configuration
                  </Button>
                ) : (
                  <Button 
                    onClick={nextStep} 
                    disabled={loading}
                  >
                    Next
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                )}
              </div>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  )
}

export default ModemModeSetup