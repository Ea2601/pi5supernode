import React from 'react'
import { cva, type VariantProps } from 'class-variance-authority'
import { cn } from '@/lib/utils'

const buttonVariants = cva(
  'inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 active:scale-95',
  {
    variants: {
      variant: {
        default: 'gradient-button shadow-lg hover:shadow-xl hover:shadow-phosphor-turquoise/25',
        destructive: 'bg-red-600 text-white hover:bg-red-700 shadow-lg hover:shadow-red-500/25',
        outline: 'border border-phosphor-turquoise/50 bg-transparent text-phosphor-turquoise hover:bg-phosphor-turquoise/10 hover:shadow-[0_0_15px_rgba(0,206,209,0.4)]',
        secondary: 'bg-phosphor-navy text-white hover:bg-phosphor-navy-light shadow-lg',
        ghost: 'text-white hover:bg-white/10 hover:text-phosphor-turquoise',
        link: 'text-phosphor-turquoise underline-offset-4 hover:underline',
        neon: 'bg-transparent border-2 border-phosphor-turquoise text-phosphor-turquoise hover:bg-phosphor-turquoise hover:text-phosphor-dark transition-all duration-300 shadow-[0_0_10px_rgba(0,206,209,0.4)] hover:shadow-[0_0_20px_rgba(0,206,209,0.6)]',
        phosphor: 'phosphor-button',
        'phosphor-green': 'phosphor-button-green',
        'phosphor-blue': 'phosphor-button-blue',
        'phosphor-outline': 'phosphor-outline'
      },
      size: {
        default: 'h-10 px-4 py-2',
        sm: 'h-9 rounded-md px-3',
        lg: 'h-11 rounded-md px-8',
        xl: 'h-12 rounded-lg px-10 text-base',
        icon: 'h-10 w-10'
      }
    },
    defaultVariants: {
      variant: 'default',
      size: 'default'
    }
  }
)

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean
  loading?: boolean
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, loading = false, children, disabled, ...props }, ref) => {
    const isDisabled = disabled || loading
    
    return (
      <button
        className={cn(buttonVariants({ variant, size, className }), {
          'pointer-events-none opacity-50': loading,
          'animate-pulse': loading
        })}
        ref={ref}
        disabled={isDisabled}
        {...props}
      >
        {loading ? (
          <>
            <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" />
            {children}
          </>
        ) : (
          children
        )}
      </button>
    )
  }
)
Button.displayName = 'Button'

export { Button, buttonVariants }