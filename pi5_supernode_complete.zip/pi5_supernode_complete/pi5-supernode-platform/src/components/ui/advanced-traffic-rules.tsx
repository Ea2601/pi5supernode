import React, { useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Network,
  Users,
  Route,
  Shield,
  Plus,
  Edit,
  Trash2,
  Play,
  Pause,
  TestTube,
  Activity,
  BarChart3,
  Settings,
  Filter,
  Search,
  RefreshCw,
  Eye,
  Zap,
  ArrowRight,
  CheckCircle,
  AlertTriangle
} from 'lucide-react'
import { Button } from './button'
import { Card, CardHeader, CardTitle, CardContent } from './card'
import { supabase } from '@/lib/supabase'
import { cn } from '@/lib/utils'

interface UserGroup {
  id: string
  group_name: string
  description: string
  color_code: string
  priority: number
  is_active: boolean
}

interface TrafficType {
  id: string
  type_name: string
  description: string
  category: string
  bandwidth_priority: number
  is_active: boolean
}

interface NetworkPath {
  id: string
  path_name: string
  description: string
  gateway_ip: string
  path_type: string
  bandwidth_limit_mbps: number
  reliability_score: number
  is_active: boolean
}

interface Tunnel {
  id: string
  tunnel_name: string
  tunnel_type: string
  description: string
  status: string
  ping_ms: number
  uptime_percentage: number
  is_active: boolean
}

interface TrafficRule {
  id: string
  rule_name: string
  description: string
  user_group_id: string
  traffic_type_id: string
  network_path_id: string
  tunnel_id: string
  action: string
  priority: number
  bandwidth_limit_kbps?: number
  is_enabled: boolean
  is_testing: boolean
  packets_matched: number
  bytes_matched: number
  created_at: string
}

interface DynamicOptions {
  userGroups: UserGroup[]
  trafficTypes: TrafficType[]
  networkPaths: NetworkPath[]
  tunnels: Tunnel[]
}

const AdvancedTrafficRules: React.FC = () => {
  const [rules, setRules] = useState<TrafficRule[]>([])
  const [options, setOptions] = useState<DynamicOptions | null>(null)
  const [loading, setLoading] = useState(true)
  const [showCreateModal, setShowCreateModal] = useState(false)
  const [showTrafficFlow, setShowTrafficFlow] = useState(false)
  const [selectedRule, setSelectedRule] = useState<TrafficRule | null>(null)
  const [searchTerm, setSearchTerm] = useState('')
  const [filter, setFilter] = useState<'all' | 'enabled' | 'disabled' | 'testing'>('all')
  const [flowData, setFlowData] = useState<any>(null)
  const [statistics, setStatistics] = useState<any>(null)

  // Form state for rule creation/editing
  const [ruleForm, setRuleForm] = useState({
    ruleName: '',
    description: '',
    userGroupId: '',
    trafficTypeId: '',
    networkPathId: '',
    tunnelId: '',
    action: 'route',
    priority: 100,
    bandwidthLimitKbps: '',
    isEnabled: true,
    isTesting: false
  })

  useEffect(() => {
    loadData()
  }, [])

  useEffect(() => {
    loadRules()
  }, [filter, searchTerm])

  const loadData = async () => {
    try {
      setLoading(true)
      
      // Load dynamic options
      const { data: optionsData, error: optionsError } = await supabase.functions.invoke('advanced-traffic-management', {
        body: { action: 'get_dynamic_options' }
      })

      if (optionsError) throw optionsError
      setOptions(optionsData.data.options)

      // Load traffic rules
      await loadRules()
      
      // Load statistics
      await loadStatistics()
    } catch (error) {
      console.error('Error loading data:', error)
    } finally {
      setLoading(false)
    }
  }

  const loadRules = async () => {
    try {
      const { data, error } = await supabase
        .from('traffic_rules')
        .select('*')
        .order('priority', { ascending: true })

      if (error) throw error
      
      let filteredRules = data || []
      
      // Apply filters
      if (filter === 'enabled') {
        filteredRules = filteredRules.filter(r => r.is_enabled)
      } else if (filter === 'disabled') {
        filteredRules = filteredRules.filter(r => !r.is_enabled)
      } else if (filter === 'testing') {
        filteredRules = filteredRules.filter(r => r.is_testing)
      }
      
      // Apply search
      if (searchTerm) {
        filteredRules = filteredRules.filter(r => 
          r.rule_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          r.description?.toLowerCase().includes(searchTerm.toLowerCase())
        )
      }
      
      setRules(filteredRules)
    } catch (error) {
      console.error('Error loading rules:', error)
    }
  }

  const loadStatistics = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('advanced-traffic-management', {
        body: { action: 'get_rule_statistics' }
      })

      if (error) throw error
      setStatistics(data.data.statistics)
    } catch (error) {
      console.error('Error loading statistics:', error)
    }
  }

  const loadTrafficFlow = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('advanced-traffic-management', {
        body: { action: 'get_traffic_flow' }
      })

      if (error) throw error
      setFlowData(data.data.flowData)
    } catch (error) {
      console.error('Error loading traffic flow:', error)
    }
  }

  const createRule = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('advanced-traffic-management', {
        body: {
          action: 'create_traffic_rule',
          ...ruleForm,
          bandwidthLimitKbps: ruleForm.bandwidthLimitKbps ? parseInt(ruleForm.bandwidthLimitKbps) : null
        }
      })

      if (error) throw error
      
      setShowCreateModal(false)
      resetForm()
      loadRules()
    } catch (error) {
      console.error('Error creating rule:', error)
    }
  }

  const updateRule = async (ruleId: string, updates: Partial<TrafficRule>) => {
    try {
      const { data, error } = await supabase.functions.invoke('advanced-traffic-management', {
        body: {
          action: 'update_traffic_rule',
          ruleId,
          ...updates
        }
      })

      if (error) throw error
      loadRules()
    } catch (error) {
      console.error('Error updating rule:', error)
    }
  }

  const testRule = async (rule: TrafficRule) => {
    try {
      const { data, error } = await supabase.functions.invoke('advanced-traffic-management', {
        body: {
          action: 'test_traffic_rule',
          ruleId: rule.id,
          testPackets: [
            { source: '192.168.1.100', destination: '8.8.8.8', protocol: 'tcp', port: 443 },
            { source: '192.168.1.101', destination: '1.1.1.1', protocol: 'udp', port: 53 }
          ]
        }
      })

      if (error) throw error
      
      console.log('Test results:', data.data)
      // Show test results in a modal or toast
    } catch (error) {
      console.error('Error testing rule:', error)
    }
  }

  const applyRuleChanges = async (ruleIds: string[]) => {
    try {
      const { data, error } = await supabase.functions.invoke('advanced-traffic-management', {
        body: {
          action: 'apply_rule_changes',
          ruleIds
        }
      })

      if (error) throw error
      
      console.log('Apply results:', data.data)
      loadRules()
    } catch (error) {
      console.error('Error applying rule changes:', error)
    }
  }

  const resetForm = () => {
    setRuleForm({
      ruleName: '',
      description: '',
      userGroupId: '',
      trafficTypeId: '',
      networkPathId: '',
      tunnelId: '',
      action: 'route',
      priority: 100,
      bandwidthLimitKbps: '',
      isEnabled: true,
      isTesting: false
    })
  }

  const getOptionName = (options: any[], id: string, nameField: string) => {
    const option = options.find(opt => opt.id === id)
    return option ? option[nameField] : 'Unknown'
  }

  const getStatusColor = (isEnabled: boolean, isTesting: boolean) => {
    if (isTesting) return 'text-yellow-600 bg-yellow-100'
    if (isEnabled) return 'text-green-600 bg-green-100'
    return 'text-gray-600 bg-gray-100'
  }

  const getStatusText = (isEnabled: boolean, isTesting: boolean) => {
    if (isTesting) return 'Testing'
    if (isEnabled) return 'Active'
    return 'Disabled'
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white flex items-center space-x-2">
            <Network className="h-6 w-6 text-enterprise-neon" />
            <span>Advanced Traffic Rules</span>
          </h2>
          <p className="text-gray-400 mt-1">
            Hangi kullanıcı grubunun hangi trafiği hangi yolu izleyerek hangi tünelden çıkacak
          </p>
        </div>
        
        <div className="flex space-x-2">
          <Button 
            variant="outline" 
            onClick={() => {
              setShowTrafficFlow(true)
              loadTrafficFlow()
            }}
          >
            <Activity className="h-4 w-4 mr-2" />
            Traffic Flow
          </Button>
          <Button 
            variant="outline" 
            onClick={loadStatistics}
          >
            <BarChart3 className="h-4 w-4 mr-2" />
            Statistics
          </Button>
          <Button onClick={() => setShowCreateModal(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Create Rule
          </Button>
        </div>
      </div>

      {/* Statistics Cards */}
      {statistics && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="bg-white/5 border-white/10">
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <Network className="h-5 w-5 text-blue-400" />
                <div>
                  <p className="text-sm text-gray-400">Total Rules</p>
                  <p className="text-xl font-bold text-white">{statistics.overview.totalRules}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-white/5 border-white/10">
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <CheckCircle className="h-5 w-5 text-green-400" />
                <div>
                  <p className="text-sm text-gray-400">Active Rules</p>
                  <p className="text-xl font-bold text-white">{statistics.overview.activeRules}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-white/5 border-white/10">
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <Activity className="h-5 w-5 text-purple-400" />
                <div>
                  <p className="text-sm text-gray-400">Packets Matched</p>
                  <p className="text-xl font-bold text-white">
                    {(statistics.overview.totalPacketsMatched / 1000000).toFixed(1)}M
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-white/5 border-white/10">
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <Zap className="h-5 w-5 text-yellow-400" />
                <div>
                  <p className="text-sm text-gray-400">Bandwidth Used</p>
                  <p className="text-xl font-bold text-white">
                    {statistics.performance.bandwidth.used.toFixed(0)} Mbps
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Search and Filters */}
      <div className="flex items-center space-x-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <input
            type="text"
            placeholder="Search rules..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
          />
        </div>
        
        <div className="flex space-x-2">
          {['all', 'enabled', 'disabled', 'testing'].map((filterType) => (
            <button
              key={filterType}
              onClick={() => setFilter(filterType as any)}
              className={cn(
                "px-3 py-2 rounded-lg text-sm font-medium transition-colors",
                filter === filterType
                  ? "bg-enterprise-neon text-black"
                  : "bg-white/5 text-gray-400 hover:bg-white/10 hover:text-white"
              )}
            >
              {filterType.charAt(0).toUpperCase() + filterType.slice(1)}
            </button>
          ))}
        </div>
        
        <Button 
          variant="outline" 
          onClick={loadData}
          disabled={loading}
        >
          <RefreshCw className={cn("h-4 w-4", loading && "animate-spin")} />
        </Button>
      </div>

      {/* Rules Table */}
      <Card className="bg-white/5 border-white/10">
        <CardHeader>
          <CardTitle className="text-white">Traffic Rules</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="space-y-4">
              {[1, 2, 3].map((i) => (
                <div key={i} className="animate-pulse bg-white/5 rounded-lg h-16"></div>
              ))}
            </div>
          ) : rules.length === 0 ? (
            <div className="text-center py-8">
              <Network className="h-12 w-12 mx-auto text-gray-400 mb-4" />
              <p className="text-gray-400">No traffic rules found</p>
              <Button className="mt-4" onClick={() => setShowCreateModal(true)}>
                Create Your First Rule
              </Button>
            </div>
          ) : (
            <div className="space-y-2">
              {rules.map((rule) => (
                <motion.div
                  key={rule.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-white/5 rounded-lg p-4 hover:bg-white/10 transition-colors"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-4">
                        <h3 className="font-medium text-white">{rule.rule_name}</h3>
                        <span className={cn(
                          "px-2 py-1 rounded-full text-xs font-medium",
                          getStatusColor(rule.is_enabled, rule.is_testing)
                        )}>
                          {getStatusText(rule.is_enabled, rule.is_testing)}
                        </span>
                        <span className="text-xs text-gray-400">Priority: {rule.priority}</span>
                      </div>
                      
                      <div className="mt-2 flex items-center space-x-6 text-sm text-gray-400">
                        <div className="flex items-center space-x-2">
                          <Users className="h-4 w-4" />
                          <span>
                            {options ? getOptionName(options.userGroups, rule.user_group_id, 'group_name') : 'Loading...'}
                          </span>
                        </div>
                        
                        <ArrowRight className="h-4 w-4" />
                        
                        <div className="flex items-center space-x-2">
                          <Activity className="h-4 w-4" />
                          <span>
                            {options ? getOptionName(options.trafficTypes, rule.traffic_type_id, 'type_name') : 'Loading...'}
                          </span>
                        </div>
                        
                        <ArrowRight className="h-4 w-4" />
                        
                        <div className="flex items-center space-x-2">
                          <Route className="h-4 w-4" />
                          <span>
                            {options ? getOptionName(options.networkPaths, rule.network_path_id, 'path_name') : 'Loading...'}
                          </span>
                        </div>
                        
                        <ArrowRight className="h-4 w-4" />
                        
                        <div className="flex items-center space-x-2">
                          <Shield className="h-4 w-4" />
                          <span>
                            {options ? getOptionName(options.tunnels, rule.tunnel_id, 'tunnel_name') : 'Loading...'}
                          </span>
                        </div>
                      </div>
                      
                      {rule.description && (
                        <p className="text-sm text-gray-500 mt-1">{rule.description}</p>
                      )}
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => testRule(rule)}
                      >
                        <TestTube className="h-4 w-4" />
                      </Button>
                      
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => updateRule(rule.id, { is_enabled: !rule.is_enabled })}
                      >
                        {rule.is_enabled ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                      </Button>
                      
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setSelectedRule(rule)
                          // Open edit modal
                        }}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          // Delete rule
                        }}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  
                  {/* Rule Statistics */}
                  {(rule.packets_matched > 0 || rule.bytes_matched > 0) && (
                    <div className="mt-3 pt-3 border-t border-white/10">
                      <div className="flex items-center space-x-6 text-xs text-gray-500">
                        <span>Packets: {rule.packets_matched.toLocaleString()}</span>
                        <span>Bytes: {(rule.bytes_matched / 1024 / 1024).toFixed(2)} MB</span>
                      </div>
                    </div>
                  )}
                </motion.div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Create Rule Modal */}
      <AnimatePresence>
        {showCreateModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-gray-900/95 backdrop-blur-sm border border-white/10 rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto"
            >
              <div className="p-6 bg-white/5 rounded-lg">
                <h2 className="text-xl font-semibold text-white mb-6">Create Traffic Rule</h2>
                
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">Rule Name</label>
                    <input
                      type="text"
                      value={ruleForm.ruleName}
                      onChange={(e) => setRuleForm(prev => ({ ...prev, ruleName: e.target.value }))}
                      className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-enterprise-neon focus:border-enterprise-neon"
                      placeholder="Enter rule name"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">User Group</label>
                    <select
                      value={ruleForm.userGroupId}
                      onChange={(e) => setRuleForm(prev => ({ ...prev, userGroupId: e.target.value }))}
                      className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-enterprise-neon focus:border-enterprise-neon"
                    >
                      <option value="" className="bg-gray-800 text-gray-400">Select user group</option>
                      {options?.userGroups.map(group => (
                        <option key={group.id} value={group.id} className="bg-gray-800 text-white">{group.group_name}</option>
                      ))}
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">Traffic Type</label>
                    <select
                      value={ruleForm.trafficTypeId}
                      onChange={(e) => setRuleForm(prev => ({ ...prev, trafficTypeId: e.target.value }))}
                      className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-enterprise-neon focus:border-enterprise-neon"
                    >
                      <option value="" className="bg-gray-800 text-gray-400">Select traffic type</option>
                      {options?.trafficTypes.map(type => (
                        <option key={type.id} value={type.id} className="bg-gray-800 text-white">{type.type_name}</option>
                      ))}
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">Network Path</label>
                    <select
                      value={ruleForm.networkPathId}
                      onChange={(e) => setRuleForm(prev => ({ ...prev, networkPathId: e.target.value }))}
                      className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-enterprise-neon focus:border-enterprise-neon"
                    >
                      <option value="" className="bg-gray-800 text-gray-400">Select network path</option>
                      {options?.networkPaths.map(path => (
                        <option key={path.id} value={path.id} className="bg-gray-800 text-white">{path.path_name}</option>
                      ))}
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">Tunnel</label>
                    <select
                      value={ruleForm.tunnelId}
                      onChange={(e) => setRuleForm(prev => ({ ...prev, tunnelId: e.target.value }))}
                      className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-enterprise-neon focus:border-enterprise-neon"
                    >
                      <option value="" className="bg-gray-800 text-gray-400">Select tunnel</option>
                      {options?.tunnels.map(tunnel => (
                        <option key={tunnel.id} value={tunnel.id} className="bg-gray-800 text-white">{tunnel.tunnel_name}</option>
                      ))}
                    </select>
                  </div>
                </div>
                
                <div className="flex justify-end space-x-2 mt-6">
                  <Button variant="outline" onClick={() => setShowCreateModal(false)}>
                    Cancel
                  </Button>
                  <Button onClick={createRule}>
                    Create Rule
                  </Button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

export default AdvancedTrafficRules