import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  CheckCircle,
  XCircle,
  ArrowRight,
  ArrowLeft,
  Wifi,
  Server,
  Shield,
  Settings,
  Loader2,
} from 'lucide-react';

interface NetworkInterface {
  name: string;
  type: string;
  status: string;
  ip: string | null;
  gateway: string | null;
}

interface SetupConfig {
  network: {
    primaryInterface: string;
    ipMode: string;
    staticIP: string;
    gateway: string;
  };
  security: {
    adminPassword: string;
    firewallEnabled: boolean;
    sshEnabled: boolean;
  };
  system: {
    hostname: string;
    timezone: string;
    autoUpdates: boolean;
  };
}

export default function QuickSetupWizard({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) {
  const [currentStep, setCurrentStep] = useState(0);
  const [networkInterfaces, setNetworkInterfaces] = useState<NetworkInterface[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [setupConfig, setSetupConfig] = useState<SetupConfig>({
    network: {
      primaryInterface: '',
      ipMode: 'dhcp',
      staticIP: '',
      gateway: '',
    },
    security: {
      adminPassword: '',
      firewallEnabled: true,
      sshEnabled: false,
    },
    system: {
      hostname: 'pi5-supernode',
      timezone: 'UTC',
      autoUpdates: true,
    },
  });
  const [setupResult, setSetupResult] = useState<any>(null);

  const steps = [
    { title: 'Welcome', icon: Settings },
    { title: 'Network Detection', icon: Wifi },
    { title: 'Security Config', icon: Shield },
    { title: 'System Config', icon: Server },
    { title: 'Complete', icon: CheckCircle },
  ];

  const detectNetwork = async () => {
    setIsLoading(true);
    try {
      const response = await fetch('/functions/v1/quick-setup-manager/detect-network');
      const result = await response.json();
      if (result.data) {
        setNetworkInterfaces(result.data);
        const connectedInterface = result.data.find((iface: NetworkInterface) => iface.status === 'connected');
        if (connectedInterface) {
          setSetupConfig(prev => ({
            ...prev,
            network: {
              ...prev.network,
              primaryInterface: connectedInterface.name,
              staticIP: connectedInterface.ip || '',
              gateway: connectedInterface.gateway || '',
            }
          }));
        }
      }
    } catch (error) {
      console.error('Network detection failed:', error);
    }
    setIsLoading(false);
  };

  const applyConfiguration = async () => {
    setIsLoading(true);
    try {
      const response = await fetch('/functions/v1/quick-setup-manager/apply-basic-config', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          networkConfig: setupConfig.network,
          securityConfig: setupConfig.security,
          systemConfig: setupConfig.system,
        }),
      });
      const result = await response.json();
      if (result.data) {
        setSetupResult(result.data);
        setCurrentStep(4); // Move to completion step
      }
    } catch (error) {
      console.error('Configuration application failed:', error);
    }
    setIsLoading(false);
  };

  useEffect(() => {
    if (currentStep === 1) {
      detectNetwork();
    }
  }, [currentStep]);

  const nextStep = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 0: // Welcome
        return (
          <div className="text-center space-y-4 sm:space-y-6">
            <div className="mx-auto w-16 h-16 sm:w-20 sm:h-20 bg-blue-500/20 rounded-full flex items-center justify-center">
              <Settings className="w-8 h-8 sm:w-10 sm:h-10 text-blue-400" />
            </div>
            <div>
              <h2 className="responsive-title font-bold text-white mb-4">Welcome to Pi5 Supernode Setup</h2>
              <p className="responsive-subtitle text-gray-400">
                This wizard will help you configure your Pi5 Supernode system quickly and easily.
                We'll detect your hardware, configure network settings, and set up basic security.
              </p>
            </div>
            <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-3 sm:p-4">
              <h3 className="font-semibold text-blue-400 mb-2 text-sm sm:text-base">What we'll configure:</h3>
              <ul className="text-left space-y-1 sm:space-y-2 text-gray-300 text-sm sm:text-base">
                <li>• Network interfaces and connectivity</li>
                <li>• Basic security settings and admin access</li>
                <li>• System hostname and time settings</li>
                <li>• Monitoring and update preferences</li>
              </ul>
            </div>
          </div>
        );

      case 1: // Network Detection
        return (
          <div className="space-y-4 sm:space-y-6">
            <div className="text-center">
              <Wifi className="mx-auto w-12 h-12 sm:w-16 sm:h-16 text-blue-400 mb-4" />
              <h2 className="text-lg sm:text-xl font-bold text-white mb-2">Detecting Network Interfaces</h2>
              <p className="text-sm sm:text-base text-gray-400">Scanning for available network connections...</p>
            </div>
            
            {isLoading ? (
              <div className="text-center">
                <Loader2 className="w-6 h-6 sm:w-8 sm:h-8 animate-spin mx-auto mb-4 text-blue-400" />
                <p className="text-sm sm:text-base text-gray-400">Scanning network interfaces...</p>
              </div>
            ) : (
              <div className="space-y-3 sm:space-y-4">
                {networkInterfaces.map((iface) => (
                  <div key={iface.name} className="bg-gray-800/50 rounded-lg p-3 sm:p-4">
                    <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center space-y-2 sm:space-y-0">
                      <div>
                        <h3 className="font-semibold text-white text-sm sm:text-base">{iface.name}</h3>
                        <p className="text-xs sm:text-sm text-gray-400 capitalize">{iface.type}</p>
                      </div>
                      <div className="flex flex-col sm:text-right">
                        <span className={`px-2 py-1 rounded text-xs sm:text-sm w-fit sm:ml-auto ${
                          iface.status === 'connected' ? 'bg-green-500/20 text-green-400' : 
                          iface.status === 'available' ? 'bg-yellow-500/20 text-yellow-400' : 
                          'bg-red-500/20 text-red-400'
                        }`}>
                          {iface.status}
                        </span>
                        {iface.ip && <p className="text-xs sm:text-sm text-gray-400 mt-1">{iface.ip}</p>}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        );

      case 2: // Security Configuration
        return (
          <div className="space-y-4 sm:space-y-6">
            <div className="text-center mb-4 sm:mb-6">
              <Shield className="mx-auto w-12 h-12 sm:w-16 sm:h-16 text-red-400 mb-4" />
              <h2 className="text-lg sm:text-xl font-bold text-white mb-2">Security Configuration</h2>
              <p className="text-sm sm:text-base text-gray-400">Set up basic security settings</p>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Admin Password</label>
                <input
                  type="password"
                  className="w-full bg-gray-800/50 border border-gray-600 rounded-lg px-3 py-2 text-white touch-target"
                  placeholder="Enter a strong admin password"
                  value={setupConfig.security.adminPassword}
                  onChange={(e) => 
                    setSetupConfig(prev => ({ ...prev, security: { ...prev.security, adminPassword: e.target.value } }))
                  }
                />
                <p className="text-xs sm:text-sm text-gray-500 mt-1">
                  Use a strong password with at least 8 characters
                </p>
              </div>
              
              <div className="flex items-center justify-between py-3 border-b border-gray-700">
                <div>
                  <h3 className="font-medium text-white text-sm sm:text-base">Enable Firewall</h3>
                  <p className="text-xs sm:text-sm text-gray-400">Basic firewall protection</p>
                </div>
                <input
                  type="checkbox"
                  checked={setupConfig.security.firewallEnabled}
                  onChange={(e) => 
                    setSetupConfig(prev => ({ ...prev, security: { ...prev.security, firewallEnabled: e.target.checked } }))
                  }
                  className="w-5 h-5 touch-target"
                />
              </div>
              
              <div className="flex items-center justify-between py-3">
                <div>
                  <h3 className="font-medium text-white text-sm sm:text-base">Enable SSH Access</h3>
                  <p className="text-xs sm:text-sm text-gray-400">Remote terminal access</p>
                </div>
                <input
                  type="checkbox"
                  checked={setupConfig.security.sshEnabled}
                  onChange={(e) => 
                    setSetupConfig(prev => ({ ...prev, security: { ...prev.security, sshEnabled: e.target.checked } }))
                  }
                  className="w-5 h-5 touch-target"
                />
              </div>
            </div>
          </div>
        );

      case 3: // System Configuration
        return (
          <div className="space-y-4 sm:space-y-6">
            <div className="text-center mb-4 sm:mb-6">
              <Server className="mx-auto w-12 h-12 sm:w-16 sm:h-16 text-purple-400 mb-4" />
              <h2 className="text-lg sm:text-xl font-bold text-white mb-2">System Configuration</h2>
              <p className="text-sm sm:text-base text-gray-400">Configure basic system settings</p>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">System Hostname</label>
                <input
                  type="text"
                  className="w-full bg-gray-800/50 border border-gray-600 rounded-lg px-3 py-2 text-white touch-target"
                  placeholder="pi5-supernode"
                  value={setupConfig.system.hostname}
                  onChange={(e) => 
                    setSetupConfig(prev => ({ ...prev, system: { ...prev.system, hostname: e.target.value } }))
                  }
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Timezone</label>
                <select
                  className="w-full bg-gray-800/50 border border-gray-600 rounded-lg px-3 py-2 text-white touch-target"
                  value={setupConfig.system.timezone}
                  onChange={(e) => 
                    setSetupConfig(prev => ({ ...prev, system: { ...prev.system, timezone: e.target.value } }))
                  }
                >
                  <option value="UTC">UTC</option>
                  <option value="America/New_York">Eastern Time</option>
                  <option value="America/Chicago">Central Time</option>
                  <option value="America/Denver">Mountain Time</option>
                  <option value="America/Los_Angeles">Pacific Time</option>
                  <option value="Europe/London">London</option>
                  <option value="Europe/Paris">Paris</option>
                  <option value="Asia/Tokyo">Tokyo</option>
                </select>
              </div>
              
              <div className="flex items-center justify-between py-3">
                <div>
                  <h3 className="font-medium text-white text-sm sm:text-base">Enable Auto Updates</h3>
                  <p className="text-xs sm:text-sm text-gray-400">Automatic system updates</p>
                </div>
                <input
                  type="checkbox"
                  checked={setupConfig.system.autoUpdates}
                  onChange={(e) => 
                    setSetupConfig(prev => ({ ...prev, system: { ...prev.system, autoUpdates: e.target.checked } }))
                  }
                  className="w-5 h-5 touch-target"
                />
              </div>
            </div>
          </div>
        );

      case 4: // Complete
        return (
          <div className="text-center space-y-4 sm:space-y-6">
            <div className="mx-auto w-16 h-16 sm:w-20 sm:h-20 bg-green-500/20 rounded-full flex items-center justify-center">
              <CheckCircle className="w-8 h-8 sm:w-10 sm:h-10 text-green-400" />
            </div>
            <div>
              <h2 className="responsive-title font-bold text-white mb-4">Setup Complete!</h2>
              <p className="responsive-subtitle text-gray-400">
                Your Pi5 Supernode has been successfully configured. The system is now ready for use.
              </p>
            </div>
            {setupResult && (
              <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-3 sm:p-4">
                <h3 className="font-semibold text-green-400 mb-2 text-sm sm:text-base">Configuration Summary:</h3>
                <ul className="text-left space-y-1 text-gray-300 text-xs sm:text-sm">
                  <li>• Network interface configured</li>
                  <li>• Security settings applied</li>
                  <li>• System preferences saved</li>
                  <li>• Monitoring services started</li>
                </ul>
              </div>
            )}
          </div>
        );

      default:
        return null;
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl max-h-[90vh] overflow-y-auto mobile-card">
        <CardHeader className="pb-4">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-2 sm:space-y-0">
            <CardTitle className="responsive-title">Quick Setup Wizard</CardTitle>
            <div className="flex items-center space-x-2">
              {steps.map((step, index) => {
                const Icon = step.icon;
                return (
                  <div
                    key={index}
                    className={`flex items-center space-x-1 sm:space-x-2 px-2 sm:px-3 py-1 rounded-full text-xs sm:text-sm ${
                      index === currentStep
                        ? 'bg-blue-500/20 text-blue-400'
                        : index < currentStep
                        ? 'bg-green-500/20 text-green-400'
                        : 'bg-gray-500/20 text-gray-400'
                    }`}
                  >
                    <Icon className="w-3 h-3 sm:w-4 sm:h-4" />
                    <span className="hidden sm:inline">{step.title}</span>
                  </div>
                );
              })}
            </div>
          </div>
          <CardDescription className="text-xs sm:text-sm text-gray-400">
            Step {currentStep + 1} of {steps.length}
          </CardDescription>
        </CardHeader>
        
        <CardContent className="pt-0">
          <div className="mb-6">
            {renderStepContent()}
          </div>
          
          <div className="mobile-button-group">
            {currentStep > 0 && currentStep < 4 && (
              <Button
                variant="outline"
                onClick={prevStep}
                className="touch-target"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Previous
              </Button>
            )}
            
            {currentStep < 3 && (
              <Button
                onClick={nextStep}
                className="touch-target"
                disabled={isLoading}
              >
                {isLoading ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <ArrowRight className="w-4 h-4 mr-2" />
                )}
                Next
              </Button>
            )}
            
            {currentStep === 3 && (
              <Button
                onClick={applyConfiguration}
                className="touch-target"
                disabled={isLoading}
              >
                {isLoading ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <CheckCircle className="w-4 h-4 mr-2" />
                )}
                Apply Configuration
              </Button>
            )}
            
            {currentStep === 4 && (
              <Button
                onClick={onClose}
                className="touch-target"
              >
                <CheckCircle className="w-4 h-4 mr-2" />
                Complete
              </Button>
            )}
            
            <Button
              variant="outline"
              onClick={onClose}
              className="touch-target"
            >
              Cancel
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
