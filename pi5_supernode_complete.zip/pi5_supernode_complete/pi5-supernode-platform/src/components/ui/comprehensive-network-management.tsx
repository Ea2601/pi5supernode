import React, { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import {
  Network as NetworkIcon,
  Wifi,
  Server,
  Shield,
  Settings,
  Plus,
  Edit,
  Trash2,
  Power,
  RefreshCw,
  Globe,
  Router,
  Layers,
  Search,
  Filter,
  Download,
  Upload,
  Signal,
  Lock,
  Unlock,
  Eye,
  EyeOff,
  AlertTriangle,
  CheckCircle,
  Clock,
  Users,
  Zap
} from 'lucide-react'
import { useUIStore } from '@/lib/store'
import { Button } from '@/components/ui/button'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card'
import TableCard from '@/components/ui/table-card'
import MetricCard from '@/components/ui/metric-card'
import Modal from '@/components/ui/modal'
import { cn } from '@/lib/utils'
import { supabase } from '@/lib/supabase'

interface DHCPPool {
  id: string
  name: string
  description: string
  vlan_id: number
  network_cidr: string
  start_ip: string
  end_ip: string
  gateway_ip: string
  dns_servers: string[]
  lease_time: string
  is_active: boolean
}

interface DHCPReservation {
  id: string
  pool_id: string
  device_name: string
  mac_address: string
  reserved_ip: string
  description: string
  is_active: boolean
}

interface WiFiNetwork {
  id: string
  ssid: string
  frequency_band: string
  security_type: string
  password: string
  hidden: boolean
  max_clients: number
  is_guest_network: boolean
  guest_isolation: boolean
  channel_width: number
  tx_power_dbm: number
  is_enabled: boolean
}

interface VLAN {
  id: string
  vlan_id: number
  vlan_name: string
  description: string
  network_cidr: string
  gateway_ip: string
  dhcp_enabled: boolean
  inter_vlan_routing: boolean
  qos_priority: number
  is_active: boolean
}

const ComprehensiveNetworkManagement: React.FC = () => {
  const { addNotification } = useUIStore()
  const [loading, setLoading] = useState(false)
  const [activeTab, setActiveTab] = useState('dhcp')
  
  // DHCP State
  const [dhcpPools, setDHCPPools] = useState<DHCPPool[]>([])
  const [dhcpReservations, setDHCPReservations] = useState<DHCPReservation[]>([])
  const [showDHCPPoolModal, setShowDHCPPoolModal] = useState(false)
  const [showDHCPReservationModal, setShowDHCPReservationModal] = useState(false)
  const [editingDHCPPool, setEditingDHCPPool] = useState<DHCPPool | null>(null)
  
  // WiFi State
  const [wifiNetworks, setWiFiNetworks] = useState<WiFiNetwork[]>([])
  const [showWiFiModal, setShowWiFiModal] = useState(false)
  const [editingWiFiNetwork, setEditingWiFiNetwork] = useState<WiFiNetwork | null>(null)
  const [showPassword, setShowPassword] = useState<{[key: string]: boolean}>({})
  
  // VLAN State
  const [vlans, setVLANs] = useState<VLAN[]>([])
  const [showVLANModal, setShowVLANModal] = useState(false)
  const [editingVLAN, setEditingVLAN] = useState<VLAN | null>(null)
  
  // Network Status
  const [networkStatus, setNetworkStatus] = useState<any>(null)
  const [networkMetrics, setNetworkMetrics] = useState<any>(null)
  
  // Form States
  const [dhcpPoolForm, setDHCPPoolForm] = useState({
    name: '',
    description: '',
    vlanId: 1,
    networkCidr: '',
    startIp: '',
    endIp: '',
    gatewayIp: '',
    dnsServers: ['8.8.8.8', '1.1.1.1'],
    leaseTimeHours: 24
  })
  
  const [dhcpReservationForm, setDHCPReservationForm] = useState({
    poolId: '',
    deviceName: '',
    macAddress: '',
    reservedIp: '',
    description: ''
  })
  
  const [wifiForm, setWiFiForm] = useState({
    ssid: '',
    frequencyBand: 'dual',
    securityType: 'wpa3',
    password: '',
    hidden: false,
    maxClients: 50,
    isGuestNetwork: false,
    guestIsolation: false,
    channelWidth: 80,
    txPowerDbm: 20
  })
  
  const [vlanForm, setVLANForm] = useState({
    vlanId: 10,
    vlanName: '',
    description: '',
    networkCidr: '',
    gatewayIp: '',
    dhcpEnabled: true,
    interVlanRouting: false,
    qosPriority: 0
  })

  useEffect(() => {
    loadAllNetworkData()
  }, [])

  const loadAllNetworkData = async () => {
    setLoading(true)
    try {
      await Promise.all([
        loadDHCPPools(),
        loadDHCPReservations(),
        loadWiFiNetworks(),
        loadVLANs(),
        loadNetworkStatus()
      ])
    } catch (error) {
      console.error('Error loading network data:', error)
      addNotification({ type: 'error', message: 'Failed to load network data' })
    } finally {
      setLoading(false)
    }
  }

  const loadDHCPPools = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('enhanced-network-management', {
        body: { action: 'get_dhcp_pools' }
      })
      
      if (error) throw error
      setDHCPPools(data?.data?.pools || [])
    } catch (error) {
      console.error('Error loading DHCP pools:', error)
    }
  }

  const loadDHCPReservations = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('enhanced-network-management', {
        body: { action: 'get_dhcp_reservations' }
      })
      
      if (error) throw error
      setDHCPReservations(data?.data?.reservations || [])
    } catch (error) {
      console.error('Error loading DHCP reservations:', error)
    }
  }

  const loadWiFiNetworks = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('enhanced-network-management', {
        body: { action: 'get_wifi_networks' }
      })
      
      if (error) throw error
      setWiFiNetworks(data?.data?.networks || [])
    } catch (error) {
      console.error('Error loading WiFi networks:', error)
    }
  }

  const loadVLANs = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('enhanced-network-management', {
        body: { action: 'get_vlans' }
      })
      
      if (error) throw error
      setVLANs(data?.data?.vlans || [])
    } catch (error) {
      console.error('Error loading VLANs:', error)
    }
  }

  const loadNetworkStatus = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('enhanced-network-management', {
        body: { action: 'get_network_status' }
      })
      
      if (error) throw error
      setNetworkStatus(data?.data?.status || [])
      setNetworkMetrics(data?.data?.metrics || null)
    } catch (error) {
      console.error('Error loading network status:', error)
    }
  }

  const createDHCPPool = async () => {
    try {
      setLoading(true)
      const { data, error } = await supabase.functions.invoke('enhanced-network-management', {
        body: { 
          action: 'create_dhcp_pool',
          ...dhcpPoolForm
        }
      })
      
      if (error) throw error
      addNotification({ type: 'success', message: 'DHCP pool created successfully' })
      setShowDHCPPoolModal(false)
      resetDHCPPoolForm()
      await loadDHCPPools()
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to create DHCP pool' })
    } finally {
      setLoading(false)
    }
  }

  const updateDHCPPool = async () => {
    if (!editingDHCPPool) return
    
    try {
      setLoading(true)
      const { data, error } = await supabase.functions.invoke('enhanced-network-management', {
        body: { 
          action: 'update_dhcp_pool',
          poolId: editingDHCPPool.id,
          ...dhcpPoolForm
        }
      })
      
      if (error) throw error
      addNotification({ type: 'success', message: 'DHCP pool updated successfully' })
      setShowDHCPPoolModal(false)
      setEditingDHCPPool(null)
      resetDHCPPoolForm()
      await loadDHCPPools()
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to update DHCP pool' })
    } finally {
      setLoading(false)
    }
  }

  const deleteDHCPPool = async (poolId: string) => {
    if (!confirm('Are you sure you want to delete this DHCP pool?')) return
    
    try {
      setLoading(true)
      const { data, error } = await supabase.functions.invoke('enhanced-network-management', {
        body: { 
          action: 'delete_dhcp_pool',
          poolId
        }
      })
      
      if (error) throw error
      addNotification({ type: 'success', message: 'DHCP pool deleted successfully' })
      await loadDHCPPools()
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to delete DHCP pool' })
    } finally {
      setLoading(false)
    }
  }

  const createWiFiNetwork = async () => {
    try {
      setLoading(true)
      const { data, error } = await supabase.functions.invoke('enhanced-network-management', {
        body: { 
          action: 'create_wifi_network',
          ...wifiForm
        }
      })
      
      if (error) throw error
      addNotification({ type: 'success', message: 'WiFi network created successfully' })
      setShowWiFiModal(false)
      resetWiFiForm()
      await loadWiFiNetworks()
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to create WiFi network' })
    } finally {
      setLoading(false)
    }
  }

  const toggleWiFiNetwork = async (networkId: string, enabled: boolean) => {
    try {
      setLoading(true)
      const { data, error } = await supabase.functions.invoke('enhanced-network-management', {
        body: { 
          action: 'toggle_wifi_network',
          networkId,
          enabled
        }
      })
      
      if (error) throw error
      addNotification({ 
        type: 'success', 
        message: `WiFi network ${enabled ? 'enabled' : 'disabled'} successfully` 
      })
      await loadWiFiNetworks()
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to toggle WiFi network' })
    } finally {
      setLoading(false)
    }
  }

  const deleteWiFiNetwork = async (networkId: string) => {
    if (!confirm('Are you sure you want to delete this WiFi network?')) return
    
    try {
      setLoading(true)
      const { data, error } = await supabase.functions.invoke('enhanced-network-management', {
        body: { 
          action: 'delete_wifi_network',
          networkId
        }
      })
      
      if (error) throw error
      addNotification({ type: 'success', message: 'WiFi network deleted successfully' })
      await loadWiFiNetworks()
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to delete WiFi network' })
    } finally {
      setLoading(false)
    }
  }

  const createVLAN = async () => {
    try {
      setLoading(true)
      const { data, error } = await supabase.functions.invoke('enhanced-network-management', {
        body: { 
          action: 'create_vlan',
          ...vlanForm
        }
      })
      
      if (error) throw error
      addNotification({ type: 'success', message: 'VLAN created successfully' })
      setShowVLANModal(false)
      resetVLANForm()
      await loadVLANs()
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to create VLAN' })
    } finally {
      setLoading(false)
    }
  }

  const performNetworkScan = async () => {
    try {
      setLoading(true)
      addNotification({ type: 'info', message: 'Starting network scan...' })
      
      const { data, error } = await supabase.functions.invoke('enhanced-network-management', {
        body: { 
          action: 'perform_network_scan',
          scanType: 'device_discovery'
        }
      })
      
      if (error) throw error
      
      const scanResults = data?.data?.scanResults
      addNotification({ 
        type: 'success', 
        message: `Network scan completed. Found ${scanResults?.devicesFound?.length || 0} devices.` 
      })
    } catch (error) {
      addNotification({ type: 'error', message: 'Network scan failed' })
    } finally {
      setLoading(false)
    }
  }

  const resetDHCPPoolForm = () => {
    setDHCPPoolForm({
      name: '',
      description: '',
      vlanId: 1,
      networkCidr: '',
      startIp: '',
      endIp: '',
      gatewayIp: '',
      dnsServers: ['8.8.8.8', '1.1.1.1'],
      leaseTimeHours: 24
    })
  }

  const resetWiFiForm = () => {
    setWiFiForm({
      ssid: '',
      frequencyBand: 'dual',
      securityType: 'wpa3',
      password: '',
      hidden: false,
      maxClients: 50,
      isGuestNetwork: false,
      guestIsolation: false,
      channelWidth: 80,
      txPowerDbm: 20
    })
  }

  const resetVLANForm = () => {
    setVLANForm({
      vlanId: 10,
      vlanName: '',
      description: '',
      networkCidr: '',
      gatewayIp: '',
      dhcpEnabled: true,
      interVlanRouting: false,
      qosPriority: 0
    })
  }

  const editDHCPPool = (pool: DHCPPool) => {
    setEditingDHCPPool(pool)
    setDHCPPoolForm({
      name: pool.name,
      description: pool.description || '',
      vlanId: pool.vlan_id,
      networkCidr: pool.network_cidr,
      startIp: pool.start_ip,
      endIp: pool.end_ip,
      gatewayIp: pool.gateway_ip,
      dnsServers: pool.dns_servers || ['8.8.8.8', '1.1.1.1'],
      leaseTimeHours: parseInt(pool.lease_time.replace(' hours', '')) || 24
    })
    setShowDHCPPoolModal(true)
  }

  const togglePasswordVisibility = (networkId: string) => {
    setShowPassword(prev => ({
      ...prev,
      [networkId]: !prev[networkId]
    }))
  }

  const tabs = [
    { id: 'dhcp', label: 'DHCP Pools', icon: Server },
    { id: 'wifi', label: 'WiFi Networks', icon: Wifi },
    { id: 'vlan', label: 'VLANs', icon: Layers },
    { id: 'monitoring', label: 'Network Monitoring', icon: NetworkIcon }
  ]

  const dhcpColumns = [
    {
      key: 'name' as keyof DHCPPool,
      label: 'Pool Name',
      sortable: true,
      render: (value: any, item: DHCPPool) => (
        <div>
          <div className="font-medium text-white">{value}</div>
          <div className="text-sm text-gray-400">{item.description}</div>
        </div>
      )
    },
    {
      key: 'network_cidr' as keyof DHCPPool,
      label: 'Network',
      sortable: true,
      render: (value: any) => (
        <span className="font-mono text-sm text-gray-300">{value}</span>
      )
    },
    {
      key: 'start_ip' as keyof DHCPPool,
      label: 'IP Range',
      render: (value: any, item: DHCPPool) => (
        <span className="font-mono text-sm text-gray-300">
          {value} - {item.end_ip}
        </span>
      )
    },
    {
      key: 'gateway_ip' as keyof DHCPPool,
      label: 'Gateway',
      render: (value: any) => (
        <span className="font-mono text-sm text-gray-300">{value}</span>
      )
    },
    {
      key: 'is_active' as keyof DHCPPool,
      label: 'Status',
      sortable: true,
      render: (value: any) => (
        <span className={value ? 'status-active' : 'status-inactive'}>
          {value ? 'Active' : 'Inactive'}
        </span>
      )
    }
  ]

  const wifiColumns = [
    {
      key: 'ssid' as keyof WiFiNetwork,
      label: 'Network Name (SSID)',
      sortable: true,
      render: (value: any, item: WiFiNetwork) => (
        <div className="flex items-center space-x-2">
          <span className="font-medium text-white">{value}</span>
          {item.hidden && <Eye className="h-4 w-4 text-gray-400" />}
          {item.is_guest_network && (
            <span className="px-2 py-1 bg-blue-500/20 text-blue-300 text-xs rounded">
              Guest
            </span>
          )}
        </div>
      )
    },
    {
      key: 'frequency_band' as keyof WiFiNetwork,
      label: 'Band',
      render: (value: any) => (
        <span className="status-badge bg-purple-500/20 text-purple-300 border-purple-500/30">
          {value}
        </span>
      )
    },
    {
      key: 'security_type' as keyof WiFiNetwork,
      label: 'Security',
      render: (value: any) => (
        <span className="status-badge bg-green-500/20 text-green-300 border-green-500/30">
          {value.toUpperCase()}
        </span>
      )
    },
    {
      key: 'password' as keyof WiFiNetwork,
      label: 'Password',
      render: (value: any, item: WiFiNetwork) => (
        <div className="flex items-center space-x-2">
          <span className="font-mono text-sm text-gray-300">
            {showPassword[item.id] ? value : '••••••••••••'}
          </span>
          <Button
            variant="outline"
            size="sm"
            onClick={() => togglePasswordVisibility(item.id)}
          >
            {showPassword[item.id] ? <EyeOff className="h-3 w-3" /> : <Eye className="h-3 w-3" />}
          </Button>
        </div>
      )
    },
    {
      key: 'max_clients' as keyof WiFiNetwork,
      label: 'Max Clients',
      render: (value: any) => (
        <span className="text-gray-300">{value}</span>
      )
    },
    {
      key: 'is_enabled' as keyof WiFiNetwork,
      label: 'Status',
      sortable: true,
      render: (value: any) => (
        <span className={value ? 'status-active' : 'status-inactive'}>
          {value ? 'Broadcasting' : 'Disabled'}
        </span>
      )
    }
  ]

  const vlanColumns = [
    {
      key: 'vlan_id' as keyof VLAN,
      label: 'VLAN ID',
      sortable: true,
      render: (value: any) => (
        <span className="font-mono text-lg font-bold text-enterprise-neon">{value}</span>
      )
    },
    {
      key: 'vlan_name' as keyof VLAN,
      label: 'Name',
      sortable: true,
      render: (value: any, item: VLAN) => (
        <div>
          <div className="font-medium text-white">{value}</div>
          <div className="text-sm text-gray-400">{item.description}</div>
        </div>
      )
    },
    {
      key: 'network_cidr' as keyof VLAN,
      label: 'Network',
      render: (value: any) => (
        <span className="font-mono text-sm text-gray-300">{value}</span>
      )
    },
    {
      key: 'qos_priority' as keyof VLAN,
      label: 'QoS Priority',
      sortable: true,
      render: (value: any) => (
        <span className={cn(
          'px-2 py-1 rounded text-xs font-medium',
          value >= 6 ? 'bg-red-500/20 text-red-300' :
          value >= 4 ? 'bg-yellow-500/20 text-yellow-300' :
          'bg-green-500/20 text-green-300'
        )}>
          {value}
        </span>
      )
    },
    {
      key: 'dhcp_enabled' as keyof VLAN,
      label: 'DHCP',
      render: (value: any) => (
        <span className={value ? 'status-active' : 'status-inactive'}>
          {value ? 'Enabled' : 'Disabled'}
        </span>
      )
    },
    {
      key: 'is_active' as keyof VLAN,
      label: 'Status',
      sortable: true,
      render: (value: any) => (
        <span className={value ? 'status-active' : 'status-inactive'}>
          {value ? 'Active' : 'Inactive'}
        </span>
      )
    }
  ]

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Network Management</h1>
          <p className="text-gray-400">Comprehensive DHCP, WiFi, VLAN, and network monitoring</p>
        </div>
        
        <div className="flex items-center space-x-3">
          <Button
            variant="outline"
            onClick={performNetworkScan}
            loading={loading}
          >
            <Search className="h-4 w-4 mr-2" />
            Network Scan
          </Button>
          
          <Button
            variant="outline"
            onClick={loadAllNetworkData}
            loading={loading}
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
        </div>
      </div>

      {/* Network Overview Metrics */}
      {networkMetrics && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <MetricCard
            title="Total Devices"
            value={networkMetrics.totalDevices}
            subtitle={`${networkMetrics.activeConnections} active`}
            icon={Users}
            color="info"
            loading={loading}
          />
          
          <MetricCard
            title="Bandwidth Usage"
            value={`${networkMetrics.bandwidthUsage?.download || 0} Mbps`}
            subtitle={`↑ ${networkMetrics.bandwidthUsage?.upload || 0} Mbps`}
            icon={Zap}
            color="success"
            loading={loading}
          />
          
          <MetricCard
            title="Network Latency"
            value={`${networkMetrics.latency || 0}ms`}
            subtitle={`${networkMetrics.packetLoss || 0}% loss`}
            icon={Signal}
            color={networkMetrics.latency > 50 ? 'warning' : 'success'}
            loading={loading}
          />
          
          <MetricCard
            title="Network Uptime"
            value={networkMetrics.uptime || '99.9%'}
            subtitle="Last 30 days"
            icon={Clock}
            color="success"
            loading={loading}
          />
        </div>
      )}

      {/* Tab Navigation */}
      <div className="flex space-x-1 glassmorphism-card bg-gray-800/30 p-1 rounded-lg w-fit">
        {tabs.map((tab) => {
          const Icon = tab.icon
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={cn(
                'flex items-center space-x-2 px-4 py-2 rounded-md transition-all duration-200',
                activeTab === tab.id
                  ? 'bg-enterprise-neon/20 text-enterprise-neon border border-enterprise-neon/30'
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              )}
            >
              <Icon className="h-4 w-4" />
              <span>{tab.label}</span>
            </button>
          )
        })}
      </div>

      {/* Tab Content */}
      <div className="space-y-6">
        {activeTab === 'dhcp' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h3 className="text-xl font-semibold text-white">DHCP Pool Management</h3>
              <Button variant="neon" onClick={() => setShowDHCPPoolModal(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Add DHCP Pool
              </Button>
            </div>
            
            <TableCard
              title="DHCP Pools"
              description="Manage DHCP address pools and reservations"
              data={dhcpPools}
              columns={dhcpColumns}
              loading={loading}
              actions={[
                {
                  label: 'Edit',
                  onClick: editDHCPPool,
                  variant: 'outline'
                },
                {
                  label: 'Delete',
                  onClick: (pool: DHCPPool) => deleteDHCPPool(pool.id),
                  variant: 'destructive'
                }
              ]}
            />
          </div>
        )}
        
        {activeTab === 'wifi' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h3 className="text-xl font-semibold text-white">WiFi Network Management</h3>
              <Button variant="neon" onClick={() => setShowWiFiModal(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Create WiFi Network
              </Button>
            </div>
            
            <TableCard
              title="WiFi Networks"
              description="Manage wireless network configurations"
              data={wifiNetworks}
              columns={wifiColumns}
              loading={loading}
              actions={[
                {
                  label: (network: WiFiNetwork) => network.is_enabled ? 'Disable' : 'Enable',
                  onClick: (network: WiFiNetwork) => toggleWiFiNetwork(network.id, !network.is_enabled),
                  variant: 'outline'
                },
                {
                  label: 'Edit',
                  onClick: (network: WiFiNetwork) => console.log('Edit network:', network),
                  variant: 'outline'
                },
                {
                  label: 'Delete',
                  onClick: (network: WiFiNetwork) => deleteWiFiNetwork(network.id),
                  variant: 'destructive'
                }
              ]}
            />
          </div>
        )}
        
        {activeTab === 'vlan' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h3 className="text-xl font-semibold text-white">VLAN Management</h3>
              <Button variant="neon" onClick={() => setShowVLANModal(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Create VLAN
              </Button>
            </div>
            
            <TableCard
              title="Virtual LANs"
              description="Manage VLAN segmentation and routing policies"
              data={vlans}
              columns={vlanColumns}
              loading={loading}
              actions={[
                {
                  label: 'Edit',
                  onClick: (vlan: VLAN) => console.log('Edit VLAN:', vlan),
                  variant: 'outline'
                },
                {
                  label: 'Delete',
                  onClick: (vlan: VLAN) => console.log('Delete VLAN:', vlan),
                  variant: 'destructive'
                }
              ]}
            />
          </div>
        )}
        
        {activeTab === 'monitoring' && (
          <div className="space-y-6">
            <h3 className="text-xl font-semibold text-white">Network Monitoring</h3>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Network Status Components</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {networkStatus?.map((component: any) => (
                      <div key={component.id} className="flex items-center justify-between p-3 bg-gray-800/50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <div className={cn(
                            'w-2 h-2 rounded-full',
                            component.status === 'healthy' ? 'bg-green-500' :
                            component.status === 'warning' ? 'bg-yellow-500' :
                            'bg-red-500'
                          )} />
                          <span className="text-white font-medium capitalize">{component.component}</span>
                        </div>
                        <div className="text-right">
                          <div className={cn(
                            'text-sm font-medium',
                            component.status === 'healthy' ? 'text-green-400' :
                            component.status === 'warning' ? 'text-yellow-400' :
                            'text-red-400'
                          )}>
                            {component.status}
                          </div>
                          {component.response_time_ms && (
                            <div className="text-xs text-gray-400">
                              {component.response_time_ms}ms
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Network Tools</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Button 
                    variant="outline" 
                    className="w-full justify-start"
                    onClick={performNetworkScan}
                    loading={loading}
                  >
                    <Search className="h-4 w-4 mr-2" />
                    Perform Device Discovery Scan
                  </Button>
                  
                  <Button 
                    variant="outline" 
                    className="w-full justify-start"
                    onClick={() => addNotification({ type: 'info', message: 'Bandwidth test started' })}
                  >
                    <Zap className="h-4 w-4 mr-2" />
                    Run Bandwidth Test
                  </Button>
                  
                  <Button 
                    variant="outline" 
                    className="w-full justify-start"
                    onClick={() => addNotification({ type: 'info', message: 'Network diagnostics started' })}
                  >
                    <Shield className="h-4 w-4 mr-2" />
                    Network Diagnostics
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        )}
      </div>

      {/* DHCP Pool Modal */}
      <Modal
        isOpen={showDHCPPoolModal}
        onClose={() => {
          setShowDHCPPoolModal(false)
          setEditingDHCPPool(null)
          resetDHCPPoolForm()
        }}
        title={editingDHCPPool ? 'Edit DHCP Pool' : 'Create DHCP Pool'}
        description="Configure DHCP address pool settings"
        size="lg"
      >
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Pool Name
              </label>
              <input
                type="text"
                value={dhcpPoolForm.name}
                onChange={(e) => setDHCPPoolForm({...dhcpPoolForm, name: e.target.value})}
                className="input-field"
                placeholder="Main Network"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                VLAN ID
              </label>
              <input
                type="number"
                value={dhcpPoolForm.vlanId}
                onChange={(e) => setDHCPPoolForm({...dhcpPoolForm, vlanId: parseInt(e.target.value)})}
                className="input-field"
                min="1"
                max="4094"
              />
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Description
            </label>
            <textarea
              value={dhcpPoolForm.description}
              onChange={(e) => setDHCPPoolForm({...dhcpPoolForm, description: e.target.value})}
              className="input-field"
              rows={2}
              placeholder="Pool description"
            />
          </div>
          
          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Network CIDR
              </label>
              <input
                type="text"
                value={dhcpPoolForm.networkCidr}
                onChange={(e) => setDHCPPoolForm({...dhcpPoolForm, networkCidr: e.target.value})}
                className="input-field"
                placeholder="192.168.1.0/24"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Start IP
              </label>
              <input
                type="text"
                value={dhcpPoolForm.startIp}
                onChange={(e) => setDHCPPoolForm({...dhcpPoolForm, startIp: e.target.value})}
                className="input-field"
                placeholder="192.168.1.100"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                End IP
              </label>
              <input
                type="text"
                value={dhcpPoolForm.endIp}
                onChange={(e) => setDHCPPoolForm({...dhcpPoolForm, endIp: e.target.value})}
                className="input-field"
                placeholder="192.168.1.200"
              />
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Gateway IP
              </label>
              <input
                type="text"
                value={dhcpPoolForm.gatewayIp}
                onChange={(e) => setDHCPPoolForm({...dhcpPoolForm, gatewayIp: e.target.value})}
                className="input-field"
                placeholder="192.168.1.1"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Lease Time (hours)
              </label>
              <input
                type="number"
                value={dhcpPoolForm.leaseTimeHours}
                onChange={(e) => setDHCPPoolForm({...dhcpPoolForm, leaseTimeHours: parseInt(e.target.value)})}
                className="input-field"
                min="1"
                max="8760"
              />
            </div>
          </div>
          
          <div className="flex justify-end space-x-3 pt-4">
            <Button 
              variant="outline" 
              onClick={() => {
                setShowDHCPPoolModal(false)
                setEditingDHCPPool(null)
                resetDHCPPoolForm()
              }}
            >
              Cancel
            </Button>
            <Button 
              variant="neon" 
              onClick={editingDHCPPool ? updateDHCPPool : createDHCPPool}
              loading={loading}
            >
              {editingDHCPPool ? 'Update Pool' : 'Create Pool'}
            </Button>
          </div>
        </div>
      </Modal>

      {/* WiFi Network Modal */}
      <Modal
        isOpen={showWiFiModal}
        onClose={() => {
          setShowWiFiModal(false)
          resetWiFiForm()
        }}
        title="Create WiFi Network"
        description="Configure a new wireless network"
        size="lg"
      >
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Network Name (SSID)
              </label>
              <input
                type="text"
                value={wifiForm.ssid}
                onChange={(e) => setWiFiForm({...wifiForm, ssid: e.target.value})}
                className="input-field"
                placeholder="My-WiFi-Network"
                maxLength={32}
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Frequency Band
              </label>
              <select
                value={wifiForm.frequencyBand}
                onChange={(e) => setWiFiForm({...wifiForm, frequencyBand: e.target.value})}
                className="input-field"
              >
                <option value="2.4GHz">2.4GHz</option>
                <option value="5GHz">5GHz</option>
                <option value="dual">Dual Band</option>
              </select>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Security Type
              </label>
              <select
                value={wifiForm.securityType}
                onChange={(e) => setWiFiForm({...wifiForm, securityType: e.target.value})}
                className="input-field"
              >
                <option value="open">Open (No Security)</option>
                <option value="wep">WEP</option>
                <option value="wpa">WPA</option>
                <option value="wpa2">WPA2</option>
                <option value="wpa3">WPA3</option>
                <option value="wpa2-wpa3">WPA2/WPA3 Mixed</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Password
              </label>
              <input
                type="password"
                value={wifiForm.password}
                onChange={(e) => setWiFiForm({...wifiForm, password: e.target.value})}
                className="input-field"
                placeholder="Network password"
                disabled={wifiForm.securityType === 'open'}
              />
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Max Clients
              </label>
              <input
                type="number"
                value={wifiForm.maxClients}
                onChange={(e) => setWiFiForm({...wifiForm, maxClients: parseInt(e.target.value)})}
                className="input-field"
                min="1"
                max="255"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                TX Power (dBm)
              </label>
              <input
                type="number"
                value={wifiForm.txPowerDbm}
                onChange={(e) => setWiFiForm({...wifiForm, txPowerDbm: parseInt(e.target.value)})}
                className="input-field"
                min="1"
                max="30"
              />
            </div>
          </div>
          
          <div className="space-y-3">
            <div className="flex items-center space-x-3">
              <input
                type="checkbox"
                id="hidden"
                checked={wifiForm.hidden}
                onChange={(e) => setWiFiForm({...wifiForm, hidden: e.target.checked})}
                className="checkbox"
              />
              <label htmlFor="hidden" className="text-gray-300">
                Hidden network (don't broadcast SSID)
              </label>
            </div>
            
            <div className="flex items-center space-x-3">
              <input
                type="checkbox"
                id="guest-network"
                checked={wifiForm.isGuestNetwork}
                onChange={(e) => setWiFiForm({...wifiForm, isGuestNetwork: e.target.checked})}
                className="checkbox"
              />
              <label htmlFor="guest-network" className="text-gray-300">
                Guest network
              </label>
            </div>
            
            <div className="flex items-center space-x-3">
              <input
                type="checkbox"
                id="guest-isolation"
                checked={wifiForm.guestIsolation}
                onChange={(e) => setWiFiForm({...wifiForm, guestIsolation: e.target.checked})}
                className="checkbox"
                disabled={!wifiForm.isGuestNetwork}
              />
              <label htmlFor="guest-isolation" className="text-gray-300">
                Enable guest isolation
              </label>
            </div>
          </div>
          
          <div className="flex justify-end space-x-3 pt-4">
            <Button variant="outline" onClick={() => {
              setShowWiFiModal(false)
              resetWiFiForm()
            }}>
              Cancel
            </Button>
            <Button variant="neon" onClick={createWiFiNetwork} loading={loading}>
              Create Network
            </Button>
          </div>
        </div>
      </Modal>

      {/* VLAN Modal */}
      <Modal
        isOpen={showVLANModal}
        onClose={() => {
          setShowVLANModal(false)
          resetVLANForm()
        }}
        title="Create VLAN"
        description="Configure a new Virtual LAN"
        size="lg"
      >
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                VLAN ID
              </label>
              <input
                type="number"
                value={vlanForm.vlanId}
                onChange={(e) => setVLANForm({...vlanForm, vlanId: parseInt(e.target.value)})}
                className="input-field"
                min="1"
                max="4094"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                VLAN Name
              </label>
              <input
                type="text"
                value={vlanForm.vlanName}
                onChange={(e) => setVLANForm({...vlanForm, vlanName: e.target.value})}
                className="input-field"
                placeholder="Management"
              />
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Description
            </label>
            <textarea
              value={vlanForm.description}
              onChange={(e) => setVLANForm({...vlanForm, description: e.target.value})}
              className="input-field"
              rows={2}
              placeholder="VLAN description"
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Network CIDR
              </label>
              <input
                type="text"
                value={vlanForm.networkCidr}
                onChange={(e) => setVLANForm({...vlanForm, networkCidr: e.target.value})}
                className="input-field"
                placeholder="192.168.10.0/24"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Gateway IP
              </label>
              <input
                type="text"
                value={vlanForm.gatewayIp}
                onChange={(e) => setVLANForm({...vlanForm, gatewayIp: e.target.value})}
                className="input-field"
                placeholder="192.168.10.1"
              />
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              QoS Priority (0-7)
            </label>
            <input
              type="number"
              value={vlanForm.qosPriority}
              onChange={(e) => setVLANForm({...vlanForm, qosPriority: parseInt(e.target.value)})}
              className="input-field w-24"
              min="0"
              max="7"
            />
            <p className="text-xs text-gray-400 mt-1">
              Higher numbers indicate higher priority (7 = highest)
            </p>
          </div>
          
          <div className="space-y-3">
            <div className="flex items-center space-x-3">
              <input
                type="checkbox"
                id="dhcp-enabled"
                checked={vlanForm.dhcpEnabled}
                onChange={(e) => setVLANForm({...vlanForm, dhcpEnabled: e.target.checked})}
                className="checkbox"
              />
              <label htmlFor="dhcp-enabled" className="text-gray-300">
                Enable DHCP for this VLAN
              </label>
            </div>
            
            <div className="flex items-center space-x-3">
              <input
                type="checkbox"
                id="inter-vlan-routing"
                checked={vlanForm.interVlanRouting}
                onChange={(e) => setVLANForm({...vlanForm, interVlanRouting: e.target.checked})}
                className="checkbox"
              />
              <label htmlFor="inter-vlan-routing" className="text-gray-300">
                Enable inter-VLAN routing
              </label>
            </div>
          </div>
          
          <div className="flex justify-end space-x-3 pt-4">
            <Button variant="outline" onClick={() => {
              setShowVLANModal(false)
              resetVLANForm()
            }}>
              Cancel
            </Button>
            <Button variant="neon" onClick={createVLAN} loading={loading}>
              Create VLAN
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  )
}

export default ComprehensiveNetworkManagement