import React, { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import {
  Settings as SettingsIcon,
  User,
  Shield,
  Bell,
  Key,
  Database,
  Download,
  Upload,
  RefreshCw,
  Save,
  Eye,
  EyeOff,
  Copy,
  FileText,
  HelpCircle,
  BookOpen,
  Terminal,
  Monitor,
  Zap,
  Users,
  Lock,
  Trash2,
  Plus,
  Edit,
  AlertTriangle,
  CheckCircle,
  Clock
} from 'lucide-react'
import { useUIStore } from '@/lib/store'
import { Button } from '@/components/ui/button'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card'
import MetricCard from '@/components/ui/metric-card'
import Modal from '@/components/ui/modal'
import QuickSetup from '@/components/ui/quick-setup'
import { cn } from '@/lib/utils'
import { supabase } from '@/lib/supabase'

interface User {
  id: string
  email: string
  role: string
  created_at: string
  last_sign_in_at?: string
  email_confirmed_at?: string
}

interface Backup {
  id: string
  backup_name: string
  backup_type: string
  file_size_bytes: number
  status: string
  created_at: string
}

interface ApiKey {
  id: string
  keyName: string
  permissions: string[]
  lastUsed?: string
  expiresAt: string
  isActive: boolean
  createdAt: string
}

const EnhancedSettingsTabs: React.FC = () => {
  const { addNotification } = useUIStore()
  const [loading, setLoading] = useState(false)
  const [activeTab, setActiveTab] = useState('quick-setup')
  
  // System Settings State
  const [systemSettings, setSystemSettings] = useState({
    hostname: 'pi5-supernode',
    timezone: 'UTC',
    ntp_enabled: true,
    auto_updates: true,
    dns_servers: ['1.1.1.1', '8.8.8.8'],
    domain_name: 'local.lan'
  })
  
  // Security Settings State
  const [securitySettings, setSecuritySettings] = useState({
    firewall_enabled: true,
    ssh_enabled: true,
    ssh_port: 22,
    fail2ban_enabled: true,
    session_timeout: 3600,
    password_policy: {
      min_length: 8,
      require_uppercase: true,
      require_numbers: true,
      require_symbols: false
    }
  })
  
  // User Management State
  const [users, setUsers] = useState<User[]>([])
  const [showUserModal, setShowUserModal] = useState(false)
  const [editingUser, setEditingUser] = useState<User | null>(null)
  const [userForm, setUserForm] = useState({
    email: '',
    password: '',
    role: 'user'
  })
  
  // Backup Management State
  const [backups, setBackups] = useState<Backup[]>([])
  const [showBackupModal, setShowBackupModal] = useState(false)
  const [backupForm, setBackupForm] = useState({
    backupName: '',
    backupType: 'manual',
    includeUserData: true,
    includeConfiguration: true,
    includeDatabase: true
  })
  
  // API Key Management State
  const [apiKeys, setApiKeys] = useState<ApiKey[]>([])
  const [showApiKeyModal, setShowApiKeyModal] = useState(false)
  const [newApiKey, setNewApiKey] = useState<string | null>(null)
  const [showApiKey, setShowApiKey] = useState(false)
  const [apiKeyForm, setApiKeyForm] = useState({
    keyName: '',
    permissions: [] as string[]
  })
  
  // System Info State
  const [systemInfo, setSystemInfo] = useState<any>(null)

  useEffect(() => {
    loadAllData()
  }, [])

  const loadAllData = async () => {
    setLoading(true)
    try {
      await Promise.all([
        loadSystemSettings(),
        loadSecuritySettings(),
        loadUsers(),
        loadBackups(),
        loadApiKeys(),
        loadSystemInfo()
      ])
    } catch (error) {
      console.error('Error loading data:', error)
      addNotification({ type: 'error', message: 'Failed to load settings data' })
    } finally {
      setLoading(false)
    }
  }

  const loadSystemSettings = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('comprehensive-settings-management', {
        body: { action: 'get_system_settings' }
      })
      
      if (error) throw error
      if (data?.data?.settings) {
        setSystemSettings(prev => ({ ...prev, ...data.data.settings }))
      }
    } catch (error) {
      console.error('Error loading system settings:', error)
    }
  }

  const loadSecuritySettings = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('comprehensive-settings-management', {
        body: { action: 'get_security_settings' }
      })
      
      if (error) throw error
      if (data?.data?.settings) {
        setSecuritySettings(prev => ({ ...prev, ...data.data.settings }))
      }
    } catch (error) {
      console.error('Error loading security settings:', error)
    }
  }

  const loadUsers = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('comprehensive-settings-management', {
        body: { action: 'get_users' }
      })
      
      if (error) throw error
      setUsers(data?.data?.users || [])
    } catch (error) {
      console.error('Error loading users:', error)
    }
  }

  const loadBackups = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('comprehensive-settings-management', {
        body: { action: 'get_backups' }
      })
      
      if (error) throw error
      setBackups(data?.data?.backups || [])
    } catch (error) {
      console.error('Error loading backups:', error)
    }
  }

  const loadApiKeys = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('comprehensive-settings-management', {
        body: { action: 'get_api_keys' }
      })
      
      if (error) throw error
      setApiKeys(data?.data?.apiKeys || [])
    } catch (error) {
      console.error('Error loading API keys:', error)
    }
  }

  const loadSystemInfo = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('comprehensive-settings-management', {
        body: { action: 'get_system_info' }
      })
      
      if (error) throw error
      setSystemInfo(data?.data?.systemInfo || null)
    } catch (error) {
      console.error('Error loading system info:', error)
    }
  }

  const saveSystemSettings = async () => {
    try {
      setLoading(true)
      const { data, error } = await supabase.functions.invoke('comprehensive-settings-management', {
        body: { 
          action: 'update_system_settings',
          settings: systemSettings
        }
      })
      
      if (error) throw error
      addNotification({ type: 'success', message: 'System settings saved successfully' })
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to save system settings' })
    } finally {
      setLoading(false)
    }
  }

  const saveSecuritySettings = async () => {
    try {
      setLoading(true)
      const { data, error } = await supabase.functions.invoke('comprehensive-settings-management', {
        body: { 
          action: 'update_security_settings',
          settings: securitySettings
        }
      })
      
      if (error) throw error
      addNotification({ type: 'success', message: 'Security settings saved successfully' })
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to save security settings' })
    } finally {
      setLoading(false)
    }
  }

  const createUser = async () => {
    try {
      setLoading(true)
      const { data, error } = await supabase.functions.invoke('comprehensive-settings-management', {
        body: { 
          action: 'create_user',
          ...userForm
        }
      })
      
      if (error) throw error
      addNotification({ type: 'success', message: 'User created successfully' })
      setShowUserModal(false)
      setUserForm({ email: '', password: '', role: 'user' })
      await loadUsers()
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to create user' })
    } finally {
      setLoading(false)
    }
  }

  const deleteUser = async (userId: string) => {
    if (!confirm('Are you sure you want to delete this user?')) return
    
    try {
      setLoading(true)
      const { data, error } = await supabase.functions.invoke('comprehensive-settings-management', {
        body: { 
          action: 'delete_user',
          userId
        }
      })
      
      if (error) throw error
      addNotification({ type: 'success', message: 'User deleted successfully' })
      await loadUsers()
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to delete user' })
    } finally {
      setLoading(false)
    }
  }

  const createBackup = async () => {
    try {
      setLoading(true)
      const { data, error } = await supabase.functions.invoke('comprehensive-settings-management', {
        body: { 
          action: 'create_backup',
          backupName: backupForm.backupName,
          backupType: backupForm.backupType,
          backupScope: {
            includeUserData: backupForm.includeUserData,
            includeConfiguration: backupForm.includeConfiguration,
            includeDatabase: backupForm.includeDatabase
          }
        }
      })
      
      if (error) throw error
      addNotification({ type: 'success', message: 'Backup created successfully' })
      setShowBackupModal(false)
      setBackupForm({
        backupName: '',
        backupType: 'manual',
        includeUserData: true,
        includeConfiguration: true,
        includeDatabase: true
      })
      await loadBackups()
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to create backup' })
    } finally {
      setLoading(false)
    }
  }

  const deleteBackup = async (backupId: string) => {
    if (!confirm('Are you sure you want to delete this backup?')) return
    
    try {
      setLoading(true)
      const { data, error } = await supabase.functions.invoke('comprehensive-settings-management', {
        body: { 
          action: 'delete_backup',
          backupId
        }
      })
      
      if (error) throw error
      addNotification({ type: 'success', message: 'Backup deleted successfully' })
      await loadBackups()
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to delete backup' })
    } finally {
      setLoading(false)
    }
  }

  const generateApiKey = async () => {
    try {
      setLoading(true)
      const { data, error } = await supabase.functions.invoke('comprehensive-settings-management', {
        body: { 
          action: 'generate_api_key',
          keyName: apiKeyForm.keyName,
          permissions: apiKeyForm.permissions
        }
      })
      
      if (error) throw error
      setNewApiKey(data?.data?.apiKey || '')
      addNotification({ type: 'success', message: 'API key generated successfully' })
      setApiKeyForm({ keyName: '', permissions: [] })
      await loadApiKeys()
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to generate API key' })
    } finally {
      setLoading(false)
    }
  }

  const revokeApiKey = async (keyId: string) => {
    if (!confirm('Are you sure you want to revoke this API key?')) return
    
    try {
      setLoading(true)
      const { data, error } = await supabase.functions.invoke('comprehensive-settings-management', {
        body: { 
          action: 'revoke_api_key',
          keyId
        }
      })
      
      if (error) throw error
      addNotification({ type: 'success', message: 'API key revoked successfully' })
      await loadApiKeys()
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to revoke API key' })
    } finally {
      setLoading(false)
    }
  }

  const restartSystem = async () => {
    if (!confirm('Are you sure you want to restart the system? This will cause a brief interruption of service.')) return
    
    try {
      setLoading(true)
      const { data, error } = await supabase.functions.invoke('comprehensive-settings-management', {
        body: { action: 'restart_system' }
      })
      
      if (error) throw error
      addNotification({ 
        type: 'warning', 
        message: 'System restart initiated. The system will be back online in approximately 2 minutes.' 
      })
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to restart system' })
    } finally {
      setLoading(false)
    }
  }

  const copyApiKey = () => {
    if (newApiKey) {
      navigator.clipboard.writeText(newApiKey)
      addNotification({ type: 'success', message: 'API key copied to clipboard' })
    }
  }

  const formatFileSize = (bytes: number) => {
    const sizes = ['Bytes', 'KB', 'MB', 'GB']
    if (bytes === 0) return '0 Bytes'
    const i = Math.floor(Math.log(bytes) / Math.log(1024))
    return Math.round(bytes / Math.pow(1024, i) * 100) / 100 + ' ' + sizes[i]
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString()
  }

  const tabs = [
    { id: 'quick-setup', label: 'Quick Setup', icon: Zap },
    { id: 'system', label: 'System', icon: SettingsIcon },
    { id: 'security', label: 'Security', icon: Shield },
    { id: 'users', label: 'User Management', icon: Users },
    { id: 'backup', label: 'Backup & Restore', icon: Database },
    { id: 'api', label: 'API Keys', icon: Key },
    { id: 'advanced', label: 'Advanced', icon: Terminal },
    { id: 'docs', label: 'Documentation', icon: FileText }
  ]

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">System Settings</h1>
          <p className="text-gray-400">Comprehensive system configuration and management</p>
        </div>
        
        <div className="flex items-center space-x-3">
          <Button
            variant="outline"
            onClick={loadAllData}
            loading={loading}
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          
          <Button 
            variant="destructive"
            onClick={restartSystem}
            disabled={loading}
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Restart System
          </Button>
        </div>
      </div>

      {/* System Overview Cards */}
      {systemInfo && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <MetricCard
            title="System Uptime"
            value={systemInfo.software?.uptime || 'Unknown'}
            subtitle="Since last restart"
            icon={Clock}
            color="success"
            loading={loading}
          />
          
          <MetricCard
            title="CPU Usage"
            value={`${systemInfo.performance?.cpuUsage || 0}%`}
            subtitle={`${systemInfo.hardware?.cores || 4} cores @ ${systemInfo.hardware?.cpu?.split('@')[1]?.trim() || '2.4GHz'}`}
            icon={Monitor}
            color={systemInfo.performance?.cpuUsage > 80 ? 'danger' : 'success'}
            loading={loading}
          />
          
          <MetricCard
            title="Memory Usage"
            value={`${systemInfo.performance?.memoryUsage || 0}%`}
            subtitle={systemInfo.hardware?.memory || '8GB RAM'}
            icon={Database}
            color={systemInfo.performance?.memoryUsage > 90 ? 'danger' : 'success'}
            loading={loading}
          />
          
          <MetricCard
            title="Storage Usage"
            value={`${systemInfo.performance?.diskUsage || 0}%`}
            subtitle={systemInfo.hardware?.storage || '256GB SSD'}
            icon={Database}
            color={systemInfo.performance?.diskUsage > 90 ? 'danger' : 'success'}
            loading={loading}
          />
        </div>
      )}

      {/* Tab Navigation */}
      <div className="flex space-x-1 glassmorphism-card bg-gray-800/30 p-1 rounded-lg w-fit">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={cn(
              'flex items-center space-x-2 px-4 py-2 rounded-md transition-all duration-200',
              activeTab === tab.id
                ? 'bg-enterprise-neon/20 text-enterprise-neon border border-enterprise-neon/30'
                : 'text-gray-400 hover:text-white hover:bg-white/5'
            )}
          >
            <tab.icon className="h-4 w-4" />
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {/* Tab Content */}
      <div className="space-y-6">
        {activeTab === 'quick-setup' && (
          <QuickSetup />
        )}
        
        {activeTab === 'system' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>General Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Hostname
                  </label>
                  <input
                    type="text"
                    value={systemSettings.hostname}
                    onChange={(e) => setSystemSettings(prev => ({ ...prev, hostname: e.target.value }))}
                    className="input-field"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Timezone
                  </label>
                  <select
                    value={systemSettings.timezone}
                    onChange={(e) => setSystemSettings(prev => ({ ...prev, timezone: e.target.value }))}
                    className="input-field"
                  >
                    <option value="UTC">UTC</option>
                    <option value="America/New_York">Eastern Time</option>
                    <option value="America/Chicago">Central Time</option>
                    <option value="America/Denver">Mountain Time</option>
                    <option value="America/Los_Angeles">Pacific Time</option>
                    <option value="Europe/London">London</option>
                    <option value="Europe/Paris">Paris</option>
                    <option value="Asia/Tokyo">Tokyo</option>
                  </select>
                </div>
                
                <div className="flex items-center space-x-3">
                  <input
                    type="checkbox"
                    id="auto-updates"
                    checked={systemSettings.auto_updates}
                    onChange={(e) => setSystemSettings(prev => ({ ...prev, auto_updates: e.target.checked }))}
                    className="checkbox"
                  />
                  <label htmlFor="auto-updates" className="text-gray-300">
                    Enable automatic system updates
                  </label>
                </div>
                
                <div className="flex items-center space-x-3">
                  <input
                    type="checkbox"
                    id="ntp-enabled"
                    checked={systemSettings.ntp_enabled}
                    onChange={(e) => setSystemSettings(prev => ({ ...prev, ntp_enabled: e.target.checked }))}
                    className="checkbox"
                  />
                  <label htmlFor="ntp-enabled" className="text-gray-300">
                    Enable Network Time Protocol (NTP)
                  </label>
                </div>
                
                <Button variant="neon" onClick={saveSystemSettings} loading={loading}>
                  <Save className="h-4 w-4 mr-2" />
                  Save System Settings
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Network Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Domain Name
                  </label>
                  <input
                    type="text"
                    value={systemSettings.domain_name}
                    onChange={(e) => setSystemSettings(prev => ({ ...prev, domain_name: e.target.value }))}
                    className="input-field"
                    placeholder="local.lan"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    DNS Servers
                  </label>
                  <div className="space-y-2">
                    {systemSettings.dns_servers.map((server, index) => (
                      <input
                        key={index}
                        type="text"
                        value={server}
                        onChange={(e) => {
                          const newServers = [...systemSettings.dns_servers]
                          newServers[index] = e.target.value
                          setSystemSettings(prev => ({ ...prev, dns_servers: newServers }))
                        }}
                        className="input-field"
                        placeholder="DNS Server"
                      />
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {activeTab === 'security' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Security Policies</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center space-x-3">
                  <input
                    type="checkbox"
                    id="firewall"
                    checked={securitySettings.firewall_enabled}
                    onChange={(e) => setSecuritySettings(prev => ({ ...prev, firewall_enabled: e.target.checked }))}
                    className="checkbox"
                  />
                  <label htmlFor="firewall" className="text-gray-300">
                    Enable firewall protection
                  </label>
                </div>
                
                <div className="flex items-center space-x-3">
                  <input
                    type="checkbox"
                    id="fail2ban"
                    checked={securitySettings.fail2ban_enabled}
                    onChange={(e) => setSecuritySettings(prev => ({ ...prev, fail2ban_enabled: e.target.checked }))}
                    className="checkbox"
                  />
                  <label htmlFor="fail2ban" className="text-gray-300">
                    Enable Fail2Ban intrusion prevention
                  </label>
                </div>
                
                <div className="flex items-center space-x-3">
                  <input
                    type="checkbox"
                    id="ssh-enabled"
                    checked={securitySettings.ssh_enabled}
                    onChange={(e) => setSecuritySettings(prev => ({ ...prev, ssh_enabled: e.target.checked }))}
                    className="checkbox"
                  />
                  <label htmlFor="ssh-enabled" className="text-gray-300">
                    Enable SSH access
                  </label>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    SSH Port
                  </label>
                  <input
                    type="number"
                    value={securitySettings.ssh_port}
                    onChange={(e) => setSecuritySettings(prev => ({ ...prev, ssh_port: parseInt(e.target.value) }))}
                    className="input-field w-32"
                    min="1"
                    max="65535"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Session Timeout (seconds)
                  </label>
                  <input
                    type="number"
                    value={securitySettings.session_timeout}
                    onChange={(e) => setSecuritySettings(prev => ({ ...prev, session_timeout: parseInt(e.target.value) }))}
                    className="input-field w-32"
                    min="300"
                  />
                </div>
                
                <Button variant="neon" onClick={saveSecuritySettings} loading={loading}>
                  <Save className="h-4 w-4 mr-2" />
                  Save Security Settings
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Password Policy</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Minimum Length
                  </label>
                  <input
                    type="number"
                    value={securitySettings.password_policy.min_length}
                    onChange={(e) => setSecuritySettings(prev => ({
                      ...prev,
                      password_policy: {
                        ...prev.password_policy,
                        min_length: parseInt(e.target.value)
                      }
                    }))}
                    className="input-field w-24"
                    min="6"
                    max="64"
                  />
                </div>
                
                <div className="space-y-3">
                  <div className="flex items-center space-x-3">
                    <input
                      type="checkbox"
                      id="require-uppercase"
                      checked={securitySettings.password_policy.require_uppercase}
                      onChange={(e) => setSecuritySettings(prev => ({
                        ...prev,
                        password_policy: {
                          ...prev.password_policy,
                          require_uppercase: e.target.checked
                        }
                      }))}
                      className="checkbox"
                    />
                    <label htmlFor="require-uppercase" className="text-gray-300">
                      Require uppercase letters
                    </label>
                  </div>
                  
                  <div className="flex items-center space-x-3">
                    <input
                      type="checkbox"
                      id="require-numbers"
                      checked={securitySettings.password_policy.require_numbers}
                      onChange={(e) => setSecuritySettings(prev => ({
                        ...prev,
                        password_policy: {
                          ...prev.password_policy,
                          require_numbers: e.target.checked
                        }
                      }))}
                      className="checkbox"
                    />
                    <label htmlFor="require-numbers" className="text-gray-300">
                      Require numbers
                    </label>
                  </div>
                  
                  <div className="flex items-center space-x-3">
                    <input
                      type="checkbox"
                      id="require-symbols"
                      checked={securitySettings.password_policy.require_symbols}
                      onChange={(e) => setSecuritySettings(prev => ({
                        ...prev,
                        password_policy: {
                          ...prev.password_policy,
                          require_symbols: e.target.checked
                        }
                      }))}
                      className="checkbox"
                    />
                    <label htmlFor="require-symbols" className="text-gray-300">
                      Require symbols
                    </label>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Continue with other tabs in the next part... */}
      </div>

      {/* Modals */}
      <Modal
        isOpen={showUserModal}
        onClose={() => setShowUserModal(false)}
        title="Create User"
        description="Add a new user to the system"
      >
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Email Address
            </label>
            <input
              type="email"
              value={userForm.email}
              onChange={(e) => setUserForm(prev => ({ ...prev, email: e.target.value }))}
              className="input-field"
              placeholder="user@example.com"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Password
            </label>
            <input
              type="password"
              value={userForm.password}
              onChange={(e) => setUserForm(prev => ({ ...prev, password: e.target.value }))}
              className="input-field"
              placeholder="Enter password"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Role
            </label>
            <select
              value={userForm.role}
              onChange={(e) => setUserForm(prev => ({ ...prev, role: e.target.value }))}
              className="input-field"
            >
              <option value="user">User</option>
              <option value="operator">Operator</option>
              <option value="admin">Administrator</option>
            </select>
          </div>
          
          <div className="flex justify-end space-x-3 pt-4">
            <Button variant="outline" onClick={() => setShowUserModal(false)}>
              Cancel
            </Button>
            <Button variant="neon" onClick={createUser} loading={loading}>
              Create User
            </Button>
          </div>
        </div>
      </Modal>

      {/* API Key Display Modal */}
      {newApiKey && (
        <Modal
          isOpen={!!newApiKey}
          onClose={() => setNewApiKey(null)}
          title="API Key Generated"
          description="Your new API key has been generated. Please copy and store it securely."
        >
          <div className="space-y-4">
            <div className="bg-gray-800 p-4 rounded-lg border border-gray-700">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <code className={cn(
                    'text-sm font-mono',
                    showApiKey ? 'text-enterprise-neon' : 'text-gray-500'
                  )}>
                    {showApiKey ? newApiKey : '••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••'}
                  </code>
                </div>
                <div className="flex items-center space-x-2 ml-4">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowApiKey(!showApiKey)}
                  >
                    {showApiKey ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={copyApiKey}
                  >
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
            
            <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-lg p-4">
              <div className="flex items-start space-x-3">
                <AlertTriangle className="h-5 w-5 text-yellow-500 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-yellow-500 font-medium">Important Security Notice</h4>
                  <p className="text-yellow-300/80 text-sm mt-1">
                    This API key will only be shown once. Please copy and store it in a secure location. 
                    You will not be able to view it again.
                  </p>
                </div>
              </div>
            </div>
            
            <div className="flex justify-end space-x-3 pt-4">
              <Button variant="neon" onClick={() => setNewApiKey(null)}>
                <CheckCircle className="h-4 w-4 mr-2" />
                I've Saved the Key
              </Button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  )
}

export default EnhancedSettingsTabs