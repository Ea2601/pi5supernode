import React from 'react'
import { motion } from 'framer-motion'
import { MoreHorizontal, Search, Filter } from 'lucide-react'
import { cn } from '@/lib/utils'
import { Card, CardHeader, CardTitle, CardContent } from './card'
import { Button } from './button'

export interface Column<T> {
  key: keyof T
  label: string
  sortable?: boolean
  width?: string
  render?: (value: any, item: T) => React.ReactNode
}

export interface TableCardProps<T> {
  title: string
  description?: string
  data: T[]
  columns: Column<T>[]
  loading?: boolean
  searchable?: boolean
  filterable?: boolean
  actions?: Array<{
    label: string | ((item: T) => string)
    icon?: React.ComponentType<{ className?: string }> | ((item: T) => React.ComponentType<any>)
    onClick: (item: T) => void
    variant?: 'default' | 'destructive' | 'outline' | 'secondary' | 'ghost' | 'neon'
  }>
  onRowClick?: (item: T) => void
  emptyMessage?: string
}

function TableCard<T extends Record<string, any>>({
  title,
  description,
  data,
  columns,
  loading = false,
  searchable = true,
  filterable = false,
  actions = [],
  onRowClick,
  emptyMessage = 'No data available'
}: TableCardProps<T>) {
  const [searchTerm, setSearchTerm] = React.useState('')
  const [sortConfig, setSortConfig] = React.useState<{
    key: keyof T
    direction: 'asc' | 'desc'
  } | null>(null)

  const filteredData = React.useMemo(() => {
    if (!searchTerm) return data
    
    return data.filter(item =>
      Object.values(item).some(value =>
        String(value).toLowerCase().includes(searchTerm.toLowerCase())
      )
    )
  }, [data, searchTerm])

  const sortedData = React.useMemo(() => {
    if (!sortConfig) return filteredData

    return [...filteredData].sort((a, b) => {
      const aValue = a[sortConfig.key]
      const bValue = b[sortConfig.key]

      if (aValue < bValue) {
        return sortConfig.direction === 'asc' ? -1 : 1
      }
      if (aValue > bValue) {
        return sortConfig.direction === 'asc' ? 1 : -1
      }
      return 0
    })
  }, [filteredData, sortConfig])

  const handleSort = (key: keyof T) => {
    let direction: 'asc' | 'desc' = 'asc'
    if (sortConfig && sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc'
    }
    setSortConfig({ key, direction })
  }

  return (
    <Card className="overflow-hidden">
      <CardHeader className="border-b border-white/10">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>{title}</CardTitle>
            {description && (
              <p className="text-sm text-gray-400 mt-1">{description}</p>
            )}
          </div>
          
          <div className="flex items-center space-x-2">
            {filterable && (
              <Button variant="outline" size="sm">
                <Filter className="h-4 w-4" />
              </Button>
            )}
            
            {searchable && (
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 pr-4 py-2 bg-gray-800 border border-gray-600 rounded-lg text-gray-100 placeholder-gray-400 focus:border-enterprise-neon focus:ring-enterprise-neon/20 focus:outline-none hover:bg-gray-700 transition-colors"
                />
              </div>
            )}
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="p-0">
        {loading ? (
          <div className="flex items-center justify-center p-12">
            <div className="animate-spin rounded-full h-8 w-8 border-2 border-enterprise-neon border-t-transparent" />
          </div>
        ) : sortedData.length === 0 ? (
          <div className="text-center p-12 text-gray-400">
            {emptyMessage}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-enterprise-slate-lighter/20">
                  {columns.map((column) => (
                    <th
                      key={String(column.key)}
                      className={cn(
                        'px-6 py-4 text-left text-xs font-medium text-gray-300 uppercase tracking-wider',
                        column.width,
                        column.sortable && 'cursor-pointer hover:text-enterprise-neon'
                      )}
                      onClick={() => column.sortable && handleSort(column.key)}
                    >
                      <div className="flex items-center space-x-1">
                        <span>{column.label}</span>
                        {column.sortable && sortConfig?.key === column.key && (
                          <span className="text-enterprise-neon">
                            {sortConfig.direction === 'asc' ? '↑' : '↓'}
                          </span>
                        )}
                      </div>
                    </th>
                  ))}
                  {actions.length > 0 && (
                    <th className="px-6 py-4 text-right text-xs font-medium text-gray-300 uppercase tracking-wider">
                      Actions
                    </th>
                  )}
                </tr>
              </thead>
              <tbody>
                {sortedData.map((item, index) => (
                  <motion.tr
                    key={index}
                    className={cn(
                      'border-b border-enterprise-slate-lighter/10 hover:bg-white/5 transition-colors',
                      onRowClick && 'cursor-pointer'
                    )}
                    onClick={() => onRowClick?.(item)}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.2, delay: index * 0.05 }}
                  >
                    {columns.map((column) => (
                      <td key={String(column.key)} className="px-6 py-4 whitespace-nowrap">
                        {column.render ? (
                          column.render(item[column.key], item)
                        ) : (
                          <span className="text-sm text-gray-300">
                            {String(item[column.key] || '-')}
                          </span>
                        )}
                      </td>
                    ))}
                    {actions.length > 0 && (
                      <td className="px-6 py-4 whitespace-nowrap text-right">
                        <div className="flex items-center justify-end space-x-2">
                          {actions.map((action, actionIndex) => {
                            const label = typeof action.label === 'function' ? action.label(item) : action.label
                            const IconComponent = action.icon ? (
                              typeof action.icon === 'function' ? (action.icon as any)(item) : action.icon
                            ) : null
                            
                            return (
                              <Button
                                key={actionIndex}
                                variant={action.variant || 'outline'}
                                size="sm"
                                onClick={(e) => {
                                  e.stopPropagation()
                                  action.onClick(item)
                                }}
                              >
                                {IconComponent && React.createElement(IconComponent as any, { className: "h-4 w-4 mr-1" })}
                                {label}
                              </Button>
                            )
                          })}
                        </div>
                      </td>
                    )}
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

export default TableCard