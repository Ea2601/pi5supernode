import React, { useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Bell,
  X,
  Check,
  AlertTriangle,
  AlertCircle,
  Info,
  Trash2,
  ExternalLink,
  RefreshCw
} from 'lucide-react'
import { Button } from './button'
import { Card, CardHeader, CardTitle, CardContent } from './card'
import { NotificationService, type Notification } from '@/lib/services/notificationService'
import { cn } from '@/lib/utils'

interface NotificationCenterProps {
  isOpen: boolean
  onClose: () => void
  onNotificationCountChange: (count: number) => void
}

const NotificationCenter: React.FC<NotificationCenterProps> = ({
  isOpen,
  onClose,
  onNotificationCountChange
}) => {
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [loading, setLoading] = useState(false)
  const [filter, setFilter] = useState<'all' | 'unread' | 'critical'>('all')

  useEffect(() => {
    if (isOpen) {
      loadNotifications()
    }
  }, [isOpen, filter])

  useEffect(() => {
    // Set up real-time subscription
    const subscription = NotificationService.subscribeToNotifications(
      (newNotification) => {
        setNotifications(prev => [newNotification, ...prev])
        onNotificationCountChange(notifications.filter(n => !n.is_read).length + 1)
      }
    )

    return () => {
      subscription.unsubscribe()
    }
  }, [notifications])

  const loadNotifications = async () => {
    try {
      setLoading(true)
      const options: any = { limit: 50 }
      
      if (filter === 'unread') {
        options.unreadOnly = true
      } else if (filter === 'critical') {
        options.severity = 'critical'
      }

      const { notifications: notifs } = await NotificationService.getNotifications(options)
      setNotifications(notifs)
      
      const unreadCount = notifs.filter(n => !n.is_read).length
      onNotificationCountChange(unreadCount)
    } catch (error) {
      console.error('Error loading notifications:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleMarkAsRead = async (notificationId: string) => {
    try {
      await NotificationService.markAsRead(notificationId)
      setNotifications(prev => 
        prev.map(n => n.id === notificationId ? { ...n, is_read: true } : n)
      )
      onNotificationCountChange(notifications.filter(n => !n.is_read && n.id !== notificationId).length)
    } catch (error) {
      console.error('Error marking notification as read:', error)
    }
  }

  const handleAcknowledge = async (notificationId: string) => {
    try {
      await NotificationService.acknowledge(notificationId, 'admin')
      setNotifications(prev => 
        prev.map(n => n.id === notificationId ? { ...n, is_acknowledged: true } : n)
      )
    } catch (error) {
      console.error('Error acknowledging notification:', error)
    }
  }

  const handleDelete = async (notificationId: string) => {
    try {
      await NotificationService.deleteNotification(notificationId)
      setNotifications(prev => prev.filter(n => n.id !== notificationId))
    } catch (error) {
      console.error('Error deleting notification:', error)
    }
  }

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'critical':
      case 'high':
        return <AlertTriangle className="h-4 w-4" />
      case 'medium':
      case 'low':
        return <AlertCircle className="h-4 w-4" />
      case 'info':
      default:
        return <Info className="h-4 w-4" />
    }
  }

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical':
        return 'text-red-500 border-red-200 bg-red-50'
      case 'high':
        return 'text-red-400 border-red-200 bg-red-50'
      case 'medium':
        return 'text-yellow-500 border-yellow-200 bg-yellow-50'
      case 'low':
        return 'text-yellow-400 border-yellow-200 bg-yellow-50'
      case 'info':
      default:
        return 'text-blue-500 border-blue-200 bg-blue-50'
    }
  }

  const formatTimeAgo = (timestamp: string) => {
    const now = new Date()
    const time = new Date(timestamp)
    const diffInMs = now.getTime() - time.getTime()
    const diffInMinutes = Math.floor(diffInMs / (1000 * 60))
    const diffInHours = Math.floor(diffInMinutes / 60)
    const diffInDays = Math.floor(diffInHours / 24)

    if (diffInDays > 0) return `${diffInDays}d ago`
    if (diffInHours > 0) return `${diffInHours}h ago`
    if (diffInMinutes > 0) return `${diffInMinutes}m ago`
    return 'Just now'
  }

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/20 z-40"
            onClick={onClose}
          />
          
          {/* Notification Panel */}
          <motion.div
            initial={{ opacity: 0, x: 400 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 400 }}
            className="fixed right-0 top-0 h-full w-96 bg-white shadow-2xl z-50 overflow-hidden"
          >
            <div className="flex flex-col h-full">
              {/* Header */}
              <div className="p-4 border-b border-gray-200">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Bell className="h-5 w-5 text-gray-600" />
                    <h2 className="text-lg font-semibold text-gray-900">Notifications</h2>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={loadNotifications}
                      disabled={loading}
                    >
                      <RefreshCw className={cn("h-4 w-4", loading && "animate-spin")} />
                    </Button>
                    <Button variant="outline" size="sm" onClick={onClose}>
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                
                {/* Filter Tabs */}
                <div className="flex space-x-1 mt-3">
                  <button
                    onClick={() => setFilter('all')}
                    className={cn(
                      "px-3 py-1 text-sm rounded-md transition-colors",
                      filter === 'all'
                        ? "bg-blue-100 text-blue-700"
                        : "text-gray-600 hover:bg-gray-100"
                    )}
                  >
                    All
                  </button>
                  <button
                    onClick={() => setFilter('unread')}
                    className={cn(
                      "px-3 py-1 text-sm rounded-md transition-colors",
                      filter === 'unread'
                        ? "bg-blue-100 text-blue-700"
                        : "text-gray-600 hover:bg-gray-100"
                    )}
                  >
                    Unread
                  </button>
                  <button
                    onClick={() => setFilter('critical')}
                    className={cn(
                      "px-3 py-1 text-sm rounded-md transition-colors",
                      filter === 'critical'
                        ? "bg-blue-100 text-blue-700"
                        : "text-gray-600 hover:bg-gray-100"
                    )}
                  >
                    Critical
                  </button>
                </div>
              </div>

              {/* Notifications List */}
              <div className="flex-1 overflow-y-auto">
                {loading ? (
                  <div className="p-4 text-center">
                    <RefreshCw className="h-6 w-6 animate-spin mx-auto text-gray-400" />
                    <p className="text-gray-500 mt-2">Loading notifications...</p>
                  </div>
                ) : notifications.length === 0 ? (
                  <div className="p-4 text-center">
                    <Bell className="h-12 w-12 mx-auto text-gray-300" />
                    <p className="text-gray-500 mt-2">No notifications</p>
                  </div>
                ) : (
                  <div className="divide-y divide-gray-200">
                    {notifications.map((notification) => (
                      <motion.div
                        key={notification.id}
                        layout
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -20 }}
                        className={cn(
                          "p-4 hover:bg-gray-50 transition-colors",
                          !notification.is_read && "bg-blue-50 border-l-4 border-blue-400"
                        )}
                      >
                        <div className="flex items-start space-x-3">
                          <div className={cn(
                            "flex items-center justify-center w-8 h-8 rounded-full",
                            getSeverityColor(notification.severity)
                          )}>
                            {getSeverityIcon(notification.severity)}
                          </div>
                          
                          <div className="flex-1 min-w-0">
                            <div className="flex items-start justify-between">
                              <h3 className="text-sm font-medium text-gray-900 truncate">
                                {notification.title}
                              </h3>
                              <span className="text-xs text-gray-500 ml-2">
                                {formatTimeAgo(notification.created_at)}
                              </span>
                            </div>
                            
                            <p className="text-sm text-gray-600 mt-1">
                              {notification.message}
                            </p>
                            
                            {/* Action Buttons */}
                            {notification.action_buttons && notification.action_buttons.length > 0 && (
                              <div className="flex space-x-2 mt-2">
                                {notification.action_buttons.map((button, index) => (
                                  <Button
                                    key={index}
                                    variant={button.variant as any || "outline"}
                                    size="sm"
                                    onClick={() => {
                                      // Handle button action
                                      console.log('Action:', button.action)
                                    }}
                                  >
                                    {button.label}
                                  </Button>
                                ))}
                              </div>
                            )}
                            
                            {/* Quick Actions */}
                            <div className="flex items-center space-x-2 mt-2">
                              {!notification.is_read && (
                                <button
                                  onClick={() => handleMarkAsRead(notification.id)}
                                  className="text-xs text-blue-600 hover:text-blue-700 flex items-center space-x-1"
                                >
                                  <Check className="h-3 w-3" />
                                  <span>Mark Read</span>
                                </button>
                              )}
                              
                              {notification.severity === 'critical' && !notification.is_acknowledged && (
                                <button
                                  onClick={() => handleAcknowledge(notification.id)}
                                  className="text-xs text-green-600 hover:text-green-700 flex items-center space-x-1"
                                >
                                  <Check className="h-3 w-3" />
                                  <span>Acknowledge</span>
                                </button>
                              )}
                              
                              {notification.action_url && (
                                <a
                                  href={notification.action_url}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="text-xs text-blue-600 hover:text-blue-700 flex items-center space-x-1"
                                >
                                  <ExternalLink className="h-3 w-3" />
                                  <span>View</span>
                                </a>
                              )}
                              
                              <button
                                onClick={() => handleDelete(notification.id)}
                                className="text-xs text-red-600 hover:text-red-700 flex items-center space-x-1"
                              >
                                <Trash2 className="h-3 w-3" />
                                <span>Delete</span>
                              </button>
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  )
}

export default NotificationCenter