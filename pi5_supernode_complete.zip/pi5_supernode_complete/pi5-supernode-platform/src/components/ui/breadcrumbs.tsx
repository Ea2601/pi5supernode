import React from 'react'
import { useLocation, Link } from 'react-router-dom'
import { ChevronRight, Home } from 'lucide-react'
import { cn } from '@/lib/utils'

interface BreadcrumbItem {
  label: string
  path: string
  isActive: boolean
}

interface BreadcrumbProps {
  className?: string
}

// Route mappings for cleaner breadcrumb labels
const routeLabels: Record<string, string> = {
  '': 'Home',
  'dashboard': 'Dashboard',
  'speed-testing': 'Speed Testing',
  'traffic-rules': 'Traffic Rules',
  'network-management': 'Network Management',
  'dhcp': 'DHCP',
  'wifi': 'WiFi',
  'vlans': 'VLANs',
  'wan-settings': 'WAN Settings',
  'vpn-management': 'VPN Management',
  'automations': 'Automations',
  'settings': 'Settings',
  'system': 'System',
  'security': 'Security',
  'backup': 'Backup',
  'users': 'Users',
  'advanced': 'Advanced'
}

const Breadcrumbs: React.FC<BreadcrumbProps> = ({ className }) => {
  const location = useLocation()
  
  // Generate breadcrumb items from current path
  const generateBreadcrumbs = (): BreadcrumbItem[] => {
    const pathSegments = location.pathname.split('/').filter(Boolean)
    const breadcrumbs: BreadcrumbItem[] = []
    
    // Add home/dashboard as root
    breadcrumbs.push({
      label: 'Dashboard',
      path: '/dashboard',
      isActive: pathSegments.length === 0 || pathSegments[0] === 'dashboard'
    })
    
    // Build breadcrumbs for each path segment
    let currentPath = ''
    pathSegments.forEach((segment, index) => {
      currentPath += `/${segment}`
      const isActive = index === pathSegments.length - 1
      
      // Skip dashboard since it's already added as root
      if (segment === 'dashboard') return
      
      breadcrumbs.push({
        label: routeLabels[segment] || segment.charAt(0).toUpperCase() + segment.slice(1),
        path: currentPath,
        isActive
      })
    })
    
    return breadcrumbs
  }
  
  const breadcrumbs = generateBreadcrumbs()
  
  // Don't show breadcrumbs for dashboard only
  if (breadcrumbs.length <= 1) {
    return null
  }
  
  return (
    <nav className={cn('flex items-center space-x-1 text-sm', className)} aria-label="Breadcrumb">
      <Home className="h-4 w-4 text-gray-400" />
      
      {breadcrumbs.map((item, index) => (
        <div key={item.path} className="flex items-center space-x-1">
          {index > 0 && (
            <ChevronRight className="h-4 w-4 text-gray-500" />
          )}
          
          {item.isActive ? (
            <span className="text-enterprise-neon font-medium">
              {item.label}
            </span>
          ) : (
            <Link
              to={item.path}
              className="text-gray-400 hover:text-enterprise-neon transition-colors hover:underline"
            >
              {item.label}
            </Link>
          )}
        </div>
      ))}
    </nav>
  )
}

export default Breadcrumbs