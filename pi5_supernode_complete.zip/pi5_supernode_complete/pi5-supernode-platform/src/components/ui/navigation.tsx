import React from 'react'
import { NavLink, useLocation } from 'react-router-dom'
import { motion } from 'framer-motion'
import {
  LayoutDashboard,
  Zap,
  Shield,
  Network,
  Cog,
  Settings,
  ChevronLeft,
  ChevronRight,
  Activity,
  User,
  Globe,
  Router,
  Layers,
  X,
  Monitor,
  Server,
  HardDrive,
  Eye,
  BookOpen
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { useUIStore } from '@/lib/store'
import { Button } from './button'

interface NavigationItem {
  id: string
  label: string
  icon: React.ComponentType<{ className?: string }>
  path: string
  badge?: string
}

const navigationItems: NavigationItem[] = [
  {
    id: 'dashboard',
    label: 'Dashboard',
    icon: LayoutDashboard,
    path: '/dashboard'
  },
  {
    id: 'speed-testing',
    label: 'Speed Testing',
    icon: Zap,
    path: '/speed-testing'
  },
  {
    id: 'network',
    label: 'Network',
    icon: Network,
    path: '/network'
  },
  {
    id: 'devices',
    label: 'Devices',
    icon: Monitor,
    path: '/devices'
  },
  {
    id: 'traffic-rules',
    label: 'Traffic Rules',
    icon: Shield,
    path: '/traffic-rules'
  },

  {
    id: 'wan-settings',
    label: 'WAN Settings',
    icon: Globe,
    path: '/wan-settings'
  },
  {
    id: 'vpn-management',
    label: 'VPN Management',
    icon: Router,
    path: '/vpn-management'
  },
  {
    id: 'observability',
    label: 'Observability',
    icon: Eye,
    path: '/observability'
  },
  {
    id: 'storage',
    label: 'Storage',
    icon: HardDrive,
    path: '/storage'
  },
  {
    id: 'automations',
    label: 'Automations',
    icon: Cog,
    path: '/automations'
  },
  {
    id: 'documentation',
    label: 'Documentation',
    icon: BookOpen,
    path: '/documentation'
  },
  {
    id: 'settings',
    label: 'Settings',
    icon: Settings,
    path: '/settings'
  }
]

export interface NavigationProps {
  className?: string
  onMobileClose?: () => void
}

const Navigation: React.FC<NavigationProps> = ({ className, onMobileClose }) => {
  const { sidebarCollapsed, setSidebarCollapsed } = useUIStore()
  const location = useLocation()

  const isRouteActive = (path: string) => {
    if (path === '/dashboard') return location.pathname === '/dashboard' || location.pathname === '/'
    return location.pathname.startsWith(path)
  }

  const handleNavClick = () => {
    if (onMobileClose) {
      onMobileClose()
    }
  }

  return (
    <motion.aside
      className={cn(
        'glassmorphism border-r border-white/10 flex flex-col h-screen sticky top-0 transition-all duration-300',
        // Mobile styles
        'md:relative md:translate-x-0',
        // Desktop styles
        sidebarCollapsed ? 'md:w-16' : 'md:w-64',
        className
      )}
      initial={false}
      animate={{ width: sidebarCollapsed ? 64 : 256 }}
    >
      {/* Header */}
      <div className="p-4 border-b border-white/10">
        <div className="flex items-center justify-between">
          {/* Mobile close button */}
          {onMobileClose && (
            <Button
              variant="ghost"
              size="icon"
              onClick={onMobileClose}
              className="text-gray-400 hover:text-phosphor-turquoise md:hidden touch-target"
            >
              <X className="h-5 w-5" />
            </Button>
          )}
          
          {/* Logo and title - always show on mobile, conditional on desktop */}
          {(onMobileClose || !sidebarCollapsed) && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex items-center space-x-2"
            >
              <div className="w-8 h-8 bg-gradient-to-r from-phosphor-turquoise to-phosphor-blue rounded-lg flex items-center justify-center">
                <Activity className="h-5 w-5 text-phosphor-dark" />
              </div>
              <div>
                <h2 className="text-sm font-semibold text-white">Pi5 Supernode</h2>
                <p className="text-xs text-gray-400">Enterprise Network</p>
              </div>
            </motion.div>
          )}
          
          {/* Desktop collapse button */}
          {!onMobileClose && (
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
              className="text-gray-400 hover:text-phosphor-turquoise hidden md:flex touch-target"
            >
              {sidebarCollapsed ? (
                <ChevronRight className="h-4 w-4" />
              ) : (
                <ChevronLeft className="h-4 w-4" />
              )}
            </Button>
          )}
        </div>
      </div>

      {/* Navigation Items */}
      <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
        {navigationItems.map((item) => {
          const Icon = item.icon
          const isActive = isRouteActive(item.path)
          
          return (
            <NavLink
              key={item.id}
              to={item.path}
              onClick={handleNavClick}
              className={({ isActive: navLinkActive }) => cn(
                'w-full sidebar-item touch-target',
                (isActive || navLinkActive) && 'active'
              )}
            >
              {({ isActive: navLinkActive }) => (
                <motion.div
                  className="flex items-center space-x-3 w-full"
                  whileHover={{ x: 2 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <Icon className={cn(
                    'h-5 w-5 transition-colors flex-shrink-0',
                    (isActive || navLinkActive) ? 'text-enterprise-neon' : 'text-gray-400 group-hover:text-enterprise-neon'
                  )} />
                  
                  {/* Always show text on mobile, conditional on desktop */}
                  {(onMobileClose || !sidebarCollapsed) && (
                    <motion.span
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      className={cn(
                        'text-sm font-medium transition-colors',
                        (isActive || navLinkActive) ? 'text-enterprise-neon' : 'text-gray-300 group-hover:text-white'
                      )}
                    >
                      {item.label}
                    </motion.span>
                  )}
                  
                  {item.badge && (onMobileClose || !sidebarCollapsed) && (
                    <span className="ml-auto bg-enterprise-neon text-enterprise-dark text-xs px-2 py-1 rounded-full">
                      {item.badge}
                    </span>
                  )}
                </motion.div>
              )}
            </NavLink>
          )
        })}
      </nav>

      {/* Footer */}
      <div className="p-4 border-t border-white/10">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-gradient-to-r from-gray-600 to-gray-500 rounded-full flex items-center justify-center flex-shrink-0">
            <User className="h-4 w-4 text-white" />
          </div>
          
          {(onMobileClose || !sidebarCollapsed) && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex-1 min-w-0"
            >
              <p className="text-sm font-medium text-white truncate">Admin User</p>
              <p className="text-xs text-gray-400 truncate">admin@pi5-supernode</p>
            </motion.div>
          )}
        </div>
      </div>
    </motion.aside>
  )
}

export default Navigation