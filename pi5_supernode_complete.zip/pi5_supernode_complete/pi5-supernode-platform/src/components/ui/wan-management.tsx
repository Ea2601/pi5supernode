import React, { useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Globe,
  Wifi,
  Router,
  Zap,
  Plus,
  Settings,
  Edit,
  Trash2,
  Play,
  Pause,
  RefreshCw,
  CheckCircle,
  AlertTriangle,
  XCircle,
  Clock,
  TrendingUp,
  Activity,
  Signal,
  Monitor,
  Shield,
  BarChart3
} from 'lucide-react'
import { Card, CardHeader, CardTitle, CardContent } from './card'
import { Button } from './button'
import Modal from './modal'
import { supabase } from '@/lib/supabase'
import { cn } from '@/lib/utils'

interface ConnectionType {
  id: string
  type_name: string
  display_name: string
  description: string
  requires_authentication: boolean
  supports_cellular: boolean
  supports_static_ip: boolean
  supports_dhcp: boolean
  default_mtu: number
  configuration_template: any
}

interface WANConnection {
  id: string
  connection_name: string
  connection_type: string
  interface_name: string
  is_primary: boolean
  is_enabled: boolean
  priority: number
  weight: number
  ip_address?: string
  gateway?: string
  dns_primary?: string
  dns_secondary?: string
  username?: string
  password?: string
  apn?: string
  mtu: number
  bandwidth_upload_kbps?: number
  bandwidth_download_kbps?: number
  health_check_enabled: boolean
  currentStatus?: any
}

const WANManagement: React.FC = () => {
  const [connectionTypes, setConnectionTypes] = useState<ConnectionType[]>([])
  const [connections, setConnections] = useState<WANConnection[]>([])
  const [loading, setLoading] = useState(true)
  const [showCreateModal, setShowCreateModal] = useState(false)
  const [showEditModal, setShowEditModal] = useState(false)
  const [selectedConnection, setSelectedConnection] = useState<WANConnection | null>(null)
  const [testingConnection, setTestingConnection] = useState<string | null>(null)
  const [diagnostics, setDiagnostics] = useState<any>(null)
  const [activeTab, setActiveTab] = useState('connections')
  
  const [connectionForm, setConnectionForm] = useState({
    connection_name: '',
    connection_type: '',
    interface_name: '',
    is_primary: false,
    is_enabled: true,
    priority: 100,
    weight: 1,
    ip_address: '',
    subnet_mask: '',
    gateway: '',
    dns_primary: '8.8.8.8',
    dns_secondary: '1.1.1.1',
    username: '',
    password: '',
    apn: '',
    mtu: 1500,
    bandwidth_upload_kbps: '',
    bandwidth_download_kbps: '',
    health_check_enabled: true
  })

  useEffect(() => {
    loadData()
  }, [])

  const loadData = async () => {
    try {
      setLoading(true)
      
      const [typesResult, connectionsResult, diagnosticsResult] = await Promise.all([
        supabase.functions.invoke('wan-management', {
          body: { action: 'get_connection_types' }
        }),
        supabase.functions.invoke('wan-management', {
          body: { action: 'get_wan_connections' }
        }),
        supabase.functions.invoke('wan-management', {
          body: { action: 'get_wan_diagnostics' }
        })
      ])

      if (typesResult.data) {
        setConnectionTypes(typesResult.data.data.connectionTypes)
      }
      
      if (connectionsResult.data) {
        setConnections(connectionsResult.data.data.connections)
      }
      
      if (diagnosticsResult.data) {
        setDiagnostics(diagnosticsResult.data.data.diagnostics)
      }
      
    } catch (error) {
      console.error('Error loading WAN data:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleCreateConnection = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('wan-management', {
        body: {
          action: 'create_wan_connection',
          connectionData: {
            ...connectionForm,
            bandwidth_upload_kbps: connectionForm.bandwidth_upload_kbps ? parseInt(connectionForm.bandwidth_upload_kbps) : null,
            bandwidth_download_kbps: connectionForm.bandwidth_download_kbps ? parseInt(connectionForm.bandwidth_download_kbps) : null
          }
        }
      })

      if (error) throw error
      
      setShowCreateModal(false)
      resetForm()
      await loadData()
    } catch (error) {
      console.error('Error creating connection:', error)
    }
  }

  const handleTestConnection = async (connectionId: string) => {
    setTestingConnection(connectionId)
    
    try {
      const { data, error } = await supabase.functions.invoke('wan-management', {
        body: {
          action: 'test_connection',
          connectionId
        }
      })

      if (error) throw error
      
      await loadData()
    } catch (error) {
      console.error('Error testing connection:', error)
    } finally {
      setTestingConnection(null)
    }
  }

  const handleToggleConnection = async (connectionId: string) => {
    try {
      const { data, error } = await supabase.functions.invoke('wan-management', {
        body: {
          action: 'toggle_connection',
          connectionId
        }
      })

      if (error) throw error
      
      await loadData()
    } catch (error) {
      console.error('Error toggling connection:', error)
    }
  }

  const handleDeleteConnection = async (connectionId: string) => {
    if (!confirm('Are you sure you want to delete this connection?')) return
    
    try {
      const { data, error } = await supabase.functions.invoke('wan-management', {
        body: {
          action: 'delete_wan_connection',
          connectionId
        }
      })

      if (error) throw error
      
      await loadData()
    } catch (error) {
      console.error('Error deleting connection:', error)
    }
  }

  const performHealthCheck = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('wan-management', {
        body: { action: 'perform_health_check' }
      })

      if (error) throw error
      
      await loadData()
    } catch (error) {
      console.error('Error performing health check:', error)
    }
  }

  const resetForm = () => {
    setConnectionForm({
      connection_name: '',
      connection_type: '',
      interface_name: '',
      is_primary: false,
      is_enabled: true,
      priority: 100,
      weight: 1,
      ip_address: '',
      subnet_mask: '',
      gateway: '',
      dns_primary: '8.8.8.8',
      dns_secondary: '1.1.1.1',
      username: '',
      password: '',
      apn: '',
      mtu: 1500,
      bandwidth_upload_kbps: '',
      bandwidth_download_kbps: '',
      health_check_enabled: true
    })
  }

  const getConnectionIcon = (type: string) => {
    const icons: Record<string, any> = {
      static_ip: Router,
      dhcp_client: Router,
      pppoe: Globe,
      '3g_4g': Signal,
      satellite: Activity,
      cable_docsis: Zap,
      dsl_adsl: Globe,
      fiber_direct: Activity,
      usb_tethering: Monitor,
      wifi_client: Wifi
    }
    return icons[type] || Router
  }

  const getStatusColor = (status: any) => {
    if (!status) return 'text-gray-400'
    
    switch (status.status) {
      case 'connected': return 'text-green-400'
      case 'connecting': return 'text-yellow-400'
      case 'disconnected': return 'text-red-400'
      case 'failed': return 'text-red-400'
      default: return 'text-gray-400'
    }
  }

  const getStatusIcon = (status: any) => {
    if (!status) return XCircle
    
    switch (status.status) {
      case 'connected': return CheckCircle
      case 'connecting': return Clock
      case 'failed': return XCircle
      default: return AlertTriangle
    }
  }

  const renderConnectionForm = () => {
    const selectedType = connectionTypes.find(t => t.type_name === connectionForm.connection_type)
    
    return (
      <div className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Connection Name
            </label>
            <input
              type="text"
              value={connectionForm.connection_name}
              onChange={(e) => setConnectionForm(prev => ({ ...prev, connection_name: e.target.value }))}
              className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
              placeholder="My Internet Connection"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Connection Type
            </label>
            <select
              value={connectionForm.connection_type}
              onChange={(e) => {
                const type = connectionTypes.find(t => t.type_name === e.target.value)
                setConnectionForm(prev => ({ 
                  ...prev, 
                  connection_type: e.target.value,
                  mtu: type?.default_mtu || 1500
                }))
              }}
              className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
            >
              <option value="">Select connection type</option>
              {connectionTypes.map((type) => (
                <option key={type.type_name} value={type.type_name} className="bg-gray-800 text-white">
                  {type.display_name}
                </option>
              ))}
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Interface Name
            </label>
            <input
              type="text"
              value={connectionForm.interface_name}
              onChange={(e) => setConnectionForm(prev => ({ ...prev, interface_name: e.target.value }))}
              className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
              placeholder="eth0, wlan0, ppp0"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Priority
            </label>
            <input
              type="number"
              value={connectionForm.priority}
              onChange={(e) => setConnectionForm(prev => ({ ...prev, priority: parseInt(e.target.value) }))}
              className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
              min="1"
              max="1000"
            />
          </div>
        </div>
        
        {/* Type-specific configuration */}
        {selectedType && (
          <div className="space-y-4 p-4 bg-white/5 rounded-lg">
            <h4 className="text-lg font-medium text-white mb-3">
              {selectedType.display_name} Configuration
            </h4>
            
            {selectedType.supports_static_ip && connectionForm.connection_type === 'static_ip' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    IP Address
                  </label>
                  <input
                    type="text"
                    value={connectionForm.ip_address}
                    onChange={(e) => setConnectionForm(prev => ({ ...prev, ip_address: e.target.value }))}
                    className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
                    placeholder="192.168.1.100"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Subnet Mask
                  </label>
                  <input
                    type="text"
                    value={connectionForm.subnet_mask}
                    onChange={(e) => setConnectionForm(prev => ({ ...prev, subnet_mask: e.target.value }))}
                    className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
                    placeholder="255.255.255.0"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Gateway
                  </label>
                  <input
                    type="text"
                    value={connectionForm.gateway}
                    onChange={(e) => setConnectionForm(prev => ({ ...prev, gateway: e.target.value }))}
                    className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
                    placeholder="192.168.1.1"
                  />
                </div>
              </div>
            )}
            
            {selectedType.requires_authentication && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Username
                  </label>
                  <input
                    type="text"
                    value={connectionForm.username}
                    onChange={(e) => setConnectionForm(prev => ({ ...prev, username: e.target.value }))}
                    className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Password
                  </label>
                  <input
                    type="password"
                    value={connectionForm.password}
                    onChange={(e) => setConnectionForm(prev => ({ ...prev, password: e.target.value }))}
                    className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
                  />
                </div>
              </div>
            )}
            
            {selectedType.supports_cellular && (
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  APN (Access Point Name)
                </label>
                <input
                  type="text"
                  value={connectionForm.apn}
                  onChange={(e) => setConnectionForm(prev => ({ ...prev, apn: e.target.value }))}
                  className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
                  placeholder="internet"
                />
              </div>
            )}
          </div>
        )}
        
        {/* Advanced Settings */}
        <div className="space-y-4 p-4 bg-white/5 rounded-lg">
          <h4 className="text-lg font-medium text-white mb-3">Advanced Settings</h4>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                MTU Size
              </label>
              <input
                type="number"
                value={connectionForm.mtu}
                onChange={(e) => setConnectionForm(prev => ({ ...prev, mtu: parseInt(e.target.value) }))}
                className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
                min="576"
                max="9000"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Upload Bandwidth (Kbps)
              </label>
              <input
                type="number"
                value={connectionForm.bandwidth_upload_kbps}
                onChange={(e) => setConnectionForm(prev => ({ ...prev, bandwidth_upload_kbps: e.target.value }))}
                className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Download Bandwidth (Kbps)
              </label>
              <input
                type="number"
                value={connectionForm.bandwidth_download_kbps}
                onChange={(e) => setConnectionForm(prev => ({ ...prev, bandwidth_download_kbps: e.target.value }))}
                className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
              />
            </div>
          </div>
          
          <div className="flex items-center space-x-6">
            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="is_primary"
                checked={connectionForm.is_primary}
                onChange={(e) => setConnectionForm(prev => ({ ...prev, is_primary: e.target.checked }))}
                className="w-4 h-4 text-enterprise-neon bg-white/5 border-white/10 rounded focus:ring-enterprise-neon"
              />
              <label htmlFor="is_primary" className="text-sm text-gray-300">
                Set as primary connection
              </label>
            </div>
            
            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="health_check_enabled"
                checked={connectionForm.health_check_enabled}
                onChange={(e) => setConnectionForm(prev => ({ ...prev, health_check_enabled: e.target.checked }))}
                className="w-4 h-4 text-enterprise-neon bg-white/5 border-white/10 rounded focus:ring-enterprise-neon"
              />
              <label htmlFor="health_check_enabled" className="text-sm text-gray-300">
                Enable health monitoring
              </label>
            </div>
          </div>
        </div>
      </div>
    )
  }

  const tabs = [
    { id: 'connections', label: 'WAN Connections', icon: Globe },
    { id: 'diagnostics', label: 'Diagnostics', icon: Activity },
    { id: 'load-balancing', label: 'Load Balancing', icon: BarChart3 }
  ]

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white flex items-center space-x-2">
            <Globe className="h-6 w-6 text-enterprise-neon" />
            <span>WAN Management</span>
          </h2>
          <p className="text-gray-400 mt-1">
            Multi-WAN configuration, load balancing, and failover management
          </p>
        </div>
        
        <div className="flex items-center space-x-3">
          <Button variant="outline" onClick={performHealthCheck}>
            <Activity className="h-4 w-4 mr-2" />
            Health Check
          </Button>
          <Button variant="outline" onClick={loadData}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          <Button onClick={() => setShowCreateModal(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Add Connection
          </Button>
        </div>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-white/5 border-white/10">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Globe className="h-5 w-5 text-blue-400" />
              <div>
                <p className="text-sm text-gray-400">Total Connections</p>
                <p className="text-xl font-bold text-white">{connections.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-white/5 border-white/10">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <CheckCircle className="h-5 w-5 text-green-400" />
              <div>
                <p className="text-sm text-gray-400">Active</p>
                <p className="text-xl font-bold text-white">
                  {connections.filter(c => c.currentStatus?.status === 'connected').length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-white/5 border-white/10">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Shield className="h-5 w-5 text-yellow-400" />
              <div>
                <p className="text-sm text-gray-400">Primary</p>
                <p className="text-lg font-bold text-white">
                  {connections.find(c => c.is_primary)?.connection_name || 'None'}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-white/5 border-white/10">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <TrendingUp className="h-5 w-5 text-green-400" />
              <div>
                <p className="text-sm text-gray-400">Total Bandwidth</p>
                <p className="text-xl font-bold text-white">
                  {Math.round(connections.reduce((sum, c) => sum + (c.bandwidth_download_kbps || 0), 0) / 1000)} Mbps
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tab Navigation */}
      <div className="flex space-x-1 bg-white/5 p-1 rounded-lg w-fit">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={cn(
              'flex items-center space-x-2 px-4 py-2 rounded-md transition-all duration-200',
              activeTab === tab.id
                ? 'bg-enterprise-neon/20 text-enterprise-neon border border-enterprise-neon/30'
                : 'text-gray-400 hover:text-white hover:bg-white/5'
            )}
          >
            <tab.icon className="h-4 w-4" />
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {/* Tab Content */}
      {activeTab === 'connections' && (
        <div className="space-y-4">
          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {[1, 2, 3].map((i) => (
                <Card key={i} className="bg-white/5 border-white/10 animate-pulse">
                  <CardContent className="p-6">
                    <div className="h-4 bg-gray-600 rounded w-3/4 mb-4"></div>
                    <div className="h-3 bg-gray-600 rounded w-full mb-2"></div>
                    <div className="h-3 bg-gray-600 rounded w-2/3"></div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {connections.map((connection) => {
                const IconComponent = getConnectionIcon(connection.connection_type)
                const StatusIcon = getStatusIcon(connection.currentStatus)
                const isTesting = testingConnection === connection.id
                
                return (
                  <motion.div
                    key={connection.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="group"
                  >
                    <Card className="bg-white/5 border-white/10 hover:bg-white/10 transition-all duration-300">
                      <CardContent className="p-6">
                        <div className="flex items-start justify-between mb-4">
                          <div className="flex items-center space-x-3">
                            <div className={cn(
                              'p-3 rounded-lg flex items-center justify-center',
                              connection.is_primary 
                                ? 'bg-enterprise-neon/20 text-enterprise-neon'
                                : 'bg-blue-500/20 text-blue-400'
                            )}>
                              <IconComponent className="h-6 w-6" />
                            </div>
                            <div>
                              <h3 className="font-semibold text-white group-hover:text-enterprise-neon transition-colors">
                                {connection.connection_name}
                              </h3>
                              <p className="text-sm text-gray-400">
                                {connectionTypes.find(t => t.type_name === connection.connection_type)?.display_name}
                              </p>
                              {connection.is_primary && (
                                <span className="inline-block px-2 py-1 text-xs font-medium bg-enterprise-neon/20 text-enterprise-neon rounded-full mt-1">
                                  Primary
                                </span>
                              )}
                            </div>
                          </div>
                          
                          <div className="flex items-center space-x-2">
                            <StatusIcon className={cn('h-5 w-5', getStatusColor(connection.currentStatus))} />
                          </div>
                        </div>
                        
                        {/* Connection Details */}
                        <div className="space-y-2 mb-4">
                          <div className="flex justify-between text-sm">
                            <span className="text-gray-400">Interface:</span>
                            <span className="text-white font-mono">{connection.interface_name}</span>
                          </div>
                          
                          {connection.currentStatus && (
                            <>
                              {connection.currentStatus.latency_ms && (
                                <div className="flex justify-between text-sm">
                                  <span className="text-gray-400">Latency:</span>
                                  <span className="text-white">{connection.currentStatus.latency_ms.toFixed(1)} ms</span>
                                </div>
                              )}
                              
                              {connection.currentStatus.current_ip_address && (
                                <div className="flex justify-between text-sm">
                                  <span className="text-gray-400">IP Address:</span>
                                  <span className="text-white font-mono">{connection.currentStatus.current_ip_address}</span>
                                </div>
                              )}
                            </>
                          )}
                          
                          <div className="flex justify-between text-sm">
                            <span className="text-gray-400">Priority:</span>
                            <span className="text-white">{connection.priority}</span>
                          </div>
                        </div>
                        
                        {/* Action Buttons */}
                        <div className="flex items-center space-x-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleTestConnection(connection.id)}
                            disabled={isTesting}
                          >
                            {isTesting ? (
                              <RefreshCw className="h-4 w-4 animate-spin" />
                            ) : (
                              <Play className="h-4 w-4" />
                            )}
                          </Button>
                          
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleToggleConnection(connection.id)}
                          >
                            {connection.is_enabled ? (
                              <Pause className="h-4 w-4" />
                            ) : (
                              <Play className="h-4 w-4" />
                            )}
                          </Button>
                          
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              setSelectedConnection(connection)
                              setConnectionForm({
                                connection_name: connection.connection_name,
                                connection_type: connection.connection_type,
                                interface_name: connection.interface_name,
                                is_primary: connection.is_primary,
                                is_enabled: connection.is_enabled,
                                priority: connection.priority,
                                weight: connection.weight,
                                ip_address: connection.ip_address || '',
                                subnet_mask: '',
                                gateway: connection.gateway || '',
                                dns_primary: connection.dns_primary || '8.8.8.8',
                                dns_secondary: connection.dns_secondary || '1.1.1.1',
                                username: connection.username || '',
                                password: connection.password || '',
                                apn: connection.apn || '',
                                mtu: connection.mtu,
                                bandwidth_upload_kbps: connection.bandwidth_upload_kbps?.toString() || '',
                                bandwidth_download_kbps: connection.bandwidth_download_kbps?.toString() || '',
                                health_check_enabled: connection.health_check_enabled
                              })
                              setShowEditModal(true)
                            }}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => handleDeleteConnection(connection.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                )
              })}
            </div>
          )}
        </div>
      )}

      {activeTab === 'diagnostics' && diagnostics && (
        <div className="space-y-6">
          <Card className="bg-white/5 border-white/10">
            <CardHeader>
              <CardTitle>Network Interfaces</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {diagnostics.networkInterfaces.map((iface: any, index: number) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className={cn(
                        'w-3 h-3 rounded-full',
                        iface.status === 'up' ? 'bg-green-400' : 'bg-red-400'
                      )} />
                      <div>
                        <div className="font-medium text-white">{iface.name}</div>
                        <div className="text-sm text-gray-400">MTU: {iface.mtu}</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-white">{iface.speed}</div>
                      <div className="text-sm text-gray-400">{iface.status}</div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-white/5 border-white/10">
            <CardHeader>
              <CardTitle>Bandwidth Utilization</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-gray-400">Upload</span>
                    <span className="text-white">
                      {diagnostics.bandwidthUtilization.upload.current} Mbps / {diagnostics.bandwidthUtilization.upload.max} Mbps
                    </span>
                  </div>
                  <div className="w-full bg-gray-700 rounded-full h-2">
                    <div 
                      className="bg-blue-400 h-2 rounded-full"
                      style={{ width: `${diagnostics.bandwidthUtilization.upload.percentage}%` }}
                    />
                  </div>
                </div>
                
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-gray-400">Download</span>
                    <span className="text-white">
                      {diagnostics.bandwidthUtilization.download.current} Mbps / {diagnostics.bandwidthUtilization.download.max} Mbps
                    </span>
                  </div>
                  <div className="w-full bg-gray-700 rounded-full h-2">
                    <div 
                      className="bg-green-400 h-2 rounded-full"
                      style={{ width: `${diagnostics.bandwidthUtilization.download.percentage}%` }}
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Create Connection Modal */}
      <Modal
        isOpen={showCreateModal}
        onClose={() => {
          setShowCreateModal(false)
          resetForm()
        }}
        title="Create WAN Connection"
      >
        <div className="space-y-6">
          {renderConnectionForm()}
          
          <div className="flex justify-end space-x-2">
            <Button 
              variant="outline" 
              onClick={() => {
                setShowCreateModal(false)
                resetForm()
              }}
            >
              Cancel
            </Button>
            <Button onClick={handleCreateConnection}>
              Create Connection
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  )
}

export default WANManagement