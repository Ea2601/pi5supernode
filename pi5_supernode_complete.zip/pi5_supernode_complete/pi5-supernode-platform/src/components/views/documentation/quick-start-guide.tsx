import React from 'react'
import { motion } from 'framer-motion'
import { useNavigate, useLocation } from 'react-router-dom'
import { 
  CheckCircle, 
  AlertCircle, 
  Info, 
  Play, 
  Settings, 
  Network, 
  Shield, 
  Activity 
} from 'lucide-react'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

interface Step {
  id: number
  title: string
  description: string
  commands?: string[]
  notes?: string[]
  warning?: string
}

const quickStartSteps: Step[] = [
  {
    id: 1,
    title: 'Hardware Requirements & Connections',
    description: 'Verify your Pi5 hardware and make initial connections',
    notes: [
      'Raspberry Pi 5 with 8GB RAM (minimum 4GB)',
      'MicroSD card (32GB minimum, 64GB recommended)',
      'USB-C power supply (5V/5A)',
      'Ethernet cable for initial setup',
      'HDMI cable for initial configuration (optional)'
    ]
  },
  {
    id: 2,
    title: 'Operating System Installation',
    description: 'Install Raspberry Pi OS and enable SSH access',
    commands: [
      '# Download Raspberry Pi Imager from rpi.org',
      '# Flash Raspberry Pi OS Lite (64-bit) to SD card',
      '# Enable SSH by creating empty ssh file in boot partition',
      'touch /boot/ssh'
    ],
    notes: [
      'Use Raspberry Pi OS Lite for better performance',
      'Enable SSH during imaging process for headless setup',
      'Set strong password during imaging'
    ]
  },
  {
    id: 3,
    title: 'Initial Pi5 Setup',
    description: 'Boot the Pi5 and perform initial configuration',
    commands: [
      '# Connect via SSH (replace with your Pi\'s IP)',
      'ssh pi@192.168.1.100',
      '',
      '# Update system packages',
      'sudo apt update && sudo apt upgrade -y',
      '',
      '# Install essential tools',
      'sudo apt install -y curl wget git vim htop'
    ],
    notes: [
      'Find Pi IP using network scanner or router admin panel',
      'Default username is "pi" (if using older images)',
      'Change default password immediately'
    ]
  },
  {
    id: 4,
    title: 'Download Installation Script',
    description: 'Get the Pi5 Supernode automatic installation script',
    commands: [
      '# Download the installation script',
      'curl -sSL https://raw.githubusercontent.com/pi5-supernode/installer/main/install.sh -o install.sh',
      '',
      '# Make it executable',
      'chmod +x install.sh',
      '',
      '# Review the script (recommended)',
      'less install.sh'
    ],
    warning: 'Always review scripts before running them with sudo privileges'
  },
  {
    id: 5,
    title: 'Run Automated Installation',
    description: 'Execute the installation script to set up all components',
    commands: [
      '# Run the installation script',
      'sudo ./install.sh',
      '',
      '# Follow the interactive prompts',
      '# - Network interface selection',
      '# - Admin password setup',
      '# - Feature selection'
    ],
    notes: [
      'Installation takes 15-30 minutes depending on internet speed',
      'Script will automatically reboot when complete',
      'Keep terminal session active during installation'
    ]
  },
  {
    id: 6,
    title: 'Initial Network Configuration',
    description: 'Configure basic network settings and verify connectivity',
    commands: [
      '# Access web interface',
      'http://your-pi-ip:3000',
      '',
      '# Or via SSH to configure network',
      'sudo pi5-supernode network setup'
    ],
    notes: [
      'Default web interface runs on port 3000',
      'Use HTTPS in production environments',
      'Configure firewall rules as needed'
    ]
  },
  {
    id: 7,
    title: 'Verification & Testing',
    description: 'Verify all components are working correctly',
    commands: [
      '# Check system status',
      'sudo systemctl status pi5-supernode',
      '',
      '# Verify network interfaces',
      'ip link show',
      '',
      '# Test API endpoint',
      'curl http://localhost:3000/api/system/status'
    ],
    notes: [
      'All services should show "active (running)" status',
      'Web interface should be accessible',
      'API should return system information'
    ]
  }
]

const QuickStartGuide: React.FC = () => {
  const navigate = useNavigate()
  const location = useLocation()

  // Function to handle navigation to different sections
  const handleNavigation = (path: string, section?: string) => {
    if (path === '/documentation' && section) {
      // If navigating within documentation, update the URL hash for section
      navigate(`${path}#${section}`)
      // If we're already on documentation page, scroll to section
      if (location.pathname === '/documentation') {
        setTimeout(() => {
          const element = document.getElementById(section)
          if (element) {
            element.scrollIntoView({ behavior: 'smooth', block: 'start' })
          }
        }, 100)
      }
    } else {
      navigate(path)
    }
  }

  // Function to handle documentation section navigation
  const handleDocumentationSection = (sectionId: string) => {
    // Dispatch custom event to change documentation section
    window.dispatchEvent(new CustomEvent('changeDocumentationSection', { 
      detail: { sectionId } 
    }))
    
    // If not on documentation page, navigate there first
    if (location.pathname !== '/documentation') {
      navigate('/documentation')
      // Wait for navigation and then change section
      setTimeout(() => {
        window.dispatchEvent(new CustomEvent('changeDocumentationSection', { 
          detail: { sectionId } 
        }))
      }, 100)
    }
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-white mb-4">Quick Start Guide</h1>
        <p className="text-lg text-gray-300">
          Get your Pi5 Supernode up and running in under 30 minutes with this step-by-step guide.
        </p>
      </div>

      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card className="p-6 bg-gradient-to-br from-green-500/20 to-emerald-500/20 border-green-500/30">
          <div className="flex items-center space-x-3 mb-3">
            <Play className="h-6 w-6 text-green-400" />
            <h3 className="text-lg font-semibold text-white">Time Required</h3>
          </div>
          <p className="text-green-200">15-30 minutes</p>
          <p className="text-sm text-green-300 mt-1">Automated installation</p>
        </Card>

        <Card className="p-6 bg-gradient-to-br from-blue-500/20 to-cyan-500/20 border-blue-500/30">
          <div className="flex items-center space-x-3 mb-3">
            <Settings className="h-6 w-6 text-blue-400" />
            <h3 className="text-lg font-semibold text-white">Difficulty</h3>
          </div>
          <p className="text-blue-200">Beginner</p>
          <p className="text-sm text-blue-300 mt-1">Copy & paste commands</p>
        </Card>

        <Card className="p-6 bg-gradient-to-br from-purple-500/20 to-pink-500/20 border-purple-500/30">
          <div className="flex items-center space-x-3 mb-3">
            <Network className="h-6 w-6 text-purple-400" />
            <h3 className="text-lg font-semibold text-white">Result</h3>
          </div>
          <p className="text-purple-200">Full Network Stack</p>
          <p className="text-sm text-purple-300 mt-1">Production ready</p>
        </Card>
      </div>

      {/* Important Notes */}
      <Card className="p-6 bg-gradient-to-r from-orange-500/10 to-yellow-500/10 border-orange-500/30">
        <div className="flex items-start space-x-3">
          <AlertCircle className="h-6 w-6 text-orange-400 mt-1 flex-shrink-0" />
          <div>
            <h3 className="text-lg font-semibold text-white mb-2">Before You Begin</h3>
            <ul className="space-y-1 text-orange-200">
              <li>• Ensure stable internet connection for downloads</li>
              <li>• Have your network configuration details ready</li>
              <li>• Backup any existing network configurations</li>
              <li>• Allocate at least 30 minutes for complete setup</li>
            </ul>
          </div>
        </div>
      </Card>

      {/* Step-by-Step Instructions */}
      <div className="space-y-6">
        <h2 className="text-2xl font-bold text-white">Step-by-Step Instructions</h2>
        
        {quickStartSteps.map((step, index) => (
          <motion.div
            key={step.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className="p-6 border-white/10">
              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0">
                  <div className="w-8 h-8 bg-enterprise-neon rounded-full flex items-center justify-center">
                    <span className="text-sm font-bold text-enterprise-dark">{step.id}</span>
                  </div>
                </div>
                
                <div className="flex-1">
                  <h3 className="text-xl font-semibold text-white mb-2">{step.title}</h3>
                  <p className="text-gray-300 mb-4">{step.description}</p>
                  
                  {step.warning && (
                    <div className="mb-4 p-3 bg-red-500/10 border border-red-500/30 rounded-lg">
                      <div className="flex items-center space-x-2">
                        <AlertCircle className="h-4 w-4 text-red-400" />
                        <span className="text-red-200 text-sm">{step.warning}</span>
                      </div>
                    </div>
                  )}
                  
                  {step.commands && (
                    <div className="mb-4">
                      <h4 className="text-sm font-medium text-white mb-2">Commands:</h4>
                      <pre className="bg-black/50 p-4 rounded-lg overflow-x-auto text-sm text-green-400 font-mono border border-white/10">
                        {step.commands.join('\n')}
                      </pre>
                    </div>
                  )}
                  
                  {step.notes && (
                    <div>
                      <h4 className="text-sm font-medium text-white mb-2">Notes:</h4>
                      <ul className="space-y-1">
                        {step.notes.map((note, noteIndex) => (
                          <li key={noteIndex} className="flex items-start space-x-2">
                            <Info className="h-4 w-4 text-blue-400 mt-0.5 flex-shrink-0" />
                            <span className="text-blue-200 text-sm">{note}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              </div>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Next Steps */}
      <Card className="p-6 bg-gradient-to-r from-enterprise-neon/10 to-enterprise-neon-dark/10 border-enterprise-neon/30">
        <div className="flex items-start space-x-3">
          <CheckCircle className="h-6 w-6 text-enterprise-neon mt-1" />
          <div>
            <h3 className="text-lg font-semibold text-white mb-2">Congratulations!</h3>
            <p className="text-gray-300 mb-4">
              Your Pi5 Supernode is now ready. Here's what you can do next:
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Button 
                className="bg-gradient-to-r from-enterprise-neon to-cyan-400 text-enterprise-dark hover:from-cyan-400 hover:to-enterprise-neon transition-all duration-300 hover:scale-105 hover:shadow-xl hover:shadow-enterprise-neon/40 active:scale-95 group font-medium" 
                onClick={() => handleDocumentationSection('network')}
              >
                <Network className="h-4 w-4 mr-2 group-hover:animate-pulse" />
                Configure Network Interfaces
              </Button>
              <Button 
                variant="outline" 
                className="border-2 border-enterprise-neon text-enterprise-neon hover:bg-gradient-to-r hover:from-enterprise-neon/20 hover:to-cyan-400/20 transition-all duration-300 hover:scale-105 hover:shadow-xl hover:shadow-enterprise-neon/30 active:scale-95 hover:border-cyan-400 group font-medium"
                onClick={() => handleNavigation('/settings/security')}
              >
                <Shield className="h-4 w-4 mr-2 group-hover:animate-pulse" />
                Set Up Security Policies
              </Button>
              <Button 
                variant="outline" 
                className="border-2 border-enterprise-neon text-enterprise-neon hover:bg-gradient-to-r hover:from-enterprise-neon/20 hover:to-cyan-400/20 transition-all duration-300 hover:scale-105 hover:shadow-xl hover:shadow-enterprise-neon/30 active:scale-95 hover:border-cyan-400 group font-medium"
                onClick={() => handleNavigation('/observability')}
              >
                <Activity className="h-4 w-4 mr-2 group-hover:animate-pulse" />
                View System Monitoring
              </Button>
              <Button 
                variant="outline" 
                className="border-2 border-enterprise-neon text-enterprise-neon hover:bg-gradient-to-r hover:from-enterprise-neon/20 hover:to-cyan-400/20 transition-all duration-300 hover:scale-105 hover:shadow-xl hover:shadow-enterprise-neon/30 active:scale-95 hover:border-cyan-400 group font-medium"
                onClick={() => handleDocumentationSection('advanced')}
              >
                <Settings className="h-4 w-4 mr-2 group-hover:animate-pulse" />
                Advanced Configuration
              </Button>
            </div>
          </div>
        </div>
      </Card>
    </div>
  )
}

export default QuickStartGuide