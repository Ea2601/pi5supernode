import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { 
  AlertTriangle, 
  Search, 
  CheckCircle, 
  Info, 
  HelpCircle, 
  Terminal, 
  FileText, 
  Settings, 
  Wifi, 
  Network, 
  Shield, 
  Activity,
  Copy,
  ExternalLink
} from 'lucide-react'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

interface TroubleshootingCategory {
  id: string
  title: string
  icon: React.ComponentType<{ className?: string }>
  description: string
  issues: TroubleshootingIssue[]
}

interface TroubleshootingIssue {
  id: string
  title: string
  description: string
  symptoms: string[]
  causes: string[]
  solutions: Solution[]
  severity: 'low' | 'medium' | 'high' | 'critical'
  frequency: 'rare' | 'occasional' | 'common' | 'frequent'
}

interface Solution {
  type: 'command' | 'config' | 'procedure'
  title: string
  description: string
  steps: string[]
  code?: string
}

const troubleshootingCategories: TroubleshootingCategory[] = [
  {
    id: 'hardware',
    title: 'Hardware Issues',
    icon: Settings,
    description: 'Physical connectivity and hardware-related problems',
    issues: [
      {
        id: 'interface-not-detected',
        title: 'Network Interface Not Detected',
        description: 'USB or PCI network adapters are not showing up in the system',
        symptoms: [
          'Interface missing from discovery endpoints',
          'Device not visible in lsusb or lspci output',
          'No carrier detected on physical ports'
        ],
        causes: [
          'Missing drivers for the network adapter',
          'Hardware compatibility issues',
          'Insufficient power supply',
          'Defective hardware'
        ],
        solutions: [
          {
            type: 'command',
            title: 'Check Hardware Detection',
            description: 'Verify if the hardware is detected by the system',
            steps: [
              'Check USB devices: lsusb',
              'Check PCI devices: lspci',
              'Check kernel messages: dmesg | grep -i network',
              'Verify interface list: ip link show'
            ],
            code: `# Check USB network adapters\nlsusb | grep -i network\n\n# Check PCI network cards\nlspci | grep -i ethernet\n\n# Check kernel detection\ndmesg | grep -E "(eth|wlan|usb)"\n\n# List all interfaces\nip link show`
          },
          {
            type: 'procedure',
            title: 'Install Missing Drivers',
            description: 'Install required drivers for unsupported hardware',
            steps: [
              'Identify the hardware vendor and model',
              'Search for Linux drivers on manufacturer website',
              'Install drivers using package manager or compile from source',
              'Reboot system and verify detection'
            ]
          }
        ],
        severity: 'high',
        frequency: 'occasional'
      },
      {
        id: 'cable-connectivity',
        title: 'No Link/Cable Issues',
        description: 'Physical layer connectivity problems',
        symptoms: [
          'Interface shows down state',
          'No carrier detected',
          'Link LED indicators are off'
        ],
        causes: [
          'Faulty or loose cables',
          'Wrong cable type (crossover vs straight)',
          'Port configuration mismatch',
          'Auto-negotiation failures'
        ],
        solutions: [
          {
            type: 'command',
            title: 'Check Link Status',
            description: 'Verify physical link status and settings',
            steps: [
              'Check link status: ethtool eth0',
              'Test with known good cable',
              'Force speed/duplex if auto-negotiation fails',
              'Check both ends of the connection'
            ],
            code: `# Check interface status\nethtool eth0\n\n# Check for carrier\ncat /sys/class/net/eth0/carrier\n\n# Force 1000Mbps full duplex\nethtool -s eth0 speed 1000 duplex full autoneg off`
          }
        ],
        severity: 'medium',
        frequency: 'common'
      }
    ]
  },
  {
    id: 'network-config',
    title: 'Network Configuration',
    icon: Network,
    description: 'IP addressing, routing, and connectivity issues',
    issues: [
      {
        id: 'dhcp-not-working',
        title: 'DHCP Client Not Getting IP',
        description: 'Interface unable to obtain IP address via DHCP',
        symptoms: [
          'Interface has no IP address',
          'DHCP requests timing out',
          'No response from DHCP server'
        ],
        causes: [
          'DHCP server not reachable',
          'Network isolation or VLAN issues',
          'DHCP client configuration errors',
          'Firewall blocking DHCP traffic'
        ],
        solutions: [
          {
            type: 'command',
            title: 'Debug DHCP Issues',
            description: 'Diagnose DHCP client problems',
            steps: [
              'Check DHCP client status',
              'Manually request DHCP lease',
              'Monitor DHCP traffic',
              'Verify network connectivity'
            ],
            code: `# Check DHCP status\ncurl -X GET http://localhost:3000/api/interfaces/eth0/ipv4/dhcp/enabled\n\n# Request new DHCP lease\ncurl -X POST http://localhost:3000/api/interfaces/eth0/ipv4/dhcp/request\n\n# Monitor DHCP traffic\nsudo tcpdump -i eth0 port 67 or port 68\n\n# Check for DHCP server\nsudo nmap --script broadcast-dhcp-discover`
          },
          {
            type: 'config',
            title: 'Manual DHCP Configuration',
            description: 'Configure DHCP client manually',
            steps: [
              'Stop any existing DHCP client',
              'Configure dhclient or systemd-networkd',
              'Restart networking service',
              'Verify IP assignment'
            ]
          }
        ],
        severity: 'medium',
        frequency: 'common'
      },
      {
        id: 'routing-issues',
        title: 'Routing Problems',
        description: 'Traffic not reaching intended destinations',
        symptoms: [
          'Cannot reach specific networks',
          'Default gateway not working',
          'Asymmetric routing issues'
        ],
        causes: [
          'Missing or incorrect routes',
          'Routing table conflicts',
          'Policy routing misconfigurations',
          'MTU path discovery issues'
        ],
        solutions: [
          {
            type: 'command',
            title: 'Diagnose Routing Issues',
            description: 'Troubleshoot routing problems',
            steps: [
              'Check routing table',
              'Trace route to destination',
              'Verify policy rules',
              'Test connectivity'
            ],
            code: `# Check main routing table\ncurl -X GET http://localhost:3000/api/routing/tables/main/routes\n\n# Add missing route\ncurl -X POST http://localhost:3000/api/routing/tables/main/routes \\\n  -H "Content-Type: application/json" \\\n  -d '{"destination": "10.0.0.0/8", "gateway": "192.168.1.1"}'\n\n# Test route\nping -c 3 10.0.0.1\ntraceroute 10.0.0.1`
          }
        ],
        severity: 'high',
        frequency: 'occasional'
      }
    ]
  },
  {
    id: 'wireless',
    title: 'Wireless Issues',
    icon: Wifi,
    description: 'WiFi connectivity and access point problems',
    issues: [
      {
        id: 'wifi-not-connecting',
        title: 'Cannot Connect to WiFi Network',
        description: 'Wireless interface fails to connect to access points',
        symptoms: [
          'Connection attempts fail',
          'Authentication errors',
          'Weak signal strength'
        ],
        causes: [
          'Incorrect credentials',
          'Unsupported security protocols',
          'Signal interference',
          'Driver compatibility issues'
        ],
        solutions: [
          {
            type: 'command',
            title: 'WiFi Connection Troubleshooting',
            description: 'Diagnose wireless connection issues',
            steps: [
              'Scan for available networks',
              'Check signal strength',
              'Verify credentials',
              'Attempt connection with debugging'
            ],
            code: `# Scan for networks\ncurl -X POST http://localhost:3000/api/interfaces/wlan0/wifi/scan\n\n# Check current status\ncurl -X GET http://localhost:3000/api/interfaces/wlan0/wifi/status\n\n# Connect to network\ncurl -X POST http://localhost:3000/api/interfaces/wlan0/wifi/connect \\\n  -H "Content-Type: application/json" \\\n  -d '{"ssid": "NetworkName", "password": "your_password"}'`
          }
        ],
        severity: 'medium',
        frequency: 'common'
      }
    ]
  },
  {
    id: 'security',
    title: 'Security & Firewall',
    icon: Shield,
    description: 'Firewall rules and security policy issues',
    issues: [
      {
        id: 'firewall-blocking',
        title: 'Firewall Blocking Traffic',
        description: 'Legitimate traffic being blocked by firewall rules',
        symptoms: [
          'Connection timeouts',
          'Services unreachable',
          'Port scans showing filtered ports'
        ],
        causes: [
          'Overly restrictive firewall rules',
          'Incorrect rule order',
          'Missing allow rules',
          'Default deny policies'
        ],
        solutions: [
          {
            type: 'command',
            title: 'Debug Firewall Rules',
            description: 'Analyze firewall configuration',
            steps: [
              'List current firewall rules',
              'Check rule matches and statistics',
              'Temporarily disable firewall for testing',
              'Add specific allow rules'
            ],
            code: `# List firewall rules\ncurl -X GET http://localhost:3000/api/firewall/tables/filter/chains/INPUT/rules\n\n# Check rule statistics\ncurl -X GET http://localhost:3000/api/firewall/tables/filter/chains/INPUT/rules/1/statistics\n\n# Add allow rule for SSH\ncurl -X POST http://localhost:3000/api/firewall/tables/filter/chains/INPUT/rules \\\n  -H "Content-Type: application/json" \\\n  -d '{"action": "ACCEPT", "protocol": "tcp", "port": 22}'`
          }
        ],
        severity: 'high',
        frequency: 'occasional'
      }
    ]
  },
  {
    id: 'performance',
    title: 'Performance Issues',
    icon: Activity,
    description: 'Network performance and optimization problems',
    issues: [
      {
        id: 'slow-throughput',
        title: 'Poor Network Performance',
        description: 'Lower than expected network throughput',
        symptoms: [
          'Slow file transfers',
          'High latency',
          'Packet loss'
        ],
        causes: [
          'Interface speed/duplex mismatch',
          'Network congestion',
          'Hardware limitations',
          'Buffer size issues'
        ],
        solutions: [
          {
            type: 'command',
            title: 'Performance Analysis',
            description: 'Analyze and optimize network performance',
            steps: [
              'Check interface statistics',
              'Monitor real-time traffic',
              'Test bandwidth with iperf3',
              'Optimize buffer sizes'
            ],
            code: `# Check interface errors\ncurl -X GET http://localhost:3000/api/interfaces/eth0/stats/rx/errors/total\n\n# Monitor bandwidth usage\ncurl -X GET http://localhost:3000/api/interfaces/eth0/stats/rx/bytes/rate\n\n# Optimize ring buffer sizes\ncurl -X PUT http://localhost:3000/api/interfaces/eth0/ring/rx/size \\\n  -H "Content-Type: application/json" \\\n  -d '{"size": 4096}'`
          }
        ],
        severity: 'medium',
        frequency: 'occasional'
      }
    ]
  }
]

const TroubleshootingGuide: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedCategory, setSelectedCategory] = useState<string>('all')
  const [selectedIssue, setSelectedIssue] = useState<TroubleshootingIssue | null>(null)
  const [copiedCommand, setCopiedCommand] = useState<string | null>(null)

  const filteredCategories = troubleshootingCategories.filter(category => {
    if (selectedCategory !== 'all' && category.id !== selectedCategory) return false
    if (!searchQuery) return true
    
    return category.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
           category.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
           category.issues.some(issue => 
             issue.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
             issue.description.toLowerCase().includes(searchQuery.toLowerCase())
           )
  })

  const copyToClipboard = async (text: string, commandId: string) => {
    try {
      await navigator.clipboard.writeText(text)
      setCopiedCommand(commandId)
      setTimeout(() => setCopiedCommand(null), 2000)
    } catch (err) {
      console.error('Failed to copy text: ', err)
    }
  }

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'low': return 'text-green-400 bg-green-500/20'
      case 'medium': return 'text-yellow-400 bg-yellow-500/20'
      case 'high': return 'text-orange-400 bg-orange-500/20'
      case 'critical': return 'text-red-400 bg-red-500/20'
      default: return 'text-gray-400 bg-gray-500/20'
    }
  }

  const getFrequencyColor = (frequency: string) => {
    switch (frequency) {
      case 'rare': return 'text-blue-400'
      case 'occasional': return 'text-green-400'
      case 'common': return 'text-yellow-400'
      case 'frequent': return 'text-red-400'
      default: return 'text-gray-400'
    }
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-white mb-4">Troubleshooting Guide</h1>
        <p className="text-lg text-gray-300">
          Common issues, solutions, and diagnostic procedures for Pi5 Supernode network management.
        </p>
      </div>

      {/* Quick Reference */}
      <Card className="p-6 bg-gradient-to-r from-red-500/10 to-orange-500/10 border-red-500/30">
        <div className="flex items-start space-x-3">
          <AlertTriangle className="h-6 w-6 text-red-400 mt-1" />
          <div>
            <h3 className="text-lg font-semibold text-white mb-2">Emergency Quick Reference</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <h4 className="font-medium text-red-300 mb-2">System Recovery</h4>
                <code className="text-xs bg-black/30 p-2 rounded block text-green-400">
                  sudo systemctl restart pi5-supernode
                </code>
              </div>
              <div>
                <h4 className="font-medium text-orange-300 mb-2">Network Reset</h4>
                <code className="text-xs bg-black/30 p-2 rounded block text-green-400">
                  sudo ip link set eth0 down && sudo ip link set eth0 up
                </code>
              </div>
              <div>
                <h4 className="font-medium text-yellow-300 mb-2">Firewall Disable</h4>
                <code className="text-xs bg-black/30 p-2 rounded block text-green-400">
                  sudo ufw disable
                </code>
              </div>
              <div>
                <h4 className="font-medium text-blue-300 mb-2">Logs Check</h4>
                <code className="text-xs bg-black/30 p-2 rounded block text-green-400">
                  journalctl -u pi5-supernode -f
                </code>
              </div>
            </div>
          </div>
        </div>
      </Card>

      {/* Search and Filter */}
      <div className="flex flex-col md:flex-row gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <input
            type="text"
            placeholder="Search issues, symptoms, or solutions..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-enterprise-neon focus:border-transparent"
          />
        </div>
        <div className="flex gap-2">
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
          >
            <option value="all">All Categories</option>
            {troubleshootingCategories.map((category) => (
              <option key={category.id} value={category.id}>
                {category.title}
              </option>
            ))}
          </select>
        </div>
      </div>

      {selectedIssue ? (
        /* Issue Detail View */
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.3 }}
        >
          <Card className="p-6 border-white/10">
            <div className="flex items-start justify-between mb-6">
              <div>
                <h2 className="text-2xl font-bold text-white mb-2">{selectedIssue.title}</h2>
                <p className="text-gray-300 mb-4">{selectedIssue.description}</p>
                <div className="flex items-center space-x-4">
                  <span className={cn(
                    'px-3 py-1 rounded-full text-sm font-medium',
                    getSeverityColor(selectedIssue.severity)
                  )}>
                    {selectedIssue.severity} severity
                  </span>
                  <span className={cn(
                    'text-sm',
                    getFrequencyColor(selectedIssue.frequency)
                  )}>
                    {selectedIssue.frequency} occurrence
                  </span>
                </div>
              </div>
              <Button
                variant="outline"
                onClick={() => setSelectedIssue(null)}
                className="border-white/20 text-gray-300 hover:bg-white/10"
              >
                Back to List
              </Button>
            </div>

            <div className="space-y-6">
              {/* Symptoms */}
              <div>
                <h3 className="text-lg font-semibold text-white mb-3 flex items-center">
                  <Info className="h-5 w-5 mr-2 text-blue-400" />
                  Symptoms
                </h3>
                <ul className="space-y-1">
                  {selectedIssue.symptoms.map((symptom, index) => (
                    <li key={index} className="flex items-start space-x-2">
                      <CheckCircle className="h-4 w-4 text-blue-400 mt-1 flex-shrink-0" />
                      <span className="text-gray-300">{symptom}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Causes */}
              <div>
                <h3 className="text-lg font-semibold text-white mb-3 flex items-center">
                  <HelpCircle className="h-5 w-5 mr-2 text-yellow-400" />
                  Possible Causes
                </h3>
                <ul className="space-y-1">
                  {selectedIssue.causes.map((cause, index) => (
                    <li key={index} className="flex items-start space-x-2">
                      <AlertTriangle className="h-4 w-4 text-yellow-400 mt-1 flex-shrink-0" />
                      <span className="text-gray-300">{cause}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Solutions */}
              <div>
                <h3 className="text-lg font-semibold text-white mb-3 flex items-center">
                  <CheckCircle className="h-5 w-5 mr-2 text-green-400" />
                  Solutions
                </h3>
                <div className="space-y-4">
                  {selectedIssue.solutions.map((solution, index) => (
                    <Card key={index} className="p-4 bg-white/5 border-white/10">
                      <div className="flex items-start space-x-3">
                        {solution.type === 'command' && <Terminal className="h-5 w-5 text-green-400 mt-1" />}
                        {solution.type === 'config' && <FileText className="h-5 w-5 text-blue-400 mt-1" />}
                        {solution.type === 'procedure' && <Settings className="h-5 w-5 text-purple-400 mt-1" />}
                        <div className="flex-1">
                          <h4 className="font-semibold text-white mb-2">{solution.title}</h4>
                          <p className="text-gray-300 mb-3">{solution.description}</p>
                          
                          <div className="mb-3">
                            <h5 className="text-sm font-medium text-white mb-2">Steps:</h5>
                            <ol className="space-y-1">
                              {solution.steps.map((step, stepIndex) => (
                                <li key={stepIndex} className="flex items-start space-x-2">
                                  <span className="text-enterprise-neon font-bold text-sm mt-1 flex-shrink-0">
                                    {stepIndex + 1}.
                                  </span>
                                  <span className="text-gray-300 text-sm">{step}</span>
                                </li>
                              ))}
                            </ol>
                          </div>
                          
                          {solution.code && (
                            <div className="relative">
                              <div className="bg-black/50 p-4 rounded-lg border border-white/10">
                                <div className="flex items-center justify-between mb-2">
                                  <span className="text-sm text-gray-400">Code Example</span>
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => copyToClipboard(solution.code!, `solution-${index}`)}
                                    className="opacity-70 hover:opacity-100"
                                  >
                                    {copiedCommand === `solution-${index}` ? (
                                      <CheckCircle className="h-4 w-4" />
                                    ) : (
                                      <Copy className="h-4 w-4" />
                                    )}
                                  </Button>
                                </div>
                                <pre className="text-green-400 font-mono text-sm overflow-x-auto">
                                  {solution.code}
                                </pre>
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              </div>
            </div>
          </Card>
        </motion.div>
      ) : (
        /* Issues List View */
        <div className="space-y-6">
          {filteredCategories.map((category) => {
            const Icon = category.icon
            return (
              <Card key={category.id} className="p-6 border-white/10">
                <div className="flex items-center space-x-3 mb-4">
                  <Icon className="h-6 w-6 text-enterprise-neon" />
                  <div>
                    <h2 className="text-xl font-bold text-white">{category.title}</h2>
                    <p className="text-gray-400">{category.description}</p>
                  </div>
                </div>
                
                <div className="space-y-3">
                  {category.issues.map((issue, index) => (
                    <motion.div
                      key={issue.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                    >
                      <Card 
                        className="p-4 bg-white/5 border-white/10 hover:border-enterprise-neon/50 transition-colors cursor-pointer"
                        onClick={() => setSelectedIssue(issue)}
                      >
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center space-x-3 mb-2">
                              <h3 className="font-semibold text-white">{issue.title}</h3>
                              <span className={cn(
                                'px-2 py-1 rounded text-xs font-medium',
                                getSeverityColor(issue.severity)
                              )}>
                                {issue.severity}
                              </span>
                              <span className={cn(
                                'text-xs',
                                getFrequencyColor(issue.frequency)
                              )}>
                                {issue.frequency}
                              </span>
                            </div>
                            <p className="text-gray-400 text-sm">{issue.description}</p>
                            <p className="text-gray-500 text-xs mt-1">
                              {issue.solutions.length} solution{issue.solutions.length !== 1 ? 's' : ''} available
                            </p>
                          </div>
                          <ExternalLink className="h-5 w-5 text-gray-400 flex-shrink-0" />
                        </div>
                      </Card>
                    </motion.div>
                  ))}
                </div>
              </Card>
            )
          })}
        </div>
      )}
    </div>
  )
}

export default TroubleshootingGuide