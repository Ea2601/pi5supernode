import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { 
  Network, 
  Router, 
  Wifi, 
  Cable, 
  Shield, 
  Settings, 
  Activity, 
  Info, 
  AlertTriangle, 
  CheckCircle, 
  Copy, 
  ExternalLink,
  Layers,
  Globe
} from 'lucide-react'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

interface NetworkGuideSection {
  id: string
  title: string
  icon: React.ComponentType<{ className?: string }>
  description: string
  topics: NetworkTopic[]
}

interface NetworkTopic {
  id: string
  title: string
  description: string
  examples: string[]
  apiEndpoints?: string[]
  difficulty: 'beginner' | 'intermediate' | 'advanced'
}

const networkGuideSections: NetworkGuideSection[] = [
  {
    id: 'interface-basics',
    title: 'Interface Basics',
    icon: Network,
    description: 'Fundamental interface operations and management',
    topics: [
      {
        id: 'discovery',
        title: 'Interface Discovery',
        description: 'Discover and enumerate all network interfaces on the system',
        difficulty: 'beginner',
        examples: [
          '# Discover all interfaces\ncurl -X GET http://localhost:3000/api/interfaces/discover',
          '# Physical interfaces only\ncurl -X GET http://localhost:3000/api/interfaces/discover/physical',
          '# Wireless interfaces\ncurl -X GET http://localhost:3000/api/interfaces/discover/wireless',
          '# USB network adapters\ncurl -X GET http://localhost:3000/api/interfaces/discover/usb'
        ],
        apiEndpoints: [
          'GET /interfaces/discover',
          'GET /interfaces/discover/physical',
          'GET /interfaces/discover/virtual',
          'GET /interfaces/discover/wireless',
          'GET /interfaces/discover/usb',
          'GET /interfaces/discover/pci'
        ]
      },
      {
        id: 'state-management',
        title: 'Interface State Management',
        description: 'Control interface up/down states and monitor operational status',
        difficulty: 'beginner',
        examples: [
          '# Bring interface up\ncurl -X POST http://localhost:3000/api/interfaces/eth0/state/up',
          '# Bring interface down\ncurl -X POST http://localhost:3000/api/interfaces/eth0/state/down',
          '# Check interface state\ncurl -X GET http://localhost:3000/api/interfaces/eth0/state/operational',
          '# Restart interface\ncurl -X POST http://localhost:3000/api/interfaces/eth0/state/restart'
        ],
        apiEndpoints: [
          'GET /interfaces/{ifname}/state/admin',
          'PUT /interfaces/{ifname}/state/admin',
          'POST /interfaces/{ifname}/state/up',
          'POST /interfaces/{ifname}/state/down',
          'POST /interfaces/{ifname}/state/restart'
        ]
      },
      {
        id: 'mac-address',
        title: 'MAC Address Operations',
        description: 'View and modify MAC addresses for network interfaces',
        difficulty: 'intermediate',
        examples: [
          '# Get current MAC address\ncurl -X GET http://localhost:3000/api/interfaces/eth0/mac/current',
          '# Set new MAC address\ncurl -X PUT http://localhost:3000/api/interfaces/eth0/mac/address \\\n  -H "Content-Type: application/json" \\\n  -d \'{"mac": "02:42:ac:11:00:02"}\"',
          '# Generate random MAC\ncurl -X POST http://localhost:3000/api/interfaces/eth0/mac/randomize',
          '# Restore original MAC\ncurl -X POST http://localhost:3000/api/interfaces/eth0/mac/restore'
        ],
        apiEndpoints: [
          'GET /interfaces/{ifname}/mac/current',
          'GET /interfaces/{ifname}/mac/permanent',
          'PUT /interfaces/{ifname}/mac/address',
          'POST /interfaces/{ifname}/mac/randomize',
          'POST /interfaces/{ifname}/mac/restore'
        ]
      }
    ]
  },
  {
    id: 'ip-configuration',
    title: 'IP Configuration',
    icon: Globe,
    description: 'IPv4 and IPv6 address configuration and management',
    topics: [
      {
        id: 'ipv4-basic',
        title: 'IPv4 Address Management',
        description: 'Add, remove, and modify IPv4 addresses on interfaces',
        difficulty: 'beginner',
        examples: [
          '# Add IPv4 address\ncurl -X POST http://localhost:3000/api/interfaces/eth0/ipv4/addresses \\\n  -H "Content-Type: application/json" \\\n  -d \'{"ip": "192.168.1.100", "prefix": 24}\"',
          '# Remove IPv4 address\ncurl -X DELETE http://localhost:3000/api/interfaces/eth0/ipv4/addresses/192.168.1.100',
          '# List all IPv4 addresses\ncurl -X GET http://localhost:3000/api/interfaces/eth0/ipv4/addresses',
          '# Flush all addresses\ncurl -X POST http://localhost:3000/api/interfaces/eth0/ipv4/addresses/flush'
        ],
        apiEndpoints: [
          'GET /interfaces/{ifname}/ipv4/addresses',
          'POST /interfaces/{ifname}/ipv4/addresses',
          'DELETE /interfaces/{ifname}/ipv4/addresses/{ip}',
          'POST /interfaces/{ifname}/ipv4/addresses/flush'
        ]
      },
      {
        id: 'dhcp-client',
        title: 'DHCP Client Configuration',
        description: 'Configure and manage DHCP client on interfaces',
        difficulty: 'intermediate',
        examples: [
          '# Enable DHCP client\ncurl -X PUT http://localhost:3000/api/interfaces/eth0/ipv4/dhcp/enabled \\\n  -H "Content-Type: application/json" \\\n  -d \'{"enabled": true}\"',
          '# Request DHCP lease\ncurl -X POST http://localhost:3000/api/interfaces/eth0/ipv4/dhcp/request',
          '# Renew DHCP lease\ncurl -X POST http://localhost:3000/api/interfaces/eth0/ipv4/dhcp/renew',
          '# Get lease information\ncurl -X GET http://localhost:3000/api/interfaces/eth0/ipv4/dhcp/lease/ip'
        ],
        apiEndpoints: [
          'GET /interfaces/{ifname}/ipv4/dhcp/enabled',
          'PUT /interfaces/{ifname}/ipv4/dhcp/enabled',
          'POST /interfaces/{ifname}/ipv4/dhcp/request',
          'POST /interfaces/{ifname}/ipv4/dhcp/renew',
          'GET /interfaces/{ifname}/ipv4/dhcp/lease/ip'
        ]
      },
      {
        id: 'ipv6-config',
        title: 'IPv6 Configuration',
        description: 'IPv6 addressing, autoconfiguration, and neighbor discovery',
        difficulty: 'advanced',
        examples: [
          '# Enable IPv6\ncurl -X PUT http://localhost:3000/api/interfaces/eth0/ipv6/enabled \\\n  -H "Content-Type: application/json" \\\n  -d \'{"enabled": true}\"',
          '# Add IPv6 address\ncurl -X POST http://localhost:3000/api/interfaces/eth0/ipv6/addresses \\\n  -H "Content-Type: application/json" \\\n  -d \'{"ip": "2001:db8::1", "prefix": 64}\"',
          '# Enable autoconfiguration\ncurl -X PUT http://localhost:3000/api/interfaces/eth0/ipv6/autoconf/enabled \\\n  -H "Content-Type: application/json" \\\n  -d \'{"enabled": true}\"',
          '# View neighbor table\ncurl -X GET http://localhost:3000/api/interfaces/eth0/ipv6/neighbors'
        ],
        apiEndpoints: [
          'GET /interfaces/{ifname}/ipv6/enabled',
          'PUT /interfaces/{ifname}/ipv6/enabled',
          'POST /interfaces/{ifname}/ipv6/addresses',
          'GET /interfaces/{ifname}/ipv6/neighbors'
        ]
      }
    ]
  },
  {
    id: 'vlan-bridging',
    title: 'VLAN & Bridging',
    icon: Layers,
    description: 'VLAN configuration and bridge management',
    topics: [
      {
        id: 'vlan-creation',
        title: 'VLAN Interface Creation',
        description: 'Create and configure VLAN interfaces',
        difficulty: 'intermediate',
        examples: [
          '# Create VLAN interface\ncurl -X POST http://localhost:3000/api/interfaces/create/vlan \\\n  -H "Content-Type: application/json" \\\n  -d \'{"parent": "eth0", "vid": 100, "name": "eth0.100"}\"',
          '# Add VLAN to interface\ncurl -X POST http://localhost:3000/api/interfaces/eth0/vlan/add \\\n  -H "Content-Type: application/json" \\\n  -d \'{"vid": 200}\"',
          '# Enable trunk mode\ncurl -X PUT http://localhost:3000/api/interfaces/eth0/vlan/trunk/enabled \\\n  -H "Content-Type: application/json" \\\n  -d \'{"enabled": true}\"',
          '# Set allowed VLANs\ncurl -X PUT http://localhost:3000/api/interfaces/eth0/vlan/trunk/allowed \\\n  -H "Content-Type: application/json" \\\n  -d \'{"vlans": [10, 20, 30]}\"'
        ],
        apiEndpoints: [
          'POST /interfaces/create/vlan',
          'POST /interfaces/{ifname}/vlan/add',
          'DELETE /interfaces/{ifname}/vlan/{vid}',
          'PUT /interfaces/{ifname}/vlan/trunk/enabled'
        ]
      },
      {
        id: 'bridge-setup',
        title: 'Bridge Configuration',
        description: 'Create and manage bridge interfaces with STP',
        difficulty: 'advanced',
        examples: [
          '# Create bridge\ncurl -X POST http://localhost:3000/api/interfaces/create/bridge \\\n  -H "Content-Type: application/json" \\\n  -d \'{"name": "br0"}\"',
          '# Add port to bridge\ncurl -X POST http://localhost:3000/api/interfaces/bridge/br0/ports/add \\\n  -H "Content-Type: application/json" \\\n  -d \'{"interface": "eth0"}\"',
          '# Enable STP\ncurl -X PUT http://localhost:3000/api/interfaces/bridge/br0/stp/enabled \\\n  -H "Content-Type: application/json" \\\n  -d \'{"enabled": true}\"',
          '# View bridge FDB\ncurl -X GET http://localhost:3000/api/interfaces/bridge/br0/fdb/entries'
        ],
        apiEndpoints: [
          'POST /interfaces/create/bridge',
          'POST /interfaces/bridge/{brname}/ports/add',
          'PUT /interfaces/bridge/{brname}/stp/enabled',
          'GET /interfaces/bridge/{brname}/fdb/entries'
        ]
      }
    ]
  },
  {
    id: 'bonding-teaming',
    title: 'Bonding & Teaming',
    icon: Cable,
    description: 'Link aggregation and load balancing',
    topics: [
      {
        id: 'bond-creation',
        title: 'Bond Interface Setup',
        description: 'Create and configure bonded interfaces for redundancy and performance',
        difficulty: 'advanced',
        examples: [
          '# Create bond interface\ncurl -X POST http://localhost:3000/api/interfaces/create/bond \\\n  -H "Content-Type: application/json" \\\n  -d \'{"name": "bond0", "mode": "802.3ad"}\"',
          '# Add slave interface\ncurl -X POST http://localhost:3000/api/interfaces/bond/bond0/slaves/add \\\n  -H "Content-Type: application/json" \\\n  -d \'{"interface": "eth0"}\"',
          '# Set bond mode\ncurl -X PUT http://localhost:3000/api/interfaces/bond/bond0/mode \\\n  -H "Content-Type: application/json" \\\n  -d \'{"mode": "active-backup"}\"',
          '# Configure LACP rate\ncurl -X PUT http://localhost:3000/api/interfaces/bond/bond0/lacp-rate \\\n  -H "Content-Type: application/json" \\\n  -d \'{"rate": "fast"}\"'
        ],
        apiEndpoints: [
          'POST /interfaces/create/bond',
          'POST /interfaces/bond/{bondname}/slaves/add',
          'PUT /interfaces/bond/{bondname}/mode',
          'PUT /interfaces/bond/{bondname}/lacp-rate'
        ]
      }
    ]
  },
  {
    id: 'wireless',
    title: 'Wireless Configuration',
    icon: Wifi,
    description: 'WiFi interface management and access point setup',
    topics: [
      {
        id: 'wifi-basics',
        title: 'WiFi Basic Configuration',
        description: 'Connect to wireless networks and configure basic settings',
        difficulty: 'intermediate',
        examples: [
          '# Scan for networks\ncurl -X POST http://localhost:3000/api/interfaces/wlan0/wifi/scan',
          '# Connect to network\ncurl -X POST http://localhost:3000/api/interfaces/wlan0/wifi/connect \\\n  -H "Content-Type: application/json" \\\n  -d \'{"ssid": "MyNetwork", "password": "secret123"}\"',
          '# Get connection status\ncurl -X GET http://localhost:3000/api/interfaces/wlan0/wifi/status',
          '# Disconnect\ncurl -X POST http://localhost:3000/api/interfaces/wlan0/wifi/disconnect'
        ],
        apiEndpoints: [
          'POST /interfaces/{ifname}/wifi/scan',
          'POST /interfaces/{ifname}/wifi/connect',
          'GET /interfaces/{ifname}/wifi/status',
          'POST /interfaces/{ifname}/wifi/disconnect'
        ]
      }
    ]
  }
]

const NetworkManagementGuide: React.FC = () => {
  const [activeSection, setActiveSection] = useState('interface-basics')
  const [activeTopic, setActiveTopic] = useState('discovery')
  const [copiedCommand, setCopiedCommand] = useState<string | null>(null)

  const currentSection = networkGuideSections.find(section => section.id === activeSection)
  const currentTopic = currentSection?.topics.find(topic => topic.id === activeTopic)

  const copyToClipboard = async (text: string, commandId: string) => {
    try {
      await navigator.clipboard.writeText(text)
      setCopiedCommand(commandId)
      setTimeout(() => setCopiedCommand(null), 2000)
    } catch (err) {
      console.error('Failed to copy text: ', err)
    }
  }

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'beginner': return 'text-green-400'
      case 'intermediate': return 'text-yellow-400'
      case 'advanced': return 'text-red-400'
      default: return 'text-gray-400'
    }
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-white mb-4">Network Interface Management</h1>
        <p className="text-lg text-gray-300">
          Complete tutorials for all network interface operations, from basic configuration to advanced features.
        </p>
      </div>

      {/* Overview */}
      <Card className="p-6 bg-gradient-to-r from-blue-500/10 to-cyan-500/10 border-blue-500/30">
        <div className="flex items-start space-x-3">
          <Network className="h-6 w-6 text-blue-400 mt-1" />
          <div>
            <h3 className="text-lg font-semibold text-white mb-2">Network Management Overview</h3>
            <p className="text-blue-200 mb-3">
              This guide covers comprehensive network interface management using the Pi5 Supernode API. 
              Examples include both API calls and practical use cases.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-green-400">250+</div>
                <div className="text-sm text-gray-300">API Endpoints</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-400">15</div>
                <div className="text-sm text-gray-300">Interface Types</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-purple-400">100+</div>
                <div className="text-sm text-gray-300">Examples</div>
              </div>
            </div>
          </div>
        </div>
      </Card>

      <div className="flex flex-col lg:flex-row gap-8">
        {/* Section Navigation */}
        <div className="lg:w-80 flex-shrink-0">
          <div className="sticky top-4 space-y-6">
            <div>
              <h3 className="text-lg font-semibold text-white mb-4">Guide Sections</h3>
              <nav className="space-y-2">
                {networkGuideSections.map((section) => {
                  const Icon = section.icon
                  return (
                    <button
                      key={section.id}
                      onClick={() => {
                        setActiveSection(section.id)
                        setActiveTopic(section.topics[0]?.id || '')
                      }}
                      className={cn(
                        'w-full text-left p-3 rounded-lg transition-all duration-200 group',
                        activeSection === section.id
                          ? 'bg-enterprise-neon/20 border border-enterprise-neon text-white'
                          : 'bg-white/5 border border-white/10 text-gray-300 hover:bg-white/10'
                      )}
                    >
                      <div className="flex items-center space-x-3">
                        <Icon className={cn(
                          'h-5 w-5',
                          activeSection === section.id
                            ? 'text-enterprise-neon'
                            : 'text-gray-400 group-hover:text-enterprise-neon'
                        )} />
                        <div>
                          <h4 className="font-medium text-sm">{section.title}</h4>
                          <p className="text-xs text-gray-400 mt-1">{section.description}</p>
                        </div>
                      </div>
                    </button>
                  )
                })}
              </nav>
            </div>

            {/* Topic Navigation */}
            {currentSection && (
              <div>
                <h3 className="text-lg font-semibold text-white mb-4">Topics</h3>
                <nav className="space-y-1">
                  {currentSection.topics.map((topic) => (
                    <button
                      key={topic.id}
                      onClick={() => setActiveTopic(topic.id)}
                      className={cn(
                        'w-full text-left p-2 rounded-lg text-sm transition-all duration-200',
                        activeTopic === topic.id
                          ? 'bg-enterprise-neon/20 text-enterprise-neon'
                          : 'text-gray-400 hover:text-white hover:bg-white/5'
                      )}
                    >
                      <div className="flex items-center justify-between">
                        <span>{topic.title}</span>
                        <span className={cn(
                          'text-xs px-2 py-1 rounded-full',
                          getDifficultyColor(topic.difficulty)
                        )}>
                          {topic.difficulty}
                        </span>
                      </div>
                    </button>
                  ))}
                </nav>
              </div>
            )}
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 min-w-0">
          {currentTopic && (
            <motion.div
              key={`${activeSection}-${activeTopic}`}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.3 }}
            >
              <Card className="p-6 border-white/10">
                <div className="flex items-start justify-between mb-6">
                  <div>
                    <h2 className="text-2xl font-bold text-white mb-2">{currentTopic.title}</h2>
                    <p className="text-gray-300">{currentTopic.description}</p>
                  </div>
                  <span className={cn(
                    'px-3 py-1 rounded-full text-sm font-medium',
                    currentTopic.difficulty === 'beginner' && 'bg-green-500/20 text-green-300',
                    currentTopic.difficulty === 'intermediate' && 'bg-yellow-500/20 text-yellow-300',
                    currentTopic.difficulty === 'advanced' && 'bg-red-500/20 text-red-300'
                  )}>
                    {currentTopic.difficulty}
                  </span>
                </div>

                {/* API Endpoints */}
                {currentTopic.apiEndpoints && (
                  <div className="mb-8">
                    <h3 className="text-lg font-semibold text-white mb-4">Related API Endpoints</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {currentTopic.apiEndpoints.map((endpoint, index) => {
                        const [method, path] = endpoint.split(' ')
                        return (
                          <div
                            key={index}
                            className="bg-black/30 p-3 rounded-lg border border-white/10 font-mono text-sm"
                          >
                            <span className={cn(
                              'font-bold mr-2',
                              method === 'GET' && 'text-green-400',
                              method === 'POST' && 'text-blue-400',
                              method === 'PUT' && 'text-yellow-400',
                              method === 'DELETE' && 'text-red-400'
                            )}>
                              {method}
                            </span>
                            <span className="text-gray-300">{path}</span>
                          </div>
                        )
                      })}
                    </div>
                  </div>
                )}

                {/* Examples */}
                <div>
                  <h3 className="text-lg font-semibold text-white mb-4">Examples</h3>
                  <div className="space-y-4">
                    {currentTopic.examples.map((example, index) => (
                      <div key={index} className="relative">
                        <div className="bg-black/50 p-4 rounded-lg border border-white/10">
                          <div className="flex items-start justify-between mb-2">
                            <span className="text-sm font-medium text-gray-400">
                              Example {index + 1}
                            </span>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => copyToClipboard(example, `${currentTopic.id}-${index}`)}
                              className="opacity-70 hover:opacity-100"
                            >
                              {copiedCommand === `${currentTopic.id}-${index}` ? (
                                <CheckCircle className="h-4 w-4" />
                              ) : (
                                <Copy className="h-4 w-4" />
                              )}
                            </Button>
                          </div>
                          <pre className="text-green-400 font-mono text-sm overflow-x-auto">
                            {example}
                          </pre>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </Card>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  )
}

export default NetworkManagementGuide