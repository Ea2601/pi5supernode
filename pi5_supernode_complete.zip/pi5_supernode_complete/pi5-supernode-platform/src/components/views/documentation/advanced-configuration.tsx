import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { 
  Settings, 
  Zap, 
  Shield, 
  Network, 
  Database, 
  Monitor, 
  Cpu, 
  HardDrive, 
  Copy, 
  CheckCircle, 
  AlertTriangle, 
  Info, 
  TrendingUp, 
  Lock, 
  Globe
} from 'lucide-react'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

interface AdvancedSection {
  id: string
  title: string
  icon: React.ComponentType<{ className?: string }>
  description: string
  difficulty: 'intermediate' | 'advanced' | 'expert'
  topics: AdvancedTopic[]
}

interface AdvancedTopic {
  id: string
  title: string
  description: string
  configurations: Configuration[]
  warnings?: string[]
  prerequisites?: string[]
}

interface Configuration {
  type: 'api' | 'config' | 'script'
  title: string
  description: string
  code: string
  explanation: string
}

const advancedSections: AdvancedSection[] = [
  {
    id: 'network-topologies',
    title: 'Custom Network Topologies',
    icon: Network,
    description: 'Advanced network architectures and complex routing scenarios',
    difficulty: 'expert',
    topics: [
      {
        id: 'multi-wan-failover',
        title: 'Multi-WAN Failover with Load Balancing',
        description: 'Configure multiple WAN connections with automatic failover and load distribution',
        prerequisites: [
          'Multiple internet connections',
          'Understanding of routing tables',
          'Policy-based routing knowledge'
        ],
        warnings: [
          'Complex configuration requires thorough testing',
          'May affect existing network connectivity during setup'
        ],
        configurations: [
          {
            type: 'api',
            title: 'Create Multiple WAN Interfaces',
            description: 'Set up multiple WAN interfaces for failover',
            code: `# Configure primary WAN interface
curl -X POST http://localhost:3000/api/interfaces/eth0/ipv4/addresses \\
  -H "Content-Type: application/json" \\
  -d '{"ip": "192.168.1.100", "prefix": 24}'

# Configure secondary WAN interface  
curl -X POST http://localhost:3000/api/interfaces/eth1/ipv4/addresses \\
  -H "Content-Type: application/json" \\
  -d '{"ip": "10.0.1.100", "prefix": 24}'

# Create routing tables for each WAN
curl -X POST http://localhost:3000/api/routing/tables \\
  -H "Content-Type: application/json" \\
  -d '{"id": 100, "name": "wan1_table"}'

curl -X POST http://localhost:3000/api/routing/tables \\
  -H "Content-Type: application/json" \\
  -d '{"id": 101, "name": "wan2_table"}'`,
            explanation: 'This creates separate routing tables for each WAN connection, allowing for independent routing decisions.'
          },
          {
            type: 'api',
            title: 'Configure Load Balancing Rules',
            description: 'Set up policy-based routing for load balancing',
            code: `# Create load balancing rule for even distribution
curl -X POST http://localhost:3000/api/routing/rules \\
  -H "Content-Type: application/json" \\
  -d '{
    "priority": 100,
    "match": {"source": "192.168.0.0/16"},
    "action": {"type": "table", "table": "wan1_table"}
  }'

# Create failover rule
curl -X POST http://localhost:3000/api/routing/rules \\
  -H "Content-Type: application/json" \\
  -d '{
    "priority": 110,
    "match": {"source": "192.168.0.0/16"},
    "action": {"type": "table", "table": "wan2_table"}
  }'

# Configure multipath default route
curl -X POST http://localhost:3000/api/routing/tables/main/routes \\
  -H "Content-Type: application/json" \\
  -d '{
    "destination": "0.0.0.0/0",
    "multipath": [
      {"gateway": "192.168.1.1", "weight": 1, "interface": "eth0"},
      {"gateway": "10.0.1.1", "weight": 1, "interface": "eth1"}
    ]
  }'`,
            explanation: 'This configuration distributes traffic across multiple WAN connections and provides automatic failover.'
          }
        ]
      },
      {
        id: 'vxlan-overlay',
        title: 'VXLAN Overlay Networks',
        description: 'Create Layer 2 overlay networks using VXLAN for site-to-site connectivity',
        prerequisites: [
          'Understanding of VXLAN protocol',
          'Network connectivity between sites',
          'Proper MTU configuration'
        ],
        configurations: [
          {
            type: 'api',
            title: 'Create VXLAN Tunnel Interface',
            description: 'Set up VXLAN tunnel for overlay networking',
            code: `# Create VXLAN interface
curl -X POST http://localhost:3000/api/interfaces/create/tunnel \\
  -H "Content-Type: application/json" \\
  -d '{
    "name": "vxlan100",
    "type": "vxlan",
    "vni": 100,
    "local": "192.168.1.100",
    "remote": "203.0.113.50",
    "port": 4789
  }'

# Add VXLAN interface to bridge
curl -X POST http://localhost:3000/api/interfaces/bridge/br-overlay/ports/add \\
  -H "Content-Type: application/json" \\
  -d '{"interface": "vxlan100"}'

# Configure bridge IP
curl -X POST http://localhost:3000/api/interfaces/br-overlay/ipv4/addresses \\
  -H "Content-Type: application/json" \\
  -d '{"ip": "10.100.0.1", "prefix": 24}'`,
            explanation: 'VXLAN creates a Layer 2 overlay network that can span multiple physical networks, enabling seamless connectivity.'
          }
        ]
      }
    ]
  },
  {
    id: 'performance-optimization',
    title: 'Performance Optimization',
    icon: Zap,
    description: 'Advanced tuning for maximum network performance',
    difficulty: 'advanced',
    topics: [
      {
        id: 'interrupt-optimization',
        title: 'Interrupt and CPU Affinity Optimization',
        description: 'Optimize interrupt handling and CPU affinity for high-performance networking',
        prerequisites: [
          'Multi-core system',
          'Understanding of IRQ balancing',
          'Root access to system'
        ],
        configurations: [
          {
            type: 'api',
            title: 'Configure IRQ Affinity',
            description: 'Set CPU affinity for network interface interrupts',
            code: `# Get current IRQ number for interface
curl -X GET http://localhost:3000/api/interfaces/eth0/irq/number

# Set IRQ affinity to specific CPU cores
curl -X PUT http://localhost:3000/api/interfaces/eth0/irq/affinity \\
  -H "Content-Type: application/json" \\
  -d '{"cpus": [0, 1]}'

# Configure interrupt coalescing
curl -X PUT http://localhost:3000/api/interfaces/eth0/irq/coalesce/rx-usecs \\
  -H "Content-Type: application/json" \\
  -d '{"usecs": 50}'

# Optimize ring buffer sizes
curl -X PUT http://localhost:3000/api/interfaces/eth0/ring/rx/size \\
  -H "Content-Type: application/json" \\
  -d '{"size": 4096}'

curl -X PUT http://localhost:3000/api/interfaces/eth0/ring/tx/size \\
  -H "Content-Type: application/json" \\
  -d '{"size": 4096}'`,
            explanation: 'Proper IRQ affinity and ring buffer optimization can significantly improve network performance on multi-core systems.'
          },
          {
            type: 'api',
            title: 'Enable Hardware Offloading',
            description: 'Enable various hardware offloading features',
            code: `# Enable TCP Segmentation Offload (TSO)
curl -X PUT http://localhost:3000/api/interfaces/eth0/offload/tso/enabled \\
  -H "Content-Type: application/json" \\
  -d '{"enabled": true}'

# Enable Generic Receive Offload (GRO)
curl -X PUT http://localhost:3000/api/interfaces/eth0/offload/gro/enabled \\
  -H "Content-Type: application/json" \\
  -d '{"enabled": true}'

# Enable checksum offloading
curl -X PUT http://localhost:3000/api/interfaces/eth0/offload/rxcsum/enabled \\
  -H "Content-Type: application/json" \\
  -d '{"enabled": true}'

curl -X PUT http://localhost:3000/api/interfaces/eth0/offload/txcsum/enabled \\
  -H "Content-Type: application/json" \\
  -d '{"enabled": true}'`,
            explanation: 'Hardware offloading moves processing from CPU to network card, reducing CPU load and improving throughput.'
          }
        ]
      },
      {
        id: 'qos-advanced',
        title: 'Advanced Quality of Service',
        description: 'Implement sophisticated traffic shaping and prioritization',
        configurations: [
          {
            type: 'api',
            title: 'Hierarchical Token Bucket (HTB) Setup',
            description: 'Configure advanced traffic shaping with HTB',
            code: `# Create root qdisc
curl -X POST http://localhost:3000/api/qos/qdiscs \\
  -H "Content-Type: application/json" \\
  -d '{
    "interface": "eth0",
    "type": "htb",
    "handle": "1:0",
    "default": "1:30"
  }'

# Create classes for different traffic types
curl -X POST http://localhost:3000/api/qos/classes \\
  -H "Content-Type: application/json" \\
  -d '{
    "interface": "eth0",
    "parent": "1:0",
    "classid": "1:10",
    "type": "htb",
    "rate": "10mbit",
    "ceil": "100mbit",
    "priority": 1
  }'

# High priority class (VoIP, real-time)
curl -X POST http://localhost:3000/api/qos/classes \\
  -H "Content-Type: application/json" \\
  -d '{
    "interface": "eth0",
    "parent": "1:10",
    "classid": "1:11",
    "type": "htb",
    "rate": "2mbit",
    "ceil": "5mbit",
    "priority": 0
  }'`,
            explanation: 'HTB provides hierarchical bandwidth allocation with guaranteed rates and borrowing capabilities.'
          }
        ]
      }
    ]
  },
  {
    id: 'security-hardening',
    title: 'Security Hardening',
    icon: Shield,
    description: 'Advanced security configurations and threat mitigation',
    difficulty: 'advanced',
    topics: [
      {
        id: 'ddos-protection',
        title: 'DDoS Protection and Rate Limiting',
        description: 'Implement comprehensive DDoS protection mechanisms',
        warnings: [
          'Aggressive rate limiting may affect legitimate traffic',
          'Monitor false positives during initial deployment'
        ],
        configurations: [
          {
            type: 'api',
            title: 'Connection Rate Limiting',
            description: 'Limit connection rates to prevent DDoS attacks',
            code: `# Create firewall rule for connection limiting
curl -X POST http://localhost:3000/api/firewall/tables/filter/chains/INPUT/rules \\
  -H "Content-Type: application/json" \\
  -d '{
    "match": {
      "protocol": "tcp",
      "state": "NEW",
      "connlimit": {"above": 20, "mask": 24}
    },
    "action": "DROP",
    "comment": "Limit new connections per subnet"
  }'

# Rate limit SYN packets
curl -X POST http://localhost:3000/api/firewall/tables/filter/chains/INPUT/rules \\
  -H "Content-Type: application/json" \\
  -d '{
    "match": {
      "protocol": "tcp",
      "tcp": {"syn": true},
      "limit": {"rate": "10/second", "burst": 20}
    },
    "action": "ACCEPT"
  }'

# Drop excessive SYN packets
curl -X POST http://localhost:3000/api/firewall/tables/filter/chains/INPUT/rules \\
  -H "Content-Type: application/json" \\
  -d '{
    "match": {
      "protocol": "tcp",
      "tcp": {"syn": true}
    },
    "action": "DROP",
    "comment": "Drop SYN flood attempts"
  }'`,
            explanation: 'Connection rate limiting prevents SYN flood attacks and limits the number of concurrent connections from single sources.'
          }
        ]
      },
      {
        id: 'intrusion-detection',
        title: 'Network Intrusion Detection',
        description: 'Set up network monitoring and intrusion detection',
        configurations: [
          {
            type: 'api',
            title: 'Configure Port Scan Detection',
            description: 'Detect and block port scanning attempts',
            code: `# Create port scan detection rule
curl -X POST http://localhost:3000/api/security/ids/rules \\
  -H "Content-Type: application/json" \\
  -d '{
    "name": "port_scan_detection",
    "type": "portscan",
    "threshold": {
      "ports": 10,
      "time_window": 60
    },
    "action": "block",
    "duration": 3600
  }'

# Configure failed authentication monitoring
curl -X POST http://localhost:3000/api/security/ids/rules \\
  -H "Content-Type: application/json" \\
  -d '{
    "name": "ssh_brute_force",
    "type": "failed_auth",
    "service": "ssh",
    "threshold": {
      "attempts": 5,
      "time_window": 300
    },
    "action": "ban",
    "duration": 1800
  }'`,
            explanation: 'Intrusion detection systems monitor network traffic patterns and automatically respond to suspicious activities.'
          }
        ]
      }
    ]
  },
  {
    id: 'monitoring-analytics',
    title: 'Monitoring & Analytics',
    icon: Monitor,
    description: 'Advanced monitoring, logging, and analytics setup',
    difficulty: 'intermediate',
    topics: [
      {
        id: 'real-time-monitoring',
        title: 'Real-time Network Monitoring',
        description: 'Set up comprehensive real-time monitoring and alerting',
        configurations: [
          {
            type: 'api',
            title: 'Configure Monitoring Alerts',
            description: 'Set up automated alerts for network conditions',
            code: `# Create bandwidth utilization alert
curl -X POST http://localhost:3000/api/monitoring/alerts \\
  -H "Content-Type: application/json" \\
  -d '{
    "name": "high_bandwidth_usage",
    "metric": "interface_bandwidth",
    "interface": "eth0",
    "threshold": {
      "value": 80,
      "unit": "percent",
      "direction": "above"
    },
    "duration": 300,
    "severity": "warning",
    "actions": ["email", "webhook"]
  }'

# Create interface down alert
curl -X POST http://localhost:3000/api/monitoring/alerts \\
  -H "Content-Type: application/json" \\
  -d '{
    "name": "interface_down",
    "metric": "interface_state",
    "interface": "eth0",
    "condition": "down",
    "severity": "critical",
    "actions": ["email", "sms", "webhook"]
  }'`,
            explanation: 'Automated alerts help detect network issues before they impact users and enable proactive maintenance.'
          }
        ]
      }
    ]
  },
  {
    id: 'automation-scripting',
    title: 'Automation & Scripting',
    icon: Cpu,
    description: 'Advanced automation and custom scripting solutions',
    difficulty: 'expert',
    topics: [
      {
        id: 'api-automation',
        title: 'API-based Automation',
        description: 'Create automated workflows using the Pi5 Supernode API',
        configurations: [
          {
            type: 'script',
            title: 'Automated Failover Script',
            description: 'Python script for automated WAN failover',
            code: `#!/usr/bin/env python3
import requests
import time
import logging

class WANFailover:
    def __init__(self, api_base='http://localhost:3000/api'):
        self.api_base = api_base
        self.primary_wan = 'eth0'
        self.secondary_wan = 'eth1'
        self.check_interval = 30
        
    def check_wan_status(self, interface):
        try:
            response = requests.get(
                f'{self.api_base}/interfaces/{interface}/state/operational'
            )
            return response.json().get('state') == 'up'
        except Exception as e:
            logging.error(f'Error checking {interface}: {e}')
            return False
    
    def switch_default_route(self, interface):
        try:
            # Remove current default route
            requests.delete(f'{self.api_base}/routing/tables/main/routes/default')
            
            # Add new default route
            gateway = '192.168.1.1' if interface == 'eth0' else '10.0.1.1'
            requests.post(
                f'{self.api_base}/routing/tables/main/routes',
                json={
                    'destination': '0.0.0.0/0',
                    'gateway': gateway,
                    'interface': interface
                }
            )
            logging.info(f'Switched default route to {interface}')
        except Exception as e:
            logging.error(f'Error switching route: {e}')
    
    def run(self):
        current_wan = self.primary_wan
        
        while True:
            primary_up = self.check_wan_status(self.primary_wan)
            secondary_up = self.check_wan_status(self.secondary_wan)
            
            if current_wan == self.primary_wan and not primary_up and secondary_up:
                self.switch_default_route(self.secondary_wan)
                current_wan = self.secondary_wan
            elif current_wan == self.secondary_wan and primary_up:
                self.switch_default_route(self.primary_wan)
                current_wan = self.primary_wan
                
            time.sleep(self.check_interval)

if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    failover = WANFailover()
    failover.run()`,
            explanation: 'This script continuously monitors WAN interfaces and automatically switches the default route when the primary connection fails.'
          }
        ]
      }
    ]
  }
]

const AdvancedConfiguration: React.FC = () => {
  const [selectedSection, setSelectedSection] = useState('network-topologies')
  const [selectedTopic, setSelectedTopic] = useState('multi-wan-failover')
  const [copiedCommand, setCopiedCommand] = useState<string | null>(null)

  const currentSection = advancedSections.find(section => section.id === selectedSection)
  const currentTopic = currentSection?.topics.find(topic => topic.id === selectedTopic)

  const copyToClipboard = async (text: string, commandId: string) => {
    try {
      await navigator.clipboard.writeText(text)
      setCopiedCommand(commandId)
      setTimeout(() => setCopiedCommand(null), 2000)
    } catch (err) {
      console.error('Failed to copy text: ', err)
    }
  }

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'intermediate': return 'text-yellow-400 bg-yellow-500/20'
      case 'advanced': return 'text-orange-400 bg-orange-500/20'
      case 'expert': return 'text-red-400 bg-red-500/20'
      default: return 'text-gray-400 bg-gray-500/20'
    }
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-white mb-4">Advanced Configuration</h1>
        <p className="text-lg text-gray-300">
          Expert-level features, performance tuning, and advanced network topologies for Pi5 Supernode.
        </p>
      </div>

      {/* Warning */}
      <Card className="p-6 bg-gradient-to-r from-red-500/10 to-orange-500/10 border-red-500/30">
        <div className="flex items-start space-x-3">
          <AlertTriangle className="h-6 w-6 text-red-400 mt-1 flex-shrink-0" />
          <div>
            <h3 className="text-lg font-semibold text-white mb-2">Expert Configuration Warning</h3>
            <p className="text-red-200 mb-3">
              These configurations are for experienced network administrators. Incorrect settings can disrupt network connectivity.
            </p>
            <ul className="space-y-1 text-red-300 text-sm">
              <li>• Always test configurations in a lab environment first</li>
              <li>• Maintain backup configurations and rollback procedures</li>
              <li>• Document all changes for troubleshooting</li>
              <li>• Consider the impact on production traffic</li>
            </ul>
          </div>
        </div>
      </Card>

      <div className="flex flex-col lg:flex-row gap-8">
        {/* Section Navigation */}
        <div className="lg:w-80 flex-shrink-0">
          <div className="sticky top-4 space-y-6">
            <div>
              <h3 className="text-lg font-semibold text-white mb-4">Configuration Areas</h3>
              <nav className="space-y-2">
                {advancedSections.map((section) => {
                  const Icon = section.icon
                  return (
                    <button
                      key={section.id}
                      onClick={() => {
                        setSelectedSection(section.id)
                        setSelectedTopic(section.topics[0]?.id || '')
                      }}
                      className={cn(
                        'w-full text-left p-3 rounded-lg transition-all duration-200',
                        selectedSection === section.id
                          ? 'bg-enterprise-neon/20 border border-enterprise-neon text-white'
                          : 'bg-white/5 border border-white/10 text-gray-300 hover:bg-white/10'
                      )}
                    >
                      <div className="flex items-start space-x-3">
                        <Icon className={cn(
                          'h-5 w-5 mt-0.5',
                          selectedSection === section.id
                            ? 'text-enterprise-neon'
                            : 'text-gray-400'
                        )} />
                        <div className="flex-1">
                          <h4 className="font-medium text-sm">{section.title}</h4>
                          <p className="text-xs text-gray-400 mt-1">{section.description}</p>
                          <span className={cn(
                            'inline-block mt-2 px-2 py-1 rounded text-xs font-medium',
                            getDifficultyColor(section.difficulty)
                          )}>
                            {section.difficulty}
                          </span>
                        </div>
                      </div>
                    </button>
                  )
                })}
              </nav>
            </div>

            {/* Topic Navigation */}
            {currentSection && (
              <div>
                <h3 className="text-lg font-semibold text-white mb-4">Topics</h3>
                <nav className="space-y-1">
                  {currentSection.topics.map((topic) => (
                    <button
                      key={topic.id}
                      onClick={() => setSelectedTopic(topic.id)}
                      className={cn(
                        'w-full text-left p-2 rounded-lg text-sm transition-all duration-200',
                        selectedTopic === topic.id
                          ? 'bg-enterprise-neon/20 text-enterprise-neon'
                          : 'text-gray-400 hover:text-white hover:bg-white/5'
                      )}
                    >
                      {topic.title}
                    </button>
                  ))}
                </nav>
              </div>
            )}
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 min-w-0">
          {currentTopic && (
            <motion.div
              key={`${selectedSection}-${selectedTopic}`}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.3 }}
            >
              <Card className="p-6 border-white/10">
                <div className="mb-6">
                  <h2 className="text-2xl font-bold text-white mb-3">{currentTopic.title}</h2>
                  <p className="text-gray-300">{currentTopic.description}</p>
                </div>

                {/* Prerequisites */}
                {currentTopic.prerequisites && (
                  <div className="mb-6">
                    <h3 className="text-lg font-semibold text-white mb-3 flex items-center">
                      <Info className="h-5 w-5 mr-2 text-blue-400" />
                      Prerequisites
                    </h3>
                    <ul className="space-y-1">
                      {currentTopic.prerequisites.map((prereq, index) => (
                        <li key={index} className="flex items-start space-x-2">
                          <CheckCircle className="h-4 w-4 text-blue-400 mt-1 flex-shrink-0" />
                          <span className="text-gray-300">{prereq}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Warnings */}
                {currentTopic.warnings && (
                  <div className="mb-6">
                    <h3 className="text-lg font-semibold text-white mb-3 flex items-center">
                      <AlertTriangle className="h-5 w-5 mr-2 text-orange-400" />
                      Warnings
                    </h3>
                    <ul className="space-y-1">
                      {currentTopic.warnings.map((warning, index) => (
                        <li key={index} className="flex items-start space-x-2">
                          <AlertTriangle className="h-4 w-4 text-orange-400 mt-1 flex-shrink-0" />
                          <span className="text-orange-200">{warning}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Configurations */}
                <div>
                  <h3 className="text-lg font-semibold text-white mb-4">Configuration Steps</h3>
                  <div className="space-y-6">
                    {currentTopic.configurations.map((config, index) => (
                      <Card key={index} className="p-4 bg-white/5 border-white/10">
                        <div className="flex items-start space-x-3 mb-4">
                          {config.type === 'api' && <Globe className="h-5 w-5 text-green-400 mt-1" />}
                          {config.type === 'config' && <Settings className="h-5 w-5 text-blue-400 mt-1" />}
                          {config.type === 'script' && <Database className="h-5 w-5 text-purple-400 mt-1" />}
                          <div className="flex-1">
                            <h4 className="font-semibold text-white mb-2">{config.title}</h4>
                            <p className="text-gray-300 mb-4">{config.description}</p>
                          </div>
                        </div>

                        <div className="relative mb-4">
                          <div className="bg-black/50 p-4 rounded-lg border border-white/10">
                            <div className="flex items-center justify-between mb-2">
                              <span className="text-sm text-gray-400">
                                {config.type === 'api' ? 'API Commands' : 
                                 config.type === 'config' ? 'Configuration' : 'Script'}
                              </span>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => copyToClipboard(config.code, `config-${index}`)}
                                className="opacity-70 hover:opacity-100"
                              >
                                {copiedCommand === `config-${index}` ? (
                                  <CheckCircle className="h-4 w-4" />
                                ) : (
                                  <Copy className="h-4 w-4" />
                                )}
                              </Button>
                            </div>
                            <pre className="text-green-400 font-mono text-sm overflow-x-auto">
                              {config.code}
                            </pre>
                          </div>
                        </div>

                        <div className="bg-blue-500/10 p-3 rounded-lg border border-blue-500/30">
                          <div className="flex items-start space-x-2">
                            <Info className="h-4 w-4 text-blue-400 mt-0.5 flex-shrink-0" />
                            <p className="text-blue-200 text-sm">{config.explanation}</p>
                          </div>
                        </div>
                      </Card>
                    ))}
                  </div>
                </div>
              </Card>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  )
}

export default AdvancedConfiguration