import React, { useState, useMemo } from 'react'
import { motion } from 'framer-motion'
import { 
  FileText, 
  Search, 
  Filter, 
  Code, 
  Copy, 
  CheckCircle, 
  ExternalLink, 
  Info, 
  AlertTriangle, 
  Play, 
  ArrowRight,
  Book,
  Zap
} from 'lucide-react'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

interface ApiEndpoint {
  method: 'GET' | 'POST' | 'PUT' | 'DELETE'
  path: string
  description: string
  category: string
  parameters?: ApiParameter[]
  responses?: ApiResponse[]
  examples?: string[]
}

interface ApiParameter {
  name: string
  type: string
  required: boolean
  description: string
  example?: string
}

interface ApiResponse {
  status: number
  description: string
  example?: string
}

interface ApiCategory {
  id: string
  name: string
  description: string
  endpointCount: number
}

// API Categories based on the endpoints file
const apiCategories: ApiCategory[] = [
  {
    id: 'interface-discovery',
    name: 'Interface Discovery',
    description: 'Discover and enumerate network interfaces',
    endpointCount: 10
  },
  {
    id: 'interface-management',
    name: 'Interface Management',
    description: 'Create, delete, and configure interfaces',
    endpointCount: 15
  },
  {
    id: 'interface-state',
    name: 'Interface State',
    description: 'Control interface states and properties',
    endpointCount: 12
  },
  {
    id: 'ipv4-configuration',
    name: 'IPv4 Configuration',
    description: 'IPv4 addressing and DHCP management',
    endpointCount: 25
  },
  {
    id: 'ipv6-configuration',
    name: 'IPv6 Configuration',
    description: 'IPv6 addressing and autoconfiguration',
    endpointCount: 20
  },
  {
    id: 'interface-statistics',
    name: 'Statistics & Monitoring',
    description: 'Network traffic statistics and monitoring',
    endpointCount: 30
  },
  {
    id: 'performance-tuning',
    name: 'Performance Tuning',
    description: 'Speed, duplex, and hardware optimization',
    endpointCount: 18
  },
  {
    id: 'vlan-bridging',
    name: 'VLAN & Bridging',
    description: 'VLAN configuration and bridge management',
    endpointCount: 22
  },
  {
    id: 'bonding',
    name: 'Link Aggregation',
    description: 'Bonding and teaming configuration',
    endpointCount: 16
  },
  {
    id: 'routing',
    name: 'Routing',
    description: 'Routing tables, rules, and policies',
    endpointCount: 45
  },
  {
    id: 'bgp',
    name: 'BGP Protocol',
    description: 'BGP configuration and management',
    endpointCount: 35
  },
  {
    id: 'ospf',
    name: 'OSPF Protocol',
    description: 'OSPF routing protocol',
    endpointCount: 25
  },
  {
    id: 'firewall',
    name: 'Firewall',
    description: 'Firewall rules and security policies',
    endpointCount: 40
  },
  {
    id: 'vpn',
    name: 'VPN Services',
    description: 'OpenVPN, WireGuard, and IPsec',
    endpointCount: 35
  },
  {
    id: 'wireless',
    name: 'Wireless',
    description: 'WiFi configuration and management',
    endpointCount: 20
  },
  {
    id: 'dns-dhcp',
    name: 'DNS & DHCP',
    description: 'DNS and DHCP server configuration',
    endpointCount: 30
  },
  {
    id: 'qos',
    name: 'Quality of Service',
    description: 'Traffic shaping and QoS policies',
    endpointCount: 25
  },
  {
    id: 'security',
    name: 'Security',
    description: 'Security monitoring and intrusion detection',
    endpointCount: 18
  },
  {
    id: 'system',
    name: 'System Management',
    description: 'System services and configuration',
    endpointCount: 22
  },
  {
    id: 'ha',
    name: 'High Availability',
    description: 'Clustering and failover management',
    endpointCount: 15
  },
  {
    id: 'api-management',
    name: 'API Management',
    description: 'API security, authentication, and monitoring',
    endpointCount: 28
  }
]

// Sample API endpoints (representing the extensive API from the file)
const sampleEndpoints: ApiEndpoint[] = [
  {
    method: 'GET',
    path: '/interfaces/discover',
    description: 'Discover all network interfaces in the system',
    category: 'interface-discovery',
    responses: [
      {
        status: 200,
        description: 'List of discovered interfaces',
        example: JSON.stringify({
          interfaces: [
            { name: 'eth0', type: 'ethernet', state: 'up' },
            { name: 'wlan0', type: 'wireless', state: 'down' }
          ]
        }, null, 2)
      }
    ],
    examples: [
      'curl -X GET http://localhost:3000/api/interfaces/discover',
      'curl -X GET http://localhost:3000/api/interfaces/discover?type=physical'
    ]
  },
  {
    method: 'POST',
    path: '/interfaces/{ifname}/state/up',
    description: 'Bring a network interface up',
    category: 'interface-state',
    parameters: [
      {
        name: 'ifname',
        type: 'string',
        required: true,
        description: 'Name of the network interface',
        example: 'eth0'
      }
    ],
    responses: [
      {
        status: 200,
        description: 'Interface brought up successfully',
        example: JSON.stringify({ success: true, state: 'up' }, null, 2)
      },
      {
        status: 404,
        description: 'Interface not found',
        example: JSON.stringify({ error: 'Interface not found' }, null, 2)
      }
    ],
    examples: [
      'curl -X POST http://localhost:3000/api/interfaces/eth0/state/up'
    ]
  },
  {
    method: 'POST',
    path: '/interfaces/{ifname}/ipv4/addresses',
    description: 'Add an IPv4 address to an interface',
    category: 'ipv4-configuration',
    parameters: [
      {
        name: 'ifname',
        type: 'string',
        required: true,
        description: 'Name of the network interface',
        example: 'eth0'
      },
      {
        name: 'ip',
        type: 'string',
        required: true,
        description: 'IPv4 address to add',
        example: '192.168.1.100'
      },
      {
        name: 'prefix',
        type: 'number',
        required: true,
        description: 'Network prefix length',
        example: '24'
      }
    ],
    responses: [
      {
        status: 201,
        description: 'IPv4 address added successfully',
        example: JSON.stringify({ success: true, ip: '192.168.1.100/24' }, null, 2)
      }
    ],
    examples: [
      `curl -X POST http://localhost:3000/api/interfaces/eth0/ipv4/addresses \\\n  -H "Content-Type: application/json" \\\n  -d '{"ip": "192.168.1.100", "prefix": 24}'`
    ]
  },
  {
    method: 'GET',
    path: '/interfaces/{ifname}/stats/rx/packets/total',
    description: 'Get total received packets for an interface',
    category: 'interface-statistics',
    parameters: [
      {
        name: 'ifname',
        type: 'string',
        required: true,
        description: 'Name of the network interface',
        example: 'eth0'
      }
    ],
    responses: [
      {
        status: 200,
        description: 'Total received packets count',
        example: JSON.stringify({ total_packets: 1234567 }, null, 2)
      }
    ],
    examples: [
      'curl -X GET http://localhost:3000/api/interfaces/eth0/stats/rx/packets/total'
    ]
  },
  {
    method: 'POST',
    path: '/routing/tables/{table}/routes',
    description: 'Add a new route to a routing table',
    category: 'routing',
    parameters: [
      {
        name: 'table',
        type: 'string',
        required: true,
        description: 'Routing table name or ID',
        example: 'main'
      },
      {
        name: 'destination',
        type: 'string',
        required: true,
        description: 'Destination network',
        example: '10.0.0.0/24'
      },
      {
        name: 'gateway',
        type: 'string',
        required: false,
        description: 'Gateway IP address',
        example: '192.168.1.1'
      }
    ],
    responses: [
      {
        status: 201,
        description: 'Route added successfully',
        example: JSON.stringify({ success: true, route_id: 'rt-123' }, null, 2)
      }
    ],
    examples: [
      `curl -X POST http://localhost:3000/api/routing/tables/main/routes \\\n  -H "Content-Type: application/json" \\\n  -d '{"destination": "10.0.0.0/24", "gateway": "192.168.1.1"}'`
    ]
  }
]

const ApiReference: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedCategory, setSelectedCategory] = useState<string>('all')
  const [selectedEndpoint, setSelectedEndpoint] = useState<ApiEndpoint | null>(null)
  const [copiedCommand, setCopiedCommand] = useState<string | null>(null)

  const filteredCategories = useMemo(() => {
    if (!searchQuery) return apiCategories
    return apiCategories.filter(category => 
      category.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      category.description.toLowerCase().includes(searchQuery.toLowerCase())
    )
  }, [searchQuery])

  const filteredEndpoints = useMemo(() => {
    let endpoints = sampleEndpoints
    
    if (selectedCategory !== 'all') {
      endpoints = endpoints.filter(endpoint => endpoint.category === selectedCategory)
    }
    
    if (searchQuery) {
      endpoints = endpoints.filter(endpoint => 
        endpoint.path.toLowerCase().includes(searchQuery.toLowerCase()) ||
        endpoint.description.toLowerCase().includes(searchQuery.toLowerCase())
      )
    }
    
    return endpoints
  }, [selectedCategory, searchQuery])

  const copyToClipboard = async (text: string, commandId: string) => {
    try {
      await navigator.clipboard.writeText(text)
      setCopiedCommand(commandId)
      setTimeout(() => setCopiedCommand(null), 2000)
    } catch (err) {
      console.error('Failed to copy text: ', err)
    }
  }

  const getMethodColor = (method: string) => {
    switch (method) {
      case 'GET': return 'text-green-400 bg-green-500/20'
      case 'POST': return 'text-blue-400 bg-blue-500/20'
      case 'PUT': return 'text-yellow-400 bg-yellow-500/20'
      case 'DELETE': return 'text-red-400 bg-red-500/20'
      default: return 'text-gray-400 bg-gray-500/20'
    }
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-white mb-4">API Reference</h1>
        <p className="text-lg text-gray-300">
          Complete documentation for all Pi5 Supernode API endpoints with examples and error codes.
        </p>
      </div>

      {/* API Overview */}
      <Card className="p-6 bg-gradient-to-r from-purple-500/10 to-blue-500/10 border-purple-500/30">
        <div className="flex items-start space-x-3">
          <FileText className="h-6 w-6 text-purple-400 mt-1" />
          <div>
            <h3 className="text-lg font-semibold text-white mb-2">API Overview</h3>
            <p className="text-purple-200 mb-4">
              The Pi5 Supernode API provides comprehensive control over network infrastructure. 
              All endpoints return JSON responses and follow RESTful conventions.
            </p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-green-400">500+</div>
                <div className="text-sm text-gray-300">Endpoints</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-400">22</div>
                <div className="text-sm text-gray-300">Categories</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-purple-400">REST</div>
                <div className="text-sm text-gray-300">API Style</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-yellow-400">JSON</div>
                <div className="text-sm text-gray-300">Response Format</div>
              </div>
            </div>
          </div>
        </div>
      </Card>

      {/* Search and Filters */}
      <div className="flex flex-col md:flex-row gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <input
            type="text"
            placeholder="Search endpoints, categories, or descriptions..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-enterprise-neon focus:border-transparent"
          />
        </div>
        <Button
          variant="outline"
          className="border-white/20 text-gray-300 hover:bg-white/10 px-6"
          onClick={() => {
            setSelectedCategory('all')
            setSearchQuery('')
          }}
        >
          <Filter className="h-4 w-4 mr-2" />
          Clear Filters
        </Button>
      </div>

      <div className="flex flex-col lg:flex-row gap-8">
        {/* Categories Sidebar */}
        <div className="lg:w-80 flex-shrink-0">
          <div className="sticky top-4">
            <h3 className="text-lg font-semibold text-white mb-4">API Categories</h3>
            <div className="space-y-2 max-h-96 overflow-y-auto">
              <button
                onClick={() => setSelectedCategory('all')}
                className={cn(
                  'w-full text-left p-3 rounded-lg transition-all duration-200',
                  selectedCategory === 'all'
                    ? 'bg-enterprise-neon/20 border border-enterprise-neon text-white'
                    : 'bg-white/5 border border-white/10 text-gray-300 hover:bg-white/10'
                )}
              >
                <div className="flex items-center justify-between">
                  <span className="font-medium">All Categories</span>
                  <span className="text-xs bg-white/20 px-2 py-1 rounded-full">
                    {apiCategories.reduce((sum, cat) => sum + cat.endpointCount, 0)}
                  </span>
                </div>
              </button>
              
              {filteredCategories.map((category) => (
                <button
                  key={category.id}
                  onClick={() => setSelectedCategory(category.id)}
                  className={cn(
                    'w-full text-left p-3 rounded-lg transition-all duration-200',
                    selectedCategory === category.id
                      ? 'bg-enterprise-neon/20 border border-enterprise-neon text-white'
                      : 'bg-white/5 border border-white/10 text-gray-300 hover:bg-white/10'
                  )}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h4 className="font-medium text-sm">{category.name}</h4>
                      <p className="text-xs text-gray-400 mt-1">{category.description}</p>
                    </div>
                    <span className="text-xs bg-white/20 px-2 py-1 rounded-full ml-2 flex-shrink-0">
                      {category.endpointCount}
                    </span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 min-w-0">
          {selectedEndpoint ? (
            /* Endpoint Detail View */
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.3 }}
            >
              <Card className="p-6 border-white/10">
                <div className="flex items-start justify-between mb-6">
                  <div className="flex items-center space-x-3">
                    <span className={cn(
                      'px-3 py-1 rounded-lg text-sm font-mono font-bold',
                      getMethodColor(selectedEndpoint.method)
                    )}>
                      {selectedEndpoint.method}
                    </span>
                    <code className="text-lg font-mono text-white">{selectedEndpoint.path}</code>
                  </div>
                  <Button
                    variant="outline"
                    onClick={() => setSelectedEndpoint(null)}
                    className="border-white/20 text-gray-300 hover:bg-white/10"
                  >
                    Back to List
                  </Button>
                </div>

                <p className="text-gray-300 mb-6">{selectedEndpoint.description}</p>

                {/* Parameters */}
                {selectedEndpoint.parameters && selectedEndpoint.parameters.length > 0 && (
                  <div className="mb-6">
                    <h3 className="text-lg font-semibold text-white mb-4">Parameters</h3>
                    <div className="space-y-3">
                      {selectedEndpoint.parameters.map((param, index) => (
                        <div key={index} className="bg-white/5 p-4 rounded-lg border border-white/10">
                          <div className="flex items-start justify-between mb-2">
                            <div className="flex items-center space-x-2">
                              <code className="text-enterprise-neon font-mono">{param.name}</code>
                              <span className="text-gray-400 text-sm">({param.type})</span>
                              {param.required && (
                                <span className="text-red-400 text-xs bg-red-500/20 px-2 py-1 rounded-full">
                                  Required
                                </span>
                              )}
                            </div>
                          </div>
                          <p className="text-gray-300 text-sm mb-2">{param.description}</p>
                          {param.example && (
                            <div className="text-xs text-gray-400">
                              Example: <code className="text-green-400">{param.example}</code>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Responses */}
                {selectedEndpoint.responses && (
                  <div className="mb-6">
                    <h3 className="text-lg font-semibold text-white mb-4">Responses</h3>
                    <div className="space-y-3">
                      {selectedEndpoint.responses.map((response, index) => (
                        <div key={index} className="bg-white/5 p-4 rounded-lg border border-white/10">
                          <div className="flex items-center space-x-2 mb-2">
                            <span className={cn(
                              'px-2 py-1 rounded text-xs font-bold',
                              response.status < 300 ? 'bg-green-500/20 text-green-400' :
                              response.status < 400 ? 'bg-yellow-500/20 text-yellow-400' :
                              'bg-red-500/20 text-red-400'
                            )}>
                              {response.status}
                            </span>
                            <span className="text-gray-300">{response.description}</span>
                          </div>
                          {response.example && (
                            <pre className="bg-black/50 p-3 rounded text-sm text-green-400 font-mono overflow-x-auto">
                              {response.example}
                            </pre>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Examples */}
                {selectedEndpoint.examples && (
                  <div>
                    <h3 className="text-lg font-semibold text-white mb-4">Code Examples</h3>
                    <div className="space-y-3">
                      {selectedEndpoint.examples.map((example, index) => (
                        <div key={index} className="relative">
                          <div className="bg-black/50 p-4 rounded-lg border border-white/10">
                            <div className="flex items-center justify-between mb-2">
                              <span className="text-sm text-gray-400">cURL Example {index + 1}</span>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => copyToClipboard(example, `endpoint-${index}`)}
                                className="opacity-70 hover:opacity-100"
                              >
                                {copiedCommand === `endpoint-${index}` ? (
                                  <CheckCircle className="h-4 w-4" />
                                ) : (
                                  <Copy className="h-4 w-4" />
                                )}
                              </Button>
                            </div>
                            <pre className="text-green-400 font-mono text-sm overflow-x-auto">
                              {example}
                            </pre>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </Card>
            </motion.div>
          ) : (
            /* Endpoints List View */
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-semibold text-white">
                  {selectedCategory === 'all' ? 'All Endpoints' : 
                   filteredCategories.find(c => c.id === selectedCategory)?.name || 'Endpoints'}
                </h2>
                <span className="text-gray-400">
                  {filteredEndpoints.length} endpoint{filteredEndpoints.length !== 1 ? 's' : ''}
                </span>
              </div>

              {filteredEndpoints.length === 0 ? (
                <Card className="p-8 border-white/10 text-center">
                  <Search className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-white mb-2">No endpoints found</h3>
                  <p className="text-gray-400">Try adjusting your search criteria or category filter.</p>
                </Card>
              ) : (
                <div className="space-y-3">
                  {filteredEndpoints.map((endpoint, index) => (
                    <motion.div
                      key={`${endpoint.method}-${endpoint.path}`}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.05 }}
                    >
                      <Card className="p-4 border-white/10 hover:border-enterprise-neon/50 transition-colors cursor-pointer">
                        <div 
                          className="flex items-center justify-between"
                          onClick={() => setSelectedEndpoint(endpoint)}
                        >
                          <div className="flex items-center space-x-4">
                            <span className={cn(
                              'px-3 py-1 rounded text-sm font-mono font-bold flex-shrink-0',
                              getMethodColor(endpoint.method)
                            )}>
                              {endpoint.method}
                            </span>
                            <div className="flex-1 min-w-0">
                              <code className="text-white font-mono text-sm">{endpoint.path}</code>
                              <p className="text-gray-400 text-sm mt-1 truncate">{endpoint.description}</p>
                            </div>
                          </div>
                          <ArrowRight className="h-5 w-5 text-gray-400" />
                        </div>
                      </Card>
                    </motion.div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Interactive Testing */}
      {!selectedEndpoint && (
        <Card className="p-6 bg-gradient-to-r from-enterprise-neon/10 to-enterprise-neon-dark/10 border-enterprise-neon/30">
          <div className="flex items-start space-x-3">
            <Play className="h-6 w-6 text-enterprise-neon mt-1" />
            <div>
              <h3 className="text-lg font-semibold text-white mb-2">Interactive API Testing</h3>
              <p className="text-gray-300 mb-4">
                Test API endpoints directly from the documentation interface. 
                Select any endpoint above to see detailed parameters and try it out.
              </p>
              <div className="flex space-x-3">
                <Button className="bg-enterprise-neon text-enterprise-dark hover:bg-enterprise-neon/90">
                  <Zap className="h-4 w-4 mr-2" />
                  Try API Console
                </Button>
                <Button variant="outline" className="border-enterprise-neon text-enterprise-neon hover:bg-enterprise-neon/10">
                  <Book className="h-4 w-4 mr-2" />
                  View Postman Collection
                </Button>
              </div>
            </div>
          </div>
        </Card>
      )}
    </div>
  )
}

export default ApiReference