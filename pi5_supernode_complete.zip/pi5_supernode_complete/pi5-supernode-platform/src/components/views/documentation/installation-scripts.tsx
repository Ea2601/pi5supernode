import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { 
  Download, 
  Terminal, 
  CheckCircle, 
  AlertTriangle, 
  FileText, 
  Play, 
  Copy, 
  ExternalLink 
} from 'lucide-react'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

interface Script {
  id: string
  name: string
  description: string
  filename: string
  size: string
  category: 'main' | 'utility' | 'update'
  features: string[]
  requirements: string[]
  estimatedTime: string
}

const installationScripts: Script[] = [
  {
    id: 'main-installer',
    name: 'Pi5 Supernode Complete Installer',
    description: 'Professional-grade automated installation with comprehensive package management, error handling, and system optimization',
    filename: 'pi5-full-install.sh',
    size: '25 KB',
    category: 'main',
    features: [
      'Network management tools (iproute2, bridge-utils, VLAN, ethtool)',
      'Wireless tools (wpasupplicant, hostapd, dnsmasq)',
      'VPN software (OpenVPN, WireGuard, StrongSwan)',
      'Monitoring tools (iftop, nload, vnstat, tcpdump, iperf3)',
      'Security packages (iptables, fail2ban, UFW)',
      'Development tools and Python packages',
      'Automatic service configuration',
      'System optimization for Pi5 hardware',
      'Progress reporting and error handling',
      'Log rotation and backup setup'
    ],
    requirements: [
      'Raspberry Pi 5 (4GB+ RAM recommended)',
      'Raspberry Pi OS (64-bit) or Ubuntu 22.04+',
      '8GB+ free storage space',
      'Stable internet connection',
      'User account with sudo privileges'
    ],
    estimatedTime: '15-30 minutes'
  },
  {
    id: 'verification',
    name: 'Installation Verification Tool',
    description: 'Comprehensive verification script that validates all installed packages, services, and system configuration',
    filename: 'pi5-verify-install.sh',
    size: '12 KB',
    category: 'utility',
    features: [
      'Package installation verification',
      'Service status checking',
      'Network interface detection',
      'Python package verification',
      'System configuration validation',
      'Wireless capability testing',
      'Detailed status reporting with color coding',
      'Summary statistics and recommendations'
    ],
    requirements: [
      'Pi5 Supernode installation (partial or complete)',
      'Basic system utilities'
    ],
    estimatedTime: '2-5 minutes'
  },
  {
    id: 'uninstall-script',
    name: 'Complete System Uninstaller',
    description: 'Safe removal tool with options for Pi5 Supernode only or complete package cleanup',
    filename: 'pi5-uninstall.sh',
    size: '8 KB',
    category: 'utility',
    features: [
      'Interactive uninstall options',
      'Service cleanup and user removal',
      'Configuration file cleanup',
      'System settings restoration',
      'Optional package removal',
      'Backup creation before removal',
      'Progress tracking and confirmation prompts'
    ],
    requirements: [
      'Existing Pi5 Supernode installation',
      'Root access (sudo privileges)'
    ],
    estimatedTime: '5-10 minutes'
  }
]

const InstallationScripts: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all')
  const [copiedCommand, setCopiedCommand] = useState<string | null>(null)

  const categories = [
    { id: 'all', label: 'All Scripts' },
    { id: 'main', label: 'Main Installer' },
    { id: 'utility', label: 'Utilities' },
    { id: 'update', label: 'Updates' }
  ]

  const filteredScripts = selectedCategory === 'all' 
    ? installationScripts 
    : installationScripts.filter(script => script.category === selectedCategory)

  const copyToClipboard = async (text: string, commandId: string) => {
    try {
      await navigator.clipboard.writeText(text)
      setCopiedCommand(commandId)
      setTimeout(() => setCopiedCommand(null), 2000)
    } catch (err) {
      console.error('Failed to copy text: ', err)
    }
  }

  const downloadScript = (script: Script) => {
    // Download the actual script file from the public directory
    const link = document.createElement('a')
    link.href = `/scripts/${script.filename}`
    link.download = script.filename
    link.setAttribute('target', '_blank')
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-white mb-4">Installation Scripts</h1>
        <p className="text-lg text-gray-300">
          Professional-grade automated installation scripts for Pi5 Supernode setup, verification, and maintenance.
        </p>
      </div>

      {/* Quick Install Command */}
      <Card className="p-6 bg-gradient-to-r from-enterprise-neon/10 to-enterprise-neon-dark/10 border-enterprise-neon/30">
        <div className="flex items-start space-x-3">
          <Terminal className="h-6 w-6 text-enterprise-neon mt-1" />
          <div className="flex-1">
            <h3 className="text-lg font-semibold text-white mb-2">Quick Install Command</h3>
            <p className="text-gray-300 mb-4">
              For immediate installation, download and run the main installer on your Pi5:
            </p>
            <div className="bg-black/50 p-4 rounded-lg flex items-center justify-between border border-white/10">
              <code className="text-green-400 font-mono text-sm flex-1">
                wget /scripts/pi5-full-install.sh && chmod +x pi5-full-install.sh && sudo ./pi5-full-install.sh
              </code>
              <Button
                variant="outline"
                size="sm"
                onClick={() => copyToClipboard('wget /scripts/pi5-full-install.sh && chmod +x pi5-full-install.sh && sudo ./pi5-full-install.sh', 'quick-install')}
                className="ml-3 flex-shrink-0"
              >
                {copiedCommand === 'quick-install' ? (
                  <CheckCircle className="h-4 w-4" />
                ) : (
                  <Copy className="h-4 w-4" />
                )}
              </Button>
            </div>
          </div>
        </div>
      </Card>

      {/* Safety Warning */}
      <Card className="p-6 bg-gradient-to-r from-orange-500/10 to-red-500/10 border-orange-500/30">
        <div className="flex items-start space-x-3">
          <AlertTriangle className="h-6 w-6 text-orange-400 mt-1 flex-shrink-0" />
          <div>
            <h3 className="text-lg font-semibold text-white mb-2">Security Best Practices</h3>
            <ul className="space-y-1 text-orange-200">
              <li>• Always review scripts before running them with sudo privileges</li>
              <li>• Download scripts from trusted sources only</li>
              <li>• Verify checksums when provided</li>
              <li>• Run on test systems before production deployment</li>
              <li>• Backup your system before making major changes</li>
            </ul>
          </div>
        </div>
      </Card>

      {/* Category Filter */}
      <div>
        <h2 className="text-xl font-semibold text-white mb-4">Available Scripts</h2>
        <div className="flex flex-wrap gap-2 mb-6">
          {categories.map((category) => (
            <Button
              key={category.id}
              variant={selectedCategory === category.id ? "default" : "outline"}
              onClick={() => setSelectedCategory(category.id)}
              className={cn(
                selectedCategory === category.id
                  ? "bg-enterprise-neon text-enterprise-dark"
                  : "border-white/20 text-gray-300 hover:bg-white/10"
              )}
            >
              {category.label}
            </Button>
          ))}
        </div>
      </div>

      {/* Scripts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredScripts.map((script, index) => (
          <motion.div
            key={script.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className="p-6 h-full border-white/10 hover:border-enterprise-neon/50 transition-colors">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className="text-xl font-semibold text-white mb-2">{script.name}</h3>
                  <p className="text-gray-300 text-sm mb-3">{script.description}</p>
                  <div className="flex items-center space-x-4 text-sm text-gray-400">
                    <span className="flex items-center space-x-1">
                      <FileText className="h-4 w-4" />
                      <span>{script.size}</span>
                    </span>
                    <span className="flex items-center space-x-1">
                      <Play className="h-4 w-4" />
                      <span>{script.estimatedTime}</span>
                    </span>
                  </div>
                </div>
                <span className={cn(
                  'px-2 py-1 rounded-full text-xs font-medium',
                  script.category === 'main' && 'bg-green-500/20 text-green-300',
                  script.category === 'utility' && 'bg-blue-500/20 text-blue-300',
                  script.category === 'update' && 'bg-purple-500/20 text-purple-300'
                )}>
                  {script.category}
                </span>
              </div>

              <div className="space-y-4">
                <div>
                  <h4 className="text-sm font-medium text-white mb-2">Features:</h4>
                  <ul className="space-y-1">
                    {script.features.slice(0, 4).map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-start space-x-2">
                        <CheckCircle className="h-3 w-3 text-green-400 mt-1 flex-shrink-0" />
                        <span className="text-sm text-gray-300">{feature}</span>
                      </li>
                    ))}
                    {script.features.length > 4 && (
                      <li className="text-sm text-gray-400 ml-5">
                        +{script.features.length - 4} more features
                      </li>
                    )}
                  </ul>
                </div>

                <div>
                  <h4 className="text-sm font-medium text-white mb-2">Requirements:</h4>
                  <ul className="space-y-1">
                    {script.requirements.map((requirement, reqIndex) => (
                      <li key={reqIndex} className="flex items-start space-x-2">
                        <AlertTriangle className="h-3 w-3 text-orange-400 mt-1 flex-shrink-0" />
                        <span className="text-sm text-gray-300">{requirement}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="flex space-x-3 pt-4">
                  <Button
                    onClick={() => downloadScript(script)}
                    className="flex-1 bg-enterprise-neon text-enterprise-dark hover:bg-enterprise-neon/90"
                  >
                    <Download className="h-4 w-4 mr-2" />
                    Download
                  </Button>
                  <Button
                    variant="outline"
                    className="border-white/20 text-gray-300 hover:bg-white/10"
                    onClick={() => {
                      // Open script preview in new tab
                      window.open(`/scripts/${script.filename}`, '_blank')
                    }}
                  >
                    <ExternalLink className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Installation Instructions */}
      <Card className="p-6 border-white/10">
        <h3 className="text-lg font-semibold text-white mb-4">Installation Instructions</h3>
        <div className="space-y-4">
          <div>
            <h4 className="text-sm font-medium text-white mb-2">Method 1: Direct Download and Execute</h4>
            <div className="bg-black/50 p-4 rounded-lg border border-white/10">
              <pre className="text-green-400 font-mono text-sm">
{`# Download the main installer script
wget /scripts/pi5-full-install.sh

# Make it executable
chmod +x pi5-full-install.sh

# Review the script (recommended)
less pi5-full-install.sh

# Run the installation
sudo ./pi5-full-install.sh

# Verify installation
wget /scripts/pi5-verify-install.sh
chmod +x pi5-verify-install.sh
./pi5-verify-install.sh`}
              </pre>
            </div>
          </div>

          <div>
            <h4 className="text-sm font-medium text-white mb-2">Method 2: Direct Installation</h4>
            <div className="bg-black/50 p-4 rounded-lg border border-white/10">
              <pre className="text-green-400 font-mono text-sm">
{`# Single command installation (main installer)
wget /scripts/pi5-full-install.sh && chmod +x pi5-full-install.sh && sudo ./pi5-full-install.sh

# Single command verification
wget /scripts/pi5-verify-install.sh && chmod +x pi5-verify-install.sh && ./pi5-verify-install.sh`}
              </pre>
            </div>
          </div>

          <div>
            <h4 className="text-sm font-medium text-white mb-2">Method 3: Script Management</h4>
            <div className="bg-black/50 p-4 rounded-lg border border-white/10">
              <pre className="text-green-400 font-mono text-sm">
{`# Download all scripts at once
for script in pi5-full-install.sh pi5-verify-install.sh pi5-uninstall.sh; do
  wget /scripts/$script
  chmod +x $script
done

# Run installation with verification
sudo ./pi5-full-install.sh && ./pi5-verify-install.sh`}
              </pre>
            </div>
          </div>
        </div>
      </Card>
    </div>
  )
}

export default InstallationScripts