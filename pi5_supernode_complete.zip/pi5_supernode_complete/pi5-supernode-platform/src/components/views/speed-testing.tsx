import React, { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import {
  Zap,
  Download,
  Upload,
  Activity,
  RefreshCw,
  Clock,
  TrendingUp,
  Calendar,
  Gauge,
  AlertCircle
} from 'lucide-react'
import { useUIStore } from '@/lib/store'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import NetworkSpeedTestingCard from '@/components/ui/network-speed-testing-card'
import MetricCard from '@/components/ui/metric-card'
import TableCard from '@/components/ui/table-card'
import { NetworkService } from '@/lib/services'

interface SpeedTestHistory {
  id: string
  timestamp: string
  download_speed: number
  upload_speed: number
  ping: number
  server_name: string
  test_duration: number
  quality_rating: 'excellent' | 'good' | 'fair' | 'poor'
}

const SpeedTesting: React.FC = () => {
  const { addNotification } = useUIStore()
  const [loading, setLoading] = useState(true)
  const [testHistory, setTestHistory] = useState<SpeedTestHistory[]>([])
  const [isAutoTestEnabled, setIsAutoTestEnabled] = useState(false)
  const [autoTestInterval, setAutoTestInterval] = useState(30) // minutes
  const [speedAlerts, setSpeedAlerts] = useState({
    minDownload: 100, // Mbps
    minUpload: 50, // Mbps
    maxPing: 50 // ms
  })

  useEffect(() => {
    loadSpeedTestData()
  }, [])

  const loadSpeedTestData = async () => {
    try {
      setLoading(true)
      
      // Load speed test history
      const history = await NetworkService.getSpeedTestHistory()
      
      // Transform NetworkSpeedTest[] to SpeedTestHistory[]
      const transformedHistory: SpeedTestHistory[] = history.map(test => ({
        ...test,
        server_name: 'Speed Test Server',
        test_duration: 30,
        quality_rating: test.download_speed > 100 ? 'excellent' : 
                       test.download_speed > 50 ? 'good' : 
                       test.download_speed > 25 ? 'fair' : 'poor' as const
      }))
      
      setTestHistory(transformedHistory)
      
      // Load speed test configuration
      const config = await NetworkService.getSpeedTestConfig()
      setIsAutoTestEnabled(config.auto_test_enabled || false)
      setAutoTestInterval(config.auto_test_interval || 30)
      setSpeedAlerts(config.speed_alerts || speedAlerts)
      
    } catch (error) {
      console.error('Error loading speed test data:', error)
      addNotification({ type: 'error', message: 'Failed to load speed test data' })
    } finally {
      setLoading(false)
    }
  }

  const saveAutoTestSettings = async () => {
    try {
      await NetworkService.saveSpeedTestConfig({
        auto_test_enabled: isAutoTestEnabled,
        auto_test_interval: autoTestInterval,
        speed_alerts: speedAlerts
      })
      
      addNotification({ type: 'success', message: 'Auto-test settings saved successfully' })
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to save auto-test settings' })
    }
  }

  const handleRunSpeedTest = async () => {
    try {
      addNotification({ type: 'info', message: 'Starting network speed test...' })
      
      const result = await NetworkService.runSpeedTest()
      
      // Refresh history after test
      await loadSpeedTestData()
      
      addNotification({ 
        type: 'success', 
        message: `Speed test completed: ${result.download_speed} Mbps down, ${result.upload_speed} Mbps up` 
      })
    } catch (error) {
      addNotification({ type: 'error', message: 'Speed test failed' })
    }
  }

  const calculateAverageSpeed = () => {
    if (testHistory.length === 0) return { download: 0, upload: 0, ping: 0 }
    
    const recent = testHistory.slice(0, 10) // Last 10 tests
    return {
      download: recent.reduce((sum, test) => sum + test.download_speed, 0) / recent.length,
      upload: recent.reduce((sum, test) => sum + test.upload_speed, 0) / recent.length,
      ping: recent.reduce((sum, test) => sum + test.ping, 0) / recent.length
    }
  }

  const getSpeedTrend = () => {
    if (testHistory.length < 2) return 0
    
    const recent = testHistory.slice(0, 5)
    const older = testHistory.slice(5, 10)
    
    if (older.length === 0) return 0
    
    const recentAvg = recent.reduce((sum, test) => sum + test.download_speed, 0) / recent.length
    const olderAvg = older.reduce((sum, test) => sum + test.download_speed, 0) / older.length
    
    return ((recentAvg - olderAvg) / olderAvg) * 100
  }

  const averageSpeed = calculateAverageSpeed()
  const speedTrend = getSpeedTrend()

  const historyColumns = [
    {
      key: 'timestamp' as keyof SpeedTestHistory,
      label: 'Date & Time',
      sortable: true,
      render: (value: any) => (
        <div className="text-sm text-gray-300">
          <div>{new Date(value).toLocaleDateString()}</div>
          <div className="text-gray-500">{new Date(value).toLocaleTimeString()}</div>
        </div>
      )
    },
    {
      key: 'download_speed' as keyof SpeedTestHistory,
      label: 'Download',
      sortable: true,
      render: (value: any) => (
        <div className="flex items-center space-x-2">
          <Download className="h-4 w-4 text-green-400" />
          <span className="font-mono text-green-400">{value.toFixed(2)} Mbps</span>
        </div>
      )
    },
    {
      key: 'upload_speed' as keyof SpeedTestHistory,
      label: 'Upload',
      sortable: true,
      render: (value: any) => (
        <div className="flex items-center space-x-2">
          <Upload className="h-4 w-4 text-blue-400" />
          <span className="font-mono text-blue-400">{value.toFixed(2)} Mbps</span>
        </div>
      )
    },
    {
      key: 'ping' as keyof SpeedTestHistory,
      label: 'Ping',
      sortable: true,
      render: (value: any) => (
        <div className="flex items-center space-x-2">
          <Activity className="h-4 w-4 text-yellow-400" />
          <span className="font-mono text-yellow-400">{value} ms</span>
        </div>
      )
    },
    {
      key: 'server_name' as keyof SpeedTestHistory,
      label: 'Server',
      render: (value: any) => (
        <span className="text-sm text-gray-300">{value}</span>
      )
    },
    {
      key: 'quality_rating' as keyof SpeedTestHistory,
      label: 'Quality',
      render: (value: any) => {
        const colors = {
          excellent: 'bg-green-500/20 text-green-300 border-green-500/30',
          good: 'bg-blue-500/20 text-blue-300 border-blue-500/30',
          fair: 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30',
          poor: 'bg-red-500/20 text-red-300 border-red-500/30'
        }
        return (
          <span className={`status-badge ${colors[value as keyof typeof colors]}`}>
            {value.charAt(0).toUpperCase() + value.slice(1)}
          </span>
        )
      }
    }
  ]

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Network Speed Testing</h1>
          <p className="text-gray-400">Monitor and analyze your network performance</p>
        </div>
        
        <div className="flex items-center space-x-3">
          <Button
            variant="outline"
            onClick={loadSpeedTestData}
            loading={loading}
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          
          <Button 
            variant="neon"
            onClick={handleRunSpeedTest}
          >
            <Zap className="h-4 w-4 mr-2" />
            Run Speed Test
          </Button>
        </div>
      </div>

      {/* Speed Test Card - Main Feature */}
      <NetworkSpeedTestingCard />

      {/* Speed Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard
          title="Avg Download"
          value={`${averageSpeed.download.toFixed(1)} Mbps`}
          subtitle="Last 10 tests"
          icon={Download}
          trend={{ value: Math.abs(speedTrend), isPositive: speedTrend >= 0 }}
          color="success"
          loading={loading}
        />
        
        <MetricCard
          title="Avg Upload"
          value={`${averageSpeed.upload.toFixed(1)} Mbps`}
          subtitle="Last 10 tests"
          icon={Upload}
          trend={{ value: 5, isPositive: true }}
          color="info"
          loading={loading}
        />
        
        <MetricCard
          title="Avg Ping"
          value={`${averageSpeed.ping.toFixed(0)} ms`}
          subtitle="Connection latency"
          icon={Activity}
          color={averageSpeed.ping < 50 ? 'success' : averageSpeed.ping < 100 ? 'warning' : 'danger'}
          loading={loading}
        />
        
        <MetricCard
          title="Tests Today"
          value={testHistory.filter(t => 
            new Date(t.timestamp).toDateString() === new Date().toDateString()
          ).length.toString()}
          subtitle="Completed tests"
          icon={Calendar}
          color="info"
          loading={loading}
        />
      </div>

      {/* Configuration and History */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Auto-Test Configuration */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Clock className="h-5 w-5 text-enterprise-neon" />
              <span>Automated Testing</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <label className="text-sm font-medium text-gray-300">
                  Enable Automatic Speed Tests
                </label>
                <input
                  type="checkbox"
                  checked={isAutoTestEnabled}
                  onChange={(e) => setIsAutoTestEnabled(e.target.checked)}
                  className="enterprise-checkbox"
                />
              </div>
              
              {isAutoTestEnabled && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Test Interval (minutes)
                    </label>
                    <input
                      type="number"
                      min="5"
                      max="1440"
                      value={autoTestInterval}
                      onChange={(e) => setAutoTestInterval(parseInt(e.target.value))}
                      className="enterprise-input w-full"
                    />
                  </div>
                  
                  <div className="space-y-3">
                    <h4 className="text-sm font-medium text-gray-300">Speed Alerts</h4>
                    
                    <div>
                      <label className="block text-xs text-gray-400 mb-1">
                        Minimum Download Speed (Mbps)
                      </label>
                      <input
                        type="number"
                        value={speedAlerts.minDownload}
                        onChange={(e) => setSpeedAlerts(prev => ({ ...prev, minDownload: parseInt(e.target.value) }))}
                        className="enterprise-input w-full text-sm"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-xs text-gray-400 mb-1">
                        Minimum Upload Speed (Mbps)
                      </label>
                      <input
                        type="number"
                        value={speedAlerts.minUpload}
                        onChange={(e) => setSpeedAlerts(prev => ({ ...prev, minUpload: parseInt(e.target.value) }))}
                        className="enterprise-input w-full text-sm"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-xs text-gray-400 mb-1">
                        Maximum Ping (ms)
                      </label>
                      <input
                        type="number"
                        value={speedAlerts.maxPing}
                        onChange={(e) => setSpeedAlerts(prev => ({ ...prev, maxPing: parseInt(e.target.value) }))}
                        className="enterprise-input w-full text-sm"
                      />
                    </div>
                  </div>
                  
                  <Button 
                    onClick={saveAutoTestSettings}
                    className="w-full"
                    variant="neon"
                  >
                    Save Settings
                  </Button>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Speed Trend Chart Placeholder */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <TrendingUp className="h-5 w-5 text-enterprise-neon" />
              <span>Speed Trends</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="text-center text-gray-400 py-8">
                <Gauge className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>Speed trend chart will be displayed here</p>
                <p className="text-sm mt-2">Showing download/upload speeds over time</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Speed Test History */}
      <TableCard
        title="Speed Test History"
        description="Recent network performance tests"
        data={testHistory}
        columns={historyColumns}
        loading={loading}
        emptyMessage="No speed tests found. Run your first speed test to see results here."
      />
    </div>
  )
}

export default SpeedTesting