import React, { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { 
  Rocket, 
  Download, 
  Network, 
  FileText, 
  AlertTriangle, 
  Settings 
} from 'lucide-react'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

// Import documentation sections
import QuickStartGuide from './documentation/quick-start-guide'
import InstallationScripts from './documentation/installation-scripts'
import NetworkManagementGuide from './documentation/network-management-guide'
import ApiReference from './documentation/api-reference'
import TroubleshootingGuide from './documentation/troubleshooting-guide'
import AdvancedConfiguration from './documentation/advanced-configuration'

interface DocumentationSection {
  id: string
  title: string
  icon: React.ComponentType<{ className?: string }>
  description: string
  component: React.ComponentType
}

const documentationSections: DocumentationSection[] = [
  {
    id: 'quick-start',
    title: 'Quick Start Guide',
    icon: Rocket,
    description: 'Fast setup for new users - get your Pi5 Supernode running in minutes',
    component: QuickStartGuide
  },
  {
    id: 'installation',
    title: 'Installation Scripts',
    icon: Download,
    description: 'Downloadable Pi5 auto-setup scripts with complete package installation',
    component: InstallationScripts
  },
  {
    id: 'network',
    title: 'Network Interface Management',
    icon: Network,
    description: 'Complete tutorials for all network interface operations and configurations',
    component: NetworkManagementGuide
  },
  {
    id: 'api-reference',
    title: 'API Reference',
    icon: FileText,
    description: 'Complete endpoint documentation with examples and error codes',
    component: ApiReference
  },
  {
    id: 'troubleshooting',
    title: 'Troubleshooting',
    icon: AlertTriangle,
    description: 'Common issues, solutions, and diagnostic procedures',
    component: TroubleshootingGuide
  },
  {
    id: 'advanced',
    title: 'Advanced Configuration',
    icon: Settings,
    description: 'Expert features, performance tuning, and advanced network topologies',
    component: AdvancedConfiguration
  }
]

const Documentation: React.FC = () => {
  const [activeSection, setActiveSection] = useState('quick-start')
  const [searchQuery, setSearchQuery] = useState('')

  // Listen for section change events
  useEffect(() => {
    const handleSectionChange = (event: CustomEvent) => {
      const { sectionId } = event.detail
      setActiveSection(sectionId)
    }

    window.addEventListener('changeDocumentationSection', handleSectionChange as EventListener)
    
    return () => {
      window.removeEventListener('changeDocumentationSection', handleSectionChange as EventListener)
    }
  }, [])

  const currentSection = documentationSections.find(section => section.id === activeSection)
  const ActiveComponent = currentSection?.component || QuickStartGuide

  const filteredSections = documentationSections.filter(section => 
    section.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    section.description.toLowerCase().includes(searchQuery.toLowerCase())
  )

  return (
    <div className="min-h-screen bg-enterprise-dark">
      {/* Documentation Header */}
      <div className="border-b border-white/10 bg-gradient-to-r from-enterprise-dark to-enterprise-dark/95">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center"
          >
            <h1 className="text-4xl font-bold text-white mb-4">
              Pi5 Supernode Documentation
            </h1>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Complete guide to setup, configure, and manage your Pi5 Supernode network infrastructure
            </p>
            
            {/* Search Bar */}
            <div className="mt-8 max-w-md mx-auto">
              <input
                type="text"
                placeholder="Search documentation..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-enterprise-neon focus:border-transparent"
              />
            </div>
          </motion.div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar Navigation */}
          <div className="lg:w-80 flex-shrink-0">
            <div className="sticky top-4">
              <h2 className="text-lg font-semibold text-white mb-4">Documentation Sections</h2>
              <nav className="space-y-2">
                {filteredSections.map((section) => {
                  const Icon = section.icon
                  return (
                    <motion.button
                      key={section.id}
                      onClick={() => setActiveSection(section.id)}
                      className={cn(
                        'w-full text-left p-4 rounded-lg transition-all duration-200 group',
                        activeSection === section.id
                          ? 'bg-enterprise-neon/20 border border-enterprise-neon text-white'
                          : 'bg-white/5 border border-white/10 text-gray-300 hover:bg-white/10 hover:border-white/20'
                      )}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      <div className="flex items-start space-x-3">
                        <Icon className={cn(
                          'h-5 w-5 mt-0.5 flex-shrink-0',
                          activeSection === section.id
                            ? 'text-enterprise-neon'
                            : 'text-gray-400 group-hover:text-enterprise-neon'
                        )} />
                        <div>
                          <h3 className="font-medium text-sm leading-tight">
                            {section.title}
                          </h3>
                          <p className={cn(
                            'text-xs mt-1 leading-relaxed',
                            activeSection === section.id
                              ? 'text-gray-200'
                              : 'text-gray-400'
                          )}>
                            {section.description}
                          </p>
                        </div>
                      </div>
                    </motion.button>
                  )
                })}
              </nav>
            </div>
          </div>

          {/* Main Content */}
          <div className="flex-1 min-w-0">
            <motion.div
              key={activeSection}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.3 }}
            >
              <ActiveComponent />
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Documentation