import React, { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import {
  Server,
  Plus,
  Edit,
  Trash2,
  RefreshCw,
  Network,
  Globe,
  Settings,
  AlertCircle,
  CheckCircle,
  Users,
  Clock
} from 'lucide-react'
import { useNetworkStore, useUIStore } from '@/lib/store'
import { NetworkService } from '@/lib/services'
import { Button } from '@/components/ui/button'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card'
import TableCard from '@/components/ui/table-card'
import MetricCard from '@/components/ui/metric-card'
import Modal from '@/components/ui/modal'
import { cn } from '@/lib/utils'

interface DHCPPool {
  id: string
  name: string
  network: string
  netmask: string
  range_start: string
  range_end: string
  gateway: string
  dns_servers: string[]
  lease_time: number
  enabled: boolean
  assigned_count: number
  available_count: number
  created_at: string
  updated_at: string
}

interface DHCPFormData {
  name: string
  network: string
  netmask: string
  range_start: string
  range_end: string
  gateway: string
  dns_servers: string
  lease_time: number
  enabled: boolean
}

const NetworkDHCP: React.FC = () => {
  const { addNotification } = useUIStore()
  const [loading, setLoading] = useState(true)
  const [dhcpPools, setDhcpPools] = useState<DHCPPool[]>([])
  const [showModal, setShowModal] = useState(false)
  const [editingPool, setEditingPool] = useState<DHCPPool | null>(null)
  
  const [formData, setFormData] = useState<DHCPFormData>({
    name: '',
    network: '',
    netmask: '255.255.255.0',
    range_start: '',
    range_end: '',
    gateway: '',
    dns_servers: '8.8.8.8, 1.1.1.1',
    lease_time: 86400, // 24 hours
    enabled: true
  })

  useEffect(() => {
    loadDHCPData()
  }, [])

  const loadDHCPData = async () => {
    try {
      setLoading(true)
      
      const pools = await NetworkService.getDHCPPools()
      setDhcpPools(pools)
      
    } catch (error) {
      console.error('Error loading DHCP data:', error)
      addNotification({ type: 'error', message: 'Failed to load DHCP pool data' })
    } finally {
      setLoading(false)
    }
  }

  const resetForm = () => {
    setFormData({
      name: '',
      network: '',
      netmask: '255.255.255.0',
      range_start: '',
      range_end: '',
      gateway: '',
      dns_servers: '8.8.8.8, 1.1.1.1',
      lease_time: 86400,
      enabled: true
    })
  }

  const editPool = (pool: DHCPPool) => {
    setEditingPool(pool)
    setFormData({
      name: pool.name,
      network: pool.network,
      netmask: pool.netmask,
      range_start: pool.range_start,
      range_end: pool.range_end,
      gateway: pool.gateway,
      dns_servers: pool.dns_servers.join(', '),
      lease_time: pool.lease_time,
      enabled: pool.enabled
    })
    setShowModal(true)
  }

  const handleSave = async () => {
    try {
      const poolData = {
        ...formData,
        dns_servers: formData.dns_servers.split(',').map(s => s.trim())
      }
      
      if (editingPool) {
        await NetworkService.updateDHCPPool(editingPool.id, poolData)
        addNotification({ type: 'success', message: 'DHCP pool updated successfully' })
      } else {
        await NetworkService.createDHCPPool(poolData)
        addNotification({ type: 'success', message: 'DHCP pool created successfully' })
      }
      
      setShowModal(false)
      setEditingPool(null)
      resetForm()
      await loadDHCPData()
      
    } catch (error) {
      addNotification({ type: 'error', message: `Failed to ${editingPool ? 'update' : 'create'} DHCP pool` })
    }
  }

  const togglePool = async (pool: DHCPPool) => {
    try {
      await NetworkService.toggleDHCPPool(pool.id, !pool.enabled)
      addNotification({ 
        type: 'success', 
        message: `DHCP pool ${pool.enabled ? 'disabled' : 'enabled'}` 
      })
      await loadDHCPData()
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to toggle DHCP pool' })
    }
  }

  const deletePool = async (pool: DHCPPool) => {
    if (!confirm(`Are you sure you want to delete the DHCP pool "${pool.name}"?`)) return
    
    try {
      await NetworkService.deleteDHCPPool(pool.id)
      addNotification({ type: 'success', message: 'DHCP pool deleted successfully' })
      await loadDHCPData()
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to delete DHCP pool' })
    }
  }

  const restartDHCPService = async () => {
    try {
      addNotification({ type: 'info', message: 'Restarting DHCP service...' })
      await NetworkService.restartDHCPService()
      addNotification({ type: 'success', message: 'DHCP service restarted successfully' })
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to restart DHCP service' })
    }
  }

  const totalAssigned = dhcpPools.reduce((sum, pool) => sum + pool.assigned_count, 0)
  const totalAvailable = dhcpPools.reduce((sum, pool) => sum + pool.available_count, 0)
  const activePools = dhcpPools.filter(pool => pool.enabled).length

  const columns = [
    {
      key: 'name' as keyof DHCPPool,
      label: 'Pool Name',
      sortable: true,
      render: (value: any, item: DHCPPool) => (
        <div className="flex items-center space-x-2">
          {item.enabled ? 
            <CheckCircle className="h-4 w-4 text-green-400" /> : 
            <AlertCircle className="h-4 w-4 text-red-400" />
          }
          <div>
            <div className="font-medium text-white">{value}</div>
            <div className="text-sm text-gray-400">{item.network}/{item.netmask}</div>
          </div>
        </div>
      )
    },
    {
      key: 'range_start' as keyof DHCPPool,
      label: 'IP Range',
      render: (value: any, item: DHCPPool) => (
        <div className="font-mono text-sm">
          <div className="text-enterprise-neon">{value}</div>
          <div className="text-gray-400">to {item.range_end}</div>
        </div>
      )
    },
    {
      key: 'gateway' as keyof DHCPPool,
      label: 'Gateway',
      render: (value: any) => (
        <span className="font-mono text-sm text-gray-300">{value}</span>
      )
    },
    {
      key: 'assigned_count' as keyof DHCPPool,
      label: 'Usage',
      sortable: true,
      render: (value: any, item: DHCPPool) => {
        const total = item.assigned_count + item.available_count
        const percentage = total > 0 ? (item.assigned_count / total) * 100 : 0
        
        return (
          <div className="space-y-1">
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-300">{item.assigned_count} / {total}</span>
              <span className="text-enterprise-neon">{percentage.toFixed(0)}%</span>
            </div>
            <div className="w-full bg-gray-700 rounded-full h-2">
              <div 
                className="bg-enterprise-neon h-2 rounded-full transition-all duration-500"
                style={{ width: `${percentage}%` }}
              />
            </div>
          </div>
        )
      }
    },
    {
      key: 'lease_time' as keyof DHCPPool,
      label: 'Lease Time',
      render: (value: any) => {
        const hours = value / 3600
        return (
          <div className="flex items-center space-x-2">
            <Clock className="h-4 w-4 text-gray-400" />
            <span className="text-sm text-gray-300">{hours}h</span>
          </div>
        )
      }
    },
    {
      key: 'enabled' as keyof DHCPPool,
      label: 'Status',
      sortable: true,
      render: (value: any) => (
        <span className={value ? 'status-active' : 'status-inactive'}>
          {value ? 'Active' : 'Inactive'}
        </span>
      )
    },
    {
      key: 'id' as keyof DHCPPool,
      label: 'Actions',
      render: (value: any, item: DHCPPool) => (
        <div className="flex items-center space-x-2">
          <Button
            size="sm"
            variant="ghost"
            onClick={() => editPool(item)}
          >
            <Edit className="h-4 w-4" />
          </Button>
          
          <Button
            size="sm"
            variant="ghost"
            onClick={() => togglePool(item)}
          >
            <Settings className="h-4 w-4" />
          </Button>
          
          <Button
            size="sm"
            variant="ghost"
            onClick={() => deletePool(item)}
            className="text-red-400 hover:text-red-300"
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      )
    }
  ]

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white mb-1">DHCP Pool Management</h2>
          <p className="text-gray-400">Configure and manage IP address pools</p>
        </div>
        
        <div className="flex items-center space-x-3">
          <Button
            variant="outline"
            onClick={restartDHCPService}
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Restart DHCP
          </Button>
          
          <Button 
            variant="neon"
            onClick={() => {
              resetForm()
              setShowModal(true)
            }}
          >
            <Plus className="h-4 w-4 mr-2" />
            New Pool
          </Button>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          title="Active Pools"
          value={activePools.toString()}
          subtitle={`${dhcpPools.length} total pools`}
          icon={Server}
          color="success"
          loading={loading}
        />
        
        <MetricCard
          title="Assigned IPs"
          value={totalAssigned.toString()}
          subtitle="Currently leased"
          icon={Users}
          color="info"
          loading={loading}
        />
        
        <MetricCard
          title="Available IPs"
          value={totalAvailable.toString()}
          subtitle="Ready for assignment"
          icon={Globe}
          color="warning"
          loading={loading}
        />
        
        <MetricCard
          title="Pool Utilization"
          value={totalAssigned + totalAvailable > 0 ? `${((totalAssigned / (totalAssigned + totalAvailable)) * 100).toFixed(1)}%` : '0%'}
          subtitle="Overall usage"
          icon={Network}
          color="info"
          loading={loading}
        />
      </div>

      {/* DHCP Pools Table */}
      <TableCard
        title="DHCP Pools"
        description={`${dhcpPools.length} configured pools (${activePools} active)`}
        data={dhcpPools}
        columns={columns}
        loading={loading}
        emptyMessage="No DHCP pools configured. Create your first pool to get started."
      />

      {/* Pool Creation/Edit Modal */}
      <Modal
        isOpen={showModal}
        onClose={() => {
          setShowModal(false)
          setEditingPool(null)
          resetForm()
        }}
        title={editingPool ? "Edit DHCP Pool" : "Create New DHCP Pool"}
        size="lg"
      >
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Pool Name
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                className="enterprise-input w-full"
                placeholder="e.g., Main LAN Pool"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Network
              </label>
              <input
                type="text"
                value={formData.network}
                onChange={(e) => setFormData(prev => ({ ...prev, network: e.target.value }))}
                className="enterprise-input w-full"
                placeholder="192.168.1.0"
              />
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Netmask
              </label>
              <input
                type="text"
                value={formData.netmask}
                onChange={(e) => setFormData(prev => ({ ...prev, netmask: e.target.value }))}
                className="enterprise-input w-full"
                placeholder="255.255.255.0"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Gateway
              </label>
              <input
                type="text"
                value={formData.gateway}
                onChange={(e) => setFormData(prev => ({ ...prev, gateway: e.target.value }))}
                className="enterprise-input w-full"
                placeholder="192.168.1.1"
              />
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Range Start
              </label>
              <input
                type="text"
                value={formData.range_start}
                onChange={(e) => setFormData(prev => ({ ...prev, range_start: e.target.value }))}
                className="enterprise-input w-full"
                placeholder="192.168.1.100"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Range End
              </label>
              <input
                type="text"
                value={formData.range_end}
                onChange={(e) => setFormData(prev => ({ ...prev, range_end: e.target.value }))}
                className="enterprise-input w-full"
                placeholder="192.168.1.200"
              />
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              DNS Servers
            </label>
            <input
              type="text"
              value={formData.dns_servers}
              onChange={(e) => setFormData(prev => ({ ...prev, dns_servers: e.target.value }))}
              className="enterprise-input w-full"
              placeholder="8.8.8.8, 1.1.1.1"
            />
            <p className="text-xs text-gray-500 mt-1">Separate multiple DNS servers with commas</p>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Lease Time (seconds)
              </label>
              <input
                type="number"
                value={formData.lease_time}
                onChange={(e) => setFormData(prev => ({ ...prev, lease_time: parseInt(e.target.value) }))}
                className="enterprise-input w-full"
                min="300"
                step="3600"
              />
              <p className="text-xs text-gray-500 mt-1">86400 = 24 hours</p>
            </div>
            
            <div className="flex items-center justify-center">
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={formData.enabled}
                  onChange={(e) => setFormData(prev => ({ ...prev, enabled: e.target.checked }))}
                  className="enterprise-checkbox"
                />
                <span className="text-sm text-gray-300">Enable this pool</span>
              </label>
            </div>
          </div>
          
          <div className="flex justify-end space-x-3 pt-4 border-t border-gray-700">
            <Button
              variant="outline"
              onClick={() => {
                setShowModal(false)
                setEditingPool(null)
                resetForm()
              }}
            >
              Cancel
            </Button>
            
            <Button
              variant="neon"
              onClick={handleSave}
            >
              {editingPool ? 'Update Pool' : 'Create Pool'}
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  )
}

export default NetworkDHCP