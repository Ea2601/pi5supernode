import React, { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import {
  Wifi,
  Plus,
  Edit,
  Trash2,
  RefreshCw,
  Shield,
  Eye,
  EyeOff,
  Signal,
  Users,
  Settings,
  Power,
  Lock,
  Unlock,
  Router
} from 'lucide-react'
import { useNetworkStore, useUIStore } from '@/lib/store'
import { NetworkService } from '@/lib/services'
import { Button } from '@/components/ui/button'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card'
import TableCard from '@/components/ui/table-card'
import MetricCard from '@/components/ui/metric-card'
import Modal from '@/components/ui/modal'
import { cn } from '@/lib/utils'

interface WiFiNetwork {
  id: string
  ssid: string
  password: string
  security_type: 'WPA3' | 'WPA2' | 'WPA/WPA2' | 'Open'
  frequency_band: '2.4GHz' | '5GHz' | 'Dual'
  channel: number
  max_clients: number
  hidden: boolean
  enabled: boolean
  connected_clients: number
  bandwidth_limit?: number
  guest_network: boolean
  vlan_id?: number
  created_at: string
  updated_at: string
}

interface WiFiFormData {
  ssid: string
  password: string
  security_type: 'WPA3' | 'WPA2' | 'WPA/WPA2' | 'Open'
  frequency_band: '2.4GHz' | '5GHz' | 'Dual'
  channel: number
  max_clients: number
  hidden: boolean
  enabled: boolean
  bandwidth_limit?: number
  guest_network: boolean
  vlan_id?: number
}

const NetworkWiFi: React.FC = () => {
  const { addNotification } = useUIStore()
  const [loading, setLoading] = useState(true)
  const [wifiNetworks, setWifiNetworks] = useState<WiFiNetwork[]>([])
  const [showModal, setShowModal] = useState(false)
  const [showPasswordModal, setShowPasswordModal] = useState(false)
  const [editingNetwork, setEditingNetwork] = useState<WiFiNetwork | null>(null)
  const [selectedNetwork, setSelectedNetwork] = useState<WiFiNetwork | null>(null)
  const [showPassword, setShowPassword] = useState<{ [key: string]: boolean }>({})
  
  const [formData, setFormData] = useState<WiFiFormData>({
    ssid: '',
    password: '',
    security_type: 'WPA2',
    frequency_band: '2.4GHz',
    channel: 6,
    max_clients: 50,
    hidden: false,
    enabled: true,
    bandwidth_limit: undefined,
    guest_network: false,
    vlan_id: undefined
  })

  useEffect(() => {
    loadWiFiData()
  }, [])

  const loadWiFiData = async () => {
    try {
      setLoading(true)
      
      const networks = await NetworkService.getWiFiNetworks()
      setWifiNetworks(networks)
      
    } catch (error) {
      console.error('Error loading WiFi data:', error)
      addNotification({ type: 'error', message: 'Failed to load WiFi network data' })
    } finally {
      setLoading(false)
    }
  }

  const resetForm = () => {
    setFormData({
      ssid: '',
      password: '',
      security_type: 'WPA2',
      frequency_band: '2.4GHz',
      channel: 6,
      max_clients: 50,
      hidden: false,
      enabled: true,
      bandwidth_limit: undefined,
      guest_network: false,
      vlan_id: undefined
    })
  }

  const editNetwork = (network: WiFiNetwork) => {
    setEditingNetwork(network)
    setFormData({
      ssid: network.ssid,
      password: network.password,
      security_type: network.security_type,
      frequency_band: network.frequency_band,
      channel: network.channel,
      max_clients: network.max_clients,
      hidden: network.hidden,
      enabled: network.enabled,
      bandwidth_limit: network.bandwidth_limit || undefined,
      guest_network: network.guest_network,
      vlan_id: network.vlan_id || undefined
    })
    setShowModal(true)
  }

  const handleSave = async () => {
    try {
      if (editingNetwork) {
        await NetworkService.updateWiFiNetwork(editingNetwork.id, formData)
        addNotification({ type: 'success', message: 'WiFi network updated successfully' })
      } else {
        await NetworkService.createWiFiNetwork(formData)
        addNotification({ type: 'success', message: 'WiFi network created successfully' })
      }
      
      setShowModal(false)
      setEditingNetwork(null)
      resetForm()
      await loadWiFiData()
      
    } catch (error) {
      addNotification({ type: 'error', message: `Failed to ${editingNetwork ? 'update' : 'create'} WiFi network` })
    }
  }

  const toggleNetwork = async (network: WiFiNetwork) => {
    try {
      await NetworkService.toggleWiFiNetwork(network.id, !network.enabled)
      addNotification({ 
        type: 'success', 
        message: `WiFi network ${network.enabled ? 'disabled' : 'enabled'}` 
      })
      await loadWiFiData()
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to toggle WiFi network' })
    }
  }

  const deleteNetwork = async (network: WiFiNetwork) => {
    if (!confirm(`Are you sure you want to delete the WiFi network "${network.ssid}"?`)) return
    
    try {
      await NetworkService.deleteWiFiNetwork(network.id)
      addNotification({ type: 'success', message: 'WiFi network deleted successfully' })
      await loadWiFiData()
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to delete WiFi network' })
    }
  }

  const generatePassword = () => {
    const chars = 'ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789'
    let password = ''
    for (let i = 0; i < 12; i++) {
      password += chars.charAt(Math.floor(Math.random() * chars.length))
    }
    setFormData(prev => ({ ...prev, password }))
  }

  const copyPassword = (password: string, ssid: string) => {
    navigator.clipboard.writeText(password)
    addNotification({ type: 'success', message: `Password for ${ssid} copied to clipboard` })
  }

  const togglePasswordVisibility = (networkId: string) => {
    setShowPassword(prev => ({
      ...prev,
      [networkId]: !prev[networkId]
    }))
  }

  const restartWiFiService = async () => {
    try {
      addNotification({ type: 'info', message: 'Restarting WiFi service...' })
      await NetworkService.restartWiFiService()
      addNotification({ type: 'success', message: 'WiFi service restarted successfully' })
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to restart WiFi service' })
    }
  }

  const totalConnectedClients = wifiNetworks.reduce((sum, network) => sum + network.connected_clients, 0)
  const activeNetworks = wifiNetworks.filter(network => network.enabled).length
  const guestNetworks = wifiNetworks.filter(network => network.guest_network).length

  const getSecurityIcon = (securityType: string) => {
    switch (securityType) {
      case 'WPA3':
        return <Shield className="h-4 w-4 text-green-400" />
      case 'WPA2':
        return <Lock className="h-4 w-4 text-yellow-400" />
      case 'WPA/WPA2':
        return <Lock className="h-4 w-4 text-yellow-400" />
      case 'Open':
        return <Unlock className="h-4 w-4 text-red-400" />
      default:
        return <Lock className="h-4 w-4 text-gray-400" />
    }
  }

  const getSignalStrength = (channel: number) => {
    // Simulate signal strength based on channel congestion
    const congestion = Math.random()
    if (congestion < 0.3) return { strength: 'Excellent', color: 'text-green-400', bars: 4 }
    if (congestion < 0.6) return { strength: 'Good', color: 'text-yellow-400', bars: 3 }
    if (congestion < 0.8) return { strength: 'Fair', color: 'text-orange-400', bars: 2 }
    return { strength: 'Poor', color: 'text-red-400', bars: 1 }
  }

  const columns = [
    {
      key: 'ssid' as keyof WiFiNetwork,
      label: 'Network Name (SSID)',
      sortable: true,
      render: (value: any, item: WiFiNetwork) => (
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-2">
            <Wifi className={cn(
              'h-4 w-4',
              item.enabled ? 'text-enterprise-neon' : 'text-gray-500'
            )} />
            {getSecurityIcon(item.security_type)}
          </div>
          <div>
            <div className="font-medium text-white flex items-center space-x-2">
              <span>{value}</span>
              {item.hidden && <Eye className="h-3 w-3 text-gray-400" title="Hidden network" />}
              {item.guest_network && <Users className="h-3 w-3 text-blue-400" title="Guest network" />}
            </div>
            <div className="text-sm text-gray-400">
              {item.frequency_band} • Channel {item.channel}
            </div>
          </div>
        </div>
      )
    },
    {
      key: 'security_type' as keyof WiFiNetwork,
      label: 'Security',
      render: (value: any) => {
        const colors = {
          'WPA3': 'bg-green-500/20 text-green-300 border-green-500/30',
          'WPA2': 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30',
          'WPA/WPA2': 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30',
          'Open': 'bg-red-500/20 text-red-300 border-red-500/30'
        }
        return (
          <span className={`status-badge ${colors[value as keyof typeof colors] || 'bg-gray-500/20 text-gray-300 border-gray-500/30'}`}>
            {value}
          </span>
        )
      }
    },
    {
      key: 'connected_clients' as keyof WiFiNetwork,
      label: 'Clients',
      sortable: true,
      render: (value: any, item: WiFiNetwork) => {
        const percentage = item.max_clients > 0 ? (value / item.max_clients) * 100 : 0
        
        return (
          <div className="space-y-1">
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center space-x-2">
                <Users className="h-4 w-4 text-gray-400" />
                <span className="text-gray-300">{value} / {item.max_clients}</span>
              </div>
            </div>
            <div className="w-full bg-gray-700 rounded-full h-1.5">
              <div 
                className={cn(
                  'h-1.5 rounded-full transition-all duration-500',
                  percentage < 50 ? 'bg-green-400' : percentage < 80 ? 'bg-yellow-400' : 'bg-red-400'
                )}
                style={{ width: `${percentage}%` }}
              />
            </div>
          </div>
        )
      }
    },
    {
      key: 'password' as keyof WiFiNetwork,
      label: 'Password',
      render: (value: any, item: WiFiNetwork) => {
        if (item.security_type === 'Open') {
          return <span className="text-gray-500 text-sm">No password</span>
        }
        
        const isVisible = showPassword[item.id]
        
        return (
          <div className="flex items-center space-x-2">
            <span className="font-mono text-sm text-gray-300 select-none">
              {isVisible ? value : '••••••••••••'}
            </span>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => togglePasswordVisibility(item.id)}
            >
              {isVisible ? <EyeOff className="h-3 w-3" /> : <Eye className="h-3 w-3" />}
            </Button>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => copyPassword(value, item.ssid)}
              title="Copy password"
            >
              📋
            </Button>
          </div>
        )
      }
    },
    {
      key: 'channel' as keyof WiFiNetwork,
      label: 'Signal',
      render: (value: any, item: WiFiNetwork) => {
        const signal = getSignalStrength(value)
        return (
          <div className="flex items-center space-x-2">
            <Signal className={`h-4 w-4 ${signal.color}`} />
            <div>
              <div className={`text-sm font-medium ${signal.color}`}>{signal.strength}</div>
              <div className="text-xs text-gray-500">Ch {value}</div>
            </div>
          </div>
        )
      }
    },
    {
      key: 'enabled' as keyof WiFiNetwork,
      label: 'Status',
      sortable: true,
      render: (value: any) => (
        <span className={value ? 'status-active' : 'status-inactive'}>
          {value ? 'Active' : 'Inactive'}
        </span>
      )
    },
    {
      key: 'id' as keyof WiFiNetwork,
      label: 'Actions',
      render: (value: any, item: WiFiNetwork) => (
        <div className="flex items-center space-x-2">
          <Button
            size="sm"
            variant="ghost"
            onClick={() => editNetwork(item)}
          >
            <Edit className="h-4 w-4" />
          </Button>
          
          <Button
            size="sm"
            variant="ghost"
            onClick={() => toggleNetwork(item)}
          >
            <Power className="h-4 w-4" />
          </Button>
          
          <Button
            size="sm"
            variant="ghost"
            onClick={() => deleteNetwork(item)}
            className="text-red-400 hover:text-red-300"
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      )
    }
  ]

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white mb-1">WiFi Network Management</h2>
          <p className="text-gray-400">Configure and manage wireless network settings</p>
        </div>
        
        <div className="flex items-center space-x-3">
          <Button
            variant="outline"
            onClick={restartWiFiService}
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Restart WiFi
          </Button>
          
          <Button 
            variant="neon"
            onClick={() => {
              resetForm()
              setShowModal(true)
            }}
          >
            <Plus className="h-4 w-4 mr-2" />
            New Network
          </Button>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          title="Active Networks"
          value={activeNetworks.toString()}
          subtitle={`${wifiNetworks.length} total networks`}
          icon={Wifi}
          color="success"
          loading={loading}
        />
        
        <MetricCard
          title="Connected Clients"
          value={totalConnectedClients.toString()}
          subtitle="Across all networks"
          icon={Users}
          color="info"
          loading={loading}
        />
        
        <MetricCard
          title="Guest Networks"
          value={guestNetworks.toString()}
          subtitle="Isolated networks"
          icon={Shield}
          color="warning"
          loading={loading}
        />
        
        <MetricCard
          title="Security Level"
          value={wifiNetworks.filter(n => n.security_type === 'WPA3').length > 0 ? 'WPA3' : 'WPA2'}
          subtitle="Best available"
          icon={Lock}
          color="success"
          loading={loading}
        />
      </div>

      {/* WiFi Networks Table */}
      <TableCard
        title="WiFi Networks"
        description={`${wifiNetworks.length} configured networks (${activeNetworks} active)`}
        data={wifiNetworks}
        columns={columns}
        loading={loading}
        emptyMessage="No WiFi networks configured. Create your first network to get started."
      />

      {/* Network Creation/Edit Modal */}
      <Modal
        isOpen={showModal}
        onClose={() => {
          setShowModal(false)
          setEditingNetwork(null)
          resetForm()
        }}
        title={editingNetwork ? "Edit WiFi Network" : "Create New WiFi Network"}
        size="lg"
      >
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Network Name (SSID)
              </label>
              <input
                type="text"
                value={formData.ssid}
                onChange={(e) => setFormData(prev => ({ ...prev, ssid: e.target.value }))}
                className="enterprise-input w-full"
                placeholder="My WiFi Network"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Security Type
              </label>
              <select
                value={formData.security_type}
                onChange={(e) => setFormData(prev => ({ ...prev, security_type: e.target.value as 'WPA3' | 'WPA2' | 'WPA/WPA2' | 'Open' }))}
                className="enterprise-input w-full"
              >
                <option value="WPA3">WPA3 (Recommended)</option>
                <option value="WPA2">WPA2</option>
                <option value="WPA/WPA2">WPA/WPA2 Mixed</option>
                <option value="Open">Open (No Security)</option>
              </select>
            </div>
          </div>
          
          {formData.security_type !== 'Open' && (
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Password
              </label>
              <div className="flex space-x-2">
                <input
                  type="text"
                  value={formData.password}
                  onChange={(e) => setFormData(prev => ({ ...prev, password: e.target.value }))}
                  className="enterprise-input flex-1"
                  placeholder="Enter a secure password"
                />
                <Button
                  type="button"
                  variant="outline"
                  onClick={generatePassword}
                >
                  Generate
                </Button>
              </div>
              <p className="text-xs text-gray-500 mt-1">Minimum 8 characters recommended</p>
            </div>
          )}
          
          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Frequency Band
              </label>
              <select
                value={formData.frequency_band}
                onChange={(e) => setFormData(prev => ({ ...prev, frequency_band: e.target.value as '2.4GHz' | '5GHz' | 'Dual' }))}
                className="enterprise-input w-full"
              >
                <option value="2.4GHz">2.4 GHz</option>
                <option value="5GHz">5 GHz</option>
                <option value="Dual">Dual Band</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Channel
              </label>
              <input
                type="number"
                value={formData.channel}
                onChange={(e) => setFormData(prev => ({ ...prev, channel: parseInt(e.target.value) }))}
                className="enterprise-input w-full"
                min="1"
                max="165"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Max Clients
              </label>
              <input
                type="number"
                value={formData.max_clients}
                onChange={(e) => setFormData(prev => ({ ...prev, max_clients: parseInt(e.target.value) }))}
                className="enterprise-input w-full"
                min="1"
                max="255"
              />
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Bandwidth Limit (Mbps)
              </label>
              <input
                type="number"
                value={formData.bandwidth_limit || ''}
                onChange={(e) => setFormData(prev => ({ ...prev, bandwidth_limit: e.target.value ? parseInt(e.target.value) : undefined }))}
                className="enterprise-input w-full"
                min="0"
                placeholder="0 = No limit"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                VLAN ID (Optional)
              </label>
              <input
                type="number"
                value={formData.vlan_id || ''}
                onChange={(e) => setFormData(prev => ({ ...prev, vlan_id: e.target.value ? parseInt(e.target.value) : undefined }))}
                className="enterprise-input w-full"
                min="0"
                max="4094"
                placeholder="0 = Default"
              />
            </div>
          </div>
          
          <div className="flex items-center justify-between">
            <div className="space-y-2">
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={formData.hidden}
                  onChange={(e) => setFormData(prev => ({ ...prev, hidden: e.target.checked }))}
                  className="enterprise-checkbox"
                />
                <span className="text-sm text-gray-300">Hidden network</span>
              </label>
              
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={formData.guest_network}
                  onChange={(e) => setFormData(prev => ({ ...prev, guest_network: e.target.checked }))}
                  className="enterprise-checkbox"
                />
                <span className="text-sm text-gray-300">Guest network</span>
              </label>
            </div>
            
            <label className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={formData.enabled}
                onChange={(e) => setFormData(prev => ({ ...prev, enabled: e.target.checked }))}
                className="enterprise-checkbox"
              />
              <span className="text-sm text-gray-300">Enable network</span>
            </label>
          </div>
          
          <div className="flex justify-end space-x-3 pt-4 border-t border-gray-700">
            <Button
              variant="outline"
              onClick={() => {
                setShowModal(false)
                setEditingNetwork(null)
                resetForm()
              }}
            >
              Cancel
            </Button>
            
            <Button
              variant="neon"
              onClick={handleSave}
            >
              {editingNetwork ? 'Update Network' : 'Create Network'}
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  )
}

export default NetworkWiFi