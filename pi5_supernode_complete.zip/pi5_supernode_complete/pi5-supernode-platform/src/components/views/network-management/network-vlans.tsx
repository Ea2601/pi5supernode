import React, { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import {
  Layers,
  Plus,
  Edit,
  Trash2,
  RefreshCw,
  Network,
  Shield,
  Users,
  Settings,
  Power,
  Router,
  Globe,
  Tag
} from 'lucide-react'
import { useNetworkStore, useUIStore } from '@/lib/store'
import { NetworkService } from '@/lib/services'
import { Button } from '@/components/ui/button'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card'
import TableCard from '@/components/ui/table-card'
import MetricCard from '@/components/ui/metric-card'
import Modal from '@/components/ui/modal'
import { cn } from '@/lib/utils'

interface VLAN {
  id: string
  vlan_id: number
  name: string
  description?: string
  subnet: string
  gateway: string
  dhcp_enabled: boolean
  dhcp_start?: string
  dhcp_end?: string
  isolation_enabled: boolean
  internet_access: boolean
  inter_vlan_routing: boolean
  tagged_ports: number[]
  untagged_ports: number[]
  connected_devices: number
  enabled: boolean
  created_at: string
  updated_at: string
}

interface VLANFormData {
  vlan_id: number
  name: string
  description: string
  subnet: string
  gateway: string
  dhcp_enabled: boolean
  dhcp_start: string
  dhcp_end: string
  isolation_enabled: boolean
  internet_access: boolean
  inter_vlan_routing: boolean
  tagged_ports: number[]
  untagged_ports: number[]
  enabled: boolean
}

const NetworkVLANs: React.FC = () => {
  const { addNotification } = useUIStore()
  const [loading, setLoading] = useState(true)
  const [vlans, setVlans] = useState<VLAN[]>([])
  const [showModal, setShowModal] = useState(false)
  const [editingVlan, setEditingVlan] = useState<VLAN | null>(null)
  const [availablePorts] = useState<number[]>([1, 2, 3, 4, 5, 6, 7, 8]) // Switch ports
  
  const [formData, setFormData] = useState<VLANFormData>({
    vlan_id: 10,
    name: '',
    description: '',
    subnet: '',
    gateway: '',
    dhcp_enabled: true,
    dhcp_start: '',
    dhcp_end: '',
    isolation_enabled: false,
    internet_access: true,
    inter_vlan_routing: false,
    tagged_ports: [],
    untagged_ports: [],
    enabled: true
  })

  useEffect(() => {
    loadVLANData()
  }, [])

  const loadVLANData = async () => {
    try {
      setLoading(true)
      
      const vlanData = await NetworkService.getVLANs()
      setVlans(vlanData)
      
    } catch (error) {
      console.error('Error loading VLAN data:', error)
      addNotification({ type: 'error', message: 'Failed to load VLAN data' })
    } finally {
      setLoading(false)
    }
  }

  const resetForm = () => {
    setFormData({
      vlan_id: getNextAvailableVlanId(),
      name: '',
      description: '',
      subnet: '',
      gateway: '',
      dhcp_enabled: true,
      dhcp_start: '',
      dhcp_end: '',
      isolation_enabled: false,
      internet_access: true,
      inter_vlan_routing: false,
      tagged_ports: [],
      untagged_ports: [],
      enabled: true
    })
  }

  const getNextAvailableVlanId = () => {
    const usedIds = vlans.map(v => v.vlan_id).sort((a, b) => a - b)
    for (let i = 10; i <= 4094; i++) {
      if (!usedIds.includes(i)) {
        return i
      }
    }
    return 10
  }

  const editVlan = (vlan: VLAN) => {
    setEditingVlan(vlan)
    setFormData({
      vlan_id: vlan.vlan_id,
      name: vlan.name,
      description: vlan.description || '',
      subnet: vlan.subnet,
      gateway: vlan.gateway,
      dhcp_enabled: vlan.dhcp_enabled,
      dhcp_start: vlan.dhcp_start || '',
      dhcp_end: vlan.dhcp_end || '',
      isolation_enabled: vlan.isolation_enabled,
      internet_access: vlan.internet_access,
      inter_vlan_routing: vlan.inter_vlan_routing,
      tagged_ports: vlan.tagged_ports,
      untagged_ports: vlan.untagged_ports,
      enabled: vlan.enabled
    })
    setShowModal(true)
  }

  const handleSave = async () => {
    try {
      if (editingVlan) {
        await NetworkService.updateVLAN(editingVlan.id, formData)
        addNotification({ type: 'success', message: 'VLAN updated successfully' })
      } else {
        await NetworkService.createVLAN(formData)
        addNotification({ type: 'success', message: 'VLAN created successfully' })
      }
      
      setShowModal(false)
      setEditingVlan(null)
      resetForm()
      await loadVLANData()
      
    } catch (error) {
      addNotification({ type: 'error', message: `Failed to ${editingVlan ? 'update' : 'create'} VLAN` })
    }
  }

  const toggleVlan = async (vlan: VLAN) => {
    try {
      await NetworkService.toggleVLAN(vlan.id, !vlan.enabled)
      addNotification({ 
        type: 'success', 
        message: `VLAN ${vlan.enabled ? 'disabled' : 'enabled'}` 
      })
      await loadVLANData()
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to toggle VLAN' })
    }
  }

  const deleteVlan = async (vlan: VLAN) => {
    if (!confirm(`Are you sure you want to delete VLAN "${vlan.name}" (ID: ${vlan.vlan_id})?`)) return
    
    try {
      await NetworkService.deleteVLAN(vlan.id)
      addNotification({ type: 'success', message: 'VLAN deleted successfully' })
      await loadVLANData()
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to delete VLAN' })
    }
  }

  const generateSubnet = (vlanId: number) => {
    const subnet = `192.168.${vlanId}.0/24`
    const gateway = `192.168.${vlanId}.1`
    const dhcpStart = `192.168.${vlanId}.100`
    const dhcpEnd = `192.168.${vlanId}.200`
    
    setFormData(prev => ({
      ...prev,
      subnet,
      gateway,
      dhcp_start: dhcpStart,
      dhcp_end: dhcpEnd
    }))
  }

  const handlePortSelection = (portType: 'tagged' | 'untagged', port: number, checked: boolean) => {
    setFormData(prev => {
      const currentPorts = prev[`${portType}_ports`]
      const otherPorts = prev[`${portType === 'tagged' ? 'untagged' : 'tagged'}_ports`]
      
      // Remove from other port type if adding
      if (checked) {
        const updatedOtherPorts = otherPorts.filter(p => p !== port)
        return {
          ...prev,
          [`${portType}_ports`]: [...currentPorts, port].sort(),
          [`${portType === 'tagged' ? 'untagged' : 'tagged'}_ports`]: updatedOtherPorts
        }
      } else {
        return {
          ...prev,
          [`${portType}_ports`]: currentPorts.filter(p => p !== port)
        }
      }
    })
  }

  const restartVLANService = async () => {
    try {
      addNotification({ type: 'info', message: 'Restarting VLAN service...' })
      await NetworkService.restartVLANService()
      addNotification({ type: 'success', message: 'VLAN service restarted successfully' })
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to restart VLAN service' })
    }
  }

  const activeVlans = vlans.filter(vlan => vlan.enabled).length
  const totalDevices = vlans.reduce((sum, vlan) => sum + vlan.connected_devices, 0)
  const isolatedVlans = vlans.filter(vlan => vlan.isolation_enabled).length

  const getVlanColor = (vlanId: number) => {
    const colors = ['bg-blue-500', 'bg-green-500', 'bg-yellow-500', 'bg-red-500', 'bg-purple-500', 'bg-pink-500', 'bg-indigo-500', 'bg-cyan-500']
    return colors[vlanId % colors.length]
  }

  const columns = [
    {
      key: 'vlan_id' as keyof VLAN,
      label: 'VLAN',
      sortable: true,
      render: (value: any, item: VLAN) => (
        <div className="flex items-center space-x-3">
          <div className={`w-4 h-4 rounded ${getVlanColor(value)} ${item.enabled ? '' : 'opacity-50'}`} />
          <div>
            <div className="font-medium text-white flex items-center space-x-2">
              <Tag className="h-4 w-4 text-enterprise-neon" />
              <span>ID {value}</span>
            </div>
            <div className="text-sm text-gray-400">{item.name}</div>
          </div>
        </div>
      )
    },
    {
      key: 'subnet' as keyof VLAN,
      label: 'Network',
      render: (value: any, item: VLAN) => (
        <div className="font-mono text-sm">
          <div className="text-enterprise-neon">{value}</div>
          <div className="text-gray-400">GW: {item.gateway}</div>
        </div>
      )
    },
    {
      key: 'dhcp_enabled' as keyof VLAN,
      label: 'DHCP',
      render: (value: any, item: VLAN) => (
        <div className="text-sm">
          <div className={value ? 'text-green-400' : 'text-gray-400'}>
            {value ? 'Enabled' : 'Disabled'}
          </div>
          {value && item.dhcp_start && item.dhcp_end && (
            <div className="text-gray-500 font-mono text-xs">
              {item.dhcp_start} - {item.dhcp_end}
            </div>
          )}
        </div>
      )
    },
    {
      key: 'tagged_ports' as keyof VLAN,
      label: 'Ports',
      render: (value: any, item: VLAN) => (
        <div className="text-sm space-y-1">
          {item.tagged_ports.length > 0 && (
            <div className="flex items-center space-x-2">
              <span className="text-gray-400">Tagged:</span>
              <div className="flex space-x-1">
                {item.tagged_ports.map(port => (
                  <span key={port} className="px-1.5 py-0.5 bg-blue-500/20 text-blue-300 rounded text-xs">
                    {port}
                  </span>
                ))}
              </div>
            </div>
          )}
          {item.untagged_ports.length > 0 && (
            <div className="flex items-center space-x-2">
              <span className="text-gray-400">Untagged:</span>
              <div className="flex space-x-1">
                {item.untagged_ports.map(port => (
                  <span key={port} className="px-1.5 py-0.5 bg-gray-500/20 text-gray-300 rounded text-xs">
                    {port}
                  </span>
                ))}
              </div>
            </div>
          )}
          {item.tagged_ports.length === 0 && item.untagged_ports.length === 0 && (
            <span className="text-gray-500">No ports assigned</span>
          )}
        </div>
      )
    },
    {
      key: 'connected_devices' as keyof VLAN,
      label: 'Devices',
      sortable: true,
      render: (value: any) => (
        <div className="flex items-center space-x-2">
          <Users className="h-4 w-4 text-gray-400" />
          <span className="text-gray-300">{value}</span>
        </div>
      )
    },
    {
      key: 'isolation_enabled' as keyof VLAN,
      label: 'Security',
      render: (value: any, item: VLAN) => (
        <div className="space-y-1">
          <div className={`flex items-center space-x-2 ${value ? 'text-yellow-400' : 'text-gray-400'}`}>
            <Shield className="h-3 w-3" />
            <span className="text-xs">{value ? 'Isolated' : 'Open'}</span>
          </div>
          <div className={`flex items-center space-x-2 ${item.internet_access ? 'text-green-400' : 'text-red-400'}`}>
            <Globe className="h-3 w-3" />
            <span className="text-xs">{item.internet_access ? 'Internet' : 'No Internet'}</span>
          </div>
        </div>
      )
    },
    {
      key: 'enabled' as keyof VLAN,
      label: 'Status',
      sortable: true,
      render: (value: any) => (
        <span className={value ? 'status-active' : 'status-inactive'}>
          {value ? 'Active' : 'Inactive'}
        </span>
      )
    },
    {
      key: 'id' as keyof VLAN,
      label: 'Actions',
      render: (value: any, item: VLAN) => (
        <div className="flex items-center space-x-2">
          <Button
            size="sm"
            variant="ghost"
            onClick={() => editVlan(item)}
          >
            <Edit className="h-4 w-4" />
          </Button>
          
          <Button
            size="sm"
            variant="ghost"
            onClick={() => toggleVlan(item)}
          >
            <Power className="h-4 w-4" />
          </Button>
          
          <Button
            size="sm"
            variant="ghost"
            onClick={() => deleteVlan(item)}
            className="text-red-400 hover:text-red-300"
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      )
    }
  ]

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white mb-1">VLAN Management</h2>
          <p className="text-gray-400">Configure virtual LAN segmentation and isolation</p>
        </div>
        
        <div className="flex items-center space-x-3">
          <Button
            variant="outline"
            onClick={restartVLANService}
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Restart VLANs
          </Button>
          
          <Button 
            variant="neon"
            onClick={() => {
              resetForm()
              setShowModal(true)
            }}
          >
            <Plus className="h-4 w-4 mr-2" />
            New VLAN
          </Button>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          title="Active VLANs"
          value={activeVlans.toString()}
          subtitle={`${vlans.length} total VLANs`}
          icon={Layers}
          color="success"
          loading={loading}
        />
        
        <MetricCard
          title="Connected Devices"
          value={totalDevices.toString()}
          subtitle="Across all VLANs"
          icon={Users}
          color="info"
          loading={loading}
        />
        
        <MetricCard
          title="Isolated Networks"
          value={isolatedVlans.toString()}
          subtitle="Security enabled"
          icon={Shield}
          color="warning"
          loading={loading}
        />
        
        <MetricCard
          title="Port Utilization"
          value={`${Math.round((vlans.length / availablePorts.length) * 100)}%`}
          subtitle="Switch ports used"
          icon={Router}
          color="info"
          loading={loading}
        />
      </div>

      {/* VLANs Table */}
      <TableCard
        title="VLAN Configuration"
        description={`${vlans.length} configured VLANs (${activeVlans} active)`}
        data={vlans}
        columns={columns}
        loading={loading}
        emptyMessage="No VLANs configured. Create your first VLAN to segment your network."
      />

      {/* VLAN Creation/Edit Modal */}
      <Modal
        isOpen={showModal}
        onClose={() => {
          setShowModal(false)
          setEditingVlan(null)
          resetForm()
        }}
        title={editingVlan ? "Edit VLAN" : "Create New VLAN"}
        size="lg"
      >
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                VLAN ID
              </label>
              <input
                type="number"
                value={formData.vlan_id}
                onChange={(e) => setFormData(prev => ({ ...prev, vlan_id: parseInt(e.target.value) }))}
                className="enterprise-input w-full"
                min="1"
                max="4094"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                VLAN Name
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                className="enterprise-input w-full"
                placeholder="e.g., Guest Network"
              />
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Description
            </label>
            <textarea
              value={formData.description}
              onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              className="enterprise-input w-full h-20 resize-none"
              placeholder="Describe this VLAN..."
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Subnet (CIDR)
              </label>
              <div className="flex space-x-2">
                <input
                  type="text"
                  value={formData.subnet}
                  onChange={(e) => setFormData(prev => ({ ...prev, subnet: e.target.value }))}
                  className="enterprise-input flex-1"
                  placeholder="192.168.10.0/24"
                />
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => generateSubnet(formData.vlan_id)}
                >
                  Auto
                </Button>
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Gateway IP
              </label>
              <input
                type="text"
                value={formData.gateway}
                onChange={(e) => setFormData(prev => ({ ...prev, gateway: e.target.value }))}
                className="enterprise-input w-full"
                placeholder="192.168.10.1"
              />
            </div>
          </div>
          
          <div className="space-y-3">
            <label className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={formData.dhcp_enabled}
                onChange={(e) => setFormData(prev => ({ ...prev, dhcp_enabled: e.target.checked }))}
                className="enterprise-checkbox"
              />
              <span className="text-sm text-gray-300">Enable DHCP</span>
            </label>
            
            {formData.dhcp_enabled && (
              <div className="grid grid-cols-2 gap-4 pl-6">
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-1">
                    DHCP Start IP
                  </label>
                  <input
                    type="text"
                    value={formData.dhcp_start}
                    onChange={(e) => setFormData(prev => ({ ...prev, dhcp_start: e.target.value }))}
                    className="enterprise-input w-full text-sm"
                    placeholder="192.168.10.100"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-1">
                    DHCP End IP
                  </label>
                  <input
                    type="text"
                    value={formData.dhcp_end}
                    onChange={(e) => setFormData(prev => ({ ...prev, dhcp_end: e.target.value }))}
                    className="enterprise-input w-full text-sm"
                    placeholder="192.168.10.200"
                  />
                </div>
              </div>
            )}
          </div>
          
          <div className="space-y-3">
            <h4 className="text-sm font-medium text-gray-300">Port Assignment</h4>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">Tagged Ports</label>
                <div className="grid grid-cols-4 gap-2">
                  {availablePorts.map(port => (
                    <label key={`tagged-${port}`} className="flex items-center space-x-1">
                      <input
                        type="checkbox"
                        checked={formData.tagged_ports.includes(port)}
                        onChange={(e) => handlePortSelection('tagged', port, e.target.checked)}
                        className="enterprise-checkbox"
                      />
                      <span className="text-xs text-gray-400">Port {port}</span>
                    </label>
                  ))}
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">Untagged Ports</label>
                <div className="grid grid-cols-4 gap-2">
                  {availablePorts.map(port => (
                    <label key={`untagged-${port}`} className="flex items-center space-x-1">
                      <input
                        type="checkbox"
                        checked={formData.untagged_ports.includes(port)}
                        onChange={(e) => handlePortSelection('untagged', port, e.target.checked)}
                        className="enterprise-checkbox"
                      />
                      <span className="text-xs text-gray-400">Port {port}</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
          </div>
          
          <div className="space-y-3">
            <h4 className="text-sm font-medium text-gray-300">Security & Access</h4>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    checked={formData.isolation_enabled}
                    onChange={(e) => setFormData(prev => ({ ...prev, isolation_enabled: e.target.checked }))}
                    className="enterprise-checkbox"
                  />
                  <span className="text-sm text-gray-300">Client isolation</span>
                </label>
                
                <label className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    checked={formData.internet_access}
                    onChange={(e) => setFormData(prev => ({ ...prev, internet_access: e.target.checked }))}
                    className="enterprise-checkbox"
                  />
                  <span className="text-sm text-gray-300">Internet access</span>
                </label>
              </div>
              
              <div className="space-y-2">
                <label className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    checked={formData.inter_vlan_routing}
                    onChange={(e) => setFormData(prev => ({ ...prev, inter_vlan_routing: e.target.checked }))}
                    className="enterprise-checkbox"
                  />
                  <span className="text-sm text-gray-300">Inter-VLAN routing</span>
                </label>
                
                <label className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    checked={formData.enabled}
                    onChange={(e) => setFormData(prev => ({ ...prev, enabled: e.target.checked }))}
                    className="enterprise-checkbox"
                  />
                  <span className="text-sm text-gray-300">Enable VLAN</span>
                </label>
              </div>
            </div>
          </div>
          
          <div className="flex justify-end space-x-3 pt-4 border-t border-gray-700">
            <Button
              variant="outline"
              onClick={() => {
                setShowModal(false)
                setEditingVlan(null)
                resetForm()
              }}
            >
              Cancel
            </Button>
            
            <Button
              variant="neon"
              onClick={handleSave}
            >
              {editingVlan ? 'Update VLAN' : 'Create VLAN'}
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  )
}

export default NetworkVLANs