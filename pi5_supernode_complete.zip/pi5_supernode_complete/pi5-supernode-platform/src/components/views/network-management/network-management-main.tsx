import React, { useState, useEffect } from 'react'
import { NavLink, Outlet, useLocation } from 'react-router-dom'
import { motion } from 'framer-motion'
import {
  Network,
  Router,
  Wifi,
  Layers,
  Server,
  Globe,
  Settings,
  RefreshCw,
  TrendingUp
} from 'lucide-react'
import { useNetworkStore, useUIStore } from '@/lib/store'
import { NetworkService } from '@/lib/services'
import { Button } from '@/components/ui/button'
import MetricCard from '@/components/ui/metric-card'
import { cn } from '@/lib/utils'

const NetworkManagementMain: React.FC = () => {
  const { addNotification } = useUIStore()
  const [loading, setLoading] = useState(false)
  const [networkStats, setNetworkStats] = useState({
    total_dhcp_pools: 0,
    active_wifi_networks: 0,
    configured_vlans: 0,
    active_connections: 0
  })
  
  const location = useLocation()
  
  useEffect(() => {
    loadNetworkStats()
  }, [])

  const loadNetworkStats = async () => {
    try {
      setLoading(true)
      
      // Load network management statistics
      const stats = await NetworkService.getNetworkManagementStats()
      setNetworkStats(stats.data || {
        total_dhcp_pools: 2,
        active_wifi_networks: 3,
        configured_vlans: 1,
        active_connections: 5
      })
      
    } catch (error) {
      console.error('Error loading network stats:', error)
      addNotification({ type: 'error', message: 'Failed to load network statistics' })
    } finally {
      setLoading(false)
    }
  }

  const refreshAll = async () => {
    setLoading(true)
    try {
      await loadNetworkStats()
      addNotification({ type: 'success', message: 'Network data refreshed' })
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to refresh network data' })
    } finally {
      setLoading(false)
    }
  }

  const navigationItems = [
    {
      path: '/network-management/dhcp',
      label: 'DHCP Pools',
      icon: Server,
      description: 'Manage DHCP pool configurations'
    },
    {
      path: '/network-management/wifi',
      label: 'WiFi Networks',
      icon: Wifi,
      description: 'Configure wireless networks'
    },
    {
      path: '/network-management/vlans',
      label: 'VLANs',
      icon: Layers,
      description: 'Virtual LAN management'
    }
  ]

  // Check if we're on the main network management page (no subroute)
  const isMainPage = location.pathname === '/network-management'

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Network Management</h1>
          <p className="text-gray-400">Comprehensive network infrastructure configuration</p>
        </div>
        
        <div className="flex items-center space-x-3">
          <Button
            variant="outline"
            onClick={refreshAll}
            loading={loading}
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
        </div>
      </div>

      {/* Quick Stats - Only show on main page */}
      {isMainPage && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <MetricCard
            title="DHCP Pools"
            value={networkStats.total_dhcp_pools.toString()}
            subtitle="Configured pools"
            icon={Server}
            color="success"
            loading={loading}
          />
          
          <MetricCard
            title="WiFi Networks"
            value={networkStats.active_wifi_networks.toString()}
            subtitle="Active networks"
            icon={Wifi}
            color="info"
            loading={loading}
          />
          
          <MetricCard
            title="VLANs"
            value={networkStats.configured_vlans.toString()}
            subtitle="Virtual LANs"
            icon={Layers}
            color="warning"
            loading={loading}
          />
          
          <MetricCard
            title="Connections"
            value={networkStats.active_connections.toString()}
            subtitle="Active clients"
            icon={Globe}
            color="success"
            loading={loading}
          />
        </div>
      )}

      {/* Navigation Tabs */}
      <div className="flex space-x-1 glassmorphism-card bg-gray-800/30 p-1 rounded-lg w-fit">
        {navigationItems.map((item) => {
          const Icon = item.icon
          const isActive = location.pathname.startsWith(item.path)
          
          return (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive: navLinkActive }) => cn(
                'flex items-center space-x-2 px-4 py-2 rounded-md transition-all duration-200',
                (isActive || navLinkActive)
                  ? 'bg-enterprise-neon/20 text-enterprise-neon border border-enterprise-neon/30'
                  : 'text-gray-400 hover:text-gray-200 hover:bg-gray-700/30'
              )}
            >
              <Icon className="h-4 w-4" />
              <span className="text-sm font-medium">{item.label}</span>
            </NavLink>
          )
        })}
      </div>

      {/* Main Overview Content - Only show when no subroute is active */}
      {isMainPage && (
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
          {navigationItems.map((item) => {
            const Icon = item.icon
            return (
              <motion.div
                key={item.path}
                whileHover={{ y: -2, scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <NavLink to={item.path}>
                  <div className="glassmorphism-card h-full p-6 cursor-pointer border border-transparent hover:border-enterprise-neon/30 transition-all duration-200">
                    <div className="flex items-center space-x-4 mb-4">
                      <div className="w-12 h-12 bg-gradient-to-r from-enterprise-neon/20 to-enterprise-neon-dark/20 rounded-lg flex items-center justify-center">
                        <Icon className="h-6 w-6 text-enterprise-neon" />
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold text-white">{item.label}</h3>
                        <p className="text-sm text-gray-400">{item.description}</p>
                      </div>
                    </div>
                    
                    <div className="space-y-3">
                      {item.path.includes('dhcp') && (
                        <div className="text-sm text-gray-300">
                          <div className="flex justify-between">
                            <span>Configured Pools:</span>
                            <span className="text-enterprise-neon">{networkStats.total_dhcp_pools}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>IP Ranges:</span>
                            <span className="text-gray-400">Multiple subnets</span>
                          </div>
                        </div>
                      )}
                      
                      {item.path.includes('wifi') && (
                        <div className="text-sm text-gray-300">
                          <div className="flex justify-between">
                            <span>Active Networks:</span>
                            <span className="text-enterprise-neon">{networkStats.active_wifi_networks}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Security:</span>
                            <span className="text-gray-400">WPA3/WPA2</span>
                          </div>
                        </div>
                      )}
                      
                      {item.path.includes('vlans') && (
                        <div className="text-sm text-gray-300">
                          <div className="flex justify-between">
                            <span>Configured VLANs:</span>
                            <span className="text-enterprise-neon">{networkStats.configured_vlans}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Isolation:</span>
                            <span className="text-gray-400">Layer 2/3</span>
                          </div>
                        </div>
                      )}
                      
                      <div className="pt-2 border-t border-gray-700">
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-gray-400">Manage Configuration</span>
                          <TrendingUp className="h-4 w-4 text-enterprise-neon" />
                        </div>
                      </div>
                    </div>
                  </div>
                </NavLink>
              </motion.div>
            )
          })}
        </div>
      )}

      {/* Nested Route Content */}
      <div className="min-h-0">
        <Outlet />
      </div>
    </div>
  )
}

export default NetworkManagementMain