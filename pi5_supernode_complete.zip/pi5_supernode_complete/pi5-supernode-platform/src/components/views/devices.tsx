import React, { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import {
  Router,
  Search,
  Plus,
  RefreshCw,
  Power,
  Shield,
  Edit,
  Trash2,
  Filter,
  Download,
  Upload,
  Activity,
  Clock,
  MapPin
} from 'lucide-react'
import { useNetworkStore, useUIStore } from '@/lib/store'
import { DeviceService } from '@/lib/services'
import { Button } from '@/components/ui/button'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card'
import TableCard from '@/components/ui/table-card'
import MetricCard from '@/components/ui/metric-card'
import Modal from '@/components/ui/modal'
import { cn } from '@/lib/utils'

interface DeviceFormData {
  device_name: string
  device_type: string
  ip_address: string
  mac_address: string
}

const Devices: React.FC = () => {
  const { devices, setDevices, isDiscovering, setDiscovering, selectedDevice, setSelectedDevice } = useNetworkStore()
  const { addNotification } = useUIStore()
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [deviceFilter, setDeviceFilter] = useState('all')
  const [showAddModal, setShowAddModal] = useState(false)
  const [showEditModal, setShowEditModal] = useState(false)
  const [formData, setFormData] = useState<DeviceFormData>({
    device_name: '',
    device_type: 'PC',
    ip_address: '',
    mac_address: ''
  })

  useEffect(() => {
    loadDevices()
  }, [])

  const loadDevices = async () => {
    try {
      setLoading(true)
      const devices = await DeviceService.getAllDevices()
      setDevices(devices)
    } catch (error) {
      console.error('Error loading devices:', error)
      addNotification({ type: 'error', message: 'Failed to load devices' })
    } finally {
      setLoading(false)
    }
  }

  const discoverDevices = async () => {
    if (isDiscovering) return
    
    try {
      setDiscovering(true)
      addNotification({ type: 'info', message: 'Scanning network for devices...' })
      
      // Call real device discovery API
      const discoveredDevices = await DeviceService.discoverDevices()
      
      await loadDevices()
      addNotification({ type: 'success', message: `Discovered ${discoveredDevices.length} new devices` })
    } catch (error) {
      console.error('Discovery error:', error)
      addNotification({ type: 'error', message: 'Device discovery failed' })
    } finally {
      setDiscovering(false)
    }
  }

  const wakeDevice = async (device: any) => {
    try {
      addNotification({ type: 'info', message: `Sending Wake-on-LAN to ${device.device_name}...` })
      
      await DeviceService.wakeDevice(device.mac_address)
      
      addNotification({ type: 'success', message: `Wake-on-LAN sent to ${device.device_name}` })
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to wake device' })
    }
  }

  const blockDevice = async (device: any) => {
    try {
      await DeviceService.blockDevice(device.mac_address, true)
      
      await loadDevices()
      addNotification({ type: 'success', message: `Blocked ${device.device_name}` })
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to block device' })
    }
  }

  const deleteDevice = async (device: any) => {
    try {
      await DeviceService.deleteDevice(device.mac_address)
      
      await loadDevices()
      addNotification({ type: 'success', message: `Deleted ${device.device_name}` })
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to delete device' })
    }
  }

  const handleAddDevice = async () => {
    try {
      await DeviceService.addDevice({
        ...formData,
        device_brand: 'Unknown',
        is_active: true,
        last_seen: new Date().toISOString(),
        first_discovered: new Date().toISOString()
      })
      
      setShowAddModal(false)
      setFormData({ device_name: '', device_type: 'PC', ip_address: '', mac_address: '' })
      await loadDevices()
      addNotification({ type: 'success', message: 'Device added successfully' })
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to add device' })
    }
  }

  const filteredDevices = devices.filter(device => {
    const matchesSearch = Object.values(device).some(value =>
      String(value).toLowerCase().includes(searchTerm.toLowerCase())
    )
    const matchesFilter = deviceFilter === 'all' || 
      (deviceFilter === 'active' && device.is_active) ||
      (deviceFilter === 'inactive' && !device.is_active)
    
    return matchesSearch && matchesFilter
  })

  const activeDevices = devices.filter(d => d.is_active).length
  const inactiveDevices = devices.filter(d => !d.is_active).length
  const totalTraffic = devices.reduce((sum, d) => sum + (Math.random() * 100), 0)

  const deviceColumns = [
    {
      key: 'device_name' as keyof typeof filteredDevices[0],
      label: 'Device',
      sortable: true,
      render: (value: any, item: typeof filteredDevices[0]) => (
        <div className="flex items-center space-x-3">
          <div className={cn(
            'w-3 h-3 rounded-full',
            item.is_active ? 'bg-green-400 animate-pulse' : 'bg-gray-400'
          )} />
          <div>
            <div className="font-medium text-white">{value || 'Unknown Device'}</div>
            <div className="text-sm text-gray-400">{item.device_brand || 'Unknown'}</div>
          </div>
        </div>
      )
    },
    {
      key: 'mac_address' as keyof typeof filteredDevices[0],
      label: 'MAC Address',
      sortable: true,
      render: (value: any) => (
        <span className="font-mono text-sm text-gray-300">{value}</span>
      )
    },
    {
      key: 'ip_address' as keyof typeof filteredDevices[0],
      label: 'IP Address',
      sortable: true,
      render: (value: any) => (
        <span className="font-mono text-sm text-gray-300">{value || 'N/A'}</span>
      )
    },
    {
      key: 'device_type' as keyof typeof filteredDevices[0],
      label: 'Type',
      sortable: true,
      render: (value: any) => (
        <span className="status-badge bg-blue-500/20 text-blue-300 border-blue-500/30">
          {value || 'Unknown'}
        </span>
      )
    },
    {
      key: 'last_seen' as keyof typeof filteredDevices[0],
      label: 'Last Seen',
      sortable: true,
      render: (value: any) => (
        <div className="text-sm">
          <div className="text-gray-300">
            {value ? new Date(value).toLocaleDateString() : 'Never'}
          </div>
          <div className="text-gray-500">
            {value ? new Date(value).toLocaleTimeString() : ''}
          </div>
        </div>
      )
    },
    {
      key: 'is_active' as keyof typeof filteredDevices[0],
      label: 'Status',
      sortable: true,
      render: (value: any) => (
        <span className={value ? 'status-active' : 'status-inactive'}>
          {value ? 'Active' : 'Inactive'}
        </span>
      )
    }
  ]

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Device Management</h1>
          <p className="text-gray-400">Network device discovery, monitoring, and control</p>
        </div>
        
        <div className="flex items-center space-x-3">
          <Button
            variant="outline"
            onClick={discoverDevices}
            loading={isDiscovering}
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Discover Devices
          </Button>
          
          <Button 
            variant="neon"
            onClick={() => setShowAddModal(true)}
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Device
          </Button>
        </div>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard
          title="Total Devices"
          value={devices.length}
          subtitle="Discovered devices"
          icon={Router}
          color="info"
          loading={loading}
        />
        
        <MetricCard
          title="Active Devices"
          value={activeDevices}
          subtitle={`${Math.round((activeDevices / devices.length) * 100) || 0}% online`}
          icon={Activity}
          color="success"
          loading={loading}
        />
        
        <MetricCard
          title="Inactive Devices"
          value={inactiveDevices}
          subtitle="Offline devices"
          icon={Clock}
          color={inactiveDevices > 0 ? 'warning' : 'success'}
          loading={loading}
        />
        
        <MetricCard
          title="Total Traffic"
          value={`${totalTraffic.toFixed(1)} MB/s`}
          subtitle="Combined bandwidth"
          icon={Upload}
          color="info"
          loading={loading}
        />
      </div>

      {/* Controls */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Device List</CardTitle>
            <div className="flex items-center space-x-3">
              {/* Search */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search devices..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 pr-4 py-2 w-64 enterprise-input rounded-lg"
                />
              </div>
              
              {/* Filter */}
              <select
                value={deviceFilter}
                onChange={(e) => setDeviceFilter(e.target.value)}
                className="enterprise-input rounded-lg px-3 py-2"
              >
                <option value="all">All Devices</option>
                <option value="active">Active Only</option>
                <option value="inactive">Inactive Only</option>
              </select>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Device Table */}
      <TableCard
        title={`Devices (${filteredDevices.length})`}
        description="Network device inventory and status"
        data={filteredDevices}
        columns={deviceColumns}
        loading={loading}
        searchable={false}
        actions={[
          {
            label: 'Wake',
            onClick: wakeDevice,
            variant: 'outline'
          },
          {
            label: 'Edit',
            onClick: (device) => {
              setSelectedDevice(device)
              setFormData({
                device_name: device.device_name || '',
                device_type: device.device_type || 'PC',
                ip_address: device.ip_address || '',
                mac_address: device.mac_address
              })
              setShowEditModal(true)
            },
            variant: 'outline'
          },
          {
            label: 'Block',
            onClick: blockDevice,
            variant: 'destructive'
          },
          {
            label: 'Delete',
            onClick: deleteDevice,
            variant: 'destructive'
          }
        ]}
        onRowClick={(device) => setSelectedDevice(device)}
      />

      {/* Add Device Modal */}
      <Modal
        isOpen={showAddModal}
        onClose={() => setShowAddModal(false)}
        title="Add New Device"
        description="Manually add a device to the network inventory"
      >
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Device Name
            </label>
            <input
              type="text"
              value={formData.device_name}
              onChange={(e) => setFormData({...formData, device_name: e.target.value})}
              className="w-full enterprise-input rounded-lg px-3 py-2"
              placeholder="My Device"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Device Type
            </label>
            <select
              value={formData.device_type}
              onChange={(e) => setFormData({...formData, device_type: e.target.value})}
              className="w-full enterprise-input rounded-lg px-3 py-2"
            >
              <option value="PC">Computer</option>
              <option value="Mobile">Mobile Device</option>
              <option value="Server">Server</option>
              <option value="IoT">IoT Device</option>
              <option value="Router">Router</option>
              <option value="Switch">Switch</option>
              <option value="AP">Access Point</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              MAC Address
            </label>
            <input
              type="text"
              value={formData.mac_address}
              onChange={(e) => setFormData({...formData, mac_address: e.target.value})}
              className="w-full enterprise-input rounded-lg px-3 py-2"
              placeholder="00:11:22:33:44:55"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              IP Address (Optional)
            </label>
            <input
              type="text"
              value={formData.ip_address}
              onChange={(e) => setFormData({...formData, ip_address: e.target.value})}
              className="w-full enterprise-input rounded-lg px-3 py-2"
              placeholder="192.168.1.100"
            />
          </div>
          
          <div className="flex justify-end space-x-3 pt-4">
            <Button variant="outline" onClick={() => setShowAddModal(false)}>
              Cancel
            </Button>
            <Button variant="neon" onClick={handleAddDevice}>
              Add Device
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  )
}

export default Devices