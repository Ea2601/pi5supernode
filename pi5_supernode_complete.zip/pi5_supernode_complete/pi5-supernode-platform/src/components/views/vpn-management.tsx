import React, { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import {
  Shield,
  Plus,
  Edit,
  Trash2,
  RefreshCw,
  Download,
  Users,
  Settings,
  Power,
  Key,
  Globe,
  Server,
  QrCode,
  Copy,
  Eye,
  EyeOff,
  Activity,
  AlertCircle,
  CheckCircle,
  Play,
  Pause,
  MonitorSpeaker,
  HardDrive,
  Cpu,
  Clock,
  Wifi,
  Link2,
  Terminal
} from 'lucide-react'
import { useVPNStore, useUIStore } from '@/lib/store'
import { VPNService, VPSService, type WireGuardServer, type WireGuardClient, type VPSServer, type CreateVPSServerData, type VPSStatusResponse } from '@/lib/services'
import { Button } from '@/components/ui/button'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card'
import TableCard from '@/components/ui/table-card'
import MetricCard from '@/components/ui/metric-card'
import Modal from '@/components/ui/modal'
import { cn } from '@/lib/utils'

interface ServerFormData {
  server_name: string
  listen_port: number
  network: string
  max_clients: number
  dns_servers: string
  endpoint: string
}

interface ClientFormData {
  client_name: string
  server_id: string
  allowed_ips: string
  bandwidth_limit: number
  expires_at: string
}

interface VPSFormData {
  vps_name: string
  vps_ip: string
  ssh_username: string
  ssh_password: string
  ssh_port: number
  ssh_key_type: 'password' | 'key'
  server_specs: {
    cpu?: string
    ram?: string
    storage?: string
    location?: string
  }
}

interface WireGuardInstallData {
  wgServerName: string
  vpsServerId: string
}

const VPNManagement: React.FC = () => {
  const { servers, clients, setServers, setClients } = useVPNStore()
  const { addNotification } = useUIStore()
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState('servers')
  const [showServerModal, setShowServerModal] = useState(false)
  const [showClientModal, setShowClientModal] = useState(false)
  const [showConfigModal, setShowConfigModal] = useState(false)
  const [editingServer, setEditingServer] = useState<WireGuardServer | null>(null)
  const [editingClient, setEditingClient] = useState<WireGuardClient | null>(null)
  const [selectedClient, setSelectedClient] = useState<WireGuardClient | null>(null)
  const [clientConfig, setClientConfig] = useState('')
  const [showKeys, setShowKeys] = useState<{ [key: string]: boolean }>({})
  
  const [serverForm, setServerForm] = useState<ServerFormData>({
    server_name: '',
    listen_port: 51820,
    network: '10.8.0.0/24',
    max_clients: 100,
    dns_servers: '1.1.1.1, 8.8.8.8',
    endpoint: ''
  })
  
  const [clientForm, setClientForm] = useState<ClientFormData>({
    client_name: '',
    server_id: '',
    allowed_ips: '0.0.0.0/0',
    bandwidth_limit: 0,
    expires_at: ''
  })

  // VPS Automation state
  const [vpsServers, setVpsServers] = useState<VPSServer[]>([])
  const [vpsLoading, setVpsLoading] = useState(false)
  const [showVPSModal, setShowVPSModal] = useState(false)
  const [showInstallModal, setShowInstallModal] = useState(false)
  const [showStatusModal, setShowStatusModal] = useState(false)
  const [editingVPS, setEditingVPS] = useState<VPSServer | null>(null)
  const [selectedVPS, setSelectedVPS] = useState<VPSServer | null>(null)
  const [vpsStatus, setVpsStatus] = useState<VPSStatusResponse | null>(null)
  const [statusPolling, setStatusPolling] = useState<boolean>(false)

  const [vpsForm, setVpsForm] = useState<VPSFormData>({
    vps_name: '',
    vps_ip: '',
    ssh_username: 'root',
    ssh_password: '',
    ssh_port: 22,
    ssh_key_type: 'password',
    server_specs: {
      cpu: '',
      ram: '',
      storage: '',
      location: ''
    }
  })

  const [installForm, setInstallForm] = useState<WireGuardInstallData>({
    wgServerName: '',
    vpsServerId: ''
  })

  useEffect(() => {
    loadVPNData()
  }, [])

  const loadVPNData = async () => {
    try {
      setLoading(true)
      
      const [serversData, clientsData, vpsServersData] = await Promise.all([
        VPNService.getWireGuardServers(),
        VPNService.getWireGuardClients(),
        VPSService.getAllVPSServers()
      ])
      
      setServers(serversData)
      setClients(clientsData)
      setVpsServers(vpsServersData)
      
    } catch (error) {
      console.error('Error loading VPN data:', error)
      addNotification({ type: 'error', message: 'Failed to load VPN data' })
    } finally {
      setLoading(false)
    }
  }

  const resetServerForm = () => {
    setServerForm({
      server_name: '',
      listen_port: 51820,
      network: '10.8.0.0/24',
      max_clients: 100,
      dns_servers: '1.1.1.1, 8.8.8.8',
      endpoint: ''
    })
  }

  const resetClientForm = () => {
    setClientForm({
      client_name: '',
      server_id: servers.length > 0 ? servers[0].id : '',
      allowed_ips: '0.0.0.0/0',
      bandwidth_limit: 0,
      expires_at: ''
    })
  }

  const editServer = (server: WireGuardServer) => {
    setEditingServer(server)
    setServerForm({
      server_name: server.server_name,
      listen_port: server.listen_port,
      network: server.network,
      max_clients: server.max_clients,
      dns_servers: '1.1.1.1, 8.8.8.8',
      endpoint: server.endpoint
    })
    setShowServerModal(true)
  }

  const editClient = (client: WireGuardClient) => {
    setEditingClient(client)
    setClientForm({
      client_name: client.client_name,
      server_id: client.server_id,
      allowed_ips: client.allowed_ips.join(', '),
      bandwidth_limit: 0,
      expires_at: ''
    })
    setShowClientModal(true)
  }

  const handleCreateServer = async () => {
    try {
      if (editingServer) {
        await VPNService.updateWireGuardServer(editingServer.id, serverForm)
        addNotification({ type: 'success', message: 'WireGuard server updated successfully' })
      } else {
        await VPNService.createWireGuardServer(serverForm)
        addNotification({ type: 'success', message: 'WireGuard server created successfully' })
      }
      
      setShowServerModal(false)
      setEditingServer(null)
      resetServerForm()
      await loadVPNData()
      
    } catch (error) {
      addNotification({ type: 'error', message: `Failed to ${editingServer ? 'update' : 'create'} server` })
    }
  }

  const handleCreateClient = async () => {
    try {
      const clientData = {
        ...clientForm,
        allowed_ips: clientForm.allowed_ips.split(',').map(ip => ip.trim())
      }
      
      if (editingClient) {
        await VPNService.updateWireGuardClient(editingClient.id, clientData)
        addNotification({ type: 'success', message: 'VPN client updated successfully' })
      } else {
        // Find the server for the client
        const selectedServer = servers.find(s => s.id === clientForm.server_id)
        if (!selectedServer) {
          addNotification({ type: 'error', message: 'Please select a valid server' })
          return
        }
        
        await VPNService.createWireGuardClient(selectedServer, clientData)
        addNotification({ type: 'success', message: 'VPN client created successfully' })
      }
      
      setShowClientModal(false)
      setEditingClient(null)
      resetClientForm()
      await loadVPNData()
      
    } catch (error) {
      addNotification({ type: 'error', message: `Failed to ${editingClient ? 'update' : 'create'} client` })
    }
  }

  const toggleServer = async (server: WireGuardServer) => {
    try {
      const newStatus = server.status === 'active' ? 'stopped' : 'active'
      await VPNService.toggleWireGuardServer(server.id, newStatus)
      
      addNotification({ 
        type: 'success', 
        message: `Server ${newStatus === 'active' ? 'started' : 'stopped'}` 
      })
      await loadVPNData()
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to toggle server status' })
    }
  }

  const deleteServer = async (server: WireGuardServer) => {
    if (!confirm(`Are you sure you want to delete server "${server.server_name}"?`)) return
    
    try {
      await VPNService.deleteWireGuardServer(server.id)
      addNotification({ type: 'success', message: 'WireGuard server deleted successfully' })
      await loadVPNData()
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to delete server' })
    }
  }

  const deleteClient = async (client: WireGuardClient) => {
    if (!confirm(`Are you sure you want to delete client "${client.client_name}"?`)) return
    
    try {
      await VPNService.deleteWireGuardClient(client.id)
      addNotification({ type: 'success', message: 'VPN client deleted successfully' })
      await loadVPNData()
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to delete client' })
    }
  }

  const downloadClientConfig = async (client: WireGuardClient) => {
    try {
      const config = await VPNService.generateClientConfig(client.id)
      setClientConfig(config)
      setSelectedClient(client)
      setShowConfigModal(true)
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to generate client configuration' })
    }
  }

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text)
    addNotification({ type: 'success', message: `${label} copied to clipboard` })
  }

  const toggleKeyVisibility = (id: string) => {
    setShowKeys(prev => ({ ...prev, [id]: !prev[id] }))
  }

  // VPS Management Functions
  const resetVPSForm = () => {
    setVpsForm({
      vps_name: '',
      vps_ip: '',
      ssh_username: 'root',
      ssh_password: '',
      ssh_port: 22,
      ssh_key_type: 'password',
      server_specs: {
        cpu: '',
        ram: '',
        storage: '',
        location: ''
      }
    })
  }

  const resetInstallForm = () => {
    setInstallForm({
      wgServerName: '',
      vpsServerId: ''
    })
  }

  const editVPS = (vps: VPSServer) => {
    setEditingVPS(vps)
    setVpsForm({
      vps_name: vps.vps_name,
      vps_ip: vps.vps_ip,
      ssh_username: vps.ssh_username,
      ssh_password: '', // Don't populate password for security
      ssh_port: vps.ssh_port,
      ssh_key_type: vps.ssh_key_type,
      server_specs: vps.server_specs || {
        cpu: '',
        ram: '',
        storage: '',
        location: ''
      }
    })
    setShowVPSModal(true)
  }

  const handleCreateVPS = async () => {
    try {
      const vpsData: CreateVPSServerData = {
        vps_name: vpsForm.vps_name,
        vps_ip: vpsForm.vps_ip,
        ssh_username: vpsForm.ssh_username,
        ssh_port: vpsForm.ssh_port,
        ssh_key_type: vpsForm.ssh_key_type,
        server_specs: vpsForm.server_specs
      }
      
      if (editingVPS) {
        await VPSService.updateVPSServer(editingVPS.id, vpsData)
        addNotification({ type: 'success', message: 'VPS server updated successfully' })
      } else {
        const newVPS = await VPSService.createVPSServer(vpsData)
        // Store credentials separately
        if (vpsForm.ssh_password) {
          await VPSService.storeVPSCredentials(newVPS.id, {
            ssh_password: vpsForm.ssh_password
          })
        }
        addNotification({ type: 'success', message: 'VPS server created successfully' })
      }
      
      setShowVPSModal(false)
      setEditingVPS(null)
      resetVPSForm()
      await loadVPNData()
      
    } catch (error) {
      console.error('Error saving VPS:', error)
      addNotification({ type: 'error', message: `Failed to ${editingVPS ? 'update' : 'create'} VPS server` })
    }
  }

  const deleteVPS = async (vps: VPSServer) => {
    if (!confirm(`Are you sure you want to delete VPS "${vps.vps_name}"?`)) return
    
    try {
      await VPSService.deleteVPSServer(vps.id)
      addNotification({ type: 'success', message: 'VPS server deleted successfully' })
      await loadVPNData()
    } catch (error) {
      console.error('Error deleting VPS:', error)
      addNotification({ type: 'error', message: 'Failed to delete VPS server' })
    }
  }

  const testVPSConnection = async (vps: VPSServer) => {
    try {
      const credentials = await VPSService.getVPSCredentials(vps.id)
      if (!credentials?.ssh_password) {
        addNotification({ type: 'error', message: 'SSH password not found for this VPS' })
        return
      }
      
      addNotification({ type: 'info', message: 'Testing VPS connection...' })
      const result = await VPSService.testVPSConnection(
        vps.vps_ip, 
        vps.ssh_username, 
        credentials.ssh_password, 
        vps.ssh_port
      )
      
      if (result.success) {
        addNotification({ type: 'success', message: result.message })
      } else {
        addNotification({ type: 'error', message: result.message })
      }
    } catch (error) {
      console.error('Connection test error:', error)
      addNotification({ type: 'error', message: 'Failed to test VPS connection' })
    }
  }

  const installWireGuard = (vps: VPSServer) => {
    setSelectedVPS(vps)
    setInstallForm({
      wgServerName: `${vps.vps_name}-WG`,
      vpsServerId: vps.id
    })
    setShowInstallModal(true)
  }

  const handleInstallWireGuard = async () => {
    if (!selectedVPS) return
    
    try {
      const credentials = await VPSService.getVPSCredentials(selectedVPS.id)
      if (!credentials?.ssh_password) {
        addNotification({ type: 'error', message: 'SSH credentials not found for this VPS' })
        return
      }

      const installData = {
        vpsServerId: selectedVPS.id,
        vpsIp: selectedVPS.vps_ip,
        sshUsername: selectedVPS.ssh_username,
        sshPassword: credentials.ssh_password,
        wgServerName: installForm.wgServerName
      }
      
      const result = await VPSService.installWireGuard(installData)
      
      if (result.success) {
        addNotification({ type: 'success', message: result.message })
        setShowInstallModal(false)
        resetInstallForm()
        setSelectedVPS(null)
        await loadVPNData()
      } else {
        addNotification({ type: 'error', message: result.message })
      }
    } catch (error) {
      console.error('WireGuard installation error:', error)
      addNotification({ type: 'error', message: 'Failed to install WireGuard' })
    }
  }

  const viewVPSStatus = async (vps: VPSServer) => {
    setSelectedVPS(vps)
    setShowStatusModal(true)
    setStatusPolling(true)
    
    // Initial status fetch
    await fetchVPSStatus(vps.id)
    
    // Start polling for status updates every 5 seconds
    const pollInterval = setInterval(async () => {
      try {
        await fetchVPSStatus(vps.id)
      } catch (error) {
        console.error('Status polling error:', error)
      }
    }, 5000)
    
    // Store interval ID to clear it later
    ;(window as any).vpsStatusPollInterval = pollInterval
  }

  const fetchVPSStatus = async (vpsServerId: string) => {
    try {
      const status = await VPSService.getVPSStatus(vpsServerId)
      setVpsStatus(status)
    } catch (error) {
      console.error('Error fetching VPS status:', error)
    }
  }

  const closeStatusModal = () => {
    setShowStatusModal(false)
    setSelectedVPS(null)
    setVpsStatus(null)
    setStatusPolling(false)
    
    // Clear polling interval
    if ((window as any).vpsStatusPollInterval) {
      clearInterval((window as any).vpsStatusPollInterval)
      ;(window as any).vpsStatusPollInterval = null
    }
  }

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 Bytes'
    const k = 1024
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
  }

  const activeServers = servers.filter(server => server.status === 'active').length
  const totalClients = clients.length
  const connectedClients = clients.filter(client => client.is_active).length
  
  // VPS Statistics
  const totalVPS = vpsServers.length
  const completedVPS = vpsServers.filter(vps => vps.status === 'completed').length
  const installingVPS = vpsServers.filter(vps => vps.status === 'installing').length
  const failedVPS = vpsServers.filter(vps => vps.status === 'failed').length

  const tabs = [
    { id: 'servers', label: 'WireGuard Servers', icon: Server },
    { id: 'clients', label: 'VPN Clients', icon: Users },
    { id: 'monitoring', label: 'Connection Monitoring', icon: Activity },
    { id: 'automation', label: 'VPS Automation', icon: Globe }
  ]

  const serverColumns = [
    {
      key: 'server_name' as keyof WireGuardServer,
      label: 'Server',
      sortable: true,
      render: (value: any, item: WireGuardServer) => (
        <div className="flex items-center space-x-3">
          <div className={`p-2 rounded-lg ${item.status === 'active' ? 'bg-green-500/20' : 'bg-gray-500/20'}`}>
            <Shield className={`h-4 w-4 ${item.status === 'active' ? 'text-green-400' : 'text-gray-400'}`} />
          </div>
          <div>
            <div className="font-medium text-white">{value}</div>
            <div className="text-sm text-gray-400">{item.network}</div>
          </div>
        </div>
      )
    },
    {
      key: 'endpoint' as keyof WireGuardServer,
      label: 'Endpoint',
      render: (value: any, item: WireGuardServer) => (
        <div className="font-mono text-sm">
          <div className="text-enterprise-neon">{value}</div>
          <div className="text-gray-400">Port: {item.listen_port}</div>
        </div>
      )
    },
    {
      key: 'client_count' as keyof WireGuardServer,
      label: 'Clients',
      sortable: true,
      render: (value: any, item: WireGuardServer) => {
        const percentage = item.max_clients > 0 ? (value / item.max_clients) * 100 : 0
        
        return (
          <div className="space-y-1">
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-300">{value} / {item.max_clients}</span>
              <span className="text-enterprise-neon">{percentage.toFixed(0)}%</span>
            </div>
            <div className="w-full bg-gray-700 rounded-full h-2">
              <div 
                className="bg-enterprise-neon h-2 rounded-full transition-all duration-500"
                style={{ width: `${percentage}%` }}
              />
            </div>
          </div>
        )
      }
    },
    {
      key: 'public_key' as keyof WireGuardServer,
      label: 'Public Key',
      render: (value: any, item: WireGuardServer) => {
        const isVisible = showKeys[item.id]
        const displayKey = isVisible ? value : value.substring(0, 8) + '...' + value.substring(value.length - 8)
        
        return (
          <div className="flex items-center space-x-2">
            <span className="font-mono text-xs text-gray-300 select-none">
              {displayKey}
            </span>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => toggleKeyVisibility(item.id)}
            >
              {isVisible ? <EyeOff className="h-3 w-3" /> : <Eye className="h-3 w-3" />}
            </Button>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => copyToClipboard(value, 'Public key')}
            >
              <Copy className="h-3 w-3" />
            </Button>
          </div>
        )
      }
    },
    {
      key: 'status' as keyof WireGuardServer,
      label: 'Status',
      sortable: true,
      render: (value: any) => (
        <span className={value === 'active' ? 'status-active' : 'status-inactive'}>
          {value.charAt(0).toUpperCase() + value.slice(1)}
        </span>
      )
    },
    {
      key: 'id' as keyof WireGuardServer,
      label: 'Actions',
      render: (value: any, item: WireGuardServer) => (
        <div className="flex items-center space-x-2">
          <Button
            size="sm"
            variant="ghost"
            onClick={() => editServer(item)}
          >
            <Edit className="h-4 w-4" />
          </Button>
          
          <Button
            size="sm"
            variant="ghost"
            onClick={() => toggleServer(item)}
          >
            <Power className="h-4 w-4" />
          </Button>
          
          <Button
            size="sm"
            variant="ghost"
            onClick={() => deleteServer(item)}
            className="text-red-400 hover:text-red-300"
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      )
    }
  ]

  const clientColumns = [
    {
      key: 'client_name' as keyof WireGuardClient,
      label: 'Client',
      sortable: true,
      render: (value: any, item: WireGuardClient) => (
        <div className="flex items-center space-x-3">
          <div className={`w-2 h-2 rounded-full ${item.is_active ? 'bg-green-400 animate-pulse' : 'bg-gray-400'}`} />
          <div>
            <div className="font-medium text-white">{value}</div>
            <div className="text-sm text-gray-400">{item.assigned_ip}</div>
          </div>
        </div>
      )
    },
    {
      key: 'server_id' as keyof WireGuardClient,
      label: 'Server',
      render: (value: any) => {
        const server = servers.find(s => s.id === value)
        return (
          <span className="text-sm text-gray-300">
            {server?.server_name || 'Unknown'}
          </span>
        )
      }
    },
    {
      key: 'allowed_ips' as keyof WireGuardClient,
      label: 'Allowed IPs',
      render: (value: any) => (
        <div className="font-mono text-xs text-gray-300">
          {Array.isArray(value) ? value.join(', ') : value}
        </div>
      )
    },
    {
      key: 'last_handshake' as keyof WireGuardClient,
      label: 'Last Seen',
      render: (value: any) => (
        <span className="text-sm text-gray-400">
          {value ? new Date(value).toLocaleString() : 'Never'}
        </span>
      )
    },
    {
      key: 'bytes_received' as keyof WireGuardClient,
      label: 'Traffic',
      render: (value: any, item: WireGuardClient) => (
        <div className="text-sm space-y-1">
          <div className="flex items-center space-x-2">
            <span className="text-gray-400">RX:</span>
            <span className="text-green-400">{formatBytes(value)}</span>
          </div>
          <div className="flex items-center space-x-2">
            <span className="text-gray-400">TX:</span>
            <span className="text-blue-400">{formatBytes(item.bytes_sent)}</span>
          </div>
        </div>
      )
    },
    {
      key: 'is_active' as keyof WireGuardClient,
      label: 'Status',
      sortable: true,
      render: (value: any) => (
        <span className={value ? 'status-active' : 'status-inactive'}>
          {value ? 'Connected' : 'Disconnected'}
        </span>
      )
    },
    {
      key: 'id' as keyof WireGuardClient,
      label: 'Actions',
      render: (value: any, item: WireGuardClient) => (
        <div className="flex items-center space-x-2">
          <Button
            size="sm"
            variant="ghost"
            onClick={() => downloadClientConfig(item)}
            title="Download config"
          >
            <Download className="h-4 w-4" />
          </Button>
          
          <Button
            size="sm"
            variant="ghost"
            onClick={() => editClient(item)}
          >
            <Edit className="h-4 w-4" />
          </Button>
          
          <Button
            size="sm"
            variant="ghost"
            onClick={() => deleteClient(item)}
            className="text-red-400 hover:text-red-300"
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      )
    }
  ]

  // VPS Servers Table Columns
  const vpsColumns = [
    {
      key: 'vps_name' as keyof VPSServer,
      label: 'VPS Server',
      sortable: true,
      render: (value: any, item: VPSServer) => (
        <div className="flex items-center space-x-3">
          <div className={`p-2 rounded-lg ${
            item.status === 'completed' ? 'bg-green-500/20' :
            item.status === 'installing' ? 'bg-yellow-500/20' :
            item.status === 'failed' ? 'bg-red-500/20' :
            'bg-gray-500/20'
          }`}>
            <Server className={`h-4 w-4 ${
              item.status === 'completed' ? 'text-green-400' :
              item.status === 'installing' ? 'text-yellow-400' :
              item.status === 'failed' ? 'text-red-400' :
              'text-gray-400'
            }`} />
          </div>
          <div>
            <div className="font-medium text-white">{value}</div>
            <div className="text-sm text-gray-400">{item.vps_ip}</div>
          </div>
        </div>
      )
    },
    {
      key: 'server_specs' as keyof VPSServer,
      label: 'Specifications',
      render: (value: any, item: VPSServer) => (
        <div className="text-sm space-y-1">
          {value?.cpu && (
            <div className="flex items-center space-x-2">
              <Cpu className="h-3 w-3 text-blue-400" />
              <span className="text-gray-300">{value.cpu}</span>
            </div>
          )}
          {value?.ram && (
            <div className="flex items-center space-x-2">
              <MonitorSpeaker className="h-3 w-3 text-green-400" />
              <span className="text-gray-300">{value.ram}</span>
            </div>
          )}
          {value?.location && (
            <div className="flex items-center space-x-2">
              <Globe className="h-3 w-3 text-enterprise-neon" />
              <span className="text-gray-400">{value.location}</span>
            </div>
          )}
        </div>
      )
    },
    {
      key: 'ssh_username' as keyof VPSServer,
      label: 'SSH Access',
      render: (value: any, item: VPSServer) => (
        <div className="font-mono text-sm">
          <div className="text-enterprise-neon">{value}@{item.vps_ip}</div>
          <div className="text-gray-400">Port: {item.ssh_port}</div>
        </div>
      )
    },
    {
      key: 'status' as keyof VPSServer,
      label: 'Status',
      sortable: true,
      render: (value: any, item: VPSServer) => {
        const getStatusColor = (status: string) => {
          switch (status) {
            case 'completed':
              return 'status-active'
            case 'installing':
              return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30'
            case 'failed':
              return 'bg-red-500/20 text-red-400 border-red-500/30'
            case 'connecting':
              return 'bg-blue-500/20 text-blue-400 border-blue-500/30'
            default:
              return 'status-inactive'
          }
        }
        
        return (
          <div className="flex items-center space-x-2">
            <span className={`px-2 py-1 rounded-full text-xs font-medium border ${getStatusColor(value)}`}>
              {value.charAt(0).toUpperCase() + value.slice(1)}
            </span>
            {item.status === 'installing' && (
              <div className="animate-spin h-3 w-3 border-2 border-yellow-400 border-t-transparent rounded-full" />
            )}
          </div>
        )
      }
    },
    {
      key: 'created_at' as keyof VPSServer,
      label: 'Created',
      sortable: true,
      render: (value: any) => (
        <span className="text-sm text-gray-400">
          {new Date(value).toLocaleDateString()}
        </span>
      )
    },
    {
      key: 'id' as keyof VPSServer,
      label: 'Actions',
      render: (value: any, item: VPSServer) => (
        <div className="flex items-center space-x-2">
          {item.status === 'pending' && (
            <Button
              size="sm"
              variant="ghost"
              onClick={() => testVPSConnection(item)}
              title="Test connection"
            >
              <Link2 className="h-4 w-4" />
            </Button>
          )}
          
          {(item.status === 'pending' || item.status === 'failed') && (
            <Button
              size="sm"
              variant="ghost"
              onClick={() => installWireGuard(item)}
              title="Install WireGuard"
            >
              <Play className="h-4 w-4" />
            </Button>
          )}
          
          {(item.status === 'installing' || item.status === 'completed' || item.status === 'failed') && (
            <Button
              size="sm"
              variant="ghost"
              onClick={() => viewVPSStatus(item)}
              title="View status"
            >
              <Activity className="h-4 w-4" />
            </Button>
          )}
          
          <Button
            size="sm"
            variant="ghost"
            onClick={() => editVPS(item)}
            title="Edit VPS"
          >
            <Edit className="h-4 w-4" />
          </Button>
          
          <Button
            size="sm"
            variant="ghost"
            onClick={() => deleteVPS(item)}
            className="text-red-400 hover:text-red-300"
            title="Delete VPS"
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      )
    }
  ]

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">VPN Management</h1>
          <p className="text-gray-400">WireGuard server and client management with automated VPS deployment</p>
        </div>
        
        <div className="flex items-center space-x-3">
          <Button
            variant="outline"
            onClick={loadVPNData}
            loading={loading}
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          
          <Button 
            variant="neon"
            onClick={() => {
              if (activeTab === 'servers') {
                resetServerForm()
                setShowServerModal(true)
              } else if (activeTab === 'clients') {
                resetClientForm()
                setShowClientModal(true)
              } else if (activeTab === 'automation') {
                resetVPSForm()
                setShowVPSModal(true)
              }
            }}
          >
            <Plus className="h-4 w-4 mr-2" />
            {activeTab === 'servers' ? 'New Server' : 
             activeTab === 'clients' ? 'New Client' : 'New VPS'}
          </Button>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard
          title="Active Servers"
          value={activeServers.toString()}
          subtitle={`${servers.length} total servers`}
          icon={Server}
          color="success"
          loading={loading}
        />
        
        <MetricCard
          title="Connected Clients"
          value={connectedClients.toString()}
          subtitle={`${totalClients} total clients`}
          icon={Users}
          color="info"
          loading={loading}
        />
        
        <MetricCard
          title="VPS Servers"
          value={completedVPS.toString()}
          subtitle={`${totalVPS} total VPS (${installingVPS} installing)`}
          icon={Globe}
          color={failedVPS > 0 ? "danger" : "success"}
          loading={loading}
        />
        
        <MetricCard
          title="Security Level"
          value="WireGuard"
          subtitle="Modern VPN protocol"
          icon={Shield}
          color="success"
          loading={loading}
        />
      </div>

      {/* Tab Navigation */}
      <div className="flex space-x-1 glassmorphism-card bg-gray-800/30 p-1 rounded-lg w-fit">
        {tabs.map((tab) => {
          const Icon = tab.icon
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={cn(
                'flex items-center space-x-2 px-4 py-2 rounded-md transition-all duration-200',
                activeTab === tab.id
                  ? 'bg-enterprise-neon/20 text-enterprise-neon border border-enterprise-neon/30'
                  : 'text-gray-400 hover:text-gray-200 hover:bg-gray-700/30'
              )}
            >
              <Icon className="h-4 w-4" />
              <span className="text-sm font-medium">{tab.label}</span>
            </button>
          )
        })}
      </div>

      {/* Tab Content */}
      {activeTab === 'servers' && (
        <TableCard
          title="WireGuard Servers"
          description={`${servers.length} configured servers (${activeServers} active)`}
          data={servers}
          columns={serverColumns}
          loading={loading}
          emptyMessage="No WireGuard servers configured. Create your first server to get started."
        />
      )}

      {activeTab === 'clients' && (
        <TableCard
          title="VPN Clients"
          description={`${clients.length} configured clients (${connectedClients} connected)`}
          data={clients}
          columns={clientColumns}
          loading={loading}
          emptyMessage="No VPN clients configured. Add your first client to get started."
        />
      )}

      {activeTab === 'monitoring' && (
        <div className="text-center py-8 text-gray-400">
          <Activity className="h-16 w-16 mx-auto mb-4 opacity-50" />
          <h3 className="text-xl font-semibold mb-2">Connection Monitoring</h3>
          <p>Real-time monitoring of VPN connections and performance metrics</p>
        </div>
      )}

      {activeTab === 'automation' && (
        <TableCard
          title="VPS Servers"
          description={`${totalVPS} configured VPS servers (${completedVPS} completed, ${installingVPS} installing)`}
          data={vpsServers}
          columns={vpsColumns}
          loading={loading}
          emptyMessage="No VPS servers configured. Add your first VPS server to get started with automated WireGuard deployment."
        />
      )}

      {/* Server Creation/Edit Modal */}
      <Modal
        isOpen={showServerModal}
        onClose={() => {
          setShowServerModal(false)
          setEditingServer(null)
          resetServerForm()
        }}
        title={editingServer ? "Edit WireGuard Server" : "Create New WireGuard Server"}
        size="lg"
      >
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Server Name
              </label>
              <input
                type="text"
                value={serverForm.server_name}
                onChange={(e) => setServerForm(prev => ({ ...prev, server_name: e.target.value }))}
                className="enterprise-input w-full"
                placeholder="My VPN Server"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Listen Port
              </label>
              <input
                type="number"
                value={serverForm.listen_port}
                onChange={(e) => setServerForm(prev => ({ ...prev, listen_port: parseInt(e.target.value) }))}
                className="enterprise-input w-full"
                min="1"
                max="65535"
              />
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Network (CIDR)
              </label>
              <input
                type="text"
                value={serverForm.network}
                onChange={(e) => setServerForm(prev => ({ ...prev, network: e.target.value }))}
                className="enterprise-input w-full"
                placeholder="10.8.0.0/24"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Max Clients
              </label>
              <input
                type="number"
                value={serverForm.max_clients}
                onChange={(e) => setServerForm(prev => ({ ...prev, max_clients: parseInt(e.target.value) }))}
                className="enterprise-input w-full"
                min="1"
                max="1000"
              />
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Public Endpoint
              </label>
              <input
                type="text"
                value={serverForm.endpoint}
                onChange={(e) => setServerForm(prev => ({ ...prev, endpoint: e.target.value }))}
                className="enterprise-input w-full"
                placeholder="vpn.example.com or IP address"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                DNS Servers
              </label>
              <input
                type="text"
                value={serverForm.dns_servers}
                onChange={(e) => setServerForm(prev => ({ ...prev, dns_servers: e.target.value }))}
                className="enterprise-input w-full"
                placeholder="1.1.1.1, 8.8.8.8"
              />
            </div>
          </div>
          
          <div className="flex justify-end space-x-3 pt-4 border-t border-gray-700">
            <Button
              variant="outline"
              onClick={() => {
                setShowServerModal(false)
                setEditingServer(null)
                resetServerForm()
              }}
            >
              Cancel
            </Button>
            
            <Button
              variant="neon"
              onClick={handleCreateServer}
            >
              {editingServer ? 'Update Server' : 'Create Server'}
            </Button>
          </div>
        </div>
      </Modal>

      {/* Client Creation/Edit Modal */}
      <Modal
        isOpen={showClientModal}
        onClose={() => {
          setShowClientModal(false)
          setEditingClient(null)
          resetClientForm()
        }}
        title={editingClient ? "Edit VPN Client" : "Create New VPN Client"}
      >
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Client Name
              </label>
              <input
                type="text"
                value={clientForm.client_name}
                onChange={(e) => setClientForm(prev => ({ ...prev, client_name: e.target.value }))}
                className="enterprise-input w-full"
                placeholder="John's Phone"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Server
              </label>
              <select
                value={clientForm.server_id}
                onChange={(e) => setClientForm(prev => ({ ...prev, server_id: e.target.value }))}
                className="enterprise-input w-full"
              >
                <option value="">Select a server</option>
                {servers.map(server => (
                  <option key={server.id} value={server.id}>
                    {server.server_name}
                  </option>
                ))}
              </select>
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Allowed IPs
            </label>
            <input
              type="text"
              value={clientForm.allowed_ips}
              onChange={(e) => setClientForm(prev => ({ ...prev, allowed_ips: e.target.value }))}
              className="enterprise-input w-full"
              placeholder="0.0.0.0/0 (route all traffic)"
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Bandwidth Limit (Mbps)
              </label>
              <input
                type="number"
                value={clientForm.bandwidth_limit}
                onChange={(e) => setClientForm(prev => ({ ...prev, bandwidth_limit: parseInt(e.target.value) }))}
                className="enterprise-input w-full"
                min="0"
                placeholder="0 = No limit"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Expires At (Optional)
              </label>
              <input
                type="datetime-local"
                value={clientForm.expires_at}
                onChange={(e) => setClientForm(prev => ({ ...prev, expires_at: e.target.value }))}
                className="enterprise-input w-full"
              />
            </div>
          </div>
          
          <div className="flex justify-end space-x-3 pt-4 border-t border-gray-700">
            <Button
              variant="outline"
              onClick={() => {
                setShowClientModal(false)
                setEditingClient(null)
                resetClientForm()
              }}
            >
              Cancel
            </Button>
            
            <Button
              variant="neon"
              onClick={handleCreateClient}
            >
              {editingClient ? 'Update Client' : 'Create Client'}
            </Button>
          </div>
        </div>
      </Modal>

      {/* Client Config Modal */}
      <Modal
        isOpen={showConfigModal}
        onClose={() => setShowConfigModal(false)}
        title={`VPN Configuration - ${selectedClient?.client_name}`}
        size="lg"
      >
        <div className="space-y-4">
          <div className="bg-gray-800/50 p-4 rounded-lg">
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-sm font-medium text-gray-300">WireGuard Configuration</h4>
              <div className="flex space-x-2">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => copyToClipboard(clientConfig, 'Configuration')}
                >
                  <Copy className="h-4 w-4 mr-1" />
                  Copy
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => {
                    const blob = new Blob([clientConfig], { type: 'text/plain' })
                    const url = URL.createObjectURL(blob)
                    const a = document.createElement('a')
                    a.href = url
                    a.download = `${selectedClient?.client_name}.conf`
                    a.click()
                    URL.revokeObjectURL(url)
                  }}
                >
                  <Download className="h-4 w-4 mr-1" />
                  Download
                </Button>
              </div>
            </div>
            <pre className="text-sm text-gray-300 whitespace-pre-wrap overflow-x-auto">
              {clientConfig}
            </pre>
          </div>
          
          <div className="text-sm text-gray-400">
            <p className="mb-2">To use this configuration:</p>
            <ol className="list-decimal list-inside space-y-1 ml-4">
              <li>Download and install the WireGuard app on your device</li>
              <li>Import this configuration file or scan the QR code</li>
              <li>Connect to establish the VPN tunnel</li>
            </ol>
          </div>
        </div>
      </Modal>

      {/* VPS Creation/Edit Modal */}
      <Modal
        isOpen={showVPSModal}
        onClose={() => {
          setShowVPSModal(false)
          setEditingVPS(null)
          resetVPSForm()
        }}
        title={editingVPS ? "Edit VPS Server" : "Add New VPS Server"}
        size="lg"
      >
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                VPS Name
              </label>
              <input
                type="text"
                value={vpsForm.vps_name}
                onChange={(e) => setVpsForm(prev => ({ ...prev, vps_name: e.target.value }))}
                className="enterprise-input w-full"
                placeholder="My VPS Server"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                VPS IP Address
              </label>
              <input
                type="text"
                value={vpsForm.vps_ip}
                onChange={(e) => setVpsForm(prev => ({ ...prev, vps_ip: e.target.value }))}
                className="enterprise-input w-full"
                placeholder="192.168.1.100"
              />
            </div>
          </div>
          
          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                SSH Username
              </label>
              <input
                type="text"
                value={vpsForm.ssh_username}
                onChange={(e) => setVpsForm(prev => ({ ...prev, ssh_username: e.target.value }))}
                className="enterprise-input w-full"
                placeholder="root"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                SSH Password
              </label>
              <input
                type="password"
                value={vpsForm.ssh_password}
                onChange={(e) => setVpsForm(prev => ({ ...prev, ssh_password: e.target.value }))}
                className="enterprise-input w-full"
                placeholder="••••••••"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                SSH Port
              </label>
              <input
                type="number"
                value={vpsForm.ssh_port}
                onChange={(e) => setVpsForm(prev => ({ ...prev, ssh_port: parseInt(e.target.value) }))}
                className="enterprise-input w-full"
                min="1"
                max="65535"
                placeholder="22"
              />
            </div>
          </div>

          <div className="border-t border-gray-700 pt-4">
            <h4 className="text-sm font-medium text-gray-300 mb-3 flex items-center">
              <HardDrive className="h-4 w-4 mr-2" />
              Server Specifications (Optional)
            </h4>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  CPU
                </label>
                <input
                  type="text"
                  value={vpsForm.server_specs.cpu}
                  onChange={(e) => setVpsForm(prev => ({ 
                    ...prev, 
                    server_specs: { ...prev.server_specs, cpu: e.target.value }
                  }))}
                  className="enterprise-input w-full"
                  placeholder="4 vCPUs"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  RAM
                </label>
                <input
                  type="text"
                  value={vpsForm.server_specs.ram}
                  onChange={(e) => setVpsForm(prev => ({ 
                    ...prev, 
                    server_specs: { ...prev.server_specs, ram: e.target.value }
                  }))}
                  className="enterprise-input w-full"
                  placeholder="8GB"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  Storage
                </label>
                <input
                  type="text"
                  value={vpsForm.server_specs.storage}
                  onChange={(e) => setVpsForm(prev => ({ 
                    ...prev, 
                    server_specs: { ...prev.server_specs, storage: e.target.value }
                  }))}
                  className="enterprise-input w-full"
                  placeholder="80GB SSD"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  Location
                </label>
                <input
                  type="text"
                  value={vpsForm.server_specs.location}
                  onChange={(e) => setVpsForm(prev => ({ 
                    ...prev, 
                    server_specs: { ...prev.server_specs, location: e.target.value }
                  }))}
                  className="enterprise-input w-full"
                  placeholder="New York, USA"
                />
              </div>
            </div>
          </div>
          
          <div className="flex justify-end space-x-3 pt-4 border-t border-gray-700">
            <Button
              variant="outline"
              onClick={() => {
                setShowVPSModal(false)
                setEditingVPS(null)
                resetVPSForm()
              }}
            >
              Cancel
            </Button>
            
            <Button
              variant="neon"
              onClick={handleCreateVPS}
            >
              {editingVPS ? 'Update VPS' : 'Add VPS Server'}
            </Button>
          </div>
        </div>
      </Modal>

      {/* WireGuard Installation Modal */}
      <Modal
        isOpen={showInstallModal}
        onClose={() => {
          setShowInstallModal(false)
          setSelectedVPS(null)
          resetInstallForm()
        }}
        title={`Install WireGuard on ${selectedVPS?.vps_name}`}
      >
        <div className="space-y-4">
          <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4">
            <div className="flex items-center space-x-2 mb-2">
              <Terminal className="h-4 w-4 text-blue-400" />
              <span className="text-sm font-medium text-blue-300">WireGuard Installation</span>
            </div>
            <p className="text-sm text-blue-200">
              This will automatically install and configure WireGuard on your VPS server. 
              The process includes system updates, WireGuard installation, key generation, 
              and firewall configuration.
            </p>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              WireGuard Server Name
            </label>
            <input
              type="text"
              value={installForm.wgServerName}
              onChange={(e) => setInstallForm(prev => ({ ...prev, wgServerName: e.target.value }))}
              className="enterprise-input w-full"
              placeholder="Production-VPN-Server"
            />
          </div>

          {selectedVPS && (
            <div className="bg-gray-800/50 p-4 rounded-lg">
              <h4 className="text-sm font-medium text-gray-300 mb-3">Target Server Details</h4>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-gray-400">Server:</span>
                  <span className="ml-2 text-white">{selectedVPS.vps_name}</span>
                </div>
                <div>
                  <span className="text-gray-400">IP:</span>
                  <span className="ml-2 text-enterprise-neon font-mono">{selectedVPS.vps_ip}</span>
                </div>
                <div>
                  <span className="text-gray-400">SSH User:</span>
                  <span className="ml-2 text-white">{selectedVPS.ssh_username}</span>
                </div>
                <div>
                  <span className="text-gray-400">SSH Port:</span>
                  <span className="ml-2 text-white">{selectedVPS.ssh_port}</span>
                </div>
              </div>
            </div>
          )}

          <div className="flex justify-end space-x-3 pt-4 border-t border-gray-700">
            <Button
              variant="outline"
              onClick={() => {
                setShowInstallModal(false)
                setSelectedVPS(null)
                resetInstallForm()
              }}
            >
              Cancel
            </Button>
            
            <Button
              variant="neon"
              onClick={handleInstallWireGuard}
            >
              <Play className="h-4 w-4 mr-2" />
              Start Installation
            </Button>
          </div>
        </div>
      </Modal>

      {/* VPS Status Modal */}
      <Modal
        isOpen={showStatusModal}
        onClose={closeStatusModal}
        title={`VPS Status - ${selectedVPS?.vps_name}`}
        size="xl"
      >
        <div className="space-y-6">
          {vpsStatus && (
            <>
              {/* Status Overview */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <MetricCard
                  title="Server Status"
                  value={vpsStatus.vpsServer.status.charAt(0).toUpperCase() + vpsStatus.vpsServer.status.slice(1)}
                  subtitle={`Health: ${vpsStatus.healthStatus}`}
                  icon={Server}
                  color={vpsStatus.vpsServer.status === 'completed' ? 'success' : 
                        vpsStatus.vpsServer.status === 'installing' ? 'warning' : 'danger'}
                  loading={false}
                />
                
                <MetricCard
                  title="Installation Progress"
                  value={`${vpsStatus.installationProgress.progressPercentage}%`}
                  subtitle={`${vpsStatus.installationProgress.completedSteps}/${vpsStatus.installationProgress.totalSteps} steps`}
                  icon={Activity}
                  color="info"
                  loading={false}
                />
                
                <MetricCard
                  title="WireGuard Server"
                  value={vpsStatus.wireguardServer ? 'Active' : 'Not Created'}
                  subtitle={vpsStatus.wireguardServer ? 
                    `${vpsStatus.wireguardServer.clientCount}/${vpsStatus.wireguardServer.maxClients} clients` : 
                    'Installation required'
                  }
                  icon={Shield}
                  color={vpsStatus.wireguardServer ? 'success' : 'warning'}
                  loading={false}
                />
              </div>

              {/* Installation Progress */}
              {vpsStatus.installationProgress.totalSteps > 0 && (
                <div className="glassmorphism-card bg-gray-800/30 p-6 rounded-lg">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold text-white">Installation Progress</h3>
                    {statusPolling && (
                      <div className="flex items-center space-x-2 text-sm text-gray-400">
                        <div className="animate-spin h-4 w-4 border-2 border-enterprise-neon border-t-transparent rounded-full" />
                        <span>Live updating...</span>
                      </div>
                    )}
                  </div>
                  
                  {/* Progress Bar */}
                  <div className="w-full bg-gray-700 rounded-full h-3 mb-6">
                    <div 
                      className="bg-enterprise-neon h-3 rounded-full transition-all duration-500"
                      style={{ width: `${vpsStatus.installationProgress.progressPercentage}%` }}
                    />
                  </div>

                  {/* Installation Steps */}
                  <div className="space-y-3">
                    {vpsStatus.installationSteps.map((step, index) => (
                      <div key={step.id} className="flex items-start space-x-3 p-3 rounded-lg bg-gray-800/50">
                        <div className={`flex-shrink-0 w-6 h-6 rounded-full flex items-center justify-center ${
                          step.status === 'completed' ? 'bg-green-500/20' :
                          step.status === 'running' ? 'bg-yellow-500/20' :
                          step.status === 'failed' ? 'bg-red-500/20' :
                          'bg-gray-500/20'
                        }`}>
                          {step.status === 'completed' && <CheckCircle className="h-3 w-3 text-green-400" />}
                          {step.status === 'running' && <Clock className="h-3 w-3 text-yellow-400 animate-spin" />}
                          {step.status === 'failed' && <AlertCircle className="h-3 w-3 text-red-400" />}
                          {step.status === 'pending' && <div className="w-2 h-2 bg-gray-400 rounded-full" />}
                        </div>
                        
                        <div className="flex-grow">
                          <div className="flex items-center justify-between">
                            <h4 className="text-sm font-medium text-white">{step.name.replace(/_/g, ' ').toUpperCase()}</h4>
                            <span className="text-xs text-gray-400">Step {step.order}</span>
                          </div>
                          <p className="text-sm text-gray-400 mt-1">{step.description}</p>
                          
                          {step.output && (
                            <details className="mt-2">
                              <summary className="text-xs text-enterprise-neon cursor-pointer hover:text-enterprise-neon/80">
                                View output
                              </summary>
                              <pre className="mt-2 p-2 bg-gray-900 rounded text-xs text-gray-300 whitespace-pre-wrap overflow-x-auto">
                                {step.output}
                              </pre>
                            </details>
                          )}
                          
                          {step.errorMessage && (
                            <div className="mt-2 p-2 bg-red-500/10 border border-red-500/20 rounded text-xs text-red-400">
                              Error: {step.errorMessage}
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* WireGuard Server Details */}
              {vpsStatus.wireguardServer && (
                <div className="glassmorphism-card bg-gray-800/30 p-6 rounded-lg">
                  <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
                    <Shield className="h-5 w-5 mr-2 text-enterprise-neon" />
                    WireGuard Server Details
                  </h3>
                  
                  <div className="grid grid-cols-2 gap-6">
                    <div className="space-y-3">
                      <div>
                        <span className="text-sm text-gray-400">Server Name:</span>
                        <p className="text-white font-medium">{vpsStatus.wireguardServer.serverName}</p>
                      </div>
                      <div>
                        <span className="text-sm text-gray-400">Endpoint:</span>
                        <p className="text-enterprise-neon font-mono">{vpsStatus.wireguardServer.endpoint}</p>
                      </div>
                      <div>
                        <span className="text-sm text-gray-400">Network:</span>
                        <p className="text-white font-mono">{vpsStatus.wireguardServer.network}</p>
                      </div>
                    </div>
                    
                    <div className="space-y-3">
                      <div>
                        <span className="text-sm text-gray-400">Status:</span>
                        <p className={`font-medium ${
                          vpsStatus.wireguardServer.status === 'active' ? 'text-green-400' : 'text-gray-400'
                        }`}>
                          {vpsStatus.wireguardServer.status.charAt(0).toUpperCase() + 
                           vpsStatus.wireguardServer.status.slice(1)}
                        </p>
                      </div>
                      <div>
                        <span className="text-sm text-gray-400">Clients:</span>
                        <p className="text-white font-medium">
                          {vpsStatus.wireguardServer.clientCount} / {vpsStatus.wireguardServer.maxClients}
                        </p>
                      </div>
                      <div>
                        <span className="text-sm text-gray-400">Public Key:</span>
                        <div className="flex items-center space-x-2">
                          <p className="text-gray-300 font-mono text-xs truncate">
                            {vpsStatus.wireguardServer.publicKey.substring(0, 20)}...
                          </p>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => copyToClipboard(vpsStatus.wireguardServer!.publicKey, 'Public key')}
                          >
                            <Copy className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </>
          )}
          
          {!vpsStatus && (
            <div className="text-center py-8">
              <div className="animate-spin h-8 w-8 border-2 border-enterprise-neon border-t-transparent rounded-full mx-auto mb-4" />
              <p className="text-gray-400">Loading VPS status...</p>
            </div>
          )}
        </div>
      </Modal>
    </div>
  )
}

export default VPNManagement