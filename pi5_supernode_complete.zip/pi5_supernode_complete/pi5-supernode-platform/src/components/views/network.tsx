import React, { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import {
  Network as NetworkIcon,
  Wifi,
  Server,
  Shield,
  Settings,
  Plus,
  Edit,
  Trash2,
  Power,
  RefreshCw,
  Globe,
  Router,
  Layers,
  Zap
} from 'lucide-react'
import { useNetworkStore, useUIStore } from '@/lib/store'
import { NetworkService, type DNSServer, type TrafficRule } from '@/lib/services'
import { callInterfaceFunction } from '@/lib/supabase'
import { Button } from '@/components/ui/button'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card'
import TableCard from '@/components/ui/table-card'
import MetricCard from '@/components/ui/metric-card'
import Modal from '@/components/ui/modal'
import AdvancedTrafficRules from '@/components/ui/advanced-traffic-rules'
import WANManagement from '@/components/ui/wan-management'
import { TrafficRulesManager } from '@/components/enhancements/TrafficRulesManager'
import { cn } from '@/lib/utils'

interface TrafficRuleFormData {
  name: string
  description: string
  priority: number
  enabled: boolean
  conditions: {
    source_ip?: string
    destination_ip?: string
    protocol?: string
    port?: string
    time_range?: string
  }
  actions: {
    allow?: boolean
    block?: boolean
    bandwidth_limit?: number
    redirect_to?: string
  }
}

interface DNSServerFormData {
  name: string
  ip_address: string
  port: number
  type: string
  is_primary: boolean
  is_active: boolean
}

const Network: React.FC = () => {
  const { trafficRules, setTrafficRules } = useNetworkStore()
  const { addNotification } = useUIStore()
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState('interfaces')
  const [showRuleModal, setShowRuleModal] = useState(false)
  const [showDNSModal, setShowDNSModal] = useState(false)
  const [dnsServers, setDnsServers] = useState<any[]>([])
  const [dhcpPools, setDhcpPools] = useState<any[]>([])
  const [wifiNetworks, setWifiNetworks] = useState<any[]>([])
  const [vlans, setVlans] = useState<any[]>([])
  const [interfaces, setInterfaces] = useState<any[]>([])
  
  const [ruleForm, setRuleForm] = useState<TrafficRuleFormData>({
    name: '',
    description: '',
    priority: 100,
    enabled: true,
    conditions: {},
    actions: {}
  })
  
  const [dnsForm, setDnsForm] = useState<DNSServerFormData>({
    name: '',
    ip_address: '',
    port: 53,
    type: 'standard',
    is_primary: false,
    is_active: true
  })

  useEffect(() => {
    loadNetworkData()
  }, [])

  const loadInterfaceData = async () => {
    try {
      const result = await callInterfaceFunction({})
      if (result?.data?.interfaces) {
        return result.data.interfaces
      }
      return []
    } catch (error) {
      console.error('Error loading interface data:', error)
      return []
    }
  }

  const loadNetworkData = async () => {
    try {
      setLoading(true)
      
      // Load all network data using NetworkService
      const [
        trafficRulesData,
        dnsServersData, 
        dhcpPoolsData,
        wifiNetworksData,
        vlansData,
        interfacesData
      ] = await Promise.all([
        NetworkService.getTrafficRules(),
        NetworkService.getDNSServers(),
        NetworkService.getDHCPPools(),
        NetworkService.getWiFiNetworks(),
        NetworkService.getVLANs(),
        loadInterfaceData()
      ])
      
      setTrafficRules(trafficRulesData)
      setDnsServers(dnsServersData)
      setDhcpPools(dhcpPoolsData)
      setWifiNetworks(wifiNetworksData)
      setVlans(vlansData)
      setInterfaces(interfacesData)
      
    } catch (error) {
      console.error('Error loading network data:', error)
      addNotification({ type: 'error', message: 'Failed to load network configuration' })
    } finally {
      setLoading(false)
    }
  }

  const handleCreateRule = async () => {
    try {
      await NetworkService.createTrafficRule(ruleForm)
      
      setShowRuleModal(false)
      setRuleForm({
        name: '',
        description: '',
        priority: 100,
        enabled: true,
        conditions: {},
        actions: {}
      })
      
      await loadNetworkData()
      addNotification({ type: 'success', message: 'Traffic rule created successfully' })
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to create traffic rule' })
    }
  }

  const handleApplyTrafficChanges = async () => {
    try {
      addNotification({ type: 'info', message: 'Applying traffic rule changes...' })
      
      const changes = trafficRules.map(rule => ({
        type: 'update',
        ruleId: rule.id,
        ruleData: rule
      }))
      
      const result = await NetworkService.applyTrafficChanges(changes)
      
      addNotification({ 
        type: 'success', 
        message: `Applied ${result.data.successful} traffic rule changes` 
      })
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to apply traffic changes' })
    }
  }

  const handleValidateRules = async () => {
    try {
      addNotification({ type: 'info', message: 'Validating traffic rules...' })
      
      const result = await NetworkService.validateTrafficRules(trafficRules)
      
      if (result.data.overallValid) {
        addNotification({ type: 'success', message: 'All traffic rules are valid' })
      } else {
        addNotification({ 
          type: 'warning', 
          message: `Found ${result.data.errors.length} errors and ${result.data.warnings.length} warnings` 
        })
      }
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to validate traffic rules' })
    }
  }

  const handleCreateDNSServer = async () => {
    try {
      await NetworkService.createDNSServer(dnsForm)
      
      setShowDNSModal(false)
      setDnsForm({
        name: '',
        ip_address: '',
        port: 53,
        type: 'standard',
        is_primary: false,
        is_active: true
      })
      
      await loadNetworkData()
      addNotification({ type: 'success', message: 'DNS server added successfully' })
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to add DNS server' })
    }
  }

  const toggleRuleStatus = async (rule: any) => {
    try {
      await NetworkService.toggleTrafficRule(rule.id, !rule.enabled)
      
      await loadNetworkData()
      addNotification({ 
        type: 'success', 
        message: `Rule ${rule.enabled ? 'disabled' : 'enabled'}` 
      })
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to update rule status' })
    }
  }

  const deleteRule = async (rule: any) => {
    try {
      await NetworkService.deleteTrafficRule(rule.id)
      
      await loadNetworkData()
      addNotification({ type: 'success', message: 'Traffic rule deleted' })
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to delete rule' })
    }
  }
  
  const deleteDNSServer = async (server: any) => {
    try {
      await NetworkService.deleteDNSServer(server.id)
      
      await loadNetworkData()
      addNotification({ type: 'success', message: 'DNS server deleted' })
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to delete DNS server' })
    }
  }

  const tabs = [
    { id: 'interfaces', label: 'Interface Management', icon: NetworkIcon },
    { id: 'wan', label: 'WAN Settings', icon: Globe },
    { id: 'traffic-rules', label: 'Advanced Traffic Rules', icon: Zap },
    { id: 'dns', label: 'DNS Servers', icon: Server },
    { id: 'dhcp', label: 'DHCP Pools', icon: Router },
    { id: 'wifi', label: 'WiFi Networks', icon: Wifi },
    { id: 'vlan', label: 'VLANs', icon: Layers },
    { id: 'traffic', label: 'Legacy Traffic Rules', icon: Shield }
  ]

  const ruleColumns = [
    {
      key: 'name' as keyof typeof trafficRules[0],
      label: 'Rule Name',
      sortable: true,
      render: (value: any, item: typeof trafficRules[0]) => (
        <div>
          <div className="font-medium text-white">{value}</div>
          <div className="text-sm text-gray-400">{item.description}</div>
        </div>
      )
    },
    {
      key: 'priority' as keyof typeof trafficRules[0],
      label: 'Priority',
      sortable: true,
      render: (value: any) => (
        <span className="font-mono text-sm text-gray-300">{value}</span>
      )
    },
    {
      key: 'conditions' as keyof typeof trafficRules[0],
      label: 'Conditions',
      render: (value: any) => (
        <div className="text-sm text-gray-300">
          {Object.entries(value || {}).map(([key, val]) => (
            <div key={key}>
              <span className="text-gray-400">{key}:</span> {String(val)}
            </div>
          ))}
        </div>
      )
    },
    {
      key: 'actions' as keyof typeof trafficRules[0],
      label: 'Actions',
      render: (value: any) => (
        <div className="text-sm text-gray-300">
          {Object.entries(value || {}).map(([key, val]) => (
            <div key={key}>
              <span className="text-gray-400">{key}:</span> {String(val)}
            </div>
          ))}
        </div>
      )
    },
    {
      key: 'enabled' as keyof typeof trafficRules[0],
      label: 'Status',
      sortable: true,
      render: (value: any) => (
        <span className={value ? 'status-active' : 'status-inactive'}>
          {value ? 'Enabled' : 'Disabled'}
        </span>
      )
    }
  ]

  const interfaceColumns = [
    {
      key: 'name' as keyof typeof interfaces[0],
      label: 'Interface Name',
      sortable: true,
      render: (value: any, item: typeof interfaces[0]) => (
        <div className="flex items-center space-x-3">
          <div className={`w-3 h-3 rounded-full ${
            item.status === 'up' ? 'bg-green-400' : 'bg-red-400'
          }`} />
          <div>
            <div className="font-medium text-white">{value}</div>
            <div className="text-sm text-gray-400 capitalize">{item.type}</div>
          </div>
        </div>
      )
    },
    {
      key: 'status' as keyof typeof interfaces[0],
      label: 'Status',
      sortable: true,
      render: (value: any) => (
        <span className={value === 'up' ? 'status-active' : 'status-inactive'}>
          {value?.toUpperCase()}
        </span>
      )
    },
    {
      key: 'ipv4_addresses' as keyof typeof interfaces[0],
      label: 'IPv4 Addresses',
      render: (value: any) => (
        <div className="space-y-1">
          {value && value.length > 0 ? (
            value.map((addr: any, idx: number) => (
              <div key={idx} className="text-sm">
                <span className="font-mono text-gray-300">{addr.address}/{addr.prefix}</span>
                <span className="ml-2 text-xs text-gray-500 capitalize">({addr.type})</span>
              </div>
            ))
          ) : (
            <span className="text-gray-500 text-sm">No IPv4</span>
          )}
        </div>
      )
    },
    {
      key: 'mac_address' as keyof typeof interfaces[0],
      label: 'MAC Address',
      render: (value: any) => (
        <span className="font-mono text-sm text-gray-300">
          {value || 'N/A'}
        </span>
      )
    },
    {
      key: 'mtu' as keyof typeof interfaces[0],
      label: 'MTU',
      sortable: true,
      render: (value: any) => (
        <span className="font-mono text-sm text-gray-300">{value}</span>
      )
    },
    {
      key: 'rx_bytes' as keyof typeof interfaces[0],
      label: 'RX/TX Bytes',
      render: (value: any, item: typeof interfaces[0]) => (
        <div className="text-sm space-y-1">
          <div>
            <span className="text-gray-400">RX:</span>
            <span className="ml-1 font-mono text-gray-300">
              {formatBytes(value || 0)}
            </span>
          </div>
          <div>
            <span className="text-gray-400">TX:</span>
            <span className="ml-1 font-mono text-gray-300">
              {formatBytes(item.tx_bytes || 0)}
            </span>
          </div>
        </div>
      )
    }
  ]

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 B'
    const k = 1024
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
  }

  const dnsColumns = [
    {
      key: 'name' as keyof typeof dnsServers[0],
      label: 'Server Name',
      sortable: true,
      render: (value: any, item: typeof dnsServers[0]) => (
        <div className="flex items-center space-x-2">
          {item.is_primary && <span className="w-2 h-2 bg-yellow-400 rounded-full" />}
          <span className="font-medium text-white">{value}</span>
        </div>
      )
    },
    {
      key: 'ip_address' as keyof typeof dnsServers[0],
      label: 'IP Address',
      sortable: true,
      render: (value: any) => (
        <span className="font-mono text-sm text-gray-300">{value}</span>
      )
    },
    {
      key: 'port' as keyof typeof dnsServers[0],
      label: 'Port',
      sortable: true,
      render: (value: any) => (
        <span className="font-mono text-sm text-gray-300">{value}</span>
      )
    },
    {
      key: 'type' as keyof typeof dnsServers[0],
      label: 'Type',
      render: (value: any) => (
        <span className="status-badge bg-blue-500/20 text-blue-300 border-blue-500/30">
          {value}
        </span>
      )
    },
    {
      key: 'is_active' as keyof typeof dnsServers[0],
      label: 'Status',
      render: (value: any) => (
        <span className={value ? 'status-active' : 'status-inactive'}>
          {value ? 'Active' : 'Inactive'}
        </span>
      )
    }
  ]

  const renderTabContent = () => {
    switch (activeTab) {
      case 'interfaces':
        return (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h3 className="text-xl font-semibold text-white">Network Interface Management</h3>
              <Button variant="outline" onClick={loadNetworkData}>
                <RefreshCw className="h-4 w-4 mr-2" />
                Refresh
              </Button>
            </div>
            
            <TableCard
              title="Network Interfaces"
              description="System network interfaces and their configuration"
              data={interfaces}
              columns={interfaceColumns}
              loading={loading}
              actions={[
                {
                  label: 'Configure',
                  onClick: (intf) => console.log('Configure interface:', intf),
                  variant: 'outline'
                },
                {
                  label: 'Status',
                  onClick: (intf) => console.log('Toggle interface:', intf),
                  variant: 'outline'
                }
              ]}
            />
          </div>
        )
        
      case 'wan':
        return <WANManagement />
        
      case 'traffic-rules':
        return <TrafficRulesManager />
        
      case 'dns':
        return (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h3 className="text-xl font-semibold text-white">DNS Server Configuration</h3>
              <Button variant="neon" onClick={() => setShowDNSModal(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Add DNS Server
              </Button>
            </div>
            
            <TableCard
              title="DNS Servers"
              description="Manage DNS server configurations"
              data={dnsServers}
              columns={dnsColumns}
              loading={loading}
              actions={[
                {
                  label: 'Edit',
                  onClick: (server) => console.log('Edit DNS server:', server),
                  variant: 'outline'
                },
                {
                  label: 'Delete',
                  onClick: deleteDNSServer,
                  variant: 'destructive'
                }
              ]}
            />
          </div>
        )
      
      case 'traffic':
        return (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h3 className="text-xl font-semibold text-white">Traffic Rule Management</h3>
              <div className="flex items-center space-x-3">
                <Button variant="outline" onClick={handleValidateRules}>
                  <Shield className="h-4 w-4 mr-2" />
                  Validate Rules
                </Button>
                <Button variant="outline" onClick={handleApplyTrafficChanges}>
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Apply Changes
                </Button>
                <Button variant="neon" onClick={() => setShowRuleModal(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Create Rule
                </Button>
              </div>
            </div>
            
            <TableCard
              title="Traffic Rules"
              description="Network traffic control and filtering rules"
              data={trafficRules}
              columns={ruleColumns}
              loading={loading}
              actions={[
                {
                  label: 'Toggle',
                  onClick: toggleRuleStatus,
                  variant: 'outline'
                },
                {
                  label: 'Edit',
                  onClick: (rule) => console.log('Edit rule:', rule),
                  variant: 'outline'
                },
                {
                  label: 'Delete',
                  onClick: deleteRule,
                  variant: 'destructive'
                }
              ]}
            />
          </div>
        )
      
      default:
        return (
          <div className="text-center py-12">
            <div className="text-gray-400 text-lg">Configuration panel for {activeTab.toUpperCase()}</div>
            <div className="text-gray-500 mt-2">Coming soon...</div>
          </div>
        )
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Network Configuration</h1>
          <p className="text-gray-400">DNS, DHCP, WiFi, VLAN, and traffic rule management</p>
        </div>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
        <MetricCard
          title="Network Interfaces"
          value={interfaces.length}
          subtitle={`${interfaces.filter(i => i.status === 'up').length} active`}
          icon={NetworkIcon}
          color="success"
          loading={loading}
        />
        
        <MetricCard
          title="DNS Servers"
          value={dnsServers.length}
          subtitle={`${dnsServers.filter(d => d.is_active).length} active`}
          icon={Globe}
          color="info"
          loading={loading}
        />
        
        <MetricCard
          title="Traffic Rules"
          value={trafficRules.length}
          subtitle={`${trafficRules.filter(r => r.enabled).length} enabled`}
          icon={Shield}
          color="success"
          loading={loading}
        />
        
        <MetricCard
          title="WiFi Networks"
          value={wifiNetworks.length}
          subtitle={`${wifiNetworks.filter(w => w.is_enabled).length} broadcasting`}
          icon={Wifi}
          color="info"
          loading={loading}
        />
        
        <MetricCard
          title="VLAN Count"
          value={vlans.length}
          subtitle="Network segments"
          icon={Layers}
          color="info"
          loading={loading}
        />
      </div>

      {/* Tab Navigation */}
      <Card>
        <CardHeader>
          <div className="flex space-x-1 bg-gray-800 p-1 rounded-lg">
            {tabs.map((tab) => {
              const Icon = tab.icon
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={cn(
                    'flex items-center space-x-2 px-4 py-2 rounded-md text-sm font-medium transition-all',
                    activeTab === tab.id
                      ? 'bg-enterprise-neon text-enterprise-dark'
                      : 'text-gray-400 hover:text-white hover:bg-white/5'
                  )}
                >
                  <Icon className="h-4 w-4" />
                  <span>{tab.label}</span>
                </button>
              )
            })}
          </div>
        </CardHeader>
        
        <CardContent>
          {renderTabContent()}
        </CardContent>
      </Card>

      {/* Traffic Rule Modal */}
      <Modal
        isOpen={showRuleModal}
        onClose={() => setShowRuleModal(false)}
        title="Create Traffic Rule"
        description="Define network traffic control policies"
        size="lg"
      >
        <div className="space-y-6">
          {/* Basic Info */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Rule Name
              </label>
              <input
                type="text"
                value={ruleForm.name}
                onChange={(e) => setRuleForm({...ruleForm, name: e.target.value})}
                className="w-full enterprise-input rounded-lg px-3 py-2"
                placeholder="Block Social Media"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Priority
              </label>
              <input
                type="number"
                value={ruleForm.priority}
                onChange={(e) => setRuleForm({...ruleForm, priority: parseInt(e.target.value)})}
                className="w-full enterprise-input rounded-lg px-3 py-2"
                min="1"
                max="1000"
              />
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Description
            </label>
            <textarea
              value={ruleForm.description}
              onChange={(e) => setRuleForm({...ruleForm, description: e.target.value})}
              className="w-full enterprise-input rounded-lg px-3 py-2"
              rows={3}
              placeholder="Block access to social media sites during work hours"
            />
          </div>
          
          {/* Conditions */}
          <div>
            <h4 className="text-lg font-medium text-white mb-3">Conditions</h4>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Source IP/CIDR
                </label>
                <input
                  type="text"
                  value={ruleForm.conditions.source_ip || ''}
                  onChange={(e) => setRuleForm({
                    ...ruleForm, 
                    conditions: {...ruleForm.conditions, source_ip: e.target.value}
                  })}
                  className="w-full enterprise-input rounded-lg px-3 py-2"
                  placeholder="192.168.1.0/24"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Protocol
                </label>
                <select
                  value={ruleForm.conditions.protocol || ''}
                  onChange={(e) => setRuleForm({
                    ...ruleForm, 
                    conditions: {...ruleForm.conditions, protocol: e.target.value}
                  })}
                  className="w-full enterprise-input rounded-lg px-3 py-2"
                >
                  <option value="">Any</option>
                  <option value="tcp">TCP</option>
                  <option value="udp">UDP</option>
                  <option value="icmp">ICMP</option>
                </select>
              </div>
            </div>
          </div>
          
          {/* Actions */}
          <div>
            <h4 className="text-lg font-medium text-white mb-3">Actions</h4>
            <div className="space-y-3">
              <div className="flex items-center space-x-4">
                <label className="flex items-center space-x-2">
                  <input
                    type="radio"
                    name="action"
                    checked={ruleForm.actions.allow}
                    onChange={() => setRuleForm({
                      ...ruleForm, 
                      actions: {allow: true, block: false}
                    })}
                    className="text-enterprise-neon"
                  />
                  <span className="text-white">Allow</span>
                </label>
                
                <label className="flex items-center space-x-2">
                  <input
                    type="radio"
                    name="action"
                    checked={ruleForm.actions.block}
                    onChange={() => setRuleForm({
                      ...ruleForm, 
                      actions: {allow: false, block: true}
                    })}
                    className="text-enterprise-neon"
                  />
                  <span className="text-white">Block</span>
                </label>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Bandwidth Limit (MB/s)
                </label>
                <input
                  type="number"
                  value={ruleForm.actions.bandwidth_limit || ''}
                  onChange={(e) => setRuleForm({
                    ...ruleForm, 
                    actions: {...ruleForm.actions, bandwidth_limit: parseInt(e.target.value)}
                  })}
                  className="w-full enterprise-input rounded-lg px-3 py-2"
                  placeholder="100"
                />
              </div>
            </div>
          </div>
          
          <div className="flex justify-end space-x-3 pt-4">
            <Button variant="outline" onClick={() => setShowRuleModal(false)}>
              Cancel
            </Button>
            <Button variant="neon" onClick={handleCreateRule}>
              Create Rule
            </Button>
          </div>
        </div>
      </Modal>

      {/* DNS Server Modal */}
      <Modal
        isOpen={showDNSModal}
        onClose={() => setShowDNSModal(false)}
        title="Add DNS Server"
        description="Configure a new DNS server"
      >
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Server Name
            </label>
            <input
              type="text"
              value={dnsForm.name}
              onChange={(e) => setDnsForm({...dnsForm, name: e.target.value})}
              className="w-full enterprise-input rounded-lg px-3 py-2"
              placeholder="Cloudflare DNS"
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                IP Address
              </label>
              <input
                type="text"
                value={dnsForm.ip_address}
                onChange={(e) => setDnsForm({...dnsForm, ip_address: e.target.value})}
                className="w-full enterprise-input rounded-lg px-3 py-2"
                placeholder="1.1.1.1"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Port
              </label>
              <input
                type="number"
                value={dnsForm.port}
                onChange={(e) => setDnsForm({...dnsForm, port: parseInt(e.target.value)})}
                className="w-full enterprise-input rounded-lg px-3 py-2"
                placeholder="53"
              />
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Server Type
            </label>
            <select
              value={dnsForm.type}
              onChange={(e) => setDnsForm({...dnsForm, type: e.target.value})}
              className="w-full enterprise-input rounded-lg px-3 py-2"
            >
              <option value="standard">Standard</option>
              <option value="secure">Secure DNS</option>
              <option value="filtering">Content Filtering</option>
              <option value="private">Private DNS</option>
            </select>
          </div>
          
          <div className="flex items-center space-x-4">
            <label className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={dnsForm.is_primary}
                onChange={(e) => setDnsForm({...dnsForm, is_primary: e.target.checked})}
                className="text-enterprise-neon"
              />
              <span className="text-white">Primary DNS Server</span>
            </label>
            
            <label className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={dnsForm.is_active}
                onChange={(e) => setDnsForm({...dnsForm, is_active: e.target.checked})}
                className="text-enterprise-neon"
              />
              <span className="text-white">Active</span>
            </label>
          </div>
          
          <div className="flex justify-end space-x-3 pt-4">
            <Button variant="outline" onClick={() => setShowDNSModal(false)}>
              Cancel
            </Button>
            <Button variant="neon" onClick={handleCreateDNSServer}>
              Add Server
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  )
}

export default Network