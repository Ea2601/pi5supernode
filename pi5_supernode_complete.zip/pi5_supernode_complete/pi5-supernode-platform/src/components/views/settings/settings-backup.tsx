import React, { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import {
  Database,
  Download,
  Upload,
  RefreshCw,
  Save,
  Clock,
  HardDrive,
  CheckCircle,
  AlertTriangle,
  Settings,
  Calendar,
  Archive,
  Trash2
} from 'lucide-react'
import { useUIStore } from '@/lib/store'
import { SettingsService } from '@/lib/services'
import { Button } from '@/components/ui/button'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card'
import MetricCard from '@/components/ui/metric-card'
import TableCard from '@/components/ui/table-card'
import Modal from '@/components/ui/modal'
import { cn } from '@/lib/utils'

interface BackupEntry {
  id: string
  name: string
  type: 'automatic' | 'manual'
  size: number
  created_at: string
  status: 'completed' | 'failed' | 'in_progress'
  includes: string[]
  restore_tested: boolean
}

const SettingsBackup: React.FC = () => {
  const { addNotification } = useUIStore()
  const [loading, setLoading] = useState(true)
  const [creating, setCreating] = useState(false)
  const [restoring, setRestoring] = useState(false)
  const [showCreateModal, setShowCreateModal] = useState(false)
  const [showRestoreModal, setShowRestoreModal] = useState(false)
  const [selectedBackup, setSelectedBackup] = useState<BackupEntry | null>(null)
  const [backups, setBackups] = useState<BackupEntry[]>([])
  const [loadError, setLoadError] = useState<string | null>(null)
  
  const [backupSettings, setBackupSettings] = useState({
    auto_backup_enabled: true,
    backup_schedule: '0 2 * * *',
    retention_days: 30,
    backup_location: '/var/backups/pi5-supernode',
    include_logs: true,
    include_configs: true,
    include_databases: true,
    include_certificates: true,
    compression_enabled: true
  })

  const [backupStats, setBackupStats] = useState({
    total_backups: 0,
    total_size: 0,
    last_backup: '',
    success_rate: 0
  })

  const [createBackupForm, setCreateBackupForm] = useState({
    name: '',
    description: '',
    include_logs: true,
    include_configs: true,
    include_databases: true,
    include_certificates: true
  })

  useEffect(() => {
    const initializeData = async () => {
      try {
        setLoadError(null)
        await loadBackupData()
      } catch (error) {
        console.error('Failed to initialize backup data:', error)
        setLoadError('Failed to load backup data')
      }
    }
    
    initializeData()
  }, [])

  const loadBackupData = async () => {
    try {
      setLoading(true)
      setLoadError(null)
      
      const timeoutPromise = new Promise((_, reject) => 
        setTimeout(() => reject(new Error('Request timeout')), 10000)
      )
      
      const dataPromises = Promise.all([
        SettingsService.getBackups(),
        SettingsService.getBackupSettings(),
        SettingsService.getBackupStats()
      ])
      
      const [backupsData, settingsData, statsData] = await Promise.race([dataPromises, timeoutPromise]) as any
      
      if (Array.isArray(backupsData)) setBackups(backupsData)
      if (settingsData && typeof settingsData === 'object') setBackupSettings(prev => ({ ...prev, ...settingsData }))
      if (statsData && typeof statsData === 'object') setBackupStats(prev => ({ ...prev, ...statsData }))
      
    } catch (error) {
      console.error('Error loading backup data:', error)
      setLoadError('Unable to load backup data')
    } finally {
      setLoading(false)
    }
  }

  const saveBackupSettings = async () => {
    try {
      await SettingsService.saveBackupSettings(backupSettings)
      addNotification({ type: 'success', message: 'Backup settings saved successfully' })
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to save backup settings' })
    }
  }

  const createBackup = async () => {
    try {
      setCreating(true)
      
      const backupData = {
        ...createBackupForm,
        type: 'manual' as const
      }
      
      await SettingsService.createBackup(backupData)
      
      setShowCreateModal(false)
      setCreateBackupForm({
        name: '',
        description: '',
        include_logs: true,
        include_configs: true,
        include_databases: true,
        include_certificates: true
      })
      
      await loadBackupData()
      addNotification({ type: 'success', message: 'Backup created successfully' })
      
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to create backup' })
    } finally {
      setCreating(false)
    }
  }

  const restoreBackup = async () => {
    if (!selectedBackup) return
    
    try {
      setRestoring(true)
      
      await SettingsService.restoreBackup(selectedBackup.id)
      
      setShowRestoreModal(false)
      setSelectedBackup(null)
      
      addNotification({ 
        type: 'success', 
        message: 'Backup restoration initiated. System will restart after completion.' 
      })
      
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to restore backup' })
    } finally {
      setRestoring(false)
    }
  }

  const downloadBackup = async (backup: BackupEntry) => {
    try {
      const downloadUrl = await SettingsService.getBackupDownloadUrl(backup.id)
      window.open(downloadUrl, '_blank')
      
      addNotification({ type: 'success', message: 'Backup download started' })
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to download backup' })
    }
  }

  const deleteBackup = async (backup: BackupEntry) => {
    if (!confirm(`Are you sure you want to delete backup "${backup.name}"?`)) return
    
    try {
      await SettingsService.deleteBackup(backup.id)
      await loadBackupData()
      addNotification({ type: 'success', message: 'Backup deleted successfully' })
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to delete backup' })
    }
  }

  const testRestore = async (backup: BackupEntry) => {
    try {
      addNotification({ type: 'info', message: 'Testing backup integrity...' })
      
      const result = await SettingsService.testBackupRestore(backup.id)
      
      if (result.success) {
        addNotification({ type: 'success', message: 'Backup integrity test passed' })
      } else {
        addNotification({ type: 'error', message: `Backup test failed: ${result.error}` })
      }
      
      await loadBackupData()
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to test backup' })
    }
  }

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 Bytes'
    const k = 1024
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'text-green-400'
      case 'failed':
        return 'text-red-400'
      case 'in_progress':
        return 'text-yellow-400'
      default:
        return 'text-gray-400'
    }
  }

  const scheduleOptions = [
    { value: '0 2 * * *', label: 'Daily at 2:00 AM' },
    { value: '0 3 * * 0', label: 'Weekly on Sunday at 3:00 AM' },
    { value: '0 4 1 * *', label: 'Monthly on 1st at 4:00 AM' },
    { value: '0 5 1 1,4,7,10 *', label: 'Quarterly at 5:00 AM' }
  ]

  const backupColumns = [
    {
      key: 'name' as keyof BackupEntry,
      label: 'Backup',
      sortable: true,
      render: (value: any, item: BackupEntry) => (
        <div className="flex items-center space-x-3">
          <div className={`p-2 rounded-lg ${
            item.status === 'completed' ? 'bg-green-500/20' : 
            item.status === 'failed' ? 'bg-red-500/20' : 'bg-yellow-500/20'
          }`}>
            <Archive className={`h-4 w-4 ${
              item.status === 'completed' ? 'text-green-400' : 
              item.status === 'failed' ? 'text-red-400' : 'text-yellow-400'
            }`} />
          </div>
          <div>
            <div className="font-medium text-white">{value}</div>
            <div className="text-sm text-gray-400">
              {item.type === 'automatic' ? 'Automatic' : 'Manual'} backup
            </div>
          </div>
        </div>
      )
    },
    {
      key: 'size' as keyof BackupEntry,
      label: 'Size',
      sortable: true,
      render: (value: any) => (
        <span className="font-mono text-sm text-gray-300">
          {formatBytes(value)}
        </span>
      )
    },
    {
      key: 'created_at' as keyof BackupEntry,
      label: 'Created',
      sortable: true,
      render: (value: any) => (
        <div className="text-sm">
          <div className="text-gray-300">{new Date(value).toLocaleDateString()}</div>
          <div className="text-gray-500">{new Date(value).toLocaleTimeString()}</div>
        </div>
      )
    },
    {
      key: 'includes' as keyof BackupEntry,
      label: 'Contents',
      render: (value: any) => (
        <div className="flex flex-wrap gap-1">
          {Array.isArray(value) && value.map((item, index) => (
            <span key={index} className="px-2 py-1 bg-blue-500/20 text-blue-300 rounded text-xs">
              {item}
            </span>
          ))}
        </div>
      )
    },
    {
      key: 'status' as keyof BackupEntry,
      label: 'Status',
      sortable: true,
      render: (value: any, item: BackupEntry) => (
        <div className="space-y-1">
          <span className={`${getStatusColor(value)} capitalize font-medium`}>
            {value.replace('_', ' ')}
          </span>
          {item.restore_tested && (
            <div className="flex items-center space-x-1">
              <CheckCircle className="h-3 w-3 text-green-400" />
              <span className="text-xs text-green-400">Tested</span>
            </div>
          )}
        </div>
      )
    },
    {
      key: 'id' as keyof BackupEntry,
      label: 'Actions',
      render: (value: any, item: BackupEntry) => (
        <div className="flex items-center space-x-2">
          <Button
            size="sm"
            variant="ghost"
            onClick={() => downloadBackup(item)}
            title="Download backup"
          >
            <Download className="h-4 w-4" />
          </Button>
          
          <Button
            size="sm"
            variant="ghost"
            onClick={() => testRestore(item)}
            title="Test backup"
          >
            <CheckCircle className="h-4 w-4" />
          </Button>
          
          <Button
            size="sm"
            variant="ghost"
            onClick={() => {
              setSelectedBackup(item)
              setShowRestoreModal(true)
            }}
            title="Restore backup"
          >
            <Upload className="h-4 w-4" />
          </Button>
          
          <Button
            size="sm"
            variant="ghost"
            onClick={() => deleteBackup(item)}
            className="text-red-400 hover:text-red-300"
            title="Delete backup"
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      )
    }
  ]

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white mb-1">Backup & Restore</h2>
          <p className="text-gray-400">Manage system backups and disaster recovery</p>
        </div>
        
        <div className="flex items-center space-x-3">
          <Button
            variant="outline"
            onClick={loadBackupData}
            loading={loading}
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          
          <Button 
            variant="neon"
            onClick={() => setShowCreateModal(true)}
          >
            <Archive className="h-4 w-4 mr-2" />
            Create Backup
          </Button>
        </div>
      </div>

      {/* Backup Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          title="Total Backups"
          value={backupStats.total_backups.toString()}
          subtitle="Created backups"
          icon={Archive}
          color="info"
          loading={loading}
        />
        
        <MetricCard
          title="Storage Used"
          value={formatBytes(backupStats.total_size)}
          subtitle="Backup storage"
          icon={HardDrive}
          color="warning"
          loading={loading}
        />
        
        <MetricCard
          title="Last Backup"
          value={backupStats.last_backup ? new Date(backupStats.last_backup).toLocaleDateString() : 'Never'}
          subtitle="Most recent"
          icon={Clock}
          color="success"
          loading={loading}
        />
        
        <MetricCard
          title="Success Rate"
          value={`${backupStats.success_rate}%`}
          subtitle="Backup reliability"
          icon={CheckCircle}
          color={backupStats.success_rate >= 95 ? 'success' : backupStats.success_rate >= 85 ? 'warning' : 'danger'}
          loading={loading}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Backup Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Settings className="h-5 w-5 text-enterprise-neon" />
              <span>Backup Settings</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <label className="text-sm font-medium text-gray-300">
                    Automatic Backups
                  </label>
                  <p className="text-xs text-gray-500">Schedule regular backups</p>
                </div>
                <input
                  type="checkbox"
                  checked={backupSettings.auto_backup_enabled}
                  onChange={(e) => setBackupSettings(prev => ({ ...prev, auto_backup_enabled: e.target.checked }))}
                  className="enterprise-checkbox"
                />
              </div>
              
              {backupSettings.auto_backup_enabled && (
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Backup Schedule
                  </label>
                  <select
                    value={backupSettings.backup_schedule}
                    onChange={(e) => setBackupSettings(prev => ({ ...prev, backup_schedule: e.target.value }))}
                    className="enterprise-input w-full"
                  >
                    {scheduleOptions.map(option => (
                      <option key={option.value} value={option.value}>
                        {option.label}
                      </option>
                    ))}
                  </select>
                </div>
              )}
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Retention Period (days)
                </label>
                <input
                  type="number"
                  value={backupSettings.retention_days}
                  onChange={(e) => setBackupSettings(prev => ({ ...prev, retention_days: parseInt(e.target.value) }))}
                  className="enterprise-input w-full"
                  min="1"
                  max="365"
                />
                <p className="text-xs text-gray-500 mt-1">How long to keep backups</p>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Backup Location
                </label>
                <input
                  type="text"
                  value={backupSettings.backup_location}
                  onChange={(e) => setBackupSettings(prev => ({ ...prev, backup_location: e.target.value }))}
                  className="enterprise-input w-full font-mono text-sm"
                />
              </div>
              
              <div className="flex justify-end pt-4">
                <Button
                  variant="neon"
                  onClick={saveBackupSettings}
                >
                  <Save className="h-4 w-4 mr-2" />
                  Save Settings
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Backup Contents */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Database className="h-5 w-5 text-enterprise-neon" />
              <span>Backup Contents</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <label className="text-sm font-medium text-gray-300">
                      Configuration Files
                    </label>
                    <p className="text-xs text-gray-500">System and application configs</p>
                  </div>
                  <input
                    type="checkbox"
                    checked={backupSettings.include_configs}
                    onChange={(e) => setBackupSettings(prev => ({ ...prev, include_configs: e.target.checked }))}
                    className="enterprise-checkbox"
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <label className="text-sm font-medium text-gray-300">
                      Databases
                    </label>
                    <p className="text-xs text-gray-500">User data and settings</p>
                  </div>
                  <input
                    type="checkbox"
                    checked={backupSettings.include_databases}
                    onChange={(e) => setBackupSettings(prev => ({ ...prev, include_databases: e.target.checked }))}
                    className="enterprise-checkbox"
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <label className="text-sm font-medium text-gray-300">
                      Certificates & Keys
                    </label>
                    <p className="text-xs text-gray-500">SSL certificates and private keys</p>
                  </div>
                  <input
                    type="checkbox"
                    checked={backupSettings.include_certificates}
                    onChange={(e) => setBackupSettings(prev => ({ ...prev, include_certificates: e.target.checked }))}
                    className="enterprise-checkbox"
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <label className="text-sm font-medium text-gray-300">
                      System Logs
                    </label>
                    <p className="text-xs text-gray-500">Application and system logs</p>
                  </div>
                  <input
                    type="checkbox"
                    checked={backupSettings.include_logs}
                    onChange={(e) => setBackupSettings(prev => ({ ...prev, include_logs: e.target.checked }))}
                    className="enterprise-checkbox"
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <label className="text-sm font-medium text-gray-300">
                      Compression
                    </label>
                    <p className="text-xs text-gray-500">Compress backups to save space</p>
                  </div>
                  <input
                    type="checkbox"
                    checked={backupSettings.compression_enabled}
                    onChange={(e) => setBackupSettings(prev => ({ ...prev, compression_enabled: e.target.checked }))}
                    className="enterprise-checkbox"
                  />
                </div>
              </div>
              
              <div className="pt-4 border-t border-gray-700">
                <h4 className="text-sm font-medium text-gray-300 mb-2">Estimated Backup Size</h4>
                <div className="text-sm text-gray-400">
                  Next backup will be approximately 2.4 GB
                  {backupSettings.compression_enabled && ' (compressed)'}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Backup History */}
      <TableCard
        title="Backup History"
        description={`${backups.length} backups available`}
        data={backups}
        columns={backupColumns}
        loading={loading}
        emptyMessage="No backups found. Create your first backup to get started."
      />

      {/* Create Backup Modal */}
      <Modal
        isOpen={showCreateModal}
        onClose={() => setShowCreateModal(false)}
        title="Create Manual Backup"
      >
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Backup Name
            </label>
            <input
              type="text"
              value={createBackupForm.name}
              onChange={(e) => setCreateBackupForm(prev => ({ ...prev, name: e.target.value }))}
              className="enterprise-input w-full"
              placeholder="Manual backup - 2024-01-15"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Description
            </label>
            <textarea
              value={createBackupForm.description}
              onChange={(e) => setCreateBackupForm(prev => ({ ...prev, description: e.target.value }))}
              className="enterprise-input w-full h-20 resize-none"
              placeholder="Describe this backup..."
            />
          </div>
          
          <div className="space-y-3">
            <h4 className="text-sm font-medium text-gray-300">Include in Backup</h4>
            
            <div className="space-y-2">
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={createBackupForm.include_configs}
                  onChange={(e) => setCreateBackupForm(prev => ({ ...prev, include_configs: e.target.checked }))}
                  className="enterprise-checkbox"
                />
                <span className="text-sm text-gray-300">Configuration files</span>
              </label>
              
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={createBackupForm.include_databases}
                  onChange={(e) => setCreateBackupForm(prev => ({ ...prev, include_databases: e.target.checked }))}
                  className="enterprise-checkbox"
                />
                <span className="text-sm text-gray-300">Databases</span>
              </label>
              
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={createBackupForm.include_certificates}
                  onChange={(e) => setCreateBackupForm(prev => ({ ...prev, include_certificates: e.target.checked }))}
                  className="enterprise-checkbox"
                />
                <span className="text-sm text-gray-300">Certificates & keys</span>
              </label>
              
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={createBackupForm.include_logs}
                  onChange={(e) => setCreateBackupForm(prev => ({ ...prev, include_logs: e.target.checked }))}
                  className="enterprise-checkbox"
                />
                <span className="text-sm text-gray-300">System logs</span>
              </label>
            </div>
          </div>
          
          <div className="flex justify-end space-x-3 pt-4 border-t border-gray-700">
            <Button
              variant="outline"
              onClick={() => setShowCreateModal(false)}
            >
              Cancel
            </Button>
            
            <Button
              variant="neon"
              onClick={createBackup}
              loading={creating}
            >
              Create Backup
            </Button>
          </div>
        </div>
      </Modal>

      {/* Restore Backup Modal */}
      <Modal
        isOpen={showRestoreModal}
        onClose={() => {
          setShowRestoreModal(false)
          setSelectedBackup(null)
        }}
        title="Restore System Backup"
      >
        <div className="space-y-4">
          {selectedBackup && (
            <div className="p-4 bg-yellow-500/10 border border-yellow-500/30 rounded-lg">
              <div className="flex items-center space-x-2 text-yellow-400 mb-2">
                <AlertTriangle className="h-5 w-5" />
                <span className="font-medium">Warning: System Restore</span>
              </div>
              <div className="text-sm text-gray-300 space-y-1">
                <p>This will restore your system to the state when this backup was created:</p>
                <ul className="list-disc list-inside ml-4 space-y-1">
                  <li>Backup: <strong>{selectedBackup.name}</strong></li>
                  <li>Created: <strong>{new Date(selectedBackup.created_at).toLocaleString()}</strong></li>
                  <li>Size: <strong>{formatBytes(selectedBackup.size)}</strong></li>
                </ul>
                <p className="mt-3 font-medium text-yellow-400">
                  The system will restart automatically after restoration is complete.
                </p>
              </div>
            </div>
          )}
          
          <div className="flex justify-end space-x-3">
            <Button
              variant="outline"
              onClick={() => {
                setShowRestoreModal(false)
                setSelectedBackup(null)
              }}
            >
              Cancel
            </Button>
            
            <Button
              variant="destructive"
              onClick={restoreBackup}
              loading={restoring}
            >
              Restore System
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  )
}

export default SettingsBackup