import React, { useState, useEffect } from 'react'
import { NavLink, Outlet, useLocation } from 'react-router-dom'
import { motion } from 'framer-motion'
import {
  Settings as SettingsIcon,
  Shield,
  Database,
  Users,
  Zap,
  RefreshCw,
  TrendingUp,
  Clock,
  Monitor,
  Terminal,
  AlertTriangle
} from 'lucide-react'
import { useUIStore } from '@/lib/store'
import { SettingsService } from '@/lib/services'
import { Button } from '@/components/ui/button'
import MetricCard from '@/components/ui/metric-card'
import { cn } from '@/lib/utils'

// Error Boundary Component
class SettingsErrorBoundary extends React.Component<
  { children: React.ReactNode },
  { hasError: boolean; error?: Error }
> {
  constructor(props: { children: React.ReactNode }) {
    super(props)
    this.state = { hasError: false }
  }

  static getDerivedStateFromError(error: Error) {
    return { hasError: true, error }
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error('Settings component error:', error, errorInfo)
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="flex items-center justify-center p-8">
          <div className="text-center">
            <AlertTriangle className="h-12 w-12 text-red-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-white mb-2">Settings Error</h3>
            <p className="text-gray-400 mb-4">There was an error loading the settings page.</p>
            <Button onClick={() => window.location.reload()}>
              Reload Page
            </Button>
          </div>
        </div>
      )
    }

    return this.props.children as React.ReactElement
  }
}

const SettingsMain: React.FC = () => {
  const { addNotification } = useUIStore()
  const [loading, setLoading] = useState(false)
  const [systemStats, setSystemStats] = useState({
    uptime: '15d 8h',
    ssh_status: 'Enabled',
    firewall_status: 'Active',
    auto_updates: 'Enabled'
  })
  const [loadError, setLoadError] = useState<string | null>(null)
  
  const location = useLocation()
  
  useEffect(() => {
    const initializeSettings = async () => {
      try {
        setLoadError(null)
        await loadSystemStats()
      } catch (error) {
        console.error('Failed to initialize settings:', error)
        setLoadError('Failed to load settings data')
      }
    }
    
    initializeSettings()
  }, [])

  const loadSystemStats = async () => {
    try {
      setLoading(true)
      setLoadError(null)
      
      // Load system statistics with timeout
      const timeoutPromise = new Promise((_, reject) => 
        setTimeout(() => reject(new Error('Request timeout')), 10000)
      )
      
      const statsPromise = SettingsService.getSystemStats()
      const stats = await Promise.race([statsPromise, timeoutPromise]) as any
      
      if (stats && typeof stats === 'object') {
        setSystemStats({
          uptime: stats.uptime || '15d 8h',
          ssh_status: stats.ssh_status || 'Enabled',
          firewall_status: stats.firewall_status || 'Active',
          auto_updates: stats.auto_updates || 'Enabled'
        })
      }
      
    } catch (error) {
      console.error('Error loading system stats:', error)
      setLoadError('Unable to load system statistics')
      // Don't show notification on load errors to prevent spam
      // addNotification({ type: 'error', message: 'Failed to load system statistics' })
    } finally {
      setLoading(false)
    }
  }

  const refreshAll = async () => {
    setLoading(true)
    try {
      setLoadError(null)
      await loadSystemStats()
      if (!loadError) {
        addNotification({ type: 'success', message: 'System data refreshed' })
      }
    } catch (error) {
      setLoadError('Failed to refresh system data')
      addNotification({ type: 'error', message: 'Failed to refresh system data' })
    } finally {
      setLoading(false)
    }
  }

  const restartSystem = async () => {
    if (!confirm('Are you sure you want to restart the system? This will disconnect all users.')) return
    
    try {
      addNotification({ type: 'warning', message: 'System restart initiated...' })
      await SettingsService.restartSystem()
      addNotification({ type: 'info', message: 'System will restart in 10 seconds' })
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to restart system' })
    }
  }

  const navigationItems = [
    {
      path: '/settings/system',
      label: 'System Configuration',
      icon: SettingsIcon,
      description: 'Basic system settings and configuration'
    },
    {
      path: '/settings/security',
      label: 'Security Settings',
      icon: Shield,
      description: 'Firewall, authentication, and security policies'
    },
    {
      path: '/settings/backup',
      label: 'Backup & Restore',
      icon: Database,
      description: 'System backup and restore management'
    },
    {
      path: '/settings/users',
      label: 'User Management',
      icon: Users,
      description: 'User accounts and access control'
    },
    {
      path: '/settings/advanced',
      label: 'Advanced Settings',
      icon: Zap,
      description: 'Advanced system configuration options'
    }
  ]

  // Check if we're on the main settings page (no subroute)
  const isMainPage = location.pathname === '/settings'

  // Show error state if there's a persistent error
  if (loadError && !loading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">System Settings</h1>
            <p className="text-gray-400">Configure and manage your Pi5 Supernode system</p>
          </div>
          
          <Button
            variant="outline"
            onClick={refreshAll}
            loading={loading}
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Retry
          </Button>
        </div>
        
        <div className="glassmorphism-card p-8 text-center">
          <AlertTriangle className="h-12 w-12 text-yellow-400 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-white mb-2">Unable to Load Settings</h3>
          <p className="text-gray-400 mb-4">{loadError}</p>
          <p className="text-sm text-gray-500 mb-6">
            This may be due to network connectivity issues or backend services being unavailable.
          </p>
          <div className="flex justify-center space-x-3">
            <Button onClick={refreshAll} loading={loading}>
              Try Again
            </Button>
            <Button variant="outline" onClick={() => window.location.reload()}>
              Reload Page
            </Button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <SettingsErrorBoundary>
      <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">System Settings</h1>
          <p className="text-gray-400">Configure and manage your Pi5 Supernode system</p>
        </div>
        
        <div className="flex items-center space-x-3">
          <Button
            variant="outline"
            onClick={refreshAll}
            loading={loading}
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          
          <Button 
            variant="destructive"
            onClick={restartSystem}
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Restart System
          </Button>
        </div>
      </div>

      {/* Quick Stats - Only show on main page */}
      {isMainPage && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <MetricCard
            title="System Uptime"
            value={systemStats.uptime}
            subtitle="Since last restart"
            icon={Clock}
            color="success"
            loading={loading}
          />
          
          <MetricCard
            title="SSH Status"
            value={systemStats.ssh_status}
            subtitle="Remote access"
            icon={Terminal}
            color={systemStats.ssh_status === 'Enabled' ? 'success' : 'warning'}
            loading={loading}
          />
          
          <MetricCard
            title="Firewall"
            value={systemStats.firewall_status}
            subtitle="Network protection"
            icon={Shield}
            color={systemStats.firewall_status === 'Active' ? 'success' : 'danger'}
            loading={loading}
          />
          
          <MetricCard
            title="Auto Updates"
            value={systemStats.auto_updates}
            subtitle="System maintenance"
            icon={TrendingUp}
            color={systemStats.auto_updates === 'Enabled' ? 'success' : 'warning'}
            loading={loading}
          />
        </div>
      )}

      {/* Navigation Tabs */}
      <div className="flex space-x-1 glassmorphism-card bg-gray-800/30 p-1 rounded-lg w-fit">
        {navigationItems.map((item) => {
          const Icon = item.icon
          const isActive = location.pathname.startsWith(item.path)
          
          return (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive: navLinkActive }) => cn(
                'flex items-center space-x-2 px-4 py-2 rounded-md transition-all duration-200',
                (isActive || navLinkActive)
                  ? 'bg-enterprise-neon/20 text-enterprise-neon border border-enterprise-neon/30'
                  : 'text-gray-400 hover:text-gray-200 hover:bg-gray-700/30'
              )}
            >
              <Icon className="h-4 w-4" />
              <span className="text-sm font-medium">{item.label}</span>
            </NavLink>
          )
        })}
      </div>

      {/* Main Overview Content - Only show when no subroute is active */}
      {isMainPage && (
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
          {navigationItems.map((item) => {
            const Icon = item.icon
            return (
              <motion.div
                key={item.path}
                whileHover={{ y: -2, scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <NavLink to={item.path}>
                  <div className="glassmorphism-card h-full p-6 cursor-pointer border border-transparent hover:border-enterprise-neon/30 transition-all duration-200">
                    <div className="flex items-center space-x-4 mb-4">
                      <div className="w-12 h-12 bg-gradient-to-r from-enterprise-neon/20 to-enterprise-neon-dark/20 rounded-lg flex items-center justify-center">
                        <Icon className="h-6 w-6 text-enterprise-neon" />
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold text-white">{item.label}</h3>
                        <p className="text-sm text-gray-400">{item.description}</p>
                      </div>
                    </div>
                    
                    <div className="space-y-3">
                      {item.path.includes('system') && (
                        <div className="text-sm text-gray-300">
                          <div className="flex justify-between">
                            <span>Hostname:</span>
                            <span className="text-enterprise-neon">pi5-supernode</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Timezone:</span>
                            <span className="text-gray-400">UTC</span>
                          </div>
                        </div>
                      )}
                      
                      {item.path.includes('security') && (
                        <div className="text-sm text-gray-300">
                          <div className="flex justify-between">
                            <span>Firewall:</span>
                            <span className="text-enterprise-neon">Active</span>
                          </div>
                          <div className="flex justify-between">
                            <span>2FA:</span>
                            <span className="text-gray-400">Disabled</span>
                          </div>
                        </div>
                      )}
                      
                      {item.path.includes('backup') && (
                        <div className="text-sm text-gray-300">
                          <div className="flex justify-between">
                            <span>Auto Backup:</span>
                            <span className="text-enterprise-neon">Enabled</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Schedule:</span>
                            <span className="text-gray-400">Daily 2 AM</span>
                          </div>
                        </div>
                      )}
                      
                      {item.path.includes('users') && (
                        <div className="text-sm text-gray-300">
                          <div className="flex justify-between">
                            <span>Active Users:</span>
                            <span className="text-enterprise-neon">3</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Admin Users:</span>
                            <span className="text-gray-400">1</span>
                          </div>
                        </div>
                      )}
                      
                      {item.path.includes('advanced') && (
                        <div className="text-sm text-gray-300">
                          <div className="flex justify-between">
                            <span>Debug Mode:</span>
                            <span className="text-enterprise-neon">Disabled</span>
                          </div>
                          <div className="flex justify-between">
                            <span>API Access:</span>
                            <span className="text-gray-400">Enabled</span>
                          </div>
                        </div>
                      )}
                      
                      <div className="pt-2 border-t border-gray-700">
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-gray-400">Configure Settings</span>
                          <TrendingUp className="h-4 w-4 text-enterprise-neon" />
                        </div>
                      </div>
                    </div>
                  </div>
                </NavLink>
              </motion.div>
            )
          })}
        </div>
      )}

      {/* Nested Route Content */}
      <div className="min-h-0">
        <SettingsErrorBoundary>
          <Outlet />
        </SettingsErrorBoundary>
      </div>
      </div>
    </SettingsErrorBoundary>
  )
}

export default SettingsMain