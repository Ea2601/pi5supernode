import React, { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import {
  Settings,
  Save,
  RefreshCw,
  Globe,
  Clock,
  Network,
  Terminal,
  Monitor,
  HardDrive,
  Cpu,
  Thermometer,
  AlertTriangle
} from 'lucide-react'
import { useUIStore } from '@/lib/store'
import { SettingsService, type SystemSettings } from '@/lib/services'
import { Button } from '@/components/ui/button'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card'
import MetricCard from '@/components/ui/metric-card'
import { cn } from '@/lib/utils'

const SettingsSystem: React.FC = () => {
  const { addNotification } = useUIStore()
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [loadError, setLoadError] = useState<string | null>(null)
  
  const [systemSettings, setSystemSettings] = useState<SystemSettings>({
    hostname: 'pi5-supernode',
    timezone: 'UTC',
    ntp_servers: ['pool.ntp.org', 'time.cloudflare.com'],
    dns_servers: ['1.1.1.1', '8.8.8.8'],
    ssh_enabled: true,
    ssh_port: 22,
    auto_updates: true,
    backup_enabled: true,
    backup_schedule: '0 2 * * *'
  })

  const [systemInfo, setSystemInfo] = useState({
    os_version: 'Raspberry Pi OS 12.0',
    kernel_version: '6.1.0-rpi7-rpi-v8',
    hardware: 'Raspberry Pi 5 Model B Rev 1.0',
    cpu_temp: 45.2,
    cpu_usage: 15.3,
    memory_usage: 45.7,
    disk_usage: 23.1,
    uptime: '15d 8h 32m'
  })

  useEffect(() => {
    const initializeData = async () => {
      try {
        setLoadError(null)
        await Promise.all([
          loadSystemSettings(),
          loadSystemInfo()
        ])
      } catch (error) {
        console.error('Failed to initialize system settings:', error)
        setLoadError('Failed to load system settings')
      }
    }
    
    initializeData()
  }, [])

  const loadSystemSettings = async () => {
    try {
      setLoading(true)
      setLoadError(null)
      
      // Add timeout to prevent hanging
      const timeoutPromise = new Promise((_, reject) => 
        setTimeout(() => reject(new Error('Request timeout')), 10000)
      )
      
      const settingsPromise = SettingsService.getSystemSettings()
      const settings = await Promise.race([settingsPromise, timeoutPromise]) as SystemSettings
      
      if (settings && typeof settings === 'object') {
        setSystemSettings(settings)
      }
      
    } catch (error) {
      console.error('Error loading system settings:', error)
      setLoadError('Unable to load system settings')
      // Keep default values if loading fails
    } finally {
      setLoading(false)
    }
  }

  const loadSystemInfo = async () => {
    try {
      const timeoutPromise = new Promise((_, reject) => 
        setTimeout(() => reject(new Error('Request timeout')), 8000)
      )
      
      const infoPromise = SettingsService.getSystemInfo()
      const info = await Promise.race([infoPromise, timeoutPromise]) as any
      
      if (info && typeof info === 'object') {
        setSystemInfo(prev => ({ ...prev, ...info }))
      }
    } catch (error) {
      console.error('Error loading system info:', error)
      // Don't fail the entire component if system info fails
    }
  }

  const saveSystemSettings = async () => {
    try {
      setSaving(true)
      
      await SettingsService.saveSystemSettings(systemSettings)
      addNotification({ type: 'success', message: 'System settings saved successfully' })
      
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to save system settings' })
    } finally {
      setSaving(false)
    }
  }

  const handleInputChange = (field: keyof SystemSettings, value: any) => {
    setSystemSettings(prev => ({
      ...prev,
      [field]: value
    }))
  }

  const handleArrayInputChange = (field: 'ntp_servers' | 'dns_servers', value: string) => {
    const arrayValue = value.split(',').map(s => s.trim()).filter(s => s.length > 0)
    setSystemSettings(prev => ({
      ...prev,
      [field]: arrayValue
    }))
  }

  const timezones = [
    'UTC',
    'America/New_York',
    'America/Chicago',
    'America/Denver',
    'America/Los_Angeles',
    'Europe/London',
    'Europe/Paris',
    'Europe/Berlin',
    'Asia/Tokyo',
    'Asia/Shanghai',
    'Australia/Sydney'
  ]

  // Show error state if there's a persistent error
  if (loadError && !loading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-white mb-1">System Configuration</h2>
            <p className="text-gray-400">Configure basic system settings and preferences</p>
          </div>
          
          <Button
            variant="outline"
            onClick={() => {
              setLoadError(null)
              loadSystemSettings()
              loadSystemInfo()
            }}
            loading={loading}
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Retry
          </Button>
        </div>
        
        <div className="glassmorphism-card p-8 text-center">
          <AlertTriangle className="h-12 w-12 text-yellow-400 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-white mb-2">Unable to Load Settings</h3>
          <p className="text-gray-400 mb-4">{loadError}</p>
          <div className="flex justify-center space-x-3">
            <Button 
              onClick={() => {
                setLoadError(null)
                loadSystemSettings()
                loadSystemInfo()
              }} 
              loading={loading}
            >
              Try Again
            </Button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white mb-1">System Configuration</h2>
          <p className="text-gray-400">Configure basic system settings and preferences</p>
        </div>
        
        <div className="flex items-center space-x-3">
          <Button
            variant="outline"
            onClick={() => {
              loadSystemSettings()
              loadSystemInfo()
            }}
            loading={loading}
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          
          <Button 
            variant="neon"
            onClick={saveSystemSettings}
            loading={saving}
          >
            <Save className="h-4 w-4 mr-2" />
            Save Settings
          </Button>
        </div>
      </div>

      {/* System Information */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          title="CPU Temperature"
          value={`${systemInfo.cpu_temp}°C`}
          subtitle="System temperature"
          icon={Thermometer}
          color={systemInfo.cpu_temp < 60 ? 'success' : systemInfo.cpu_temp < 75 ? 'warning' : 'danger'}
          loading={loading}
        />
        
        <MetricCard
          title="CPU Usage"
          value={`${systemInfo.cpu_usage}%`}
          subtitle="Current load"
          icon={Cpu}
          color={systemInfo.cpu_usage < 70 ? 'success' : systemInfo.cpu_usage < 85 ? 'warning' : 'danger'}
          loading={loading}
        />
        
        <MetricCard
          title="Memory Usage"
          value={`${systemInfo.memory_usage}%`}
          subtitle="RAM utilization"
          icon={Monitor}
          color={systemInfo.memory_usage < 70 ? 'success' : systemInfo.memory_usage < 85 ? 'warning' : 'danger'}
          loading={loading}
        />
        
        <MetricCard
          title="Disk Usage"
          value={`${systemInfo.disk_usage}%`}
          subtitle="Storage utilization"
          icon={HardDrive}
          color={systemInfo.disk_usage < 70 ? 'success' : systemInfo.disk_usage < 85 ? 'warning' : 'danger'}
          loading={loading}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Basic Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Settings className="h-5 w-5 text-enterprise-neon" />
              <span>Basic Settings</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  System Hostname
                </label>
                <input
                  type="text"
                  value={systemSettings.hostname}
                  onChange={(e) => handleInputChange('hostname', e.target.value)}
                  className="enterprise-input w-full"
                  placeholder="pi5-supernode"
                />
                <p className="text-xs text-gray-500 mt-1">Network identifier for this device</p>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Timezone
                </label>
                <select
                  value={systemSettings.timezone}
                  onChange={(e) => handleInputChange('timezone', e.target.value)}
                  className="enterprise-input w-full"
                >
                  {timezones.map(tz => (
                    <option key={tz} value={tz}>{tz}</option>
                  ))}
                </select>
                <p className="text-xs text-gray-500 mt-1">System timezone for scheduling and logs</p>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  NTP Servers
                </label>
                <input
                  type="text"
                  value={systemSettings.ntp_servers.join(', ')}
                  onChange={(e) => handleArrayInputChange('ntp_servers', e.target.value)}
                  className="enterprise-input w-full"
                  placeholder="pool.ntp.org, time.cloudflare.com"
                />
                <p className="text-xs text-gray-500 mt-1">Comma-separated list of NTP servers</p>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  DNS Servers
                </label>
                <input
                  type="text"
                  value={systemSettings.dns_servers.join(', ')}
                  onChange={(e) => handleArrayInputChange('dns_servers', e.target.value)}
                  className="enterprise-input w-full"
                  placeholder="1.1.1.1, 8.8.8.8"
                />
                <p className="text-xs text-gray-500 mt-1">System DNS servers for name resolution</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* SSH and Remote Access */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Terminal className="h-5 w-5 text-enterprise-neon" />
              <span>SSH & Remote Access</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <label className="text-sm font-medium text-gray-300">
                    Enable SSH
                  </label>
                  <p className="text-xs text-gray-500">Allow remote terminal access</p>
                </div>
                <input
                  type="checkbox"
                  checked={systemSettings.ssh_enabled}
                  onChange={(e) => handleInputChange('ssh_enabled', e.target.checked)}
                  className="enterprise-checkbox"
                />
              </div>
              
              {systemSettings.ssh_enabled && (
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    SSH Port
                  </label>
                  <input
                    type="number"
                    value={systemSettings.ssh_port}
                    onChange={(e) => handleInputChange('ssh_port', parseInt(e.target.value))}
                    className="enterprise-input w-full"
                    min="1"
                    max="65535"
                  />
                  <p className="text-xs text-gray-500 mt-1">Port 22 is default, change for security</p>
                </div>
              )}
              
              <div className="pt-4 border-t border-gray-700">
                <h4 className="text-sm font-medium text-gray-300 mb-3">Current SSH Status</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Service Status:</span>
                    <span className={systemSettings.ssh_enabled ? 'text-green-400' : 'text-red-400'}>
                      {systemSettings.ssh_enabled ? 'Active' : 'Inactive'}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Listen Port:</span>
                    <span className="text-gray-300">{systemSettings.ssh_port}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Connection:</span>
                    <span className="text-gray-300 font-mono text-xs">
                      ssh user@{systemSettings.hostname}.local
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Maintenance Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <RefreshCw className="h-5 w-5 text-enterprise-neon" />
              <span>System Maintenance</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <label className="text-sm font-medium text-gray-300">
                    Automatic Updates
                  </label>
                  <p className="text-xs text-gray-500">Install security updates automatically</p>
                </div>
                <input
                  type="checkbox"
                  checked={systemSettings.auto_updates}
                  onChange={(e) => handleInputChange('auto_updates', e.target.checked)}
                  className="enterprise-checkbox"
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <label className="text-sm font-medium text-gray-300">
                    Automatic Backups
                  </label>
                  <p className="text-xs text-gray-500">Regular system backups</p>
                </div>
                <input
                  type="checkbox"
                  checked={systemSettings.backup_enabled}
                  onChange={(e) => handleInputChange('backup_enabled', e.target.checked)}
                  className="enterprise-checkbox"
                />
              </div>
              
              {systemSettings.backup_enabled && (
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Backup Schedule (Cron)
                  </label>
                  <input
                    type="text"
                    value={systemSettings.backup_schedule}
                    onChange={(e) => handleInputChange('backup_schedule', e.target.value)}
                    className="enterprise-input w-full"
                    placeholder="0 2 * * *"
                  />
                  <p className="text-xs text-gray-500 mt-1">Cron expression (default: daily at 2 AM)</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* System Information */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Monitor className="h-5 w-5 text-enterprise-neon" />
              <span>System Information</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-400">OS Version:</span>
                <span className="text-gray-300">{systemInfo.os_version}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Kernel:</span>
                <span className="text-gray-300 font-mono text-xs">{systemInfo.kernel_version}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Hardware:</span>
                <span className="text-gray-300">{systemInfo.hardware}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Uptime:</span>
                <span className="text-gray-300">{systemInfo.uptime}</span>
              </div>
              
              <div className="pt-3 border-t border-gray-700">
                <h4 className="text-xs font-medium text-gray-400 mb-2">Performance</h4>
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400">CPU:</span>
                    <div className="flex items-center space-x-2">
                      <div className="w-16 bg-gray-700 rounded-full h-1.5">
                        <div 
                          className={`h-1.5 rounded-full transition-all duration-500 ${
                            systemInfo.cpu_usage < 70 ? 'bg-green-400' : 
                            systemInfo.cpu_usage < 85 ? 'bg-yellow-400' : 'bg-red-400'
                          }`}
                          style={{ width: `${systemInfo.cpu_usage}%` }}
                        />
                      </div>
                      <span className="text-xs text-gray-300">{systemInfo.cpu_usage}%</span>
                    </div>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400">Memory:</span>
                    <div className="flex items-center space-x-2">
                      <div className="w-16 bg-gray-700 rounded-full h-1.5">
                        <div 
                          className={`h-1.5 rounded-full transition-all duration-500 ${
                            systemInfo.memory_usage < 70 ? 'bg-green-400' : 
                            systemInfo.memory_usage < 85 ? 'bg-yellow-400' : 'bg-red-400'
                          }`}
                          style={{ width: `${systemInfo.memory_usage}%` }}
                        />
                      </div>
                      <span className="text-xs text-gray-300">{systemInfo.memory_usage}%</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

export default SettingsSystem