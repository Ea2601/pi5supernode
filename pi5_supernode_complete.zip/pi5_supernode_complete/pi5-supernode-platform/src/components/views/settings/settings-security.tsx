import React, { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import {
  Shield,
  Save,
  RefreshCw,
  Lock,
  Key,
  Eye,
  EyeOff,
  AlertTriangle,
  CheckCircle,
  Users,
  Clock,
  Ban,
  Activity
} from 'lucide-react'
import { useUIStore } from '@/lib/store'
import { SettingsService, type SecuritySettings } from '@/lib/services'
import { Button } from '@/components/ui/button'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card'
import MetricCard from '@/components/ui/metric-card'
import TableCard from '@/components/ui/table-card'
import { cn } from '@/lib/utils'

interface FailedAttempt {
  id: string
  ip_address: string
  username: string
  service: string
  timestamp: string
  attempt_count: number
  is_blocked: boolean
}

const SettingsSecurity: React.FC = () => {
  const { addNotification } = useUIStore()
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [showApiKey, setShowApiKey] = useState(false)
  const [failedAttempts, setFailedAttempts] = useState<FailedAttempt[]>([])
  const [loadError, setLoadError] = useState<string | null>(null)
  
  const [securitySettings, setSecuritySettings] = useState<SecuritySettings>({
    firewall_enabled: true,
    fail2ban_enabled: true,
    password_policy: {
      min_length: 8,
      require_uppercase: true,
      require_numbers: true,
      require_symbols: false
    },
    session_timeout: 3600,
    two_factor_enabled: false
  })

  const [apiKey, setApiKey] = useState('sk-1234567890abcdef...')
  const [newApiKey, setNewApiKey] = useState('')
  const [securityStats, setSecurityStats] = useState({
    blocked_ips: 23,
    failed_attempts_24h: 156,
    active_sessions: 3,
    firewall_rules: 42
  })

  useEffect(() => {
    const initializeSecuritySettings = async () => {
      try {
        setLoadError(null)
        await Promise.all([
          loadSecuritySettingsWithTimeout(),
          loadSecurityStatsWithTimeout(),
          loadFailedAttemptsWithTimeout()
        ])
      } catch (error) {
        console.error('Failed to initialize security settings:', error)
        setLoadError('Failed to load security data')
      }
    }
    
    initializeSecuritySettings()
  }, [])

  const loadSecuritySettingsWithTimeout = async () => {
    try {
      setLoading(true)
      setLoadError(null)
      
      // Timeout protection for settings loading
      const timeoutPromise = new Promise((_, reject) => 
        setTimeout(() => reject(new Error('Request timeout')), 10000)
      )
      
      const settingsPromise = SettingsService.getSecuritySettings()
      const settings = await Promise.race([settingsPromise, timeoutPromise]) as SecuritySettings
      
      if (settings && typeof settings === 'object') {
        setSecuritySettings({
          firewall_enabled: settings.firewall_enabled ?? true,
          fail2ban_enabled: settings.fail2ban_enabled ?? true,
          password_policy: {
            min_length: settings.password_policy?.min_length || 8,
            require_uppercase: settings.password_policy?.require_uppercase ?? true,
            require_numbers: settings.password_policy?.require_numbers ?? true,
            require_symbols: settings.password_policy?.require_symbols ?? false
          },
          session_timeout: settings.session_timeout || 3600,
          two_factor_enabled: settings.two_factor_enabled ?? false
        })
      }
      
      // Load API key with timeout
      const apiKeyPromise = SettingsService.getApiKey()
      const apiKeyData = await Promise.race([apiKeyPromise, timeoutPromise]) as string
      if (apiKeyData) {
        setApiKey(apiKeyData)
      }
      
    } catch (error) {
      console.error('Error loading security settings:', error)
      setLoadError('Unable to load security settings')
      // Use default values when API fails
      setSecuritySettings({
        firewall_enabled: true,
        fail2ban_enabled: true,
        password_policy: {
          min_length: 8,
          require_uppercase: true,
          require_numbers: true,
          require_symbols: false
        },
        session_timeout: 3600,
        two_factor_enabled: false
      })
    } finally {
      setLoading(false)
    }
  }

  const loadSecurityStatsWithTimeout = async () => {
    try {
      const timeoutPromise = new Promise((_, reject) => 
        setTimeout(() => reject(new Error('Request timeout')), 10000)
      )
      
      const statsPromise = SettingsService.getSecurityStats()
      const stats = await Promise.race([statsPromise, timeoutPromise]) as any
      
      if (stats && typeof stats === 'object') {
        setSecurityStats({
          blocked_ips: stats.blocked_ips || 0,
          failed_attempts_24h: stats.failed_attempts_24h || 0,
          active_sessions: stats.active_sessions || 1,
          firewall_rules: stats.firewall_rules || 0
        })
      }
    } catch (error) {
      console.error('Error loading security stats:', error)
      // Use default values when API fails
      setSecurityStats({
        blocked_ips: 23,
        failed_attempts_24h: 156,
        active_sessions: 3,
        firewall_rules: 42
      })
    }
  }

  const loadFailedAttemptsWithTimeout = async () => {
    try {
      const timeoutPromise = new Promise((_, reject) => 
        setTimeout(() => reject(new Error('Request timeout')), 10000)
      )
      
      const attemptsPromise = SettingsService.getFailedLoginAttempts()
      const attempts = await Promise.race([attemptsPromise, timeoutPromise]) as any[]
      
      if (Array.isArray(attempts)) {
        setFailedAttempts(attempts)
      }
    } catch (error) {
      console.error('Error loading failed attempts:', error)
      // Use empty array when API fails
      setFailedAttempts([])
    }
  }

  const saveSecuritySettings = async () => {
    try {
      setSaving(true)
      
      await SettingsService.saveSecuritySettings(securitySettings)
      addNotification({ type: 'success', message: 'Security settings saved successfully' })
      
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to save security settings' })
    } finally {
      setSaving(false)
    }
  }

  const generateApiKey = async () => {
    try {
      const key = await SettingsService.generateApiKey()
      setNewApiKey(key)
      addNotification({ type: 'success', message: 'New API key generated' })
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to generate API key' })
    }
  }

  const copyApiKey = () => {
    const keyToCopy = newApiKey || apiKey
    navigator.clipboard.writeText(keyToCopy)
    addNotification({ type: 'success', message: 'API key copied to clipboard' })
  }

  const unblockIP = async (ipAddress: string) => {
    try {
      await SettingsService.unblockIP(ipAddress)
      addNotification({ type: 'success', message: `IP ${ipAddress} unblocked` })
      await loadFailedAttemptsWithTimeout()
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to unblock IP address' })
    }
  }

  const handlePasswordPolicyChange = (field: string, value: any) => {
    setSecuritySettings(prev => ({
      ...prev,
      password_policy: {
        ...prev.password_policy,
        [field]: value
      }
    }))
  }

  // Show error state if there's a persistent error
  if (loadError && !loading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-white mb-1">Security Settings</h2>
            <p className="text-gray-400">Configure firewall, authentication, and security policies</p>
          </div>
          
          <Button
            variant="outline"
            onClick={() => {
              setLoadError(null)
              Promise.all([
                loadSecuritySettingsWithTimeout(),
                loadSecurityStatsWithTimeout(),
                loadFailedAttemptsWithTimeout()
              ]).catch(error => {
                console.error('Error refreshing security data:', error)
                setLoadError('Failed to refresh security data')
              })
            }}
            loading={loading}
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Retry
          </Button>
        </div>
        
        <div className="glassmorphism-card p-8 text-center">
          <AlertTriangle className="h-12 w-12 text-yellow-400 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-white mb-2">Unable to Load Security Settings</h3>
          <p className="text-gray-400 mb-4">{loadError}</p>
          <div className="flex justify-center space-x-3">
            <Button 
              onClick={() => {
                setLoadError(null)
                Promise.all([
                  loadSecuritySettingsWithTimeout(),
                  loadSecurityStatsWithTimeout(),
                  loadFailedAttemptsWithTimeout()
                ]).catch(error => {
                  console.error('Error retrying security data:', error)
                  setLoadError('Failed to load security data')
                })
              }} 
              loading={loading}
            >
              Try Again
            </Button>
          </div>
        </div>
      </div>
    )
  }

  const failedAttemptsColumns = [
    {
      key: 'ip_address' as keyof FailedAttempt,
      label: 'IP Address',
      sortable: true,
      render: (value: any, item: FailedAttempt) => (
        <div className="flex items-center space-x-2">
          <div className={`w-2 h-2 rounded-full ${item.is_blocked ? 'bg-red-400' : 'bg-yellow-400'}`} />
          <span className="font-mono text-sm text-white">{value}</span>
        </div>
      )
    },
    {
      key: 'username' as keyof FailedAttempt,
      label: 'Username',
      render: (value: any) => (
        <span className="text-gray-300">{value || 'Unknown'}</span>
      )
    },
    {
      key: 'service' as keyof FailedAttempt,
      label: 'Service',
      render: (value: any) => (
        <span className="status-badge bg-blue-500/20 text-blue-300 border-blue-500/30">
          {value.toUpperCase()}
        </span>
      )
    },
    {
      key: 'attempt_count' as keyof FailedAttempt,
      label: 'Attempts',
      sortable: true,
      render: (value: any) => (
        <span className={`font-mono ${value >= 5 ? 'text-red-400' : 'text-yellow-400'}`}>
          {value}
        </span>
      )
    },
    {
      key: 'timestamp' as keyof FailedAttempt,
      label: 'Last Attempt',
      render: (value: any) => (
        <span className="text-sm text-gray-400">
          {new Date(value).toLocaleString()}
        </span>
      )
    },
    {
      key: 'is_blocked' as keyof FailedAttempt,
      label: 'Status',
      render: (value: any) => (
        <span className={value ? 'status-inactive' : 'status-active'}>
          {value ? 'Blocked' : 'Monitoring'}
        </span>
      )
    },
    {
      key: 'id' as keyof FailedAttempt,
      label: 'Actions',
      render: (value: any, item: FailedAttempt) => (
        <div className="flex items-center space-x-2">
          {item.is_blocked && (
            <Button
              size="sm"
              variant="ghost"
              onClick={() => unblockIP(item.ip_address)}
            >
              <Ban className="h-4 w-4" />
            </Button>
          )}
        </div>
      )
    }
  ]

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white mb-1">Security Settings</h2>
          <p className="text-gray-400">Configure firewall, authentication, and security policies</p>
        </div>
        
        <div className="flex items-center space-x-3">
          <Button
            variant="outline"
            onClick={() => {
              Promise.all([
                loadSecuritySettingsWithTimeout(),
                loadSecurityStatsWithTimeout(), 
                loadFailedAttemptsWithTimeout()
              ]).then(() => {
                if (!loadError) {
                  addNotification({ type: 'success', message: 'Security data refreshed' })
                }
              }).catch(error => {
                console.error('Error refreshing security data:', error)
                addNotification({ type: 'error', message: 'Failed to refresh security data' })
              })
            }}
            loading={loading}
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          
          <Button 
            variant="neon"
            onClick={saveSecuritySettings}
            loading={saving}
          >
            <Save className="h-4 w-4 mr-2" />
            Save Settings
          </Button>
        </div>
      </div>

      {/* Security Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          title="Blocked IPs"
          value={securityStats.blocked_ips.toString()}
          subtitle="Currently blocked"
          icon={Ban}
          color="danger"
          loading={loading}
        />
        
        <MetricCard
          title="Failed Attempts"
          value={securityStats.failed_attempts_24h.toString()}
          subtitle="Last 24 hours"
          icon={AlertTriangle}
          color="warning"
          loading={loading}
        />
        
        <MetricCard
          title="Active Sessions"
          value={securityStats.active_sessions.toString()}
          subtitle="Current users"
          icon={Users}
          color="info"
          loading={loading}
        />
        
        <MetricCard
          title="Firewall Rules"
          value={securityStats.firewall_rules.toString()}
          subtitle="Protection rules"
          icon={Shield}
          color="success"
          loading={loading}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Firewall & Protection */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Shield className="h-5 w-5 text-enterprise-neon" />
              <span>Firewall & Protection</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <label className="text-sm font-medium text-gray-300">
                    Enable Firewall
                  </label>
                  <p className="text-xs text-gray-500">Block unauthorized network access</p>
                </div>
                <input
                  type="checkbox"
                  checked={securitySettings.firewall_enabled}
                  onChange={(e) => setSecuritySettings(prev => ({ ...prev, firewall_enabled: e.target.checked }))}
                  className="enterprise-checkbox"
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <label className="text-sm font-medium text-gray-300">
                    Enable Fail2Ban
                  </label>
                  <p className="text-xs text-gray-500">Auto-block IPs after failed attempts</p>
                </div>
                <input
                  type="checkbox"
                  checked={securitySettings.fail2ban_enabled}
                  onChange={(e) => setSecuritySettings(prev => ({ ...prev, fail2ban_enabled: e.target.checked }))}
                  className="enterprise-checkbox"
                />
              </div>
              
              {securitySettings.firewall_enabled && (
                <div className="pt-4 border-t border-gray-700">
                  <h4 className="text-sm font-medium text-gray-300 mb-3">Firewall Status</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Status:</span>
                      <span className="text-green-400">Active</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Rules:</span>
                      <span className="text-gray-300">{securityStats.firewall_rules}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Blocked IPs:</span>
                      <span className="text-red-400">{securityStats.blocked_ips}</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Authentication Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Lock className="h-5 w-5 text-enterprise-neon" />
              <span>Authentication</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Session Timeout (seconds)
                </label>
                <input
                  type="number"
                  value={securitySettings.session_timeout}
                  onChange={(e) => setSecuritySettings(prev => ({ ...prev, session_timeout: parseInt(e.target.value) }))}
                  className="enterprise-input w-full"
                  min="300"
                  max="86400"
                />
                <p className="text-xs text-gray-500 mt-1">Time before automatic logout (3600 = 1 hour)</p>
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <label className="text-sm font-medium text-gray-300">
                    Two-Factor Authentication
                  </label>
                  <p className="text-xs text-gray-500">Require TOTP for login</p>
                </div>
                <input
                  type="checkbox"
                  checked={securitySettings.two_factor_enabled}
                  onChange={(e) => setSecuritySettings(prev => ({ ...prev, two_factor_enabled: e.target.checked }))}
                  className="enterprise-checkbox"
                />
              </div>
              
              <div className="pt-4 border-t border-gray-700">
                <h4 className="text-sm font-medium text-gray-300 mb-3">Active Sessions</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Current User:</span>
                    <span className="text-green-400">admin@pi5-supernode</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Active Since:</span>
                    <span className="text-gray-300">2h 15m ago</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Total Sessions:</span>
                    <span className="text-gray-300">{securityStats.active_sessions}</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Password Policy */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Key className="h-5 w-5 text-enterprise-neon" />
              <span>Password Policy</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Minimum Length
                </label>
                <input
                  type="number"
                  value={securitySettings.password_policy.min_length}
                  onChange={(e) => handlePasswordPolicyChange('min_length', parseInt(e.target.value))}
                  className="enterprise-input w-full"
                  min="6"
                  max="32"
                />
              </div>
              
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-sm text-gray-300">
                    Require Uppercase Letters
                  </label>
                  <input
                    type="checkbox"
                    checked={securitySettings.password_policy.require_uppercase}
                    onChange={(e) => handlePasswordPolicyChange('require_uppercase', e.target.checked)}
                    className="enterprise-checkbox"
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <label className="text-sm text-gray-300">
                    Require Numbers
                  </label>
                  <input
                    type="checkbox"
                    checked={securitySettings.password_policy.require_numbers}
                    onChange={(e) => handlePasswordPolicyChange('require_numbers', e.target.checked)}
                    className="enterprise-checkbox"
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <label className="text-sm text-gray-300">
                    Require Symbols
                  </label>
                  <input
                    type="checkbox"
                    checked={securitySettings.password_policy.require_symbols}
                    onChange={(e) => handlePasswordPolicyChange('require_symbols', e.target.checked)}
                    className="enterprise-checkbox"
                  />
                </div>
              </div>
              
              <div className="pt-4 border-t border-gray-700">
                <h4 className="text-sm font-medium text-gray-300 mb-2">Policy Preview</h4>
                <div className="text-xs text-gray-400">
                  Password must be at least {securitySettings.password_policy.min_length} characters
                  {securitySettings.password_policy.require_uppercase && ', contain uppercase letters'}
                  {securitySettings.password_policy.require_numbers && ', contain numbers'}
                  {securitySettings.password_policy.require_symbols && ', contain symbols'}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* API Access */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Key className="h-5 w-5 text-enterprise-neon" />
              <span>API Access</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Current API Key
                </label>
                <div className="flex items-center space-x-2">
                  <input
                    type={showApiKey ? 'text' : 'password'}
                    value={newApiKey || apiKey}
                    readOnly
                    className="enterprise-input flex-1 font-mono text-sm"
                  />
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => setShowApiKey(!showApiKey)}
                  >
                    {showApiKey ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={copyApiKey}
                  >
                    📋
                  </Button>
                </div>
              </div>
              
              <div className="flex space-x-3">
                <Button
                  variant="outline"
                  onClick={generateApiKey}
                  className="flex-1"
                >
                  Generate New Key
                </Button>
              </div>
              
              {newApiKey && (
                <div className="p-3 bg-yellow-500/10 border border-yellow-500/30 rounded-lg">
                  <div className="flex items-center space-x-2 text-yellow-400 text-sm">
                    <AlertTriangle className="h-4 w-4" />
                    <span>Save this key securely - it won't be shown again!</span>
                  </div>
                </div>
              )}
              
              <div className="pt-4 border-t border-gray-700">
                <h4 className="text-sm font-medium text-gray-300 mb-2">API Usage</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Requests (24h):</span>
                    <span className="text-gray-300">1,247</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Rate Limit:</span>
                    <span className="text-gray-300">1000/hour</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Last Access:</span>
                    <span className="text-gray-300">5 minutes ago</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Failed Login Attempts */}
      <TableCard
        title="Security Events"
        description={`Recent failed login attempts and blocked IPs`}
        data={failedAttempts}
        columns={failedAttemptsColumns}
        loading={loading}
        emptyMessage="No recent security events. Your system is secure."
      />
    </div>
  )
}

export default SettingsSecurity