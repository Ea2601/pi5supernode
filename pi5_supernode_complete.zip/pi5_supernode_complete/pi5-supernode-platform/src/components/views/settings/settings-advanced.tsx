import React, { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import {
  Zap,
  Save,
  RefreshCw,
  Terminal,
  Code,
  Database,
  Globe,
  Shield,
  Activity,
  AlertTriangle,
  Info,
  Cpu,
  HardDrive,
  Network
} from 'lucide-react'
import { useUIStore } from '@/lib/store'
import { SettingsService } from '@/lib/services'
import { Button } from '@/components/ui/button'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card'
import MetricCard from '@/components/ui/metric-card'
import { cn } from '@/lib/utils'

const SettingsAdvanced: React.FC = () => {
  const { addNotification } = useUIStore()
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [loadError, setLoadError] = useState<string | null>(null)
  
  const [advancedSettings, setAdvancedSettings] = useState({
    debug_mode: false,
    memory_limit: '512M',
    swap_enabled: true,
    log_level: 'info',
    experimental_features: false,
    // Additional fields for UI compatibility
    verbose_logging: false,
    worker_processes: 4,
    api_rate_limiting: true,
    api_rate_limit: 1000,
    cors_enabled: true,
    cors_origins: ['*'],
    max_connections: 1000,
    ssl_redirect: true,
    ssl_cert_path: '/etc/ssl/certs/pi5-supernode.crt',
    ssl_key_path: '/etc/ssl/private/pi5-supernode.key'
  })

  const [performanceSettings, setPerformanceSettings] = useState({
    gpu_memory_split: 128,
    cpu_governor: 'performance',
    overclocking_enabled: false,
    thermal_throttling: true,
    network_optimization: true,
    // Additional fields for UI compatibility
    cpu_scaling_governor: 'performance',
    io_scheduler: 'mq-deadline'
  })

  const [monitoringSettings, setMonitoringSettings] = useState({
    metrics_collection: true,
    metrics_retention_days: 30,
    alert_thresholds: {
      cpu_usage: 85,
      memory_usage: 90,
      disk_usage: 95,
      temperature: 75
    },
    webhook_alerts: false,
    webhook_url: '',
    email_alerts: false,
    email_recipients: []
  })

  const [systemInfo, setSystemInfo] = useState({
    kernel_version: '',
    gcc_version: '',
    python_version: '',
    node_version: '',
    total_memory: 0,
    available_memory: 0,
    cpu_cores: 0,
    cpu_frequency: 0
  })

  useEffect(() => {
    const initializeData = async () => {
      try {
        setLoadError(null)
        await Promise.all([
          loadAdvancedSettings(),
          loadSystemInfo()
        ])
      } catch (error) {
        console.error('Failed to initialize advanced settings:', error)
        setLoadError('Failed to load advanced settings')
      }
    }
    
    initializeData()
  }, [])

  const loadAdvancedSettings = async () => {
    try {
      setLoading(true)
      setLoadError(null)
      
      const timeoutPromise = new Promise((_, reject) => 
        setTimeout(() => reject(new Error('Request timeout')), 10000)
      )
      
      const dataPromises = Promise.all([
        SettingsService.getAdvancedSettings(),
        SettingsService.getPerformanceSettings(),
        SettingsService.getMonitoringSettings()
      ])
      
      const [advancedData, performanceData, monitoringData] = await Promise.race([dataPromises, timeoutPromise]) as any
      
      // Merge service data with UI defaults
      if (advancedData && typeof advancedData === 'object') {
        setAdvancedSettings({
          debug_mode: advancedData.debug_mode || false,
          memory_limit: advancedData.memory_limit || '512M',
          swap_enabled: advancedData.swap_enabled ?? true,
          log_level: advancedData.log_level || 'info',
          experimental_features: advancedData.experimental_features || false,
          // UI-only fields with defaults
          verbose_logging: false,
          worker_processes: 4,
          api_rate_limiting: true,
          api_rate_limit: 1000,
          cors_enabled: true,
          cors_origins: ['*'],
          max_connections: 1000,
          ssl_redirect: true,
          ssl_cert_path: '/etc/ssl/certs/pi5-supernode.crt',
          ssl_key_path: '/etc/ssl/private/pi5-supernode.key'
        })
      }
      
      if (performanceData && typeof performanceData === 'object') {
        setPerformanceSettings({
          gpu_memory_split: performanceData.gpu_memory_split || 128,
          cpu_governor: performanceData.cpu_governor || 'performance',
          overclocking_enabled: performanceData.overclocking_enabled || false,
          thermal_throttling: performanceData.thermal_throttling ?? true,
          network_optimization: performanceData.network_optimization ?? true,
          // UI-only fields with defaults
          cpu_scaling_governor: 'performance',
          io_scheduler: 'mq-deadline'
        })
      }
      
      if (monitoringData && typeof monitoringData === 'object') {
        setMonitoringSettings(prev => ({ ...prev, ...monitoringData }))
      }
      
    } catch (error) {
      console.error('Error loading advanced settings:', error)
      setLoadError('Unable to load advanced settings')
    } finally {
      setLoading(false)
    }
  }

  const loadSystemInfo = async () => {
    try {
      const timeoutPromise = new Promise((_, reject) => 
        setTimeout(() => reject(new Error('Request timeout')), 8000)
      )
      
      const infoPromise = SettingsService.getAdvancedSystemInfo()
      const info = await Promise.race([infoPromise, timeoutPromise]) as any
      
      if (info && typeof info === 'object') {
        setSystemInfo(prev => ({ ...prev, ...info }))
      }
    } catch (error) {
      console.error('Error loading system info:', error)
      // Don't fail the entire component if system info fails
    }
  }

  const saveAdvancedSettings = async () => {
    try {
      setSaving(true)
      
      await Promise.all([
        SettingsService.saveAdvancedSettings({
          memory_limit: advancedSettings.memory_limit,
          swap_enabled: advancedSettings.swap_enabled,
          log_level: advancedSettings.log_level,
          debug_mode: advancedSettings.debug_mode,
          experimental_features: advancedSettings.experimental_features
        }),
        SettingsService.savePerformanceSettings({
          gpu_memory_split: performanceSettings.gpu_memory_split,
          cpu_governor: performanceSettings.cpu_governor,
          overclocking_enabled: performanceSettings.overclocking_enabled,
          thermal_throttling: performanceSettings.thermal_throttling,
          network_optimization: performanceSettings.network_optimization
        }),
        SettingsService.saveMonitoringSettings(monitoringSettings)
      ])
      
      addNotification({ type: 'success', message: 'Advanced settings saved successfully' })
      
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to save advanced settings' })
    } finally {
      setSaving(false)
    }
  }

  const resetToDefaults = async () => {
    if (!confirm('Are you sure you want to reset all advanced settings to defaults?')) return
    
    try {
      await SettingsService.resetAdvancedSettings()
      await loadAdvancedSettings()
      addNotification({ type: 'success', message: 'Settings reset to defaults' })
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to reset settings' })
    }
  }

  const generateSSLCert = async () => {
    try {
      addNotification({ type: 'info', message: 'Generating SSL certificate...' })
      
      await SettingsService.generateSSLCertificate()
      addNotification({ type: 'success', message: 'SSL certificate generated successfully' })
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to generate SSL certificate' })
    }
  }

  const optimizePerformance = async () => {
    try {
      addNotification({ type: 'info', message: 'Applying performance optimizations...' })
      
      await SettingsService.optimizeSystemPerformance()
      addNotification({ type: 'success', message: 'Performance optimizations applied' })
      
      // Reload settings to reflect changes
      await loadAdvancedSettings()
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to optimize performance' })
    }
  }

  const clearSystemCache = async () => {
    try {
      await SettingsService.clearSystemCache()
      addNotification({ type: 'success', message: 'System cache cleared' })
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to clear cache' })
    }
  }

  const handleCorsOriginsChange = (value: string) => {
    const origins = value.split(',').map(s => s.trim()).filter(s => s.length > 0)
    setAdvancedSettings(prev => ({ ...prev, cors_origins: origins }))
  }

  const handleEmailRecipientsChange = (value: string) => {
    const emails = value.split(',').map(s => s.trim()).filter(s => s.length > 0)
    setMonitoringSettings(prev => ({ ...prev, email_recipients: emails }))
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white mb-1">Advanced Settings</h2>
          <p className="text-gray-400">Advanced system configuration and performance tuning</p>
        </div>
        
        <div className="flex items-center space-x-3">
          <Button
            variant="outline"
            onClick={resetToDefaults}
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Reset Defaults
          </Button>
          
          <Button
            variant="outline"
            onClick={() => {
              loadAdvancedSettings()
              loadSystemInfo()
            }}
            loading={loading}
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          
          <Button 
            variant="neon"
            onClick={saveAdvancedSettings}
            loading={saving}
          >
            <Save className="h-4 w-4 mr-2" />
            Save Settings
          </Button>
        </div>
      </div>

      {/* System Information */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          title="CPU Cores"
          value={systemInfo.cpu_cores.toString()}
          subtitle={`${systemInfo.cpu_frequency} MHz`}
          icon={Cpu}
          color="info"
          loading={loading}
        />
        
        <MetricCard
          title="Total Memory"
          value={`${Math.round(systemInfo.total_memory / 1024 / 1024)} MB`}
          subtitle={`${Math.round(systemInfo.available_memory / 1024 / 1024)} MB available`}
          icon={HardDrive}
          color="info"
          loading={loading}
        />
        
        <MetricCard
          title="Kernel Version"
          value={systemInfo.kernel_version.split('-')[0] || 'Unknown'}
          subtitle="Linux kernel"
          icon={Terminal}
          color="info"
          loading={loading}
        />
        
        <MetricCard
          title="Node.js Version"
          value={systemInfo.node_version || 'N/A'}
          subtitle="Runtime environment"
          icon={Code}
          color="info"
          loading={loading}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Application Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Zap className="h-5 w-5 text-enterprise-neon" />
              <span>Application Settings</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <label className="text-sm font-medium text-gray-300">
                    Debug Mode
                  </label>
                  <p className="text-xs text-gray-500">Enable detailed error reporting</p>
                </div>
                <input
                  type="checkbox"
                  checked={advancedSettings.debug_mode}
                  onChange={(e) => setAdvancedSettings(prev => ({ ...prev, debug_mode: e.target.checked }))}
                  className="enterprise-checkbox"
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <label className="text-sm font-medium text-gray-300">
                    Verbose Logging
                  </label>
                  <p className="text-xs text-gray-500">Detailed application logs</p>
                </div>
                <input
                  type="checkbox"
                  checked={advancedSettings.verbose_logging}
                  onChange={(e) => setAdvancedSettings(prev => ({ ...prev, verbose_logging: e.target.checked }))}
                  className="enterprise-checkbox"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Worker Processes
                </label>
                <input
                  type="number"
                  value={advancedSettings.worker_processes}
                  onChange={(e) => setAdvancedSettings(prev => ({ ...prev, worker_processes: parseInt(e.target.value) }))}
                  className="enterprise-input w-full"
                  min="1"
                  max="16"
                />
                <p className="text-xs text-gray-500 mt-1">Number of worker processes (recommended: CPU cores)</p>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Memory Limit
                </label>
                <input
                  type="text"
                  value={advancedSettings.memory_limit}
                  onChange={(e) => setAdvancedSettings(prev => ({ ...prev, memory_limit: e.target.value }))}
                  className="enterprise-input w-full"
                  placeholder="512M"
                />
                <p className="text-xs text-gray-500 mt-1">Memory limit per process (e.g., 512M, 1G)</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* API Configuration */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Globe className="h-5 w-5 text-enterprise-neon" />
              <span>API Configuration</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <label className="text-sm font-medium text-gray-300">
                    Rate Limiting
                  </label>
                  <p className="text-xs text-gray-500">Limit API requests per hour</p>
                </div>
                <input
                  type="checkbox"
                  checked={advancedSettings.api_rate_limiting}
                  onChange={(e) => setAdvancedSettings(prev => ({ ...prev, api_rate_limiting: e.target.checked }))}
                  className="enterprise-checkbox"
                />
              </div>
              
              {advancedSettings.api_rate_limiting && (
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Rate Limit (requests/hour)
                  </label>
                  <input
                    type="number"
                    value={advancedSettings.api_rate_limit}
                    onChange={(e) => setAdvancedSettings(prev => ({ ...prev, api_rate_limit: parseInt(e.target.value) }))}
                    className="enterprise-input w-full"
                    min="100"
                    max="10000"
                  />
                </div>
              )}
              
              <div className="flex items-center justify-between">
                <div>
                  <label className="text-sm font-medium text-gray-300">
                    CORS Enabled
                  </label>
                  <p className="text-xs text-gray-500">Cross-Origin Resource Sharing</p>
                </div>
                <input
                  type="checkbox"
                  checked={advancedSettings.cors_enabled}
                  onChange={(e) => setAdvancedSettings(prev => ({ ...prev, cors_enabled: e.target.checked }))}
                  className="enterprise-checkbox"
                />
              </div>
              
              {advancedSettings.cors_enabled && (
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Allowed Origins
                  </label>
                  <input
                    type="text"
                    value={advancedSettings.cors_origins.join(', ')}
                    onChange={(e) => handleCorsOriginsChange(e.target.value)}
                    className="enterprise-input w-full"
                    placeholder="*, https://example.com"
                  />
                  <p className="text-xs text-gray-500 mt-1">Comma-separated list of allowed origins</p>
                </div>
              )}
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Max Connections
                </label>
                <input
                  type="number"
                  value={advancedSettings.max_connections}
                  onChange={(e) => setAdvancedSettings(prev => ({ ...prev, max_connections: parseInt(e.target.value) }))}
                  className="enterprise-input w-full"
                  min="100"
                  max="10000"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* SSL/TLS Configuration */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Shield className="h-5 w-5 text-enterprise-neon" />
              <span>SSL/TLS Configuration</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <label className="text-sm font-medium text-gray-300">
                    Force SSL Redirect
                  </label>
                  <p className="text-xs text-gray-500">Redirect HTTP to HTTPS</p>
                </div>
                <input
                  type="checkbox"
                  checked={advancedSettings.ssl_redirect}
                  onChange={(e) => setAdvancedSettings(prev => ({ ...prev, ssl_redirect: e.target.checked }))}
                  className="enterprise-checkbox"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  SSL Certificate Path
                </label>
                <input
                  type="text"
                  value={advancedSettings.ssl_cert_path}
                  onChange={(e) => setAdvancedSettings(prev => ({ ...prev, ssl_cert_path: e.target.value }))}
                  className="enterprise-input w-full font-mono text-sm"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  SSL Private Key Path
                </label>
                <input
                  type="text"
                  value={advancedSettings.ssl_key_path}
                  onChange={(e) => setAdvancedSettings(prev => ({ ...prev, ssl_key_path: e.target.value }))}
                  className="enterprise-input w-full font-mono text-sm"
                />
              </div>
              
              <div className="flex space-x-3">
                <Button
                  variant="outline"
                  onClick={generateSSLCert}
                  className="flex-1"
                >
                  Generate Self-Signed Cert
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Performance Tuning */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Activity className="h-5 w-5 text-enterprise-neon" />
              <span>Performance Tuning</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  CPU Scaling Governor
                </label>
                <select
                  value={performanceSettings.cpu_scaling_governor}
                  onChange={(e) => setPerformanceSettings(prev => ({ ...prev, cpu_scaling_governor: e.target.value }))}
                  className="enterprise-input w-full"
                >
                  <option value="performance">Performance</option>
                  <option value="ondemand">OnDemand</option>
                  <option value="conservative">Conservative</option>
                  <option value="powersave">PowerSave</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  GPU Memory Split (MB)
                </label>
                <input
                  type="number"
                  value={performanceSettings.gpu_memory_split}
                  onChange={(e) => setPerformanceSettings(prev => ({ ...prev, gpu_memory_split: parseInt(e.target.value) }))}
                  className="enterprise-input w-full"
                  min="64"
                  max="512"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  I/O Scheduler
                </label>
                <select
                  value={performanceSettings.io_scheduler}
                  onChange={(e) => setPerformanceSettings(prev => ({ ...prev, io_scheduler: e.target.value }))}
                  className="enterprise-input w-full"
                >
                  <option value="mq-deadline">MQ-Deadline</option>
                  <option value="kyber">Kyber</option>
                  <option value="bfq">BFQ</option>
                  <option value="none">None</option>
                </select>
              </div>
              
              <div className="flex space-x-3">
                <Button
                  variant="outline"
                  onClick={optimizePerformance}
                  className="flex-1"
                >
                  Auto-Optimize
                </Button>
                
                <Button
                  variant="outline"
                  onClick={clearSystemCache}
                  className="flex-1"
                >
                  Clear Cache
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Monitoring & Alerts */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Activity className="h-5 w-5 text-enterprise-neon" />
            <span>Monitoring & Alerts</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <label className="text-sm font-medium text-gray-300">
                    Metrics Collection
                  </label>
                  <p className="text-xs text-gray-500">Collect system performance metrics</p>
                </div>
                <input
                  type="checkbox"
                  checked={monitoringSettings.metrics_collection}
                  onChange={(e) => setMonitoringSettings(prev => ({ ...prev, metrics_collection: e.target.checked }))}
                  className="enterprise-checkbox"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Metrics Retention (days)
                </label>
                <input
                  type="number"
                  value={monitoringSettings.metrics_retention_days}
                  onChange={(e) => setMonitoringSettings(prev => ({ ...prev, metrics_retention_days: parseInt(e.target.value) }))}
                  className="enterprise-input w-full"
                  min="7"
                  max="365"
                />
              </div>
              
              <div className="space-y-3">
                <h4 className="text-sm font-medium text-gray-300">Alert Thresholds</h4>
                
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs text-gray-400 mb-1">CPU Usage (%)</label>
                    <input
                      type="number"
                      value={monitoringSettings.alert_thresholds.cpu_usage}
                      onChange={(e) => setMonitoringSettings(prev => ({ 
                        ...prev, 
                        alert_thresholds: { 
                          ...prev.alert_thresholds, 
                          cpu_usage: parseInt(e.target.value) 
                        }
                      }))}
                      className="enterprise-input w-full text-sm"
                      min="50"
                      max="100"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-xs text-gray-400 mb-1">Memory Usage (%)</label>
                    <input
                      type="number"
                      value={monitoringSettings.alert_thresholds.memory_usage}
                      onChange={(e) => setMonitoringSettings(prev => ({ 
                        ...prev, 
                        alert_thresholds: { 
                          ...prev.alert_thresholds, 
                          memory_usage: parseInt(e.target.value) 
                        }
                      }))}
                      className="enterprise-input w-full text-sm"
                      min="50"
                      max="100"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-xs text-gray-400 mb-1">Disk Usage (%)</label>
                    <input
                      type="number"
                      value={monitoringSettings.alert_thresholds.disk_usage}
                      onChange={(e) => setMonitoringSettings(prev => ({ 
                        ...prev, 
                        alert_thresholds: { 
                          ...prev.alert_thresholds, 
                          disk_usage: parseInt(e.target.value) 
                        }
                      }))}
                      className="enterprise-input w-full text-sm"
                      min="70"
                      max="100"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-xs text-gray-400 mb-1">Temperature (°C)</label>
                    <input
                      type="number"
                      value={monitoringSettings.alert_thresholds.temperature}
                      onChange={(e) => setMonitoringSettings(prev => ({ 
                        ...prev, 
                        alert_thresholds: { 
                          ...prev.alert_thresholds, 
                          temperature: parseInt(e.target.value) 
                        }
                      }))}
                      className="enterprise-input w-full text-sm"
                      min="60"
                      max="90"
                    />
                  </div>
                </div>
              </div>
            </div>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <label className="text-sm font-medium text-gray-300">
                    Webhook Alerts
                  </label>
                  <p className="text-xs text-gray-500">Send alerts to webhook URL</p>
                </div>
                <input
                  type="checkbox"
                  checked={monitoringSettings.webhook_alerts}
                  onChange={(e) => setMonitoringSettings(prev => ({ ...prev, webhook_alerts: e.target.checked }))}
                  className="enterprise-checkbox"
                />
              </div>
              
              {monitoringSettings.webhook_alerts && (
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Webhook URL
                  </label>
                  <input
                    type="url"
                    value={monitoringSettings.webhook_url}
                    onChange={(e) => setMonitoringSettings(prev => ({ ...prev, webhook_url: e.target.value }))}
                    className="enterprise-input w-full"
                    placeholder="https://hooks.slack.com/..."
                  />
                </div>
              )}
              
              <div className="flex items-center justify-between">
                <div>
                  <label className="text-sm font-medium text-gray-300">
                    Email Alerts
                  </label>
                  <p className="text-xs text-gray-500">Send alerts via email</p>
                </div>
                <input
                  type="checkbox"
                  checked={monitoringSettings.email_alerts}
                  onChange={(e) => setMonitoringSettings(prev => ({ ...prev, email_alerts: e.target.checked }))}
                  className="enterprise-checkbox"
                />
              </div>
              
              {monitoringSettings.email_alerts && (
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Email Recipients
                  </label>
                  <input
                    type="text"
                    value={monitoringSettings.email_recipients.join(', ')}
                    onChange={(e) => handleEmailRecipientsChange(e.target.value)}
                    className="enterprise-input w-full"
                    placeholder="admin@example.com, alerts@example.com"
                  />
                  <p className="text-xs text-gray-500 mt-1">Comma-separated email addresses</p>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Warning Notice */}
      <div className="p-4 bg-yellow-500/10 border border-yellow-500/30 rounded-lg">
        <div className="flex items-center space-x-2 text-yellow-400">
          <AlertTriangle className="h-5 w-5" />
          <span className="font-medium">Advanced Settings Warning</span>
        </div>
        <div className="text-sm text-gray-300 mt-2">
          <p>
            These settings are for advanced users only. Incorrect configuration may cause system 
            instability or security issues. Make sure you understand the implications before making changes.
          </p>
        </div>
      </div>
    </div>
  )
}

export default SettingsAdvanced