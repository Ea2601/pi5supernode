import React, { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import {
  Users,
  Plus,
  Edit,
  Trash2,
  RefreshCw,
  Shield,
  Key,
  Eye,
  EyeOff,
  Clock,
  Activity,
  Crown,
  User,
  Mail,
  Phone
} from 'lucide-react'
import { useUIStore } from '@/lib/store'
import { SettingsService } from '@/lib/services'
import { Button } from '@/components/ui/button'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card'
import MetricCard from '@/components/ui/metric-card'
import TableCard from '@/components/ui/table-card'
import Modal from '@/components/ui/modal'
import { cn } from '@/lib/utils'

interface UserAccount {
  id: string
  username: string
  email: string
  full_name: string
  role: 'admin' | 'operator' | 'viewer'
  is_active: boolean
  last_login: string
  created_at: string
  permissions: string[]
  two_factor_enabled: boolean
  failed_login_attempts: number
}

interface UserFormData {
  username: string
  email: string
  full_name: string
  password: string
  confirm_password: string
  role: string
  is_active: boolean
  permissions: string[]
}

const SettingsUsers: React.FC = () => {
  const { addNotification } = useUIStore()
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [showUserModal, setShowUserModal] = useState(false)
  const [showPasswordModal, setShowPasswordModal] = useState(false)
  const [editingUser, setEditingUser] = useState<UserAccount | null>(null)
  const [selectedUser, setSelectedUser] = useState<UserAccount | null>(null)
  const [users, setUsers] = useState<UserAccount[]>([])
  const [showPassword, setShowPassword] = useState(false)
  const [loadError, setLoadError] = useState<string | null>(null)
  
  const [userForm, setUserForm] = useState<UserFormData>({
    username: '',
    email: '',
    full_name: '',
    password: '',
    confirm_password: '',
    role: 'viewer',
    is_active: true,
    permissions: []
  })

  const [passwordForm, setPasswordForm] = useState({
    current_password: '',
    new_password: '',
    confirm_password: ''
  })

  const [userStats, setUserStats] = useState({
    total_users: 0,
    active_users: 0,
    admin_users: 0,
    recent_logins: 0
  })

  const availablePermissions = [
    'system:read',
    'system:write',
    'network:read',
    'network:write',
    'vpn:read',
    'vpn:write',
    'users:read',
    'users:write',
    'backup:read',
    'backup:write',
    'logs:read',
    'api:access'
  ]

  useEffect(() => {
    const initializeData = async () => {
      try {
        setLoadError(null)
        await loadUserData()
      } catch (error) {
        console.error('Failed to initialize user data:', error)
        setLoadError('Failed to load user data')
      }
    }
    
    initializeData()
  }, [])

  const loadUserData = async () => {
    try {
      setLoading(true)
      setLoadError(null)
      
      const timeoutPromise = new Promise((_, reject) => 
        setTimeout(() => reject(new Error('Request timeout')), 10000)
      )
      
      const dataPromises = Promise.all([
        SettingsService.getUsers(),
        SettingsService.getUserStats()
      ])
      
      const [usersData, statsData] = await Promise.race([dataPromises, timeoutPromise]) as any
      
      if (Array.isArray(usersData)) setUsers(usersData)
      if (statsData && typeof statsData === 'object') setUserStats(prev => ({ ...prev, ...statsData }))
      
    } catch (error) {
      console.error('Error loading user data:', error)
      setLoadError('Unable to load user data')
    } finally {
      setLoading(false)
    }
  }

  const resetUserForm = () => {
    setUserForm({
      username: '',
      email: '',
      full_name: '',
      password: '',
      confirm_password: '',
      role: 'viewer',
      is_active: true,
      permissions: []
    })
  }

  const editUser = (user: UserAccount) => {
    setEditingUser(user)
    setUserForm({
      username: user.username,
      email: user.email,
      full_name: user.full_name,
      password: '',
      confirm_password: '',
      role: user.role,
      is_active: user.is_active,
      permissions: user.permissions
    })
    setShowUserModal(true)
  }

  const handleSaveUser = async () => {
    try {
      setSaving(true)
      
      // Validate passwords match if password is being set
      if (userForm.password && userForm.password !== userForm.confirm_password) {
        addNotification({ type: 'error', message: 'Passwords do not match' })
        return
      }
      
      const userData = {
        ...userForm,
        confirm_password: undefined // Remove confirm_password from submission
      }
      
      if (editingUser) {
        await SettingsService.updateUser(editingUser.id, userData)
        addNotification({ type: 'success', message: 'User updated successfully' })
      } else {
        await SettingsService.createUser(userData)
        addNotification({ type: 'success', message: 'User created successfully' })
      }
      
      setShowUserModal(false)
      setEditingUser(null)
      resetUserForm()
      await loadUserData()
      
    } catch (error) {
      addNotification({ type: 'error', message: `Failed to ${editingUser ? 'update' : 'create'} user` })
    } finally {
      setSaving(false)
    }
  }

  const toggleUserStatus = async (user: UserAccount) => {
    try {
      await SettingsService.toggleUserStatus(user.id, !user.is_active)
      addNotification({ 
        type: 'success', 
        message: `User ${user.is_active ? 'deactivated' : 'activated'}` 
      })
      await loadUserData()
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to update user status' })
    }
  }

  const deleteUser = async (user: UserAccount) => {
    if (!confirm(`Are you sure you want to delete user "${user.username}"?`)) return
    
    try {
      await SettingsService.deleteUser(user.id)
      addNotification({ type: 'success', message: 'User deleted successfully' })
      await loadUserData()
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to delete user' })
    }
  }

  const resetUserPassword = async (user: UserAccount) => {
    try {
      const newPassword = await SettingsService.resetUserPassword(user.id)
      addNotification({ 
        type: 'success', 
        message: `Password reset for ${user.username}. New password: ${newPassword}` 
      })
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to reset user password' })
    }
  }

  const changeMyPassword = async () => {
    try {
      if (passwordForm.new_password !== passwordForm.confirm_password) {
        addNotification({ type: 'error', message: 'New passwords do not match' })
        return
      }
      
      await SettingsService.changePassword({
        current_password: passwordForm.current_password,
        new_password: passwordForm.new_password
      })
      
      setShowPasswordModal(false)
      setPasswordForm({ current_password: '', new_password: '', confirm_password: '' })
      addNotification({ type: 'success', message: 'Password changed successfully' })
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to change password' })
    }
  }

  const handlePermissionToggle = (permission: string, checked: boolean) => {
    setUserForm(prev => {
      const newPermissions = checked
        ? [...prev.permissions, permission]
        : prev.permissions.filter(p => p !== permission)
      
      return { ...prev, permissions: newPermissions }
    })
  }

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'admin':
        return <Crown className="h-4 w-4 text-yellow-400" />
      case 'operator':
        return <Shield className="h-4 w-4 text-blue-400" />
      case 'viewer':
        return <User className="h-4 w-4 text-gray-400" />
      default:
        return <User className="h-4 w-4 text-gray-400" />
    }
  }

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'admin':
        return 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30'
      case 'operator':
        return 'bg-blue-500/20 text-blue-300 border-blue-500/30'
      case 'viewer':
        return 'bg-gray-500/20 text-gray-300 border-gray-500/30'
      default:
        return 'bg-gray-500/20 text-gray-300 border-gray-500/30'
    }
  }

  const userColumns = [
    {
      key: 'username' as keyof UserAccount,
      label: 'User',
      sortable: true,
      render: (value: any, item: UserAccount) => (
        <div className="flex items-center space-x-3">
          <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
            item.is_active ? 'bg-enterprise-neon/20' : 'bg-gray-500/20'
          }`}>
            <User className={`h-5 w-5 ${
              item.is_active ? 'text-enterprise-neon' : 'text-gray-400'
            }`} />
          </div>
          <div>
            <div className="font-medium text-white flex items-center space-x-2">
              <span>{value}</span>
              {item.two_factor_enabled && (
                <Shield className="h-3 w-3 text-green-400" title="2FA Enabled" />
              )}
            </div>
            <div className="text-sm text-gray-400">{item.full_name}</div>
          </div>
        </div>
      )
    },
    {
      key: 'email' as keyof UserAccount,
      label: 'Contact',
      render: (value: any, item: UserAccount) => (
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            <Mail className="h-3 w-3 text-gray-400" />
            <span className="text-sm text-gray-300">{value}</span>
          </div>
        </div>
      )
    },
    {
      key: 'role' as keyof UserAccount,
      label: 'Role',
      sortable: true,
      render: (value: any) => (
        <div className="flex items-center space-x-2">
          {getRoleIcon(value)}
          <span className={`status-badge ${getRoleColor(value)}`}>
            {value.charAt(0).toUpperCase() + value.slice(1)}
          </span>
        </div>
      )
    },
    {
      key: 'permissions' as keyof UserAccount,
      label: 'Permissions',
      render: (value: any) => (
        <div className="text-sm text-gray-300">
          <span className="font-mono">{Array.isArray(value) ? value.length : 0} permissions</span>
        </div>
      )
    },
    {
      key: 'last_login' as keyof UserAccount,
      label: 'Last Login',
      sortable: true,
      render: (value: any) => (
        <div className="text-sm">
          <div className="text-gray-300">
            {value ? new Date(value).toLocaleDateString() : 'Never'}
          </div>
          {value && (
            <div className="text-gray-500">
              {new Date(value).toLocaleTimeString()}
            </div>
          )}
        </div>
      )
    },
    {
      key: 'is_active' as keyof UserAccount,
      label: 'Status',
      sortable: true,
      render: (value: any, item: UserAccount) => (
        <div className="space-y-1">
          <span className={value ? 'status-active' : 'status-inactive'}>
            {value ? 'Active' : 'Inactive'}
          </span>
          {item.failed_login_attempts > 0 && (
            <div className="text-xs text-red-400">
              {item.failed_login_attempts} failed attempts
            </div>
          )}
        </div>
      )
    },
    {
      key: 'id' as keyof UserAccount,
      label: 'Actions',
      render: (value: any, item: UserAccount) => (
        <div className="flex items-center space-x-2">
          <Button
            size="sm"
            variant="ghost"
            onClick={() => editUser(item)}
          >
            <Edit className="h-4 w-4" />
          </Button>
          
          <Button
            size="sm"
            variant="ghost"
            onClick={() => resetUserPassword(item)}
            title="Reset password"
          >
            <Key className="h-4 w-4" />
          </Button>
          
          <Button
            size="sm"
            variant="ghost"
            onClick={() => toggleUserStatus(item)}
            title={item.is_active ? 'Deactivate user' : 'Activate user'}
          >
            <Activity className="h-4 w-4" />
          </Button>
          
          <Button
            size="sm"
            variant="ghost"
            onClick={() => deleteUser(item)}
            className="text-red-400 hover:text-red-300"
            title="Delete user"
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      )
    }
  ]

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white mb-1">User Management</h2>
          <p className="text-gray-400">Manage user accounts and access control</p>
        </div>
        
        <div className="flex items-center space-x-3">
          <Button
            variant="outline"
            onClick={() => setShowPasswordModal(true)}
          >
            <Key className="h-4 w-4 mr-2" />
            Change My Password
          </Button>
          
          <Button
            variant="outline"
            onClick={loadUserData}
            loading={loading}
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          
          <Button 
            variant="neon"
            onClick={() => {
              resetUserForm()
              setShowUserModal(true)
            }}
          >
            <Plus className="h-4 w-4 mr-2" />
            Add User
          </Button>
        </div>
      </div>

      {/* User Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          title="Total Users"
          value={userStats.total_users.toString()}
          subtitle="Registered accounts"
          icon={Users}
          color="info"
          loading={loading}
        />
        
        <MetricCard
          title="Active Users"
          value={userStats.active_users.toString()}
          subtitle="Currently enabled"
          icon={Activity}
          color="success"
          loading={loading}
        />
        
        <MetricCard
          title="Administrators"
          value={userStats.admin_users.toString()}
          subtitle="Admin privileges"
          icon={Crown}
          color="warning"
          loading={loading}
        />
        
        <MetricCard
          title="Recent Logins"
          value={userStats.recent_logins.toString()}
          subtitle="Last 24 hours"
          icon={Clock}
          color="info"
          loading={loading}
        />
      </div>

      {/* Users Table */}
      <TableCard
        title="User Accounts"
        description={`${users.length} total users (${userStats.active_users} active)`}
        data={users}
        columns={userColumns}
        loading={loading}
        emptyMessage="No users found. Add your first user to get started."
      />

      {/* User Creation/Edit Modal */}
      <Modal
        isOpen={showUserModal}
        onClose={() => {
          setShowUserModal(false)
          setEditingUser(null)
          resetUserForm()
        }}
        title={editingUser ? "Edit User Account" : "Create New User"}
        size="lg"
      >
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Username
              </label>
              <input
                type="text"
                value={userForm.username}
                onChange={(e) => setUserForm(prev => ({ ...prev, username: e.target.value }))}
                className="enterprise-input w-full"
                placeholder="john_doe"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Full Name
              </label>
              <input
                type="text"
                value={userForm.full_name}
                onChange={(e) => setUserForm(prev => ({ ...prev, full_name: e.target.value }))}
                className="enterprise-input w-full"
                placeholder="John Doe"
              />
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Email Address
            </label>
            <input
              type="email"
              value={userForm.email}
              onChange={(e) => setUserForm(prev => ({ ...prev, email: e.target.value }))}
              className="enterprise-input w-full"
              placeholder="john@example.com"
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Password {editingUser && '(leave blank to keep current)'}
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={userForm.password}
                  onChange={(e) => setUserForm(prev => ({ ...prev, password: e.target.value }))}
                  className="enterprise-input w-full pr-10"
                  placeholder={editingUser ? 'New password (optional)' : 'Enter password'}
                />
                <Button
                  type="button"
                  size="sm"
                  variant="ghost"
                  className="absolute right-2 top-1/2 transform -translate-y-1/2"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </Button>
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Confirm Password
              </label>
              <input
                type={showPassword ? 'text' : 'password'}
                value={userForm.confirm_password}
                onChange={(e) => setUserForm(prev => ({ ...prev, confirm_password: e.target.value }))}
                className="enterprise-input w-full"
                placeholder="Confirm password"
              />
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Role
              </label>
              <select
                value={userForm.role}
                onChange={(e) => setUserForm(prev => ({ ...prev, role: e.target.value }))}
                className="enterprise-input w-full"
              >
                <option value="viewer">Viewer (Read-only)</option>
                <option value="operator">Operator (Limited write)</option>
                <option value="admin">Administrator (Full access)</option>
              </select>
            </div>
            
            <div className="flex items-center justify-center">
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={userForm.is_active}
                  onChange={(e) => setUserForm(prev => ({ ...prev, is_active: e.target.checked }))}
                  className="enterprise-checkbox"
                />
                <span className="text-sm text-gray-300">Account active</span>
              </label>
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-3">
              Permissions
            </label>
            <div className="grid grid-cols-2 gap-2 max-h-32 overflow-y-auto">
              {availablePermissions.map(permission => (
                <label key={permission} className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    checked={userForm.permissions.includes(permission)}
                    onChange={(e) => handlePermissionToggle(permission, e.target.checked)}
                    className="enterprise-checkbox"
                  />
                  <span className="text-sm text-gray-300">{permission}</span>
                </label>
              ))}
            </div>
            <p className="text-xs text-gray-500 mt-2">
              Role-based permissions are automatically included
            </p>
          </div>
          
          <div className="flex justify-end space-x-3 pt-4 border-t border-gray-700">
            <Button
              variant="outline"
              onClick={() => {
                setShowUserModal(false)
                setEditingUser(null)
                resetUserForm()
              }}
            >
              Cancel
            </Button>
            
            <Button
              variant="neon"
              onClick={handleSaveUser}
              loading={saving}
            >
              {editingUser ? 'Update User' : 'Create User'}
            </Button>
          </div>
        </div>
      </Modal>

      {/* Change Password Modal */}
      <Modal
        isOpen={showPasswordModal}
        onClose={() => {
          setShowPasswordModal(false)
          setPasswordForm({ current_password: '', new_password: '', confirm_password: '' })
        }}
        title="Change My Password"
      >
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Current Password
            </label>
            <input
              type="password"
              value={passwordForm.current_password}
              onChange={(e) => setPasswordForm(prev => ({ ...prev, current_password: e.target.value }))}
              className="enterprise-input w-full"
              placeholder="Enter current password"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              New Password
            </label>
            <input
              type="password"
              value={passwordForm.new_password}
              onChange={(e) => setPasswordForm(prev => ({ ...prev, new_password: e.target.value }))}
              className="enterprise-input w-full"
              placeholder="Enter new password"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Confirm New Password
            </label>
            <input
              type="password"
              value={passwordForm.confirm_password}
              onChange={(e) => setPasswordForm(prev => ({ ...prev, confirm_password: e.target.value }))}
              className="enterprise-input w-full"
              placeholder="Confirm new password"
            />
          </div>
          
          <div className="flex justify-end space-x-3 pt-4 border-t border-gray-700">
            <Button
              variant="outline"
              onClick={() => {
                setShowPasswordModal(false)
                setPasswordForm({ current_password: '', new_password: '', confirm_password: '' })
              }}
            >
              Cancel
            </Button>
            
            <Button
              variant="neon"
              onClick={changeMyPassword}
            >
              Change Password
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  )
}

export default SettingsUsers