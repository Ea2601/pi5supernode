import React, { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import {
  Shield,
  Server,
  Users,
  Plus,
  Power,
  Download,
  QrCode,
  Key,
  Globe,
  Activity,
  Clock,
  RefreshCw,
  Settings,
  Copy,
  Eye,
  EyeOff,
  Cloud,
  Terminal,
  CheckCircle,
  AlertTriangle,
  Loader2,
  MonitorSpeaker,
  Wifi,
  Database
} from 'lucide-react'
import { useVPNStore, useUIStore } from '@/lib/store'
import { VPNService } from '@/lib/services'
import { supabase } from '@/lib/supabase'
import { Button } from '@/components/ui/button'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card'
import TableCard from '@/components/ui/table-card'
import MetricCard from '@/components/ui/metric-card'
import Modal from '@/components/ui/modal'
import { generateWireGuardKeys, cn } from '@/lib/utils'

interface ServerFormData {
  server_name: string
  listen_port: number
  network: string
  endpoint: string
  max_clients: number
}

interface ClientFormData {
  client_name: string
  server_id: string
  allowed_ips: string[]
}

interface VPSFormData {
  vps_name: string
  vps_ip: string
  ssh_username: string
  ssh_password: string
  wg_server_name: string
}

interface VPSServer {
  id: string
  vps_name: string
  vps_ip: string
  ssh_username: string
  status: 'pending' | 'connecting' | 'installing' | 'completed' | 'failed'
  wireguard_server_id?: string
  installation_started_at?: string
  installation_completed_at?: string
  error_message?: string
  installation_log?: string
  created_at: string
}

const VPN: React.FC = () => {
  const { servers, clients, setServers, setClients, selectedServer, setSelectedServer } = useVPNStore()
  const { addNotification } = useUIStore()
  const [loading, setLoading] = useState(true)
  const [showServerModal, setShowServerModal] = useState(false)
  const [showClientModal, setShowClientModal] = useState(false)
  const [showConfigModal, setShowConfigModal] = useState(false)
  const [showQRModal, setShowQRModal] = useState(false)
  const [showVPSModal, setShowVPSModal] = useState(false)
  const [showVPSStatusModal, setShowVPSStatusModal] = useState(false)
  const [selectedClient, setSelectedClient] = useState<any>(null)
  const [selectedVPS, setSelectedVPS] = useState<VPSServer | null>(null)
  const [clientConfig, setClientConfig] = useState('')
  const [showPrivateKey, setShowPrivateKey] = useState(false)
  const [vpsServers, setVpsServers] = useState<VPSServer[]>([])
  const [vpsInstalling, setVpsInstalling] = useState(false)
  const [installationProgress, setInstallationProgress] = useState<any>(null)
  
  const [serverForm, setServerForm] = useState<ServerFormData>({
    server_name: '',
    listen_port: 51820,
    network: '10.8.0.0/24',
    endpoint: '',
    max_clients: 100
  })
  
  const [clientForm, setClientForm] = useState<ClientFormData>({
    client_name: '',
    server_id: '',
    allowed_ips: ['0.0.0.0/0']
  })
  
  const [vpsForm, setVpsForm] = useState<VPSFormData>({
    vps_name: '',
    vps_ip: '',
    ssh_username: 'root',
    ssh_password: '',
    wg_server_name: ''
  })

  useEffect(() => {
    loadVPNData()
    loadVPSData()
  }, [])

  const loadVPNData = async () => {
    try {
      setLoading(true)
      
      // Load VPN data using VPNService
      const [serversData, clientsData] = await Promise.all([
        VPNService.getAllServers(),
        VPNService.getAllClients()
      ])
      
      setServers(serversData)
      setClients(clientsData)
      
    } catch (error) {
      console.error('Error loading VPN data:', error)
      addNotification({ type: 'error', message: 'Failed to load VPN configuration' })
    } finally {
      setLoading(false)
    }
  }

  const loadVPSData = async () => {
    try {
      // Load VPS servers from database
      const { data: vpsData, error } = await supabase
        .from('vps_servers')
        .select('*')
        .order('created_at', { ascending: false })
      
      if (error) throw error
      setVpsServers(vpsData || [])
    } catch (error) {
      console.error('Error loading VPS data:', error)
      addNotification({ type: 'error', message: 'Failed to load VPS data' })
    }
  }

  const handleCreateServer = async () => {
    try {
      await VPNService.createServer({
        server_name: serverForm.server_name,
        listen_port: serverForm.listen_port,
        network: serverForm.network
      })
      
      setShowServerModal(false)
      setServerForm({
        server_name: '',
        listen_port: 51820,
        network: '10.8.0.0/24',
        endpoint: '',
        max_clients: 100
      })
      
      await loadVPNData()
      addNotification({ type: 'success', message: 'WireGuard server created successfully' })
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to create WireGuard server' })
    }
  }

  const handleCreateClient = async () => {
    try {
      const server = servers.find(s => s.id === clientForm.server_id)
      
      if (!server) {
        addNotification({ type: 'error', message: 'Please select a server' })
        return
      }
      
      await VPNService.createClient(server, {
        client_name: clientForm.client_name
      })
      
      setShowClientModal(false)
      setClientForm({
        client_name: '',
        server_id: '',
        allowed_ips: ['0.0.0.0/0']
      })
      
      await loadVPNData()
      addNotification({ type: 'success', message: 'WireGuard client created successfully' })
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to create WireGuard client' })
    }
  }

  const toggleServerStatus = async (server: any) => {
    try {
      const newStatus = server.status === 'active' ? 'stopped' : 'active'
      
      await VPNService.updateServerStatus(server.id, newStatus)
      
      await loadVPNData()
      addNotification({ 
        type: 'success', 
        message: `Server ${newStatus === 'active' ? 'started' : 'stopped'}` 
      })
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to update server status' })
    }
  }

  const generateClientConfig = (client: any) => {
    const server = servers.find(s => s.id === client.server_id)
    if (!server) return ''
    
    return `[Interface]
PrivateKey = ${client.private_key}
Address = ${client.assigned_ip}/32
DNS = 1.1.1.1

[Peer]
PublicKey = ${server.public_key}
AllowedIPs = ${client.allowed_ips.join(', ')}
Endpoint = ${server.endpoint}:${server.listen_port}
PersistentKeepalive = 25`
  }

  const handleDownloadConfig = (client: any) => {
    const config = generateClientConfig(client)
    const blob = new Blob([config], { type: 'text/plain' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `${client.client_name}.conf`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
    
    addNotification({ type: 'success', message: 'Configuration downloaded' })
  }

  const handleShowQR = (client: any) => {
    const config = generateClientConfig(client)
    setClientConfig(config)
    setSelectedClient(client)
    setShowQRModal(true)
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    addNotification({ type: 'success', message: 'Copied to clipboard' })
  }

  const syncServers = async () => {
    try {
      addNotification({ type: 'info', message: 'Synchronizing WireGuard servers...' })
      
      // Sync all active servers
      const activeServers = servers.filter(s => s.status === 'active')
      await Promise.all(activeServers.map(server => 
        VPNService.syncServerConfiguration(server.id)
      ))
      
      addNotification({ 
        type: 'success', 
        message: `Synchronized ${activeServers.length} servers` 
      })
      
      await loadVPNData()
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to sync servers' })
    }
  }

  const handleCreateVPS = async () => {
    try {
      setVpsInstalling(true)
      
      // Validate form
      if (!vpsForm.vps_name || !vpsForm.vps_ip || !vpsForm.ssh_password || !vpsForm.wg_server_name) {
        addNotification({ type: 'error', message: 'Please fill in all required fields' })
        return
      }
      
      // Create VPS server record
      const { data: vpsData, error: vpsError } = await supabase
        .from('vps_servers')
        .insert({
          vps_name: vpsForm.vps_name,
          vps_ip: vpsForm.vps_ip,
          ssh_username: vpsForm.ssh_username,
          status: 'pending'
        })
        .select()
        .single()
      
      if (vpsError) throw vpsError
      
      // Store credentials securely using Web Crypto API for encryption
      const encoder = new TextEncoder();
      const encodedData = encoder.encode(vpsForm.ssh_password);
      const key = await crypto.subtle.generateKey(
        { name: 'AES-GCM', length: 256 },
        true,
        ['encrypt', 'decrypt']
      );
      const iv = crypto.getRandomValues(new Uint8Array(12));
      const encrypted = await crypto.subtle.encrypt(
        { name: 'AES-GCM', iv: iv },
        key,
        encodedData
      );
      
      const { error: credError } = await supabase
        .from('vps_credentials')
        .insert({
          vps_server_id: vpsData.id,
          ssh_password_encrypted: Array.from(new Uint8Array(encrypted)).join(','),
          encryption_iv: Array.from(iv).join(','),
          encryption_key: JSON.stringify(await crypto.subtle.exportKey('jwk', key))
        })
      
      if (credError) throw credError
      
      // Call VPS installation edge function
      const { data: installData, error } = await supabase.functions.invoke('vps-wireguard-installer', {
        body: {
          vpsIp: vpsForm.vps_ip,
          sshUsername: vpsForm.ssh_username,
          sshPassword: vpsForm.ssh_password,
          wgServerName: vpsForm.wg_server_name,
          vpsServerId: vpsData.id
        }
      })
      
      if (error) throw error
      
      setShowVPSModal(false)
      setVpsForm({
        vps_name: '',
        vps_ip: '',
        ssh_username: 'root',
        ssh_password: '',
        wg_server_name: ''
      })
      
      await loadVPSData()
      await loadVPNData()
      addNotification({ type: 'success', message: 'VPS WireGuard installation started successfully' })
      
    } catch (error) {
      console.error('VPS installation error:', error)
      addNotification({ type: 'error', message: 'Failed to start VPS installation' })
    } finally {
      setVpsInstalling(false)
    }
  }

  const checkVPSStatus = async (vpsServer: VPSServer) => {
    try {
      const { data: statusData, error } = await supabase.functions.invoke('vps-status-check', {
        body: { vpsServerId: vpsServer.id }
      })
      
      if (error) throw error
      
      setInstallationProgress(statusData.data)
      setSelectedVPS(vpsServer)
      setShowVPSStatusModal(true)
      
    } catch (error) {
      console.error('VPS status check error:', error)
      addNotification({ type: 'error', message: 'Failed to check VPS status' })
    }
  }

  const deleteVPSServer = async (vpsServer: VPSServer) => {
    try {
      const { error } = await supabase
        .from('vps_servers')
        .delete()
        .eq('id', vpsServer.id)
      
      if (error) throw error
      
      await loadVPSData()
      addNotification({ type: 'success', message: 'VPS server deleted successfully' })
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to delete VPS server' })
    }
  }

  const activeServers = servers.filter(s => s.status === 'active').length
  const totalClients = clients.length
  const activeClients = clients.filter(c => c.is_active).length
  const totalTraffic = clients.reduce((sum, c) => sum + c.bytes_received + c.bytes_sent, 0)
  const vpsServersActive = vpsServers.filter(v => v.status === 'completed').length
  const vpsServersInstalling = vpsServers.filter(v => v.status === 'installing').length

  const serverColumns = [
    {
      key: 'server_name' as keyof typeof servers[0],
      label: 'Server',
      sortable: true,
      render: (value: any, item: typeof servers[0]) => (
        <div>
          <div className="font-medium text-white">{value}</div>
          <div className="text-sm text-gray-400">{item.endpoint}</div>
        </div>
      )
    },
    {
      key: 'network' as keyof typeof servers[0],
      label: 'Network',
      sortable: true,
      render: (value: any) => (
        <span className="font-mono text-sm text-gray-300">{value}</span>
      )
    },
    {
      key: 'listen_port' as keyof typeof servers[0],
      label: 'Port',
      sortable: true,
      render: (value: any) => (
        <span className="font-mono text-sm text-gray-300">{value}</span>
      )
    },
    {
      key: 'client_count' as keyof typeof servers[0],
      label: 'Clients',
      sortable: true,
      render: (value: any, item: typeof servers[0]) => (
        <span className="text-gray-300">{value}/{item.max_clients}</span>
      )
    },
    {
      key: 'status' as keyof typeof servers[0],
      label: 'Status',
      sortable: true,
      render: (value: any) => (
        <span className={value === 'active' ? 'status-active' : 'status-inactive'}>
          {value === 'active' ? 'Running' : 'Stopped'}
        </span>
      )
    }
  ]

  const vpsColumns = [
    {
      key: 'vps_name' as keyof VPSServer,
      label: 'VPS Server',
      sortable: true,
      render: (value: any, item: VPSServer) => (
        <div className="flex items-center space-x-3">
          <div className={cn(
            'p-2 rounded-lg',
            item.status === 'completed' ? 'bg-green-500/20' :
            item.status === 'installing' ? 'bg-blue-500/20' :
            item.status === 'failed' ? 'bg-red-500/20' :
            'bg-gray-500/20'
          )}>
            <Cloud className={cn(
              'h-4 w-4',
              item.status === 'completed' ? 'text-green-400' :
              item.status === 'installing' ? 'text-blue-400' :
              item.status === 'failed' ? 'text-red-400' :
              'text-gray-400'
            )} />
          </div>
          <div>
            <div className="font-medium text-white">{value}</div>
            <div className="text-sm text-gray-400">{item.vps_ip}:{item.ssh_username}</div>
          </div>
        </div>
      )
    },
    {
      key: 'status' as keyof VPSServer,
      label: 'Status',
      sortable: true,
      render: (value: any, item: VPSServer) => (
        <div>
          <div className="flex items-center space-x-2">
            {value === 'installing' && <Loader2 className="h-4 w-4 text-blue-400 animate-spin" />}
            {value === 'completed' && <CheckCircle className="h-4 w-4 text-green-400" />}
            {value === 'failed' && <AlertTriangle className="h-4 w-4 text-red-400" />}
            <span className={cn(
              'capitalize font-medium',
              value === 'completed' ? 'text-green-400' :
              value === 'installing' ? 'text-blue-400' :
              value === 'failed' ? 'text-red-400' :
              'text-gray-400'
            )}>
              {value}
            </span>
          </div>
          {item.installation_started_at && (
            <div className="text-xs text-gray-400 mt-1">
              Started: {new Date(item.installation_started_at).toLocaleString()}
            </div>
          )}
        </div>
      )
    },
    {
      key: 'created_at' as keyof VPSServer,
      label: 'Created',
      sortable: true,
      render: (value: any) => (
        <div className="text-sm text-gray-300">
          {new Date(value).toLocaleDateString()}
        </div>
      )
    }
  ]

  const clientColumns = [
    {
      key: 'client_name' as keyof typeof clients[0],
      label: 'Client',
      sortable: true,
      render: (value: any, item: typeof clients[0]) => (
        <div>
          <div className="font-medium text-white">{value}</div>
          <div className="text-sm text-gray-400">{item.assigned_ip}</div>
        </div>
      )
    },
    {
      key: 'server_id' as keyof typeof clients[0],
      label: 'Server',
      render: (value: any) => {
        const server = servers.find(s => s.id === value)
        return (
          <span className="text-gray-300">{server?.server_name || 'Unknown'}</span>
        )
      }
    },
    {
      key: 'bytes_received' as keyof typeof clients[0],
      label: 'Download',
      sortable: true,
      render: (value: any) => (
        <span className="text-gray-300">{(value / 1024 / 1024).toFixed(2)} MB</span>
      )
    },
    {
      key: 'bytes_sent' as keyof typeof clients[0],
      label: 'Upload',
      sortable: true,
      render: (value: any) => (
        <span className="text-gray-300">{(value / 1024 / 1024).toFixed(2)} MB</span>
      )
    },
    {
      key: 'is_active' as keyof typeof clients[0],
      label: 'Status',
      sortable: true,
      render: (value: any) => (
        <span className={value ? 'status-active' : 'status-inactive'}>
          {value ? 'Connected' : 'Disconnected'}
        </span>
      )
    }
  ]

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">VPN Management</h1>
          <p className="text-gray-400">WireGuard server and client configuration</p>
        </div>
        
        <div className="flex items-center space-x-3">
          <Button variant="outline" onClick={syncServers}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Sync Servers
          </Button>
          
          <Button variant="outline" onClick={() => setShowVPSModal(true)}>
            <Cloud className="h-4 w-4 mr-2" />
            Setup VPS
          </Button>
          
          <Button variant="outline" onClick={() => setShowServerModal(true)}>
            <Server className="h-4 w-4 mr-2" />
            Add Server
          </Button>
          
          <Button variant="neon" onClick={() => setShowClientModal(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Add Client
          </Button>
        </div>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
        <MetricCard
          title="VPS Servers"
          value={vpsServersActive}
          subtitle={`${vpsServers.length} total, ${vpsServersInstalling} installing`}
          icon={Cloud}
          color="info"
          loading={loading}
        />
        
        <MetricCard
          title="Active Servers"
          value={activeServers}
          subtitle={`${servers.length} total servers`}
          icon={Server}
          color="success"
          loading={loading}
        />
        
        <MetricCard
          title="Connected Clients"
          value={activeClients}
          subtitle={`${totalClients} total clients`}
          icon={Users}
          color="info"
          loading={loading}
        />
        
        <MetricCard
          title="Total Traffic"
          value={`${(totalTraffic / 1024 / 1024).toFixed(1)} MB`}
          subtitle="Combined data transfer"
          icon={Activity}
          color="info"
          loading={loading}
        />
        
        <MetricCard
          title="Tunnel Health"
          value="98.5%"
          subtitle="Connection reliability"
          icon={Shield}
          color="success"
          loading={loading}
        />
      </div>

      {/* VPS Servers Table */}
      <TableCard
        title="VPS WireGuard Servers"
        description="Remote VPS instances with automated WireGuard installation"
        data={vpsServers}
        columns={vpsColumns}
        loading={loading}
        actions={[
          {
            label: 'Status',
            onClick: checkVPSStatus,
            variant: 'outline'
          },
          {
            label: 'Delete',
            onClick: deleteVPSServer,
            variant: 'destructive'
          }
        ]}
      />

      {/* Servers Table */}
      <TableCard
        title="Local WireGuard Servers"
        description="VPN server instances and configurations"
        data={servers}
        columns={serverColumns}
        loading={loading}
        actions={[
          {
            label: 'Toggle',
            onClick: toggleServerStatus,
            variant: 'outline'
          },
          {
            label: 'Configure',
            onClick: (server) => {
              setSelectedServer(server)
              setShowConfigModal(true)
            },
            variant: 'outline'
          },
          {
            label: 'Delete',
            onClick: (server) => console.log('Delete server:', server),
            variant: 'destructive'
          }
        ]}
      />

      {/* Clients Table */}
      <TableCard
        title="WireGuard Clients"
        description="Client configurations and connection status"
        data={clients}
        columns={clientColumns}
        loading={loading}
        actions={[
          {
            label: 'Download',
            onClick: handleDownloadConfig,
            variant: 'outline'
          },
          {
            label: 'QR Code',
            onClick: handleShowQR,
            variant: 'outline'
          },
          {
            label: 'Delete',
            onClick: (client) => console.log('Delete client:', client),
            variant: 'destructive'
          }
        ]}
      />

      {/* Create Server Modal */}
      <Modal
        isOpen={showServerModal}
        onClose={() => setShowServerModal(false)}
        title="Create WireGuard Server"
        description="Set up a new VPN server instance"
        size="lg"
      >
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Server Name
            </label>
            <input
              type="text"
              value={serverForm.server_name}
              onChange={(e) => setServerForm({...serverForm, server_name: e.target.value})}
              className="w-full enterprise-input rounded-lg px-3 py-2"
              placeholder="Main VPN Server"
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Listen Port
              </label>
              <input
                type="number"
                value={serverForm.listen_port}
                onChange={(e) => setServerForm({...serverForm, listen_port: parseInt(e.target.value)})}
                className="w-full enterprise-input rounded-lg px-3 py-2"
                placeholder="51820"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Max Clients
              </label>
              <input
                type="number"
                value={serverForm.max_clients}
                onChange={(e) => setServerForm({...serverForm, max_clients: parseInt(e.target.value)})}
                className="w-full enterprise-input rounded-lg px-3 py-2"
                placeholder="100"
              />
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Network CIDR
            </label>
            <input
              type="text"
              value={serverForm.network}
              onChange={(e) => setServerForm({...serverForm, network: e.target.value})}
              className="w-full enterprise-input rounded-lg px-3 py-2"
              placeholder="10.8.0.0/24"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Public Endpoint
            </label>
            <input
              type="text"
              value={serverForm.endpoint}
              onChange={(e) => setServerForm({...serverForm, endpoint: e.target.value})}
              className="w-full enterprise-input rounded-lg px-3 py-2"
              placeholder="vpn.example.com"
            />
          </div>
          
          <div className="flex justify-end space-x-3 pt-4">
            <Button variant="outline" onClick={() => setShowServerModal(false)}>
              Cancel
            </Button>
            <Button variant="neon" onClick={handleCreateServer}>
              Create Server
            </Button>
          </div>
        </div>
      </Modal>

      {/* Create Client Modal */}
      <Modal
        isOpen={showClientModal}
        onClose={() => setShowClientModal(false)}
        title="Create WireGuard Client"
        description="Generate a new client configuration"
      >
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Client Name
            </label>
            <input
              type="text"
              value={clientForm.client_name}
              onChange={(e) => setClientForm({...clientForm, client_name: e.target.value})}
              className="w-full enterprise-input rounded-lg px-3 py-2"
              placeholder="John's iPhone"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              WireGuard Server
            </label>
            <select
              value={clientForm.server_id}
              onChange={(e) => setClientForm({...clientForm, server_id: e.target.value})}
              className="w-full enterprise-input rounded-lg px-3 py-2"
            >
              <option value="">Select a server</option>
              {servers.map(server => (
                <option key={server.id} value={server.id}>
                  {server.server_name} ({server.endpoint}:{server.listen_port})
                </option>
              ))}
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Allowed IPs
            </label>
            <input
              type="text"
              value={clientForm.allowed_ips.join(', ')}
              onChange={(e) => setClientForm({
                ...clientForm, 
                allowed_ips: e.target.value.split(',').map(ip => ip.trim())
              })}
              className="w-full enterprise-input rounded-lg px-3 py-2"
              placeholder="0.0.0.0/0"
            />
            <p className="text-sm text-gray-500 mt-1">
              Use 0.0.0.0/0 for full tunnel, or specific IPs/subnets for split tunnel
            </p>
          </div>
          
          <div className="flex justify-end space-x-3 pt-4">
            <Button variant="outline" onClick={() => setShowClientModal(false)}>
              Cancel
            </Button>
            <Button variant="neon" onClick={handleCreateClient}>
              Create Client
            </Button>
          </div>
        </div>
      </Modal>

      {/* QR Code Modal */}
      <Modal
        isOpen={showQRModal}
        onClose={() => setShowQRModal(false)}
        title="WireGuard Configuration"
        description={`Configuration for ${selectedClient?.client_name}`}
        size="lg"
      >
        <div className="space-y-6">
          <div className="flex justify-center">
            <div className="bg-white p-4 rounded-lg">
              <div className="w-48 h-48 bg-gray-200 flex items-center justify-center rounded">
                <QrCode className="h-12 w-12 text-gray-500" />
                <span className="ml-2 text-gray-500">QR Code</span>
              </div>
            </div>
          </div>
          
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-sm font-medium text-gray-300">
                Configuration File
              </label>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => copyToClipboard(clientConfig)}
              >
                <Copy className="h-4 w-4 mr-2" />
                Copy
              </Button>
            </div>
            <textarea
              value={clientConfig}
              readOnly
              className="w-full h-40 enterprise-input rounded-lg px-3 py-2 font-mono text-sm"
            />
          </div>
          
          <div className="text-sm text-gray-400">
            <p>• Scan the QR code with the WireGuard mobile app</p>
            <p>• Or copy the configuration and import it manually</p>
            <p>• Download the config file for desktop clients</p>
          </div>
          
          <div className="flex justify-end space-x-3">
            <Button 
              variant="outline" 
              onClick={() => handleDownloadConfig(selectedClient)}
            >
              <Download className="h-4 w-4 mr-2" />
              Download Config
            </Button>
            <Button variant="neon" onClick={() => setShowQRModal(false)}>
              Done
            </Button>
          </div>
        </div>
      </Modal>

      {/* VPS Setup Modal */}
      <Modal
        isOpen={showVPSModal}
        onClose={() => setShowVPSModal(false)}
        title="Setup VPS WireGuard Server"
        description="Automatically install and configure WireGuard on a remote VPS"
        size="lg"
      >
        <div className="space-y-4">
          <div className="glassmorphism-card bg-blue-500/10 p-4 rounded-lg">
            <div className="flex items-center space-x-2 mb-2">
              <Terminal className="h-4 w-4 text-blue-400" />
              <span className="text-blue-300 text-sm font-medium">SSH Automation</span>
            </div>
            <p className="text-sm text-gray-400">
              This will connect to your VPS via SSH and automatically install WireGuard, 
              configure firewall rules, and generate server keys.
            </p>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                VPS Name
              </label>
              <input
                type="text"
                value={vpsForm.vps_name}
                onChange={(e) => setVpsForm({...vpsForm, vps_name: e.target.value})}
                className="w-full enterprise-input rounded-lg px-3 py-2"
                placeholder="My VPS Server"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                VPS IP Address
              </label>
              <input
                type="text"
                value={vpsForm.vps_ip}
                onChange={(e) => setVpsForm({...vpsForm, vps_ip: e.target.value})}
                className="w-full enterprise-input rounded-lg px-3 py-2"
                placeholder="192.168.1.100"
              />
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                SSH Username
              </label>
              <input
                type="text"
                value={vpsForm.ssh_username}
                onChange={(e) => setVpsForm({...vpsForm, ssh_username: e.target.value})}
                className="w-full enterprise-input rounded-lg px-3 py-2"
                placeholder="root"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                SSH Password
              </label>
              <input
                type="password"
                value={vpsForm.ssh_password}
                onChange={(e) => setVpsForm({...vpsForm, ssh_password: e.target.value})}
                className="w-full enterprise-input rounded-lg px-3 py-2"
                placeholder="Enter SSH password"
              />
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              WireGuard Server Name
            </label>
            <input
              type="text"
              value={vpsForm.wg_server_name}
              onChange={(e) => setVpsForm({...vpsForm, wg_server_name: e.target.value})}
              className="w-full enterprise-input rounded-lg px-3 py-2"
              placeholder="VPS-WG-Server"
            />
          </div>
          
          <div className="glassmorphism-card bg-yellow-500/10 p-4 rounded-lg">
            <div className="flex items-center space-x-2 mb-2">
              <AlertTriangle className="h-4 w-4 text-yellow-400" />
              <span className="text-yellow-300 text-sm font-medium">Security Notice</span>
            </div>
            <p className="text-sm text-gray-400">
              SSH credentials will be encrypted and stored securely. 
              The installation process may take 2-5 minutes depending on VPS performance.
            </p>
          </div>
          
          <div className="flex justify-end space-x-3 pt-4">
            <Button variant="outline" onClick={() => setShowVPSModal(false)}>
              Cancel
            </Button>
            <Button 
              variant="neon" 
              onClick={handleCreateVPS}
              loading={vpsInstalling}
            >
              {vpsInstalling ? 'Installing...' : 'Setup VPS'}
            </Button>
          </div>
        </div>
      </Modal>

      {/* VPS Status Modal */}
      <Modal
        isOpen={showVPSStatusModal}
        onClose={() => setShowVPSStatusModal(false)}
        title={`VPS Status: ${selectedVPS?.vps_name}`}
        description="Installation progress and server details"
        size="xl"
      >
        {installationProgress && (
          <div className="space-y-6">
            {/* Progress Overview */}
            <div className="glassmorphism-card bg-gray-500/10 p-4 rounded-lg">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-white">Installation Progress</h3>
                <span className="text-2xl font-bold text-enterprise-neon">
                  {installationProgress.installationProgress.progressPercentage}%
                </span>
              </div>
              
              <div className="w-full bg-gray-700 rounded-full h-3 mb-4">
                <div 
                  className="bg-enterprise-neon h-3 rounded-full transition-all duration-500"
                  style={{ width: `${installationProgress.installationProgress.progressPercentage}%` }}
                />
              </div>
              
              <div className="grid grid-cols-4 gap-4 text-center">
                <div>
                  <div className="text-lg font-bold text-white">
                    {installationProgress.installationProgress.totalSteps}
                  </div>
                  <div className="text-sm text-gray-400">Total Steps</div>
                </div>
                <div>
                  <div className="text-lg font-bold text-green-400">
                    {installationProgress.installationProgress.completedSteps}
                  </div>
                  <div className="text-sm text-gray-400">Completed</div>
                </div>
                <div>
                  <div className="text-lg font-bold text-blue-400">
                    {installationProgress.installationProgress.runningSteps}
                  </div>
                  <div className="text-sm text-gray-400">Running</div>
                </div>
                <div>
                  <div className="text-lg font-bold text-red-400">
                    {installationProgress.installationProgress.failedSteps}
                  </div>
                  <div className="text-sm text-gray-400">Failed</div>
                </div>
              </div>
            </div>

            {/* Installation Steps */}
            <div>
              <h4 className="text-md font-semibold text-white mb-3">Installation Steps</h4>
              <div className="space-y-2">
                {installationProgress.installationSteps.map((step: any, index: number) => (
                  <div key={step.id} className="flex items-center space-x-3 p-3 glassmorphism-card bg-gray-500/10 rounded-lg">
                    <div className="flex-shrink-0">
                      {step.status === 'completed' && <CheckCircle className="h-5 w-5 text-green-400" />}
                      {step.status === 'running' && <Loader2 className="h-5 w-5 text-blue-400 animate-spin" />}
                      {step.status === 'failed' && <AlertTriangle className="h-5 w-5 text-red-400" />}
                      {step.status === 'pending' && <div className="h-5 w-5 rounded-full border-2 border-gray-500" />}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <span className="text-white font-medium">{step.description}</span>
                        <span className={cn(
                          'text-xs px-2 py-1 rounded-full',
                          step.status === 'completed' ? 'bg-green-500/20 text-green-300' :
                          step.status === 'running' ? 'bg-blue-500/20 text-blue-300' :
                          step.status === 'failed' ? 'bg-red-500/20 text-red-300' :
                          'bg-gray-500/20 text-gray-300'
                        )}>
                          {step.status}
                        </span>
                      </div>
                      {step.output && (
                        <div className="text-xs text-gray-400 mt-1 font-mono bg-black/20 p-2 rounded">
                          {step.output}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* WireGuard Server Details */}
            {installationProgress.wireguardServer && (
              <div className="glassmorphism-card bg-green-500/10 p-4 rounded-lg">
                <h4 className="text-md font-semibold text-white mb-3 flex items-center space-x-2">
                  <CheckCircle className="h-5 w-5 text-green-400" />
                  <span>WireGuard Server Created</span>
                </h4>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <div className="text-sm text-gray-400">Server Name</div>
                    <div className="text-white font-medium">{installationProgress.wireguardServer.serverName}</div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-400">Endpoint</div>
                    <div className="text-white font-medium">{installationProgress.wireguardServer.endpoint}</div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-400">Network</div>
                    <div className="text-white font-medium">{installationProgress.wireguardServer.network}</div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-400">Status</div>
                    <div className="text-green-400 font-medium">{installationProgress.wireguardServer.status}</div>
                  </div>
                </div>
              </div>
            )}
            
            <div className="flex justify-end space-x-3">
              <Button variant="outline" onClick={() => setShowVPSStatusModal(false)}>
                Close
              </Button>
              <Button variant="neon" onClick={() => checkVPSStatus(selectedVPS!)}>
                <RefreshCw className="h-4 w-4 mr-2" />
                Refresh Status
              </Button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  )
}

export default VPN