import React, { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import {
  Activity,
  Router,
  Shield,
  Network,
  TrendingUp,
  AlertTriangle,
  Users,
  RefreshCw,
  Plus,
  Settings,
  Thermometer,
  Cpu,
  HardDrive
} from 'lucide-react'
import { useNetworkStore, useVPNStore, useUIStore } from '@/lib/store'
import { DeviceService } from '@/lib/services'
import MetricCard from '@/components/ui/metric-card'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import TableCard from '@/components/ui/table-card'
import NetworkSpeedTestingCard from '@/components/ui/network-speed-testing-card'
import ModemModeSetup from '@/components/ui/modem-mode-setup'
import { useRealTimeUpdates, useSystemHealth, useNetworkMonitoring, useVPNMonitoring } from '@/hooks/useRealTime'

const Dashboard: React.FC = () => {
  const { devices, setDevices, isDiscovering, setDiscovering } = useNetworkStore()
  const { servers, clients } = useVPNStore()
  const { addNotification } = useUIStore()
  const [loading, setLoading] = useState(true)
  const [showModemSetup, setShowModemSetup] = useState(false)
  
  // Real-time hooks
  const { isConnected, systemMetrics } = useRealTimeUpdates()
  const systemHealth = useSystemHealth()
  const networkStats = useNetworkMonitoring()
  const vpnStats = useVPNMonitoring()

  useEffect(() => {
    loadDashboardData()
    const interval = setInterval(loadDashboardData, 30000) // Refresh every 30 seconds
    return () => clearInterval(interval)
  }, [])

  const loadDashboardData = async () => {
    try {
      setLoading(true)
      
      // Load network devices using DeviceService
      const networkDevices = await DeviceService.getAllDevices()
      
      // Take only the first 10 most recent devices
      const recentDevices = networkDevices
        .sort((a, b) => new Date(b.last_seen || '').getTime() - new Date(a.last_seen || '').getTime())
        .slice(0, 10)
      
      setDevices(recentDevices)
      
    } catch (error) {
      console.error('Error loading dashboard data:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleDiscoverDevices = async () => {
    setDiscovering(true)
    try {
      // Trigger real network discovery via DeviceService
      await DeviceService.discoverDevices()
      await loadDashboardData()
      addNotification({ type: 'success', message: 'Network scan completed successfully' })
    } catch (error) {
      console.error('Device discovery failed:', error)
      addNotification({ type: 'error', message: 'Failed to discover network devices' })
    } finally {
      setDiscovering(false)
    }
  }

  const handleQuickSetupSuccess = () => {
    setShowModemSetup(false)
    addNotification({ 
      type: 'success', 
      message: 'Modem mode setup completed successfully. System is being configured.' 
    })
    // Refresh dashboard data to reflect new configuration
    loadDashboardData()
  }

  const recentDevices = devices.slice(0, 5).map(device => ({
    ...device,
    id: device.mac_address
  }))

  const deviceColumns = [
    {
      key: 'device_name' as keyof typeof recentDevices[0],
      label: 'Device',
      render: (value: any, item: typeof recentDevices[0]) => (
        <div className="flex items-center space-x-3">
          <div className={`w-2 h-2 rounded-full ${
            item.is_active ? 'bg-green-400 animate-pulse' : 'bg-gray-400'
          }`} />
          <span className="text-white font-medium">{value || 'Unknown Device'}</span>
        </div>
      )
    },
    {
      key: 'ip_address' as keyof typeof recentDevices[0],
      label: 'IP Address',
      render: (value: any) => (
        <span className="text-gray-300">{value || 'N/A'}</span>
      )
    },
    {
      key: 'device_type' as keyof typeof recentDevices[0],
      label: 'Type',
      render: (value: any) => (
        <span className="status-badge bg-blue-500/20 text-blue-300 border-blue-500/30">
          {value || 'Unknown'}
        </span>
      )
    },
    {
      key: 'last_seen' as keyof typeof recentDevices[0],
      label: 'Last Seen',
      render: (value: any) => (
        <span className="text-gray-400">
          {value ? new Date(value).toLocaleTimeString() : 'Never'}
        </span>
      )
    }
  ]

  return (
    <div className="space-y-4 sm:space-y-6">
      {/* Header */}
      <div className="flex flex-col space-y-4 md:flex-row md:items-center md:justify-between md:space-y-0">
        <div>
          <h1 className="responsive-title font-bold text-white mb-2">Network Dashboard</h1>
          <div className="flex flex-col space-y-2 sm:flex-row sm:items-center sm:space-y-0 sm:space-x-4">
            <p className="responsive-subtitle text-gray-400">Real-time overview of your Pi5 Supernode network</p>
            <div className="flex items-center space-x-2">
              <div className={`w-2 h-2 rounded-full ${
                isConnected ? 'bg-green-400 animate-pulse' : 'bg-red-400'
              }`} />
              <span className="text-sm text-gray-400">
                {isConnected ? 'Live' : 'Offline'}
              </span>
            </div>
          </div>
        </div>
        
        <div className="mobile-button-group">
          <Button
            variant="outline"
            onClick={handleDiscoverDevices}
            loading={isDiscovering}
            className="touch-target"
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Discover Devices
          </Button>
          
          <Button 
            variant="neon"
            onClick={() => setShowModemSetup(true)}
            className="touch-target"
          >
            <Plus className="h-4 w-4 mr-2" />
            Quick Setup
          </Button>
        </div>
      </div>

      {/* Network Speed Testing Card - HIGH PRIORITY FEATURE */}
      <div className="w-full">
        <NetworkSpeedTestingCard />
      </div>

      {/* Real-time Metrics Grid */}
      <div className="mobile-grid">
        <MetricCard
          title="Active Devices"
          value={networkStats.active_devices}
          subtitle={`${networkStats.total_devices} total devices`}
          icon={Router}
          trend={{ value: 12, isPositive: true }}
          color="success"
          loading={loading}
        />
        
        <MetricCard
          title="VPN Connections"
          value={vpnStats.connected_clients}
          subtitle={`${vpnStats.active_servers} active servers`}
          icon={Shield}
          trend={{ value: 5, isPositive: true }}
          color="info"
          loading={loading}
        />
        
        <MetricCard
          title="CPU Usage"
          value={systemMetrics ? `${systemMetrics.cpu.toFixed(1)}%` : 'N/A'}
          subtitle="System performance"
          icon={Cpu}
          trend={{ value: systemMetrics?.cpu || 0, isPositive: false }}
          color={systemHealth.cpu_healthy ? 'success' : 'warning'}
          loading={loading}
        />
        
        <MetricCard
          title="System Health"
          value={systemHealth.overall_status.toUpperCase()}
          subtitle="Overall system status"
          icon={systemHealth.overall_status === 'healthy' ? Activity : AlertTriangle}
          color={systemHealth.overall_status === 'healthy' ? 'success' : 
                 systemHealth.overall_status === 'warning' ? 'warning' : 'danger'}
          loading={loading}
        />
      </div>

      {/* System Performance Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
        {/* Real-time Metrics Display */}
        <Card className="mobile-card">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center space-x-2 text-base sm:text-lg">
              <TrendingUp className="h-4 w-4 sm:h-5 sm:w-5 text-enterprise-neon" />
              <span>System Performance (Live)</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="space-y-4 sm:space-y-6">
              {systemMetrics && (
                <div className="grid grid-cols-2 gap-3 sm:gap-4">
                  <div className="text-center">
                    <div className="text-lg sm:text-2xl font-bold text-enterprise-neon">
                      {systemMetrics.cpu.toFixed(1)}%
                    </div>
                    <div className="text-xs sm:text-sm text-gray-400">CPU Usage</div>
                    <div className="w-full bg-gray-700 rounded-full h-2 mt-2">
                      <div 
                        className="bg-enterprise-neon h-2 rounded-full transition-all duration-500"
                        style={{ width: `${systemMetrics.cpu}%` }}
                      />
                    </div>
                  </div>
                  
                  <div className="text-center">
                    <div className="text-lg sm:text-2xl font-bold text-green-400">
                      {systemMetrics.memory.toFixed(1)}%
                    </div>
                    <div className="text-xs sm:text-sm text-gray-400">Memory Usage</div>
                    <div className="w-full bg-gray-700 rounded-full h-2 mt-2">
                      <div 
                        className="bg-green-400 h-2 rounded-full transition-all duration-500"
                        style={{ width: `${systemMetrics.memory}%` }}
                      />
                    </div>
                  </div>
                  
                  <div className="text-center">
                    <div className="text-lg sm:text-2xl font-bold text-yellow-400">
                      {systemMetrics.temperature.toFixed(1)}°C
                    </div>
                    <div className="text-xs sm:text-sm text-gray-400">Temperature</div>
                  </div>
                  
                  <div className="text-center">
                    <div className="text-lg sm:text-2xl font-bold text-blue-400">
                      {((systemMetrics.network.upload + systemMetrics.network.download) / 1000).toFixed(1)}G
                    </div>
                    <div className="text-xs sm:text-sm text-gray-400">Network I/O</div>
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Network Traffic Display */}
        <Card className="mobile-card">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center space-x-2 text-base sm:text-lg">
              <Network className="h-4 w-4 sm:h-5 sm:w-5 text-enterprise-neon" />
              <span>Network Traffic (Live)</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="space-y-4 sm:space-y-6">
              {systemMetrics && (
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm sm:text-base text-gray-300">Download</span>
                    <div className="flex items-center space-x-2">
                      <div className="w-20 sm:w-32 bg-gray-700 rounded-full h-2">
                        <div 
                          className="bg-green-400 h-2 rounded-full transition-all duration-500"
                          style={{ width: `${Math.min((systemMetrics.network.download / 1000) * 100, 100)}%` }}
                        />
                      </div>
                      <span className="text-white font-medium text-sm sm:text-base w-16 sm:w-20 text-right">
                        {systemMetrics.network.download.toFixed(1)} MB/s
                      </span>
                    </div>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <span className="text-sm sm:text-base text-gray-300">Upload</span>
                    <div className="flex items-center space-x-2">
                      <div className="w-20 sm:w-32 bg-gray-700 rounded-full h-2">
                        <div 
                          className="bg-blue-400 h-2 rounded-full transition-all duration-500"
                          style={{ width: `${Math.min((systemMetrics.network.upload / 1000) * 100, 100)}%` }}
                        />
                      </div>
                      <span className="text-white font-medium text-sm sm:text-base w-16 sm:w-20 text-right">
                        {systemMetrics.network.upload.toFixed(1)} MB/s
                      </span>
                    </div>
                  </div>
                  
                  <div className="pt-4 border-t border-gray-700">
                    <div className="grid grid-cols-2 gap-4 text-center">
                      <div>
                        <div className="text-base sm:text-lg font-bold text-white">
                          {networkStats.latency.toFixed(1)}ms
                        </div>
                        <div className="text-xs sm:text-sm text-gray-400">Latency</div>
                      </div>
                      <div>
                        <div className="text-base sm:text-lg font-bold text-white">
                          {networkStats.packet_loss.toFixed(2)}%
                        </div>
                        <div className="text-xs sm:text-sm text-gray-400">Packet Loss</div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* System Health Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
        <Card className="mobile-card">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center space-x-2 text-base sm:text-lg">
              <Activity className="h-4 w-4 sm:h-5 sm:w-5 text-enterprise-neon" />
              <span>System Status</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="space-y-3 sm:space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-sm sm:text-base text-gray-300">CPU Temperature</span>
                <div className="flex items-center space-x-2">
                  <Thermometer className={`h-3 w-3 sm:h-4 sm:w-4 ${
                    systemHealth.temperature_healthy ? 'text-green-400' : 'text-red-400'
                  }`} />
                  <span className="text-white font-medium text-sm sm:text-base">
                    {systemMetrics ? `${systemMetrics.temperature.toFixed(1)}°C` : 'N/A'}
                  </span>
                </div>
              </div>
              
              <div className="flex justify-between items-center">
                <span className="text-sm sm:text-base text-gray-300">Memory Usage</span>
                <span className={`font-medium text-sm sm:text-base ${
                  systemHealth.memory_healthy ? 'text-green-400' : 'text-red-400'
                }`}>
                  {systemMetrics ? `${systemMetrics.memory.toFixed(1)}%` : 'N/A'}
                </span>
              </div>
              
              <div className="flex justify-between items-center">
                <span className="text-sm sm:text-base text-gray-300">Network Latency</span>
                <span className="text-white font-medium text-sm sm:text-base">{networkStats.latency.toFixed(1)}ms</span>
              </div>
              
              <div className="flex justify-between items-center">
                <span className="text-sm sm:text-base text-gray-300">Packet Loss</span>
                <span className="text-white font-medium text-sm sm:text-base">{networkStats.packet_loss.toFixed(2)}%</span>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="mobile-card">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center space-x-2 text-base sm:text-lg">
              <Shield className="h-4 w-4 sm:h-5 sm:w-5 text-enterprise-neon" />
              <span>VPN Status</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="space-y-3 sm:space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-sm sm:text-base text-gray-300">Active Servers</span>
                <span className="text-green-400 font-medium text-sm sm:text-base">{vpnStats.active_servers}</span>
              </div>
              
              <div className="flex justify-between items-center">
                <span className="text-sm sm:text-base text-gray-300">Connected Clients</span>
                <span className="text-white font-medium text-sm sm:text-base">{vpnStats.connected_clients}</span>
              </div>
              
              <div className="flex justify-between items-center">
                <span className="text-sm sm:text-base text-gray-300">Average Latency</span>
                <span className="text-white font-medium text-sm sm:text-base">{vpnStats.average_latency.toFixed(1)}ms</span>
              </div>
              
              <div className="flex justify-between items-center">
                <span className="text-sm sm:text-base text-gray-300">Connection Uptime</span>
                <span className="text-green-400 font-medium text-sm sm:text-base">{vpnStats.connection_uptime.toFixed(1)}%</span>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="mobile-card">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center space-x-2 text-base sm:text-lg">
              <Users className="h-4 w-4 sm:h-5 sm:w-5 text-enterprise-neon" />
              <span>Network Overview</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="space-y-3 sm:space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-sm sm:text-base text-gray-300">Total Bandwidth</span>
                <span className="text-white font-medium text-sm sm:text-base">{networkStats.bandwidth_usage.toFixed(1)} MB/s</span>
              </div>
              
              <div className="flex justify-between items-center">
                <span className="text-sm sm:text-base text-gray-300">Active Connections</span>
                <span className="text-white font-medium text-sm sm:text-base">{networkStats.active_devices}</span>
              </div>
              
              <div className="flex justify-between items-center">
                <span className="text-sm sm:text-base text-gray-300">Blocked Devices</span>
                <span className={`font-medium text-sm sm:text-base ${
                  networkStats.blocked_devices > 0 ? 'text-red-400' : 'text-green-400'
                }`}>
                  {networkStats.blocked_devices}
                </span>
              </div>
              
              <div className="flex justify-between items-center">
                <span className="text-sm sm:text-base text-gray-300">DNS Queries/s</span>
                <span className="text-white font-medium text-sm sm:text-base">245</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Devices Table with Real-time Updates */}
      <div className="mobile-table-scroll">
        <TableCard
          title="Recent Devices (Live)"
          description="Latest network activity with real-time status updates"
          data={recentDevices}
          columns={deviceColumns}
          loading={loading}
          actions={[
            {
              label: 'Wake',
              onClick: (device) => console.log('Wake device:', device),
              variant: 'outline'
            },
            {
              label: 'Details',
              onClick: (device) => console.log('View device details:', device),
              variant: 'outline'
            }
          ]}
        />
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 sm:gap-6">
        <Card className="mobile-card">
          <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-3 sm:space-y-0 sm:space-x-4">
            <div className="p-2 sm:p-3 bg-enterprise-neon/10 rounded-lg">
              <Network className="h-5 w-5 sm:h-6 sm:w-6 text-enterprise-neon" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-white text-sm sm:text-base">Network Scan</h3>
              <p className="text-xs sm:text-sm text-gray-400">Discover new devices</p>
            </div>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={handleDiscoverDevices}
              className="touch-target w-full sm:w-auto"
            >
              Scan
            </Button>
          </div>
        </Card>
        
        <Card className="mobile-card">
          <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-3 sm:space-y-0 sm:space-x-4">
            <div className="p-2 sm:p-3 bg-enterprise-success/10 rounded-lg">
              <Shield className="h-5 w-5 sm:h-6 sm:w-6 text-enterprise-success" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-white text-sm sm:text-base">VPN Setup</h3>
              <p className="text-xs sm:text-sm text-gray-400">Create VPN server</p>
            </div>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => setShowModemSetup(true)}
              className="touch-target w-full sm:w-auto"
            >
              Setup
            </Button>
          </div>
        </Card>
        
        <Card className="mobile-card sm:col-span-2 md:col-span-1">
          <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-3 sm:space-y-0 sm:space-x-4">
            <div className="p-2 sm:p-3 bg-enterprise-warning/10 rounded-lg">
              <Settings className="h-5 w-5 sm:h-6 sm:w-6 text-enterprise-warning" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-white text-sm sm:text-base">System Health</h3>
              <p className="text-xs sm:text-sm text-gray-400">Check diagnostics</p>
            </div>
            <Button 
              variant="outline" 
              size="sm"
              className={`touch-target w-full sm:w-auto ${
                systemHealth.overall_status !== 'healthy' ? 'border-red-500 text-red-400' : ''
              }`}
            >
              {systemHealth.overall_status === 'healthy' ? 'Healthy' : 'Check'}
            </Button>
          </div>
        </Card>
      </div>

      {/* Modem Mode Setup Modal */}
      <ModemModeSetup 
        isOpen={showModemSetup}
        onClose={() => setShowModemSetup(false)}
        onSuccess={handleQuickSetupSuccess}
      />
    </div>
  )
}

export default Dashboard