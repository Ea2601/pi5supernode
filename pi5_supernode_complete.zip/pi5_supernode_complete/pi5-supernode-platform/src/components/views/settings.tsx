import React, { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import {
  Settings as SettingsIcon,
  User,
  Shield,
  Bell,
  Palette,
  Globe,
  Database,
  Download,
  Upload,
  RefreshCw,
  Save,
  Key,
  Eye,
  EyeOff,
  Copy,
  FileText,
  ExternalLink,
  HelpCircle,
  BookOpen,
  Terminal,
  Wifi,
  Network,
  Clock,
  Monitor,
  Zap
} from 'lucide-react'
import { useUIStore } from '@/lib/store'
import { SettingsService, type SystemSettings, type SecuritySettings, type NotificationSettings } from '@/lib/services'
import { Button } from '@/components/ui/button'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card'
import MetricCard from '@/components/ui/metric-card'
import Modal from '@/components/ui/modal'
import QuickSetupWizard from '@/components/ui/quick-setup-wizard'
import SettingsManager from '@/components/enhancements/SettingsManager'
import WANManager from '@/components/enhancements/WANManager'
import NetworkManagement from '@/components/enhancements/NetworkManagement'
import { cn } from '@/lib/utils'

const Settings: React.FC = () => {
  const { addNotification } = useUIStore()
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState('system')
  const [showBackupModal, setShowBackupModal] = useState(false)
  const [showApiKeyModal, setShowApiKeyModal] = useState(false)
  const [showPasswordModal, setShowPasswordModal] = useState(false)
  const [showQuickSetupWizard, setShowQuickSetupWizard] = useState(false)
  
  const [systemSettings, setSystemSettings] = useState<SystemSettings>({
    hostname: 'pi5-supernode',
    timezone: 'UTC',
    ntp_servers: ['pool.ntp.org', 'time.cloudflare.com'],
    dns_servers: ['1.1.1.1', '8.8.8.8'],
    ssh_enabled: true,
    ssh_port: 22,
    auto_updates: true,
    backup_enabled: true,
    backup_schedule: '0 2 * * *'
  })
  
  const [securitySettings, setSecuritySettings] = useState<SecuritySettings>({
    firewall_enabled: true,
    fail2ban_enabled: true,
    password_policy: {
      min_length: 8,
      require_uppercase: true,
      require_numbers: true,
      require_symbols: false
    },
    session_timeout: 3600,
    two_factor_enabled: false
  })
  
  const [notificationSettings, setNotificationSettings] = useState<NotificationSettings>({
    email_enabled: false,
    email_address: '',
    telegram_enabled: true,
    telegram_chat_id: '',
    webhook_enabled: false,
    webhook_url: '',
    alert_levels: ['critical', 'warning']
  })
  
  const [apiKey, setApiKey] = useState('sk-1234567890abcdef...')
  const [showApiKey, setShowApiKey] = useState(false)

  useEffect(() => {
    loadSettings()
  }, [])

  const loadSettings = async () => {
    try {
      setLoading(true)
      
      // Load all settings from the database
      const [systemData, securityData, notificationData] = await Promise.all([
        SettingsService.getSystemSettings(),
        SettingsService.getSecuritySettings(),
        SettingsService.getNotificationSettings()
      ])
      
      setSystemSettings(systemData)
      setSecuritySettings(securityData)
      setNotificationSettings(notificationData)
      
    } catch (error) {
      console.error('Error loading settings:', error)
      addNotification({ type: 'error', message: 'Failed to load settings' })
    } finally {
      setLoading(false)
    }
  }

  const saveSystemSettings = async () => {
    try {
      await SettingsService.saveSystemSettings(systemSettings)
      addNotification({ type: 'success', message: 'System settings saved successfully' })
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to save system settings' })
    }
  }

  const saveSecuritySettings = async () => {
    try {
      await SettingsService.saveSecuritySettings(securitySettings)
      addNotification({ type: 'success', message: 'Security settings saved successfully' })
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to save security settings' })
    }
  }

  const saveNotificationSettings = async () => {
    try {
      await SettingsService.saveNotificationSettings(notificationSettings)
      addNotification({ type: 'success', message: 'Notification settings saved successfully' })
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to save notification settings' })
    }
  }

  const generateApiKey = async () => {
    try {
      const newKey = await SettingsService.generateApiKey()
      setApiKey(newKey)
      addNotification({ type: 'success', message: 'New API key generated' })
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to generate API key' })
    }
  }

  const copyApiKey = () => {
    navigator.clipboard.writeText(apiKey)
    addNotification({ type: 'success', message: 'API key copied to clipboard' })
  }

  const createBackup = async () => {
    try {
      addNotification({ type: 'info', message: 'Creating system backup...' })
      
      const backup = await SettingsService.createBackup()
      
      addNotification({ type: 'success', message: 'System backup created successfully' })
      setShowBackupModal(false)
      
      // Automatically download the backup
      if (backup.downloadUrl) {
        window.open(backup.downloadUrl, '_blank')
      }
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to create backup' })
    }
  }

  const restartSystem = async () => {
    try {
      addNotification({ type: 'warning', message: 'System restart initiated...' })
      
      await SettingsService.restartSystem()
      
      addNotification({ type: 'info', message: 'System will restart in 10 seconds' })
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to restart system' })
    }
  }

  const documentationLinks = [
    {
      title: 'Getting Started Guide',
      description: 'Basic setup and configuration walkthrough',
      icon: BookOpen,
      url: '#/docs/getting-started'
    },
    {
      title: 'Network Configuration',
      description: 'Advanced network and routing setup',
      icon: Network,
      url: '#/docs/network'
    },
    {
      title: 'VPN Setup Guide',
      description: 'WireGuard server and client configuration',
      icon: Shield,
      url: '#/docs/vpn'
    },
    {
      title: 'API Documentation',
      description: 'REST API reference and examples',
      icon: Terminal,
      url: '#/docs/api'
    },
    {
      title: 'Troubleshooting',
      description: 'Common issues and solutions',
      icon: HelpCircle,
      url: '#/docs/troubleshooting'
    },
    {
      title: 'Hardware Requirements',
      description: 'Raspberry Pi 5 setup and optimization',
      icon: Monitor,
      url: '#/docs/hardware'
    }
  ]

  const tabs = [
    { id: 'quick-setup', label: 'Quick Setup', icon: Zap },
    { id: 'comprehensive', label: 'Comprehensive Settings', icon: SettingsIcon },
    { id: 'wan-manager', label: 'Multi-WAN', icon: Wifi },
    { id: 'network-manager', label: 'Network Management', icon: Network },
    { id: 'system', label: 'System', icon: SettingsIcon },
    { id: 'security', label: 'Security', icon: Shield },
    { id: 'notifications', label: 'Notifications', icon: Bell },
    { id: 'api', label: 'API Keys', icon: Key },
    { id: 'backup', label: 'Backup', icon: Database },
    { id: 'docs', label: 'Documentation', icon: FileText }
  ]

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">System Settings</h1>
          <p className="text-gray-400">System configuration and documentation access</p>
        </div>
        
        <div className="flex items-center space-x-3">
          <Button
            variant="outline"
            onClick={loadSettings}
            loading={loading}
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          
          <Button 
            variant="destructive"
            onClick={restartSystem}
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Restart System
          </Button>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard
          title="System Uptime"
          value="15d 8h"
          subtitle="Since last restart"
          icon={Clock}
          color="success"
          loading={loading}
        />
        
        <MetricCard
          title="SSH Status"
          value={systemSettings.ssh_enabled ? 'Enabled' : 'Disabled'}
          subtitle={`Port ${systemSettings.ssh_port}`}
          icon={Terminal}
          color={systemSettings.ssh_enabled ? 'success' : 'warning'}
          loading={loading}
        />
        
        <MetricCard
          title="Firewall"
          value={securitySettings.firewall_enabled ? 'Active' : 'Inactive'}
          subtitle="Network protection"
          icon={Shield}
          color={securitySettings.firewall_enabled ? 'success' : 'danger'}
          loading={loading}
        />
        
        <MetricCard
          title="Auto Updates"
          value={systemSettings.auto_updates ? 'Enabled' : 'Disabled'}
          subtitle="System maintenance"
          icon={Download}
          color={systemSettings.auto_updates ? 'success' : 'warning'}
          loading={loading}
        />
      </div>

      {/* Tab Navigation */}
      <div className="flex space-x-1 glassmorphism-card bg-gray-800/30 p-1 rounded-lg w-fit">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={cn(
              'flex items-center space-x-2 px-4 py-2 rounded-md transition-all duration-200',
              activeTab === tab.id
                ? 'bg-enterprise-neon/20 text-enterprise-neon border border-enterprise-neon/30'
                : 'text-gray-400 hover:text-white hover:bg-white/5'
            )}
          >
            <tab.icon className="h-4 w-4" />
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {/* Tab Content */}
      {activeTab === 'quick-setup' && (
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Quick Setup Wizard</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center space-y-4">
                <p className="text-gray-300">
                  Use the Quick Setup Wizard to configure your Pi5 Supernode system in just a few steps.
                </p>
                <Button
                  variant="neon"
                  onClick={() => setShowQuickSetupWizard(true)}
                  className="px-8 py-3 text-lg"
                >
                  <Zap className="h-5 w-5 mr-2" />
                  Start Quick Setup
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
      
      {activeTab === 'comprehensive' && (
        <SettingsManager />
      )}
      
      {activeTab === 'wan-manager' && (
        <WANManager />
      )}
      
      {activeTab === 'network-manager' && (
        <NetworkManagement />
      )}
      
      {activeTab === 'system' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>General Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Hostname
                </label>
                <input
                  type="text"
                  value={systemSettings.hostname}
                  onChange={(e) => setSystemSettings(prev => ({ ...prev, hostname: e.target.value }))}
                  className="input-field"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Timezone
                </label>
                <select
                  value={systemSettings.timezone}
                  onChange={(e) => setSystemSettings(prev => ({ ...prev, timezone: e.target.value }))}
                  className="input-field"
                >
                  <option value="UTC">UTC</option>
                  <option value="America/New_York">Eastern Time</option>
                  <option value="America/Chicago">Central Time</option>
                  <option value="America/Denver">Mountain Time</option>
                  <option value="America/Los_Angeles">Pacific Time</option>
                  <option value="Europe/London">London</option>
                  <option value="Europe/Paris">Paris</option>
                  <option value="Asia/Tokyo">Tokyo</option>
                </select>
              </div>
              
              <div className="flex items-center space-x-3">
                <input
                  type="checkbox"
                  id="auto-updates"
                  checked={systemSettings.auto_updates}
                  onChange={(e) => setSystemSettings(prev => ({ ...prev, auto_updates: e.target.checked }))}
                  className="checkbox"
                />
                <label htmlFor="auto-updates" className="text-gray-300">
                  Enable automatic system updates
                </label>
              </div>
              
              <Button variant="neon" onClick={saveSystemSettings}>
                <Save className="h-4 w-4 mr-2" />
                Save System Settings
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Network Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  DNS Servers
                </label>
                <div className="space-y-2">
                  {systemSettings.dns_servers.map((server, index) => (
                    <input
                      key={index}
                      type="text"
                      value={server}
                      onChange={(e) => {
                        const newServers = [...systemSettings.dns_servers]
                        newServers[index] = e.target.value
                        setSystemSettings(prev => ({ ...prev, dns_servers: newServers }))
                      }}
                      className="input-field"
                      placeholder="DNS Server"
                    />
                  ))}
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  SSH Configuration
                </label>
                <div className="space-y-3">
                  <div className="flex items-center space-x-3">
                    <input
                      type="checkbox"
                      id="ssh-enabled"
                      checked={systemSettings.ssh_enabled}
                      onChange={(e) => setSystemSettings(prev => ({ ...prev, ssh_enabled: e.target.checked }))}
                      className="checkbox"
                    />
                    <label htmlFor="ssh-enabled" className="text-gray-300">
                      Enable SSH access
                    </label>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-1">
                      SSH Port
                    </label>
                    <input
                      type="number"
                      value={systemSettings.ssh_port}
                      onChange={(e) => setSystemSettings(prev => ({ ...prev, ssh_port: parseInt(e.target.value) }))}
                      className="input-field w-32"
                      min="1"
                      max="65535"
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {activeTab === 'security' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Security Policies</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-3">
                <input
                  type="checkbox"
                  id="firewall"
                  checked={securitySettings.firewall_enabled}
                  onChange={(e) => setSecuritySettings(prev => ({ ...prev, firewall_enabled: e.target.checked }))}
                  className="checkbox"
                />
                <label htmlFor="firewall" className="text-gray-300">
                  Enable firewall protection
                </label>
              </div>
              
              <div className="flex items-center space-x-3">
                <input
                  type="checkbox"
                  id="fail2ban"
                  checked={securitySettings.fail2ban_enabled}
                  onChange={(e) => setSecuritySettings(prev => ({ ...prev, fail2ban_enabled: e.target.checked }))}
                  className="checkbox"
                />
                <label htmlFor="fail2ban" className="text-gray-300">
                  Enable Fail2Ban intrusion prevention
                </label>
              </div>
              
              <div className="flex items-center space-x-3">
                <input
                  type="checkbox"
                  id="2fa"
                  checked={securitySettings.two_factor_enabled}
                  onChange={(e) => setSecuritySettings(prev => ({ ...prev, two_factor_enabled: e.target.checked }))}
                  className="checkbox"
                />
                <label htmlFor="2fa" className="text-gray-300">
                  Enable two-factor authentication
                </label>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Session Timeout (seconds)
                </label>
                <input
                  type="number"
                  value={securitySettings.session_timeout}
                  onChange={(e) => setSecuritySettings(prev => ({ ...prev, session_timeout: parseInt(e.target.value) }))}
                  className="input-field w-32"
                  min="300"
                />
              </div>
              
              <Button variant="neon" onClick={saveSecuritySettings}>
                <Save className="h-4 w-4 mr-2" />
                Save Security Settings
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Password Policy</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Minimum Length
                </label>
                <input
                  type="number"
                  value={securitySettings.password_policy.min_length}
                  onChange={(e) => setSecuritySettings(prev => ({
                    ...prev,
                    password_policy: {
                      ...prev.password_policy,
                      min_length: parseInt(e.target.value)
                    }
                  }))}
                  className="input-field w-24"
                  min="6"
                  max="64"
                />
              </div>
              
              <div className="space-y-3">
                <div className="flex items-center space-x-3">
                  <input
                    type="checkbox"
                    id="require-uppercase"
                    checked={securitySettings.password_policy.require_uppercase}
                    onChange={(e) => setSecuritySettings(prev => ({
                      ...prev,
                      password_policy: {
                        ...prev.password_policy,
                        require_uppercase: e.target.checked
                      }
                    }))}
                    className="checkbox"
                  />
                  <label htmlFor="require-uppercase" className="text-gray-300">
                    Require uppercase letters
                  </label>
                </div>
                
                <div className="flex items-center space-x-3">
                  <input
                    type="checkbox"
                    id="require-numbers"
                    checked={securitySettings.password_policy.require_numbers}
                    onChange={(e) => setSecuritySettings(prev => ({
                      ...prev,
                      password_policy: {
                        ...prev.password_policy,
                        require_numbers: e.target.checked
                      }
                    }))}
                    className="checkbox"
                  />
                  <label htmlFor="require-numbers" className="text-gray-300">
                    Require numbers
                  </label>
                </div>
                
                <div className="flex items-center space-x-3">
                  <input
                    type="checkbox"
                    id="require-symbols"
                    checked={securitySettings.password_policy.require_symbols}
                    onChange={(e) => setSecuritySettings(prev => ({
                      ...prev,
                      password_policy: {
                        ...prev.password_policy,
                        require_symbols: e.target.checked
                      }
                    }))}
                    className="checkbox"
                  />
                  <label htmlFor="require-symbols" className="text-gray-300">
                    Require special characters
                  </label>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {activeTab === 'notifications' && (
        <Card>
          <CardHeader>
            <CardTitle>Notification Preferences</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="space-y-4">
                <h3 className="text-lg font-medium text-white mb-3">Email Notifications</h3>
                
                <div className="flex items-center space-x-3">
                  <input
                    type="checkbox"
                    id="email-enabled"
                    checked={notificationSettings.email_enabled}
                    onChange={(e) => setNotificationSettings(prev => ({ ...prev, email_enabled: e.target.checked }))}
                    className="checkbox"
                  />
                  <label htmlFor="email-enabled" className="text-gray-300">
                    Enable email notifications
                  </label>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Email Address
                  </label>
                  <input
                    type="email"
                    value={notificationSettings.email_address}
                    onChange={(e) => setNotificationSettings(prev => ({ ...prev, email_address: e.target.value }))}
                    className="input-field"
                    placeholder="admin@example.com"
                    disabled={!notificationSettings.email_enabled}
                  />
                </div>
              </div>
              
              <div className="space-y-4">
                <h3 className="text-lg font-medium text-white mb-3">Telegram Notifications</h3>
                
                <div className="flex items-center space-x-3">
                  <input
                    type="checkbox"
                    id="telegram-enabled"
                    checked={notificationSettings.telegram_enabled}
                    onChange={(e) => setNotificationSettings(prev => ({ ...prev, telegram_enabled: e.target.checked }))}
                    className="checkbox"
                  />
                  <label htmlFor="telegram-enabled" className="text-gray-300">
                    Enable Telegram notifications
                  </label>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Chat ID
                  </label>
                  <input
                    type="text"
                    value={notificationSettings.telegram_chat_id}
                    onChange={(e) => setNotificationSettings(prev => ({ ...prev, telegram_chat_id: e.target.value }))}
                    className="input-field"
                    placeholder="@your_chat_id"
                    disabled={!notificationSettings.telegram_enabled}
                  />
                </div>
              </div>
            </div>
            
            <div>
              <h3 className="text-lg font-medium text-white mb-3">Alert Levels</h3>
              <div className="flex space-x-4">
                {['critical', 'warning', 'info'].map(level => (
                  <div key={level} className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id={`alert-${level}`}
                      checked={notificationSettings.alert_levels.includes(level)}
                      onChange={(e) => {
                        const newLevels = e.target.checked
                          ? [...notificationSettings.alert_levels, level]
                          : notificationSettings.alert_levels.filter(l => l !== level)
                        setNotificationSettings(prev => ({ ...prev, alert_levels: newLevels }))
                      }}
                      className="checkbox"
                    />
                    <label htmlFor={`alert-${level}`} className="text-gray-300 capitalize">
                      {level}
                    </label>
                  </div>
                ))}
              </div>
            </div>
            
            <Button variant="neon" onClick={saveNotificationSettings}>
              <Save className="h-4 w-4 mr-2" />
              Save Notification Settings
            </Button>
          </CardContent>
        </Card>
      )}

      {activeTab === 'api' && (
        <Card>
          <CardHeader>
            <CardTitle>API Key Management</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="p-4 glassmorphism-card bg-blue-500/10 border border-blue-500/30 rounded-lg">
              <h3 className="text-lg font-medium text-white mb-3">Primary API Key</h3>
              
              <div className="flex items-center space-x-3">
                <div className="flex-1">
                  <input
                    type={showApiKey ? 'text' : 'password'}
                    value={apiKey}
                    readOnly
                    className="input-field font-mono"
                  />
                </div>
                
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowApiKey(!showApiKey)}
                >
                  {showApiKey ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </Button>
                
                <Button variant="outline" size="sm" onClick={copyApiKey}>
                  <Copy className="h-4 w-4" />
                </Button>
                
                <Button variant="destructive" size="sm" onClick={generateApiKey}>
                  Regenerate
                </Button>
              </div>
              
              <p className="text-sm text-gray-400 mt-2">
                Use this key to authenticate API requests. Keep it secure and never share it publicly.
              </p>
            </div>
            
            <div className="p-4 glassmorphism-card bg-yellow-500/10 border border-yellow-500/30 rounded-lg">
              <div className="flex items-start space-x-3">
                <Key className="h-5 w-5 text-yellow-400 mt-0.5" />
                <div>
                  <h4 className="font-medium text-white mb-1">API Usage Guidelines</h4>
                  <ul className="text-sm text-gray-300 space-y-1">
                    <li>• Include the API key in the Authorization header: Bearer {apiKey.substring(0, 20)}...</li>
                    <li>• Rate limit: 1000 requests per hour</li>
                    <li>• All API endpoints are documented in the API section</li>
                    <li>• Regenerate the key if you suspect it has been compromised</li>
                  </ul>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {activeTab === 'backup' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Backup Configuration</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-3">
                <input
                  type="checkbox"
                  id="backup-enabled"
                  checked={systemSettings.backup_enabled}
                  onChange={(e) => setSystemSettings(prev => ({ ...prev, backup_enabled: e.target.checked }))}
                  className="checkbox"
                />
                <label htmlFor="backup-enabled" className="text-gray-300">
                  Enable automatic backups
                </label>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Backup Schedule (Cron)
                </label>
                <input
                  type="text"
                  value={systemSettings.backup_schedule}
                  onChange={(e) => setSystemSettings(prev => ({ ...prev, backup_schedule: e.target.value }))}
                  className="input-field font-mono"
                  placeholder="0 2 * * *"
                  disabled={!systemSettings.backup_enabled}
                />
                <p className="text-xs text-gray-400 mt-1">Daily at 2:00 AM</p>
              </div>
              
              <div className="pt-4">
                <Button variant="neon" onClick={() => setShowBackupModal(true)}>
                  <Upload className="h-4 w-4 mr-2" />
                  Create Backup Now
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Recent Backups</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {[
                  { date: '2024-01-15 02:00', size: '2.3 GB', status: 'Success' },
                  { date: '2024-01-14 02:00', size: '2.1 GB', status: 'Success' },
                  { date: '2024-01-13 02:00', size: '2.0 GB', status: 'Success' }
                ].map((backup, index) => (
                  <div key={index} className="flex items-center justify-between p-3 glassmorphism-card bg-gray-500/10">
                    <div>
                      <div className="font-medium text-white">{backup.date}</div>
                      <div className="text-sm text-gray-400">{backup.size}</div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className="status-active">{backup.status}</span>
                      <Button variant="outline" size="sm">
                        <Download className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {activeTab === 'docs' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {documentationLinks.map((doc, index) => (
            <motion.div
              key={index}
              whileHover={{ scale: 1.02 }}
              className="cursor-pointer"
            >
              <Card className="h-full transition-all duration-200 hover:border-enterprise-neon/50">
                <CardContent className="p-6">
                  <div className="flex items-start space-x-4">
                    <div className="p-3 rounded-lg bg-enterprise-neon/20">
                      <doc.icon className="h-6 w-6 text-enterprise-neon" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-medium text-white mb-2">{doc.title}</h3>
                      <p className="text-sm text-gray-400 mb-4">{doc.description}</p>
                      <div className="flex items-center text-enterprise-neon text-sm">
                        <span>Read more</span>
                        <ExternalLink className="h-4 w-4 ml-1" />
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      )}

      {/* Backup Modal */}
      <Modal
        isOpen={showBackupModal}
        onClose={() => setShowBackupModal(false)}
        title="Create System Backup"
      >
        <div className="space-y-4">
          <p className="text-gray-300">
            This will create a complete backup of your system configuration, including:
          </p>
          
          <ul className="text-sm text-gray-400 space-y-1 ml-4">
            <li>• Network and VPN configurations</li>
            <li>• User accounts and permissions</li>
            <li>• System settings and preferences</li>
            <li>• Automation rules and schedules</li>
            <li>• Database content</li>
          </ul>
          
          <div className="p-3 glassmorphism-card bg-yellow-500/10 border border-yellow-500/30 rounded-lg">
            <p className="text-sm text-yellow-300">
              <strong>Note:</strong> Large backups may take several minutes to complete.
            </p>
          </div>
          
          <div className="flex justify-end space-x-3">
            <Button variant="outline" onClick={() => setShowBackupModal(false)}>
              Cancel
            </Button>
            <Button variant="neon" onClick={createBackup}>
              <Upload className="h-4 w-4 mr-2" />
              Create Backup
            </Button>
          </div>
        </div>
      </Modal>

      {/* Quick Setup Wizard Modal */}
      <QuickSetupWizard
        isOpen={showQuickSetupWizard}
        onClose={() => setShowQuickSetupWizard(false)}
      />
    </div>
  )
}

export default Settings