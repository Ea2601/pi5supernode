import React, { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import {
  Globe,
  Plus,
  Edit,
  Trash2,
  RefreshCw,
  Network,
  Activity,
  AlertTriangle,
  CheckCircle,
  TrendingUp,
  TrendingDown,
  Settings,
  Power,
  Wifi,
  Cable,
  Router,
  BarChart3
} from 'lucide-react'
import { useNetworkStore, useUIStore } from '@/lib/store'
import { NetworkService } from '@/lib/services'
import { Button } from '@/components/ui/button'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card'
import TableCard from '@/components/ui/table-card'
import MetricCard from '@/components/ui/metric-card'
import Modal from '@/components/ui/modal'
import WANManagement from '@/components/ui/wan-management'
import { cn } from '@/lib/utils'

interface WANConnection {
  id: string
  name: string
  connection_type: 'ethernet' | 'pppoe' | 'dhcp' | 'static' | 'lte' | 'starlink'
  interface_name: string
  status: 'connected' | 'disconnected' | 'connecting' | 'error'
  is_primary: boolean
  priority: number
  enabled: boolean
  
  // Connection details
  ip_address?: string
  gateway?: string
  dns_servers?: string[]
  bandwidth_up?: number
  bandwidth_down?: number
  
  // Statistics
  uptime: number
  bytes_sent: number
  bytes_received: number
  packets_sent: number
  packets_received: number
  latency: number
  
  // Health monitoring
  health_score: number
  last_health_check: string
  connection_quality: 'excellent' | 'good' | 'fair' | 'poor'
  
  created_at: string
  updated_at: string
}

interface LoadBalancing {
  id: string
  name: string
  algorithm: 'round_robin' | 'weighted' | 'least_connections' | 'failover'
  enabled: boolean
  connections: {
    wan_id: string
    weight: number
    enabled: boolean
  }[]
  health_check_enabled: boolean
  health_check_interval: number
  failover_threshold: number
}

interface WANFormData {
  name: string
  connection_type: string
  interface_name: string
  enabled: boolean
  is_primary: boolean
  priority: number
  
  // Static IP configuration
  ip_address: string
  netmask: string
  gateway: string
  dns_servers: string
  
  // PPPoE configuration
  username: string
  password: string
  
  // LTE configuration
  apn: string
  pin: string
}

const WANSettings: React.FC = () => {
  const { addNotification } = useUIStore()
  const [loading, setLoading] = useState(true)
  const [wanConnections, setWanConnections] = useState<WANConnection[]>([])
  const [loadBalancing, setLoadBalancing] = useState<LoadBalancing[]>([])
  const [showModal, setShowModal] = useState(false)
  const [showLBModal, setShowLBModal] = useState(false)
  const [editingConnection, setEditingConnection] = useState<WANConnection | null>(null)
  const [activeTab, setActiveTab] = useState('connections')
  
  const [formData, setFormData] = useState<WANFormData>({
    name: '',
    connection_type: 'dhcp',
    interface_name: 'eth0',
    enabled: true,
    is_primary: false,
    priority: 100,
    ip_address: '',
    netmask: '255.255.255.0',
    gateway: '',
    dns_servers: '8.8.8.8, 1.1.1.1',
    username: '',
    password: '',
    apn: '',
    pin: ''
  })

  useEffect(() => {
    loadWANData()
  }, [])

  const loadWANData = async () => {
    try {
      setLoading(true)
      
      const [connectionsData, lbData] = await Promise.all([
        NetworkService.getWANConnections(),
        NetworkService.getLoadBalancingConfigs()
      ])
      
      // Transform service WANConnection[] to component WANConnection[]
      const transformedConnections = connectionsData.map((conn: any, index: number) => ({
        ...conn,
        connection_type: conn.type || 'dhcp', // Map type to connection_type
        interface_name: conn.config?.interface_name || `eth${index}`,
        is_primary: conn.config?.is_primary || false,
        ip_address: conn.config?.ip_address,
        gateway: conn.config?.gateway,
        dns_servers: conn.config?.dns_servers || [],
        bandwidth_up: conn.config?.bandwidth_up || 0,
        bandwidth_down: conn.config?.bandwidth_down || 0,
        uptime: 0,
        bytes_sent: 0,
        bytes_received: 0,
        packets_sent: 0,
        packets_received: 0,
        latency: 0,
        health_score: 85,
        last_health_check: new Date().toISOString(),
        connection_quality: 'good' as const
      }))
      
      setWanConnections(transformedConnections)
      setLoadBalancing(lbData)
      
    } catch (error) {
      console.error('Error loading WAN data:', error)
      addNotification({ type: 'error', message: 'Failed to load WAN settings' })
    } finally {
      setLoading(false)
    }
  }

  const resetForm = () => {
    setFormData({
      name: '',
      connection_type: 'dhcp',
      interface_name: 'eth0',
      enabled: true,
      is_primary: false,
      priority: 100,
      ip_address: '',
      netmask: '255.255.255.0',
      gateway: '',
      dns_servers: '8.8.8.8, 1.1.1.1',
      username: '',
      password: '',
      apn: '',
      pin: ''
    })
  }

  const editConnection = (connection: WANConnection) => {
    setEditingConnection(connection)
    setFormData({
      name: connection.name,
      connection_type: connection.connection_type,
      interface_name: connection.interface_name,
      enabled: connection.enabled,
      is_primary: connection.is_primary,
      priority: connection.priority,
      ip_address: connection.ip_address || '',
      netmask: '255.255.255.0',
      gateway: connection.gateway || '',
      dns_servers: connection.dns_servers?.join(', ') || '8.8.8.8, 1.1.1.1',
      username: '',
      password: '',
      apn: '',
      pin: ''
    })
    setShowModal(true)
  }

  const handleSave = async () => {
    try {
      const connectionData = {
        name: formData.name,
        type: formData.connection_type, // Map connection_type to type
        enabled: formData.enabled,
        status: 'disconnected' as const, // Set default status
        config: {
          interface_name: formData.interface_name,
          is_primary: formData.is_primary,
          ip_address: formData.ip_address,
          netmask: formData.netmask,
          gateway: formData.gateway,
          dns_servers: formData.dns_servers.split(',').map(s => s.trim()),
          username: formData.username,
          password: formData.password,
          apn: formData.apn,
          pin: formData.pin
        },
        priority: formData.priority
      }
      
      if (editingConnection) {
        await NetworkService.updateWANConnection(editingConnection.id, connectionData)
        addNotification({ type: 'success', message: 'WAN connection updated successfully' })
      } else {
        await NetworkService.createWANConnection(connectionData)
        addNotification({ type: 'success', message: 'WAN connection created successfully' })
      }
      
      setShowModal(false)
      setEditingConnection(null)
      resetForm()
      await loadWANData()
      
    } catch (error) {
      addNotification({ type: 'error', message: `Failed to ${editingConnection ? 'update' : 'create'} WAN connection` })
    }
  }

  const toggleConnection = async (connection: WANConnection) => {
    try {
      await NetworkService.toggleWANConnection(connection.id, !connection.enabled)
      addNotification({ 
        type: 'success', 
        message: `WAN connection ${connection.enabled ? 'disabled' : 'enabled'}` 
      })
      await loadWANData()
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to toggle WAN connection' })
    }
  }

  const deleteConnection = async (connection: WANConnection) => {
    if (!confirm(`Are you sure you want to delete the WAN connection "${connection.name}"?`)) return
    
    try {
      await NetworkService.deleteWANConnection(connection.id)
      addNotification({ type: 'success', message: 'WAN connection deleted successfully' })
      await loadWANData()
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to delete WAN connection' })
    }
  }

  const testConnection = async (connection: WANConnection) => {
    try {
      addNotification({ type: 'info', message: `Testing connection ${connection.name}...` })
      
      const result = await NetworkService.testWANConnection(connection.id)
      
      if (result.success) {
        addNotification({ 
          type: 'success', 
          message: `Connection test successful: ${result.latency}ms latency` 
        })
      } else {
        addNotification({ 
          type: 'error', 
          message: `Connection test failed: ${result.error}` 
        })
      }
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to test connection' })
    }
  }

  const getConnectionIcon = (type: string) => {
    switch (type) {
      case 'ethernet':
        return <Cable className="h-4 w-4" />
      case 'lte':
        return <Wifi className="h-4 w-4" />
      case 'starlink':
        return <Globe className="h-4 w-4" />
      default:
        return <Network className="h-4 w-4" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'connected':
        return 'text-green-400'
      case 'connecting':
        return 'text-yellow-400'
      case 'disconnected':
        return 'text-gray-400'
      case 'error':
        return 'text-red-400'
      default:
        return 'text-gray-400'
    }
  }

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 Bytes'
    const k = 1024
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
  }

  const formatUptime = (seconds: number) => {
    const days = Math.floor(seconds / 86400)
    const hours = Math.floor((seconds % 86400) / 3600)
    const minutes = Math.floor((seconds % 3600) / 60)
    
    if (days > 0) return `${days}d ${hours}h`
    if (hours > 0) return `${hours}h ${minutes}m`
    return `${minutes}m`
  }

  const activeConnections = wanConnections.filter(conn => conn.status === 'connected').length
  const primaryConnection = wanConnections.find(conn => conn.is_primary)
  const totalBandwidth = wanConnections
    .filter(conn => conn.status === 'connected')
    .reduce((sum, conn) => sum + (conn.bandwidth_down || 0), 0)

  const tabs = [
    { id: 'connections', label: 'WAN Connections', icon: Globe },
    { id: 'load-balancing', label: 'Load Balancing', icon: BarChart3 },
    { id: 'failover', label: 'Failover', icon: AlertTriangle },
    { id: 'monitoring', label: 'Health Monitoring', icon: Activity }
  ]

  const connectionColumns = [
    {
      key: 'name' as keyof WANConnection,
      label: 'Connection',
      sortable: true,
      render: (value: any, item: WANConnection) => (
        <div className="flex items-center space-x-3">
          <div className={`p-2 rounded-lg ${item.status === 'connected' ? 'bg-green-500/20' : 'bg-gray-500/20'}`}>
            {getConnectionIcon(item.connection_type)}
          </div>
          <div>
            <div className="font-medium text-white flex items-center space-x-2">
              <span>{value}</span>
              {item.is_primary && (
                <span className="px-2 py-1 bg-yellow-500/20 text-yellow-300 rounded text-xs">
                  Primary
                </span>
              )}
            </div>
            <div className="text-sm text-gray-400">
              {item.connection_type.toUpperCase()} • {item.interface_name}
            </div>
          </div>
        </div>
      )
    },
    {
      key: 'status' as keyof WANConnection,
      label: 'Status',
      sortable: true,
      render: (value: any, item: WANConnection) => (
        <div className="space-y-1">
          <div className={`flex items-center space-x-2 ${getStatusColor(value)}`}>
            <Activity className="h-4 w-4" />
            <span className="capitalize font-medium">{value}</span>
          </div>
          <div className="text-xs text-gray-500">
            Uptime: {formatUptime(item.uptime)}
          </div>
        </div>
      )
    },
    {
      key: 'ip_address' as keyof WANConnection,
      label: 'Network Info',
      render: (value: any, item: WANConnection) => (
        <div className="font-mono text-sm space-y-1">
          <div className="text-enterprise-neon">{value || 'Dynamic'}</div>
          <div className="text-gray-400">GW: {item.gateway || 'Auto'}</div>
          <div className="text-gray-500 text-xs">
            Ping: {item.latency}ms
          </div>
        </div>
      )
    },
    {
      key: 'bandwidth_down' as keyof WANConnection,
      label: 'Bandwidth',
      sortable: true,
      render: (value: any, item: WANConnection) => (
        <div className="text-sm space-y-1">
          <div className="flex items-center space-x-2">
            <TrendingDown className="h-3 w-3 text-green-400" />
            <span className="text-green-400">{value || 0} Mbps</span>
          </div>
          <div className="flex items-center space-x-2">
            <TrendingUp className="h-3 w-3 text-blue-400" />
            <span className="text-blue-400">{item.bandwidth_up || 0} Mbps</span>
          </div>
        </div>
      )
    },
    {
      key: 'health_score' as keyof WANConnection,
      label: 'Health',
      sortable: true,
      render: (value: any, item: WANConnection) => {
        const colors = {
          excellent: 'text-green-400',
          good: 'text-blue-400',
          fair: 'text-yellow-400',
          poor: 'text-red-400'
        }
        
        return (
          <div className="space-y-1">
            <div className="flex items-center space-x-2">
              <div className="w-12 bg-gray-700 rounded-full h-2">
                <div 
                  className={`h-2 rounded-full transition-all duration-500 ${value >= 80 ? 'bg-green-400' : value >= 60 ? 'bg-yellow-400' : 'bg-red-400'}`}
                  style={{ width: `${value}%` }}
                />
              </div>
              <span className="text-sm font-medium">{value}%</span>
            </div>
            <div className={`text-xs ${colors[item.connection_quality]}`}>
              {item.connection_quality.charAt(0).toUpperCase() + item.connection_quality.slice(1)}
            </div>
          </div>
        )
      }
    },
    {
      key: 'bytes_received' as keyof WANConnection,
      label: 'Traffic',
      render: (value: any, item: WANConnection) => (
        <div className="text-sm space-y-1">
          <div className="flex items-center space-x-2">
            <TrendingDown className="h-3 w-3 text-gray-400" />
            <span className="text-gray-300">{formatBytes(value)}</span>
          </div>
          <div className="flex items-center space-x-2">
            <TrendingUp className="h-3 w-3 text-gray-400" />
            <span className="text-gray-300">{formatBytes(item.bytes_sent)}</span>
          </div>
        </div>
      )
    },
    {
      key: 'priority' as keyof WANConnection,
      label: 'Priority',
      sortable: true,
      render: (value: any) => (
        <span className="font-mono text-sm text-enterprise-neon">{value}</span>
      )
    },
    {
      key: 'id' as keyof WANConnection,
      label: 'Actions',
      render: (value: any, item: WANConnection) => (
        <div className="flex items-center space-x-2">
          <Button
            size="sm"
            variant="ghost"
            onClick={() => testConnection(item)}
            title="Test connection"
          >
            <Activity className="h-4 w-4" />
          </Button>
          
          <Button
            size="sm"
            variant="ghost"
            onClick={() => editConnection(item)}
          >
            <Edit className="h-4 w-4" />
          </Button>
          
          <Button
            size="sm"
            variant="ghost"
            onClick={() => toggleConnection(item)}
          >
            <Power className="h-4 w-4" />
          </Button>
          
          <Button
            size="sm"
            variant="ghost"
            onClick={() => deleteConnection(item)}
            className="text-red-400 hover:text-red-300"
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      )
    }
  ]

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Multi-WAN Configuration</h1>
          <p className="text-gray-400">Configure multiple internet connections with load balancing and failover</p>
        </div>
        
        <div className="flex items-center space-x-3">
          <Button
            variant="outline"
            onClick={loadWANData}
            loading={loading}
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          
          <Button 
            variant="neon"
            onClick={() => {
              resetForm()
              setShowModal(true)
            }}
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Connection
          </Button>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard
          title="Active Connections"
          value={activeConnections.toString()}
          subtitle={`${wanConnections.length} total connections`}
          icon={Globe}
          color="success"
          loading={loading}
        />
        
        <MetricCard
          title="Primary Connection"
          value={primaryConnection?.name || 'None'}
          subtitle={primaryConnection?.status || 'No primary set'}
          icon={Router}
          color={primaryConnection?.status === 'connected' ? 'success' : 'warning'}
          loading={loading}
        />
        
        <MetricCard
          title="Total Bandwidth"
          value={`${totalBandwidth} Mbps`}
          subtitle="Combined download"
          icon={TrendingDown}
          color="info"
          loading={loading}
        />
        
        <MetricCard
          title="Load Balancing"
          value={loadBalancing.filter(lb => lb.enabled).length > 0 ? 'Active' : 'Inactive'}
          subtitle="Multi-WAN distribution"
          icon={BarChart3}
          color={loadBalancing.filter(lb => lb.enabled).length > 0 ? 'success' : 'warning'}
          loading={loading}
        />
      </div>

      {/* Tab Navigation */}
      <div className="flex space-x-1 glassmorphism-card bg-gray-800/30 p-1 rounded-lg w-fit">
        {tabs.map((tab) => {
          const Icon = tab.icon
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={cn(
                'flex items-center space-x-2 px-4 py-2 rounded-md transition-all duration-200',
                activeTab === tab.id
                  ? 'bg-enterprise-neon/20 text-enterprise-neon border border-enterprise-neon/30'
                  : 'text-gray-400 hover:text-gray-200 hover:bg-gray-700/30'
              )}
            >
              <Icon className="h-4 w-4" />
              <span className="text-sm font-medium">{tab.label}</span>
            </button>
          )
        })}
      </div>

      {/* Tab Content */}
      {activeTab === 'connections' && (
        <TableCard
          title="WAN Connections"
          description={`${wanConnections.length} configured connections (${activeConnections} active)`}
          data={wanConnections}
          columns={connectionColumns}
          loading={loading}
          emptyMessage="No WAN connections configured. Add your first connection to get started."
        />
      )}

      {activeTab === 'load-balancing' && (
        <div className="space-y-6">
          <WANManagement />
        </div>
      )}

      {activeTab === 'failover' && (
        <div className="text-center py-8 text-gray-400">
          <AlertTriangle className="h-16 w-16 mx-auto mb-4 opacity-50" />
          <h3 className="text-xl font-semibold mb-2">Failover Configuration</h3>
          <p>Configure automatic failover between WAN connections</p>
        </div>
      )}

      {activeTab === 'monitoring' && (
        <div className="text-center py-8 text-gray-400">
          <Activity className="h-16 w-16 mx-auto mb-4 opacity-50" />
          <h3 className="text-xl font-semibold mb-2">Health Monitoring</h3>
          <p>Real-time monitoring and health checks for all WAN connections</p>
        </div>
      )}

      {/* Connection Creation/Edit Modal */}
      <Modal
        isOpen={showModal}
        onClose={() => {
          setShowModal(false)
          setEditingConnection(null)
          resetForm()
        }}
        title={editingConnection ? "Edit WAN Connection" : "Add New WAN Connection"}
        size="lg"
      >
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Connection Name
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                className="enterprise-input w-full"
                placeholder="e.g., Primary ISP"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Connection Type
              </label>
              <select
                value={formData.connection_type}
                onChange={(e) => setFormData(prev => ({ ...prev, connection_type: e.target.value }))}
                className="enterprise-input w-full"
              >
                <option value="dhcp">DHCP (Automatic)</option>
                <option value="static">Static IP</option>
                <option value="pppoe">PPPoE</option>
                <option value="lte">LTE/Cellular</option>
                <option value="starlink">Starlink</option>
                <option value="ethernet">Ethernet</option>
              </select>
            </div>
          </div>
          
          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Interface
              </label>
              <input
                type="text"
                value={formData.interface_name}
                onChange={(e) => setFormData(prev => ({ ...prev, interface_name: e.target.value }))}
                className="enterprise-input w-full"
                placeholder="eth0"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Priority
              </label>
              <input
                type="number"
                value={formData.priority}
                onChange={(e) => setFormData(prev => ({ ...prev, priority: parseInt(e.target.value) }))}
                className="enterprise-input w-full"
                min="1"
                max="1000"
              />
            </div>
            
            <div className="flex items-center justify-center pt-6">
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={formData.is_primary}
                  onChange={(e) => setFormData(prev => ({ ...prev, is_primary: e.target.checked }))}
                  className="enterprise-checkbox"
                />
                <span className="text-sm text-gray-300">Primary connection</span>
              </label>
            </div>
          </div>
          
          {/* Static IP Configuration */}
          {formData.connection_type === 'static' && (
            <div className="space-y-4 p-4 bg-gray-800/30 rounded-lg">
              <h4 className="text-sm font-medium text-gray-300">Static IP Configuration</h4>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-1">
                    IP Address
                  </label>
                  <input
                    type="text"
                    value={formData.ip_address}
                    onChange={(e) => setFormData(prev => ({ ...prev, ip_address: e.target.value }))}
                    className="enterprise-input w-full text-sm"
                    placeholder="192.168.1.100"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-1">
                    Netmask
                  </label>
                  <input
                    type="text"
                    value={formData.netmask}
                    onChange={(e) => setFormData(prev => ({ ...prev, netmask: e.target.value }))}
                    className="enterprise-input w-full text-sm"
                    placeholder="255.255.255.0"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-1">
                    Gateway
                  </label>
                  <input
                    type="text"
                    value={formData.gateway}
                    onChange={(e) => setFormData(prev => ({ ...prev, gateway: e.target.value }))}
                    className="enterprise-input w-full text-sm"
                    placeholder="192.168.1.1"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-1">
                    DNS Servers
                  </label>
                  <input
                    type="text"
                    value={formData.dns_servers}
                    onChange={(e) => setFormData(prev => ({ ...prev, dns_servers: e.target.value }))}
                    className="enterprise-input w-full text-sm"
                    placeholder="8.8.8.8, 1.1.1.1"
                  />
                </div>
              </div>
            </div>
          )}
          
          {/* PPPoE Configuration */}
          {formData.connection_type === 'pppoe' && (
            <div className="space-y-4 p-4 bg-gray-800/30 rounded-lg">
              <h4 className="text-sm font-medium text-gray-300">PPPoE Configuration</h4>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-1">
                    Username
                  </label>
                  <input
                    type="text"
                    value={formData.username}
                    onChange={(e) => setFormData(prev => ({ ...prev, username: e.target.value }))}
                    className="enterprise-input w-full text-sm"
                    placeholder="ISP username"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-1">
                    Password
                  </label>
                  <input
                    type="password"
                    value={formData.password}
                    onChange={(e) => setFormData(prev => ({ ...prev, password: e.target.value }))}
                    className="enterprise-input w-full text-sm"
                    placeholder="ISP password"
                  />
                </div>
              </div>
            </div>
          )}
          
          {/* LTE Configuration */}
          {formData.connection_type === 'lte' && (
            <div className="space-y-4 p-4 bg-gray-800/30 rounded-lg">
              <h4 className="text-sm font-medium text-gray-300">LTE/Cellular Configuration</h4>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-1">
                    APN
                  </label>
                  <input
                    type="text"
                    value={formData.apn}
                    onChange={(e) => setFormData(prev => ({ ...prev, apn: e.target.value }))}
                    className="enterprise-input w-full text-sm"
                    placeholder="internet.carrier.com"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-1">
                    PIN (Optional)
                  </label>
                  <input
                    type="text"
                    value={formData.pin}
                    onChange={(e) => setFormData(prev => ({ ...prev, pin: e.target.value }))}
                    className="enterprise-input w-full text-sm"
                    placeholder="SIM PIN"
                  />
                </div>
              </div>
            </div>
          )}
          
          <div className="flex items-center justify-between pt-4 border-t border-gray-700">
            <label className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={formData.enabled}
                onChange={(e) => setFormData(prev => ({ ...prev, enabled: e.target.checked }))}
                className="enterprise-checkbox"
              />
              <span className="text-sm text-gray-300">Enable this connection</span>
            </label>
            
            <div className="flex space-x-3">
              <Button
                variant="outline"
                onClick={() => {
                  setShowModal(false)
                  setEditingConnection(null)
                  resetForm()
                }}
              >
                Cancel
              </Button>
              
              <Button
                variant="neon"
                onClick={handleSave}
              >
                {editingConnection ? 'Update Connection' : 'Add Connection'}
              </Button>
            </div>
          </div>
        </div>
      </Modal>
    </div>
  )
}

export default WANSettings