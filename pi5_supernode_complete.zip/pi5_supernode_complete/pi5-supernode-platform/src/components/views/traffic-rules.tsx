import React, { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import {
  Shield,
  Plus,
  Edit,
  Trash2,
  Power,
  RefreshCw,
  Zap,
  Users,
  Settings,
  AlertTriangle,
  CheckCircle,
  Clock,
  Filter,
  Search
} from 'lucide-react'
import { useNetworkStore, useUIStore } from '@/lib/store'
import { NetworkService, type TrafficRule } from '@/lib/services'
import { Button } from '@/components/ui/button'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card'
import TableCard from '@/components/ui/table-card'
import MetricCard from '@/components/ui/metric-card'
import Modal from '@/components/ui/modal'
import AdvancedTrafficRules from '@/components/ui/advanced-traffic-rules'
import { TrafficRulesManager } from '@/components/enhancements/TrafficRulesManager'
import { cn } from '@/lib/utils'

interface TrafficRuleFormData {
  name: string
  description: string
  priority: number
  enabled: boolean
  conditions: {
    source_ip?: string
    destination_ip?: string
    protocol?: string
    port?: string
    time_range?: string
    user_group?: string
  }
  actions: {
    allow?: boolean
    block?: boolean
    bandwidth_limit?: number
    redirect_to?: string
    log?: boolean
  }
}

interface ClientGroup {
  id: string
  name: string
  description?: string
  members: string[]
  rules_count: number
  created_at: string
}

interface TrafficType {
  id: string
  name: string
  protocol: string
  port_range: string
  category: string
  enabled: boolean
}

const TrafficRules: React.FC = () => {
  const { trafficRules, setTrafficRules } = useNetworkStore()
  const { addNotification } = useUIStore()
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState('rules')
  const [showRuleModal, setShowRuleModal] = useState(false)
  const [showGroupModal, setShowGroupModal] = useState(false)
  const [editingRule, setEditingRule] = useState<TrafficRule | null>(null)
  const [clientGroups, setClientGroups] = useState<ClientGroup[]>([])
  const [trafficTypes, setTrafficTypes] = useState<TrafficType[]>([])
  const [searchQuery, setSearchQuery] = useState('')
  const [filterStatus, setFilterStatus] = useState<'all' | 'enabled' | 'disabled'>('all')
  
  const [ruleForm, setRuleForm] = useState<TrafficRuleFormData>({
    name: '',
    description: '',
    priority: 100,
    enabled: true,
    conditions: {},
    actions: {}
  })
  
  const [groupForm, setGroupForm] = useState({
    name: '',
    description: '',
    members: []
  })

  useEffect(() => {
    loadTrafficData()
  }, [])

  const loadTrafficData = async () => {
    try {
      setLoading(true)
      
      // Load comprehensive traffic management data
      const [rulesData, groupsData, typesData] = await Promise.all([
        NetworkService.getTrafficRules(),
        NetworkService.getClientGroups(),
        NetworkService.getTrafficTypes()
      ])
      
      setTrafficRules(rulesData)
      setClientGroups(groupsData)
      setTrafficTypes(typesData)
      
    } catch (error) {
      console.error('Error loading traffic data:', error)
      addNotification({ type: 'error', message: 'Failed to load traffic management data' })
    } finally {
      setLoading(false)
    }
  }

  const handleCreateRule = async () => {
    try {
      if (editingRule) {
        await NetworkService.updateTrafficRule(editingRule.id, ruleForm)
        addNotification({ type: 'success', message: 'Traffic rule updated successfully' })
      } else {
        await NetworkService.createTrafficRule(ruleForm)
        addNotification({ type: 'success', message: 'Traffic rule created successfully' })
      }
      
      setShowRuleModal(false)
      setEditingRule(null)
      resetRuleForm()
      
      await loadTrafficData()
    } catch (error) {
      addNotification({ type: 'error', message: `Failed to ${editingRule ? 'update' : 'create'} traffic rule` })
    }
  }

  const handleCreateGroup = async () => {
    try {
      await NetworkService.createClientGroup(groupForm)
      
      setShowGroupModal(false)
      setGroupForm({ name: '', description: '', members: [] })
      
      await loadTrafficData()
      addNotification({ type: 'success', message: 'Client group created successfully' })
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to create client group' })
    }
  }

  const resetRuleForm = () => {
    setRuleForm({
      name: '',
      description: '',
      priority: 100,
      enabled: true,
      conditions: {},
      actions: {}
    })
  }

  const editRule = (rule: TrafficRule) => {
    setEditingRule(rule)
    setRuleForm({
      name: rule.name,
      description: rule.description || '',
      priority: rule.priority,
      enabled: rule.enabled,
      conditions: rule.conditions || {},
      actions: rule.actions || {}
    })
    setShowRuleModal(true)
  }

  const toggleRuleStatus = async (rule: TrafficRule) => {
    try {
      await NetworkService.toggleTrafficRule(rule.id, !rule.enabled)
      
      await loadTrafficData()
      addNotification({ 
        type: 'success', 
        message: `Rule ${rule.enabled ? 'disabled' : 'enabled'}` 
      })
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to update rule status' })
    }
  }

  const deleteRule = async (rule: TrafficRule) => {
    if (!confirm(`Are you sure you want to delete the rule "${rule.name}"?`)) return
    
    try {
      await NetworkService.deleteTrafficRule(rule.id)
      
      await loadTrafficData()
      addNotification({ type: 'success', message: 'Traffic rule deleted' })
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to delete rule' })
    }
  }

  const handleApplyTrafficChanges = async () => {
    try {
      addNotification({ type: 'info', message: 'Applying traffic rule changes...' })
      
      const changes = trafficRules.map(rule => ({
        type: 'update',
        ruleId: rule.id,
        ruleData: rule
      }))
      
      const result = await NetworkService.applyTrafficChanges(changes)
      
      addNotification({ 
        type: 'success', 
        message: `Applied ${result.data.successful} traffic rule changes` 
      })
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to apply traffic changes' })
    }
  }

  const handleValidateRules = async () => {
    try {
      addNotification({ type: 'info', message: 'Validating traffic rules...' })
      
      const result = await NetworkService.validateTrafficRules(trafficRules)
      
      if (result.data.overallValid) {
        addNotification({ type: 'success', message: 'All traffic rules are valid' })
      } else {
        addNotification({ 
          type: 'warning', 
          message: `Found ${result.data.errors.length} errors and ${result.data.warnings.length} warnings` 
        })
      }
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to validate traffic rules' })
    }
  }

  // Filter rules based on search and status
  const filteredRules = trafficRules.filter(rule => {
    const matchesSearch = !searchQuery || 
      rule.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rule.description?.toLowerCase().includes(searchQuery.toLowerCase())
    
    const matchesStatus = filterStatus === 'all' ||
      (filterStatus === 'enabled' && rule.enabled) ||
      (filterStatus === 'disabled' && !rule.enabled)
    
    return matchesSearch && matchesStatus
  })

  const tabs = [
    { id: 'rules', label: 'Traffic Rules', icon: Shield },
    { id: 'groups', label: 'Client Groups', icon: Users },
    { id: 'types', label: 'Traffic Types', icon: Zap },
    { id: 'advanced', label: 'Advanced Rules', icon: Settings }
  ]

  const ruleColumns = [
    {
      key: 'name' as keyof TrafficRule,
      label: 'Rule Name',
      sortable: true,
      render: (value: any, item: TrafficRule) => (
        <div>
          <div className="font-medium text-white flex items-center space-x-2">
            {item.enabled ? 
              <CheckCircle className="h-4 w-4 text-green-400" /> : 
              <AlertTriangle className="h-4 w-4 text-red-400" />
            }
            <span>{value}</span>
          </div>
          <div className="text-sm text-gray-400">{item.description}</div>
        </div>
      )
    },
    {
      key: 'priority' as keyof TrafficRule,
      label: 'Priority',
      sortable: true,
      render: (value: any) => (
        <span className="font-mono text-sm text-enterprise-neon font-bold">{value}</span>
      )
    },
    {
      key: 'conditions' as keyof TrafficRule,
      label: 'Conditions',
      render: (value: any) => (
        <div className="text-sm text-gray-300 space-y-1">
          {Object.entries(value || {}).map(([key, val]) => (
            <div key={key} className="flex items-center space-x-2">
              <span className="text-gray-500 capitalize">{key.replace('_', ' ')}:</span>
              <span className="text-white">{String(val)}</span>
            </div>
          ))}
          {Object.keys(value || {}).length === 0 && (
            <span className="text-gray-500">No conditions</span>
          )}
        </div>
      )
    },
    {
      key: 'actions' as keyof TrafficRule,
      label: 'Actions',
      render: (value: any) => (
        <div className="text-sm text-gray-300 space-y-1">
          {Object.entries(value || {}).map(([key, val]) => {
            if (key === 'allow' && val) {
              return (
                <div key={key} className="flex items-center space-x-2">
                  <CheckCircle className="h-3 w-3 text-green-400" />
                  <span className="text-green-400">Allow</span>
                </div>
              )
            }
            if (key === 'block' && val) {
              return (
                <div key={key} className="flex items-center space-x-2">
                  <AlertTriangle className="h-3 w-3 text-red-400" />
                  <span className="text-red-400">Block</span>
                </div>
              )
            }
            if (key === 'bandwidth_limit' && val) {
              return (
                <div key={key} className="flex items-center space-x-2">
                  <Zap className="h-3 w-3 text-yellow-400" />
                  <span className="text-yellow-400">Limit: {String(val)} Mbps</span>
                </div>
              )
            }
            return null
          })}
          {Object.keys(value || {}).length === 0 && (
            <span className="text-gray-500">No actions</span>
          )}
        </div>
      )
    },
    {
      key: 'enabled' as keyof TrafficRule,
      label: 'Status',
      sortable: true,
      render: (value: any) => (
        <span className={value ? 'status-active' : 'status-inactive'}>
          {value ? 'Enabled' : 'Disabled'}
        </span>
      )
    },
    {
      key: 'id' as keyof TrafficRule,
      label: 'Actions',
      render: (value: any, item: TrafficRule) => (
        <div className="flex items-center space-x-2">
          <Button
            size="sm"
            variant="ghost"
            onClick={() => editRule(item)}
          >
            <Edit className="h-4 w-4" />
          </Button>
          
          <Button
            size="sm"
            variant="ghost"
            onClick={() => toggleRuleStatus(item)}
          >
            <Power className="h-4 w-4" />
          </Button>
          
          <Button
            size="sm"
            variant="ghost"
            onClick={() => deleteRule(item)}
            className="text-red-400 hover:text-red-300"
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      )
    }
  ]

  const groupColumns = [
    {
      key: 'name' as keyof ClientGroup,
      label: 'Group Name',
      sortable: true,
      render: (value: any, item: ClientGroup) => (
        <div>
          <div className="font-medium text-white">{value}</div>
          <div className="text-sm text-gray-400">{item.description}</div>
        </div>
      )
    },
    {
      key: 'members' as keyof ClientGroup,
      label: 'Members',
      render: (value: any) => (
        <div className="text-sm text-gray-300">
          <span className="font-mono">{Array.isArray(value) ? value.length : 0} devices</span>
        </div>
      )
    },
    {
      key: 'rules_count' as keyof ClientGroup,
      label: 'Rules Applied',
      render: (value: any) => (
        <span className="font-mono text-enterprise-neon">{value}</span>
      )
    },
    {
      key: 'created_at' as keyof ClientGroup,
      label: 'Created',
      render: (value: any) => (
        <span className="text-sm text-gray-400">
          {new Date(value).toLocaleDateString()}
        </span>
      )
    }
  ]

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Advanced Traffic Management</h1>
          <p className="text-gray-400">Comprehensive traffic rules and network policy management</p>
        </div>
        
        <div className="flex items-center space-x-3">
          <Button
            variant="outline"
            onClick={handleValidateRules}
          >
            <CheckCircle className="h-4 w-4 mr-2" />
            Validate Rules
          </Button>
          
          <Button
            variant="outline"
            onClick={handleApplyTrafficChanges}
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Apply Changes
          </Button>
          
          <Button 
            variant="neon"
            onClick={() => {
              resetRuleForm()
              setShowRuleModal(true)
            }}
          >
            <Plus className="h-4 w-4 mr-2" />
            New Rule
          </Button>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard
          title="Active Rules"
          value={trafficRules.filter(r => r.enabled).length.toString()}
          subtitle={`${trafficRules.length} total rules`}
          icon={Shield}
          color="success"
          loading={loading}
        />
        
        <MetricCard
          title="Client Groups"
          value={clientGroups.length.toString()}
          subtitle="Managed groups"
          icon={Users}
          color="info"
          loading={loading}
        />
        
        <MetricCard
          title="Traffic Types"
          value={trafficTypes.filter(t => t.enabled).length.toString()}
          subtitle={`${trafficTypes.length} defined types`}
          icon={Zap}
          color="warning"
          loading={loading}
        />
        
        <MetricCard
          title="Rule Validation"
          value="Healthy"
          subtitle="System status"
          icon={CheckCircle}
          color="success"
          loading={loading}
        />
      </div>

      {/* Tab Navigation */}
      <div className="flex space-x-1 glassmorphism-card bg-gray-800/30 p-1 rounded-lg w-fit">
        {tabs.map((tab) => {
          const Icon = tab.icon
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={cn(
                'flex items-center space-x-2 px-4 py-2 rounded-md transition-all duration-200',
                activeTab === tab.id
                  ? 'bg-enterprise-neon/20 text-enterprise-neon border border-enterprise-neon/30'
                  : 'text-gray-400 hover:text-gray-200 hover:bg-gray-700/30'
              )}
            >
              <Icon className="h-4 w-4" />
              <span className="text-sm font-medium">{tab.label}</span>
            </button>
          )
        })}
      </div>

      {/* Tab Content */}
      {activeTab === 'rules' && (
        <div className="space-y-6">
          {/* Search and Filters */}
          <div className="flex items-center space-x-4">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search rules..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="enterprise-input pl-10"
              />
            </div>
            
            <div className="flex items-center space-x-2">
              <Filter className="h-4 w-4 text-gray-400" />
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value as any)}
                className="enterprise-input"
              >
                <option value="all">All Rules</option>
                <option value="enabled">Enabled Only</option>
                <option value="disabled">Disabled Only</option>
              </select>
            </div>
          </div>

          {/* Rules Table */}
          <TableCard
            title="Traffic Rules"
            description={`${filteredRules.length} rules (${trafficRules.filter(r => r.enabled).length} active)`}
            data={filteredRules}
            columns={ruleColumns}
            loading={loading}
            emptyMessage="No traffic rules found. Create your first rule to get started."
          />
        </div>
      )}

      {activeTab === 'groups' && (
        <div className="space-y-6">
          <div className="flex justify-end">
            <Button
              variant="neon"
              onClick={() => setShowGroupModal(true)}
            >
              <Plus className="h-4 w-4 mr-2" />
              New Group
            </Button>
          </div>
          
          <TableCard
            title="Client Groups"
            description={`Manage device groupings for rule application`}
            data={clientGroups}
            columns={groupColumns}
            loading={loading}
            emptyMessage="No client groups found. Create groups to organize devices."
          />
        </div>
      )}

      {activeTab === 'types' && (
        <div className="space-y-6">
          <div className="text-center py-8 text-gray-400">
            <Zap className="h-16 w-16 mx-auto mb-4 opacity-50" />
            <h3 className="text-xl font-semibold mb-2">Traffic Types Management</h3>
            <p>Configure protocol definitions and traffic categorization</p>
          </div>
        </div>
      )}

      {activeTab === 'advanced' && (
        <div className="space-y-6">
          <AdvancedTrafficRules />
        </div>
      )}

      {/* Rule Creation Modal */}
      <Modal
        isOpen={showRuleModal}
        onClose={() => {
          setShowRuleModal(false)
          setEditingRule(null)
          resetRuleForm()
        }}
        title={editingRule ? "Edit Traffic Rule" : "Create New Traffic Rule"}
        size="lg"
      >
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Rule Name
              </label>
              <input
                type="text"
                value={ruleForm.name}
                onChange={(e) => setRuleForm(prev => ({ ...prev, name: e.target.value }))}
                className="enterprise-input w-full"
                placeholder="Enter rule name"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Priority
              </label>
              <input
                type="number"
                value={ruleForm.priority}
                onChange={(e) => setRuleForm(prev => ({ ...prev, priority: parseInt(e.target.value) }))}
                className="enterprise-input w-full"
                min="1"
                max="1000"
              />
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Description
            </label>
            <textarea
              value={ruleForm.description}
              onChange={(e) => setRuleForm(prev => ({ ...prev, description: e.target.value }))}
              className="enterprise-input w-full h-20 resize-none"
              placeholder="Describe this traffic rule..."
            />
          </div>
          
          <div className="flex items-center justify-between">
            <label className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={ruleForm.enabled}
                onChange={(e) => setRuleForm(prev => ({ ...prev, enabled: e.target.checked }))}
                className="enterprise-checkbox"
              />
              <span className="text-sm text-gray-300">Enable this rule</span>
            </label>
          </div>
          
          <div className="flex justify-end space-x-3 pt-4 border-t border-gray-700">
            <Button
              variant="outline"
              onClick={() => {
                setShowRuleModal(false)
                setEditingRule(null)
                resetRuleForm()
              }}
            >
              Cancel
            </Button>
            
            <Button
              variant="neon"
              onClick={handleCreateRule}
            >
              {editingRule ? 'Update Rule' : 'Create Rule'}
            </Button>
          </div>
        </div>
      </Modal>

      {/* Group Creation Modal */}
      <Modal
        isOpen={showGroupModal}
        onClose={() => setShowGroupModal(false)}
        title="Create New Client Group"
      >
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Group Name
            </label>
            <input
              type="text"
              value={groupForm.name}
              onChange={(e) => setGroupForm(prev => ({ ...prev, name: e.target.value }))}
              className="enterprise-input w-full"
              placeholder="Enter group name"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Description
            </label>
            <textarea
              value={groupForm.description}
              onChange={(e) => setGroupForm(prev => ({ ...prev, description: e.target.value }))}
              className="enterprise-input w-full h-20 resize-none"
              placeholder="Describe this group..."
            />
          </div>
          
          <div className="flex justify-end space-x-3 pt-4 border-t border-gray-700">
            <Button
              variant="outline"
              onClick={() => setShowGroupModal(false)}
            >
              Cancel
            </Button>
            
            <Button
              variant="neon"
              onClick={handleCreateGroup}
            >
              Create Group
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  )
}

export default TrafficRules