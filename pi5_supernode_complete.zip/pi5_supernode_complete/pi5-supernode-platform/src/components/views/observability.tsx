import React, { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import {
  BarChart3,
  Activity,
  TrendingUp,
  AlertTriangle,
  CheckCircle,
  RefreshCw,
  ExternalLink,
  Monitor,
  Server,
  Cpu,
  HardDrive,
  Wifi,
  Shield,
  Clock,
  ZapOff
} from 'lucide-react'
import { useNetworkStore, useVPNStore, useUIStore } from '@/lib/store'
import { ObservabilityService, type AlertItem, type SystemMetrics, type ServiceHealth } from '@/lib/services'
import { useRealTimeUpdates, useNetworkMonitoring, useVPNMonitoring } from '@/hooks/useRealTime'
import { Button } from '@/components/ui/button'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card'
import MetricCard from '@/components/ui/metric-card'
import { cn } from '@/lib/utils'


// Import AlertItem type from the service

const Observability: React.FC = () => {
  const { devices } = useNetworkStore()
  const { servers, clients } = useVPNStore()
  const { addNotification } = useUIStore()
  const [loading, setLoading] = useState(true)
  const [selectedTimeRange, setSelectedTimeRange] = useState('1h')
  const [alerts, setAlerts] = useState<AlertItem[]>([])
  const [grafanaUrl] = useState('http://localhost:3000') // Default Grafana URL
  
  const { isConnected, systemMetrics } = useRealTimeUpdates()
  // const systemHealth = useSystemHealth() // TODO: Implement this hook
  const networkStats = useNetworkMonitoring()
  const vpnStats = useVPNMonitoring()
  
  // Generate mock historical data for charts
  const [historicalData, setHistoricalData] = useState<any[]>([])
  const [networkTrafficData, setNetworkTrafficData] = useState<any[]>([])
  const [deviceStatusData, setDeviceStatusData] = useState<any[]>([])

  useEffect(() => {
    loadObservabilityData()
    
    const interval = setInterval(() => {
      updateRealTimeData()
    }, 5000)
    
    return () => clearInterval(interval)
  }, [])

  useEffect(() => {
    loadMetricsData()
  }, [selectedTimeRange])

  const loadObservabilityData = async () => {
    try {
      setLoading(true)
      
      // Load real alerts from the database
      const alerts = await ObservabilityService.getAlerts()
      setAlerts(alerts)
      
      // Load system metrics for charts
      await loadMetricsData()
    } catch (error) {
      console.error('Error loading observability data:', error)
      addNotification({ type: 'error', message: 'Failed to load monitoring data' })
    } finally {
      setLoading(false)
    }
  }

  const loadMetricsData = async () => {
    try {
      // Load real system metrics
      const systemMetrics = await ObservabilityService.getSystemMetrics(selectedTimeRange)
      
      const historical = systemMetrics.map(metric => ({
        time: new Date(metric.timestamp).toLocaleTimeString(),
        cpu: metric.cpu_percent,
        memory: metric.memory_percent,
        temperature: metric.temperature_celsius,
        timestamp: metric.timestamp
      }))
      
      // Load network traffic data
      const networkTraffic = await ObservabilityService.getNetworkTrafficData(selectedTimeRange)
      const formattedTraffic = networkTraffic.map(data => ({
        time: new Date(data.timestamp).toLocaleTimeString(),
        upload: data.bytes_sent / 1024 / 1024, // Convert to MB
        download: data.bytes_received / 1024 / 1024, // Convert to MB
        timestamp: data.timestamp
      }))
      
      // Device status distribution
      const deviceStatus = [
        { name: 'Online', value: networkStats.active_devices, fill: '#22c55e' },
        { name: 'Offline', value: networkStats.total_devices - networkStats.active_devices, fill: '#ef4444' },
        { name: 'Unknown', value: 0, fill: '#f59e0b' }
      ]
      
      setHistoricalData(historical)
      setNetworkTrafficData(formattedTraffic)
      setDeviceStatusData(deviceStatus)
    } catch (error) {
      console.error('Error loading metrics data:', error)
    }
  }

  const updateRealTimeData = () => {
    if (selectedTimeRange === '1h') {
      loadMetricsData()
    }
  }

  const acknowledgeAlert = async (alertId: string) => {
    try {
      await ObservabilityService.acknowledgeAlert(alertId)
      await loadObservabilityData()
      addNotification({ type: 'success', message: 'Alert acknowledged' })
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to acknowledge alert' })
    }
  }

  const dismissAlert = async (alertId: string) => {
    try {
      await ObservabilityService.dismissAlert(alertId)
      await loadObservabilityData()
      addNotification({ type: 'success', message: 'Alert dismissed' })
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to dismiss alert' })
    }
  }

  const openGrafana = () => {
    window.open(grafanaUrl, '_blank')
  }

  const criticalAlerts = alerts.filter(a => a.type === 'critical' && !a.acknowledged).length
  const warningAlerts = alerts.filter(a => a.type === 'warning' && !a.acknowledged).length
  const totalAlerts = alerts.filter(a => !a.acknowledged).length
  
  const uptimePercentage = 99.8 // Mock uptime
  const avgResponseTime = 12.5 // Mock response time

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Observability Dashboard</h1>
          <div className="flex items-center space-x-4">
            <p className="text-gray-400">System monitoring and performance analytics</p>
            <div className="flex items-center space-x-2">
              <div className={cn(
                'w-2 h-2 rounded-full',
                isConnected ? 'bg-green-400 animate-pulse' : 'bg-red-400'
              )} />
              <span className="text-sm text-gray-400">
                {isConnected ? 'Live Data' : 'Disconnected'}
              </span>
            </div>
          </div>
        </div>
        
        <div className="flex items-center space-x-3">
          <select
            value={selectedTimeRange}
            onChange={(e) => setSelectedTimeRange(e.target.value)}
            className="input-field w-32"
          >
            <option value="1h">Last Hour</option>
            <option value="6h">Last 6 Hours</option>
            <option value="24h">Last 24 Hours</option>
            <option value="7d">Last 7 Days</option>
          </select>
          
          <Button
            variant="outline"
            onClick={loadObservabilityData}
            loading={loading}
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          
          <Button variant="neon" onClick={openGrafana}>
            <ExternalLink className="h-4 w-4 mr-2" />
            Open Grafana
          </Button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard
          title="System Health"
          value="HEALTHY"
          subtitle="Overall status"
          icon={CheckCircle}
          color="success"
          loading={loading}
        />
        
        <MetricCard
          title="Active Alerts"
          value={totalAlerts}
          subtitle={`${criticalAlerts} critical, ${warningAlerts} warnings`}
          icon={totalAlerts > 0 ? AlertTriangle : CheckCircle}
          color={criticalAlerts > 0 ? 'danger' : warningAlerts > 0 ? 'warning' : 'success'}
          loading={loading}
        />
        
        <MetricCard
          title="Uptime"
          value={`${uptimePercentage}%`}
          subtitle="Last 30 days"
          icon={Activity}
          color="success"
          loading={loading}
        />
        
        <MetricCard
          title="Avg Response"
          value={`${avgResponseTime}ms`}
          subtitle="Network latency"
          icon={Clock}
          color="info"
          loading={loading}
        />
      </div>

      {/* Real-time System Metrics */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <TrendingUp className="h-5 w-5 text-enterprise-neon" />
              <span>System Performance</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80 flex items-center justify-center glassmorphism-card bg-gray-500/10">
              <div className="text-center">
                <BarChart3 className="h-12 w-12 text-enterprise-neon mx-auto mb-4" />
                <p className="text-gray-300">System Performance Chart</p>
                <p className="text-gray-500 text-sm">Real-time metrics visualization</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Wifi className="h-5 w-5 text-blue-400" />
              <span>Network Traffic</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80 flex items-center justify-center glassmorphism-card bg-gray-500/10">
              <div className="text-center">
                <Wifi className="h-12 w-12 text-blue-400 mx-auto mb-4" />
                <p className="text-gray-300">Network Traffic Chart</p>
                <p className="text-gray-500 text-sm">Upload/Download monitoring</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Device Status and Service Health */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Monitor className="h-5 w-5 text-purple-400" />
              <span>Device Status</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64 flex items-center justify-center glassmorphism-card bg-gray-500/10">
              <div className="text-center">
                <Monitor className="h-12 w-12 text-purple-400 mx-auto mb-4" />
                <p className="text-gray-300">Device Status Chart</p>
                <p className="text-gray-500 text-sm">Online/Offline distribution</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Server className="h-5 w-5 text-green-400" />
              <span>Service Health Status</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-center justify-between p-3 glassmorphism-card bg-green-500/10">
                <div className="flex items-center space-x-3">
                  <CheckCircle className="h-5 w-5 text-green-400" />
                  <span className="text-white font-medium">Network Service</span>
                </div>
                <span className="text-green-400 text-sm">Healthy</span>
              </div>
              
              <div className="flex items-center justify-between p-3 glassmorphism-card bg-green-500/10">
                <div className="flex items-center space-x-3">
                  <CheckCircle className="h-5 w-5 text-green-400" />
                  <span className="text-white font-medium">VPN Service</span>
                </div>
                <span className="text-green-400 text-sm">Healthy</span>
              </div>
              
              <div className="flex items-center justify-between p-3 glassmorphism-card bg-yellow-500/10">
                <div className="flex items-center space-x-3">
                  <AlertTriangle className="h-5 w-5 text-yellow-400" />
                  <span className="text-white font-medium">Automation Service</span>
                </div>
                <span className="text-yellow-400 text-sm">Warning</span>
              </div>
              
              <div className="flex items-center justify-between p-3 glassmorphism-card bg-green-500/10">
                <div className="flex items-center space-x-3">
                  <CheckCircle className="h-5 w-5 text-green-400" />
                  <span className="text-white font-medium">Storage Service</span>
                </div>
                <span className="text-green-400 text-sm">Healthy</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Alerts */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <AlertTriangle className="h-5 w-5 text-orange-400" />
              <span>Recent Alerts</span>
            </div>
            <span className="text-sm text-gray-400">
              {alerts.filter(a => !a.acknowledged).length} unacknowledged
            </span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {alerts.length === 0 ? (
              <div className="text-center py-8">
                <CheckCircle className="h-12 w-12 text-green-400 mx-auto mb-3" />
                <p className="text-gray-300">No recent alerts</p>
                <p className="text-gray-500 text-sm">Your system is running smoothly</p>
              </div>
            ) : (
              alerts.map((alert) => (
                <motion.div
                  key={alert.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className={cn(
                    'flex items-center justify-between p-4 rounded-lg border',
                    alert.acknowledged 
                      ? 'glassmorphism-card bg-gray-500/10 border-gray-600/30' 
                      : alert.type === 'critical'
                        ? 'glassmorphism-card bg-red-500/10 border-red-500/30'
                        : alert.type === 'warning'
                          ? 'glassmorphism-card bg-yellow-500/10 border-yellow-500/30'
                          : 'glassmorphism-card bg-blue-500/10 border-blue-500/30'
                  )}
                >
                  <div className="flex items-center space-x-4">
                    <div className={cn(
                      'p-2 rounded-full',
                      alert.type === 'critical' 
                        ? 'bg-red-500/20' 
                        : alert.type === 'warning' 
                          ? 'bg-yellow-500/20' 
                          : 'bg-blue-500/20'
                    )}>
                      {alert.type === 'critical' ? (
                        <ZapOff className="h-4 w-4 text-red-400" />
                      ) : alert.type === 'warning' ? (
                        <AlertTriangle className="h-4 w-4 text-yellow-400" />
                      ) : (
                        <Activity className="h-4 w-4 text-blue-400" />
                      )}
                    </div>
                    
                    <div>
                      <div className="flex items-center space-x-2">
                        <h4 className="font-medium text-white">{alert.title}</h4>
                        <span className={cn(
                          'px-2 py-1 text-xs rounded-full',
                          alert.source === 'system' ? 'bg-purple-500/20 text-purple-300' :
                          alert.source === 'network' ? 'bg-blue-500/20 text-blue-300' :
                          alert.source === 'vpn' ? 'bg-green-500/20 text-green-300' :
                          'bg-orange-500/20 text-orange-300'
                        )}>
                          {alert.source}
                        </span>
                      </div>
                      <p className="text-gray-400 text-sm">{alert.description}</p>
                      <p className="text-gray-500 text-xs">
                        {new Date(alert.timestamp).toLocaleString()}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    {!alert.acknowledged && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => acknowledgeAlert(alert.id)}
                      >
                        Acknowledge
                      </Button>
                    )}
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => dismissAlert(alert.id)}
                    >
                      Dismiss
                    </Button>
                  </div>
                </motion.div>
              ))
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default Observability