import React, { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import {
  HardDrive,
  Usb,
  Server,
  Share,
  Plus,
  Trash2,
  Edit,
  Power,
  RefreshCw,
  Upload,
  Download,
  FolderOpen,
  Lock,
  Unlock,
  ExternalLink,
  Settings,
  Activity,
  AlertCircle,
  CheckCircle,
  Monitor,
  Database,
  BarChart3,
  ZapOff
} from 'lucide-react'
import { useUIStore } from '@/lib/store'
import { StorageService, type StorageDevice, type NetworkShare, formatBytes } from '@/lib/services'
import { Button } from '@/components/ui/button'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card'
import TableCard from '@/components/ui/table-card'
import MetricCard from '@/components/ui/metric-card'
import Modal from '@/components/ui/modal'
import { cn } from '@/lib/utils'


// Import types from the service

const Storage: React.FC = () => {
  const { addNotification } = useUIStore()
  const [loading, setLoading] = useState(true)
  const [storageDevices, setStorageDevices] = useState<StorageDevice[]>([])
  const [networkShares, setNetworkShares] = useState<NetworkShare[]>([])
  const [showDeviceModal, setShowDeviceModal] = useState(false)
  const [showShareModal, setShowShareModal] = useState(false)
  const [selectedDevice, setSelectedDevice] = useState<StorageDevice | null>(null)
  const [activeTab, setActiveTab] = useState('devices')
  
  const [shareForm, setShareForm] = useState<{
    name: string
    protocol: 'smb' | 'nfs' | 'ftp' | 'sftp'
    path: string
    permissions: 'read' | 'write' | 'full'
    storage_device_id: string
    allowed_users: string[]
    is_active: boolean
  }>({
    name: '',
    protocol: 'smb',
    path: '',
    permissions: 'read',
    storage_device_id: '',
    allowed_users: ['*'],
    is_active: true
  })

  useEffect(() => {
    loadStorageData()
  }, [])

  const loadStorageData = async () => {
    try {
      setLoading(true)
      
      // Load real storage devices
      const devices = await StorageService.getAllStorageDevices()
      setStorageDevices(devices)
      
      // Load real network shares
      const shares = await StorageService.getAllNetworkShares()
      setNetworkShares(shares)
    } catch (error) {
      console.error('Error loading storage data:', error)
      addNotification({ type: 'error', message: 'Failed to load storage data' })
    } finally {
      setLoading(false)
    }
  }

  // formatBytes is now imported from the service

  const handleMountDevice = async (device: StorageDevice) => {
    try {
      if (device.is_mounted) {
        await StorageService.unmountDevice(device.id)
      } else {
        await StorageService.mountDevice(device.id)
      }
      
      await loadStorageData()
      addNotification({ 
        type: 'success', 
        message: `Device ${device.is_mounted ? 'unmounted' : 'mounted'} successfully` 
      })
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to mount/unmount device' })
    }
  }

  const handleCreateShare = async () => {
    try {
      await StorageService.createNetworkShare(shareForm)
      
      setShowShareModal(false)
      setShareForm({
        name: '',
        protocol: 'smb',
        path: '',
        permissions: 'read',
        storage_device_id: '',
        allowed_users: ['*'],
        is_active: true
      })
      
      await loadStorageData()
      addNotification({ type: 'success', message: 'Network share created successfully' })
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to create network share' })
    }
  }

  const toggleShareStatus = async (share: NetworkShare) => {
    try {
      await StorageService.toggleShareStatus(share.id)
      
      await loadStorageData()
      addNotification({ 
        type: 'success', 
        message: `Share ${share.is_active ? 'disabled' : 'enabled'}` 
      })
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to update share status' })
    }
  }

  const deleteShare = async (share: NetworkShare) => {
    try {
      await StorageService.deleteNetworkShare(share.id)
      
      await loadStorageData()
      addNotification({ type: 'success', message: 'Network share deleted' })
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to delete share' })
    }
  }

  // Calculate metrics
  const totalDevices = storageDevices.length
  const mountedDevices = storageDevices.filter(d => d.is_mounted).length
  const totalStorage = storageDevices.reduce((sum, d) => sum + d.total_size, 0)
  const usedStorage = storageDevices.reduce((sum, d) => sum + d.used_size, 0)
  const activeShares = networkShares.filter(s => s.is_active).length

  // Prepare chart data
  const storageUsageData = storageDevices.map(device => ({
    name: device.name,
    total: Math.round(device.total_size / (1024 * 1024 * 1024)), // GB
    used: Math.round(device.used_size / (1024 * 1024 * 1024)), // GB
    free: Math.round((device.total_size - device.used_size) / (1024 * 1024 * 1024))
  }))

  const shareProtocolData = [
    { name: 'SMB', value: networkShares.filter(s => s.protocol === 'smb').length, fill: '#22c55e' },
    { name: 'NFS', value: networkShares.filter(s => s.protocol === 'nfs').length, fill: '#3b82f6' },
    { name: 'FTP', value: networkShares.filter(s => s.protocol === 'ftp').length, fill: '#f59e0b' },
    { name: 'SFTP', value: networkShares.filter(s => s.protocol === 'sftp').length, fill: '#8b5cf6' }
  ].filter(item => item.value > 0)

  const deviceColumns = [
    {
      key: 'name' as keyof StorageDevice,
      label: 'Device',
      sortable: true,
      render: (value: any, item: StorageDevice) => (
        <div className="flex items-center space-x-3">
          <div className={cn(
            'p-2 rounded-lg',
            item.type === 'usb' ? 'bg-blue-500/20' :
            item.type === 'sata' ? 'bg-green-500/20' :
            item.type === 'nvme' ? 'bg-purple-500/20' :
            'bg-orange-500/20'
          )}>
            {item.type === 'usb' ? <Usb className="h-4 w-4 text-blue-400" /> :
             item.type === 'sata' ? <HardDrive className="h-4 w-4 text-green-400" /> :
             item.type === 'nvme' ? <Database className="h-4 w-4 text-purple-400" /> :
             <Monitor className="h-4 w-4 text-orange-400" />}
          </div>
          <div>
            <div className="font-medium text-white">{value}</div>
            <div className="text-sm text-gray-400">{item.device_path}</div>
          </div>
        </div>
      )
    },
    {
      key: 'total_size' as keyof StorageDevice,
      label: 'Storage',
      sortable: true,
      render: (value: any, item: StorageDevice) => {
        const usagePercent = (item.used_size / item.total_size) * 100
        return (
          <div>
            <div className="text-white font-medium">{formatBytes(value)}</div>
            <div className="text-sm text-gray-400">
              {formatBytes(item.used_size)} used ({usagePercent.toFixed(1)}%)
            </div>
            <div className="w-full bg-gray-700 rounded-full h-1.5 mt-1">
              <div 
                className={cn(
                  'h-1.5 rounded-full transition-all duration-300',
                  usagePercent > 90 ? 'bg-red-400' :
                  usagePercent > 75 ? 'bg-yellow-400' :
                  'bg-green-400'
                )}
                style={{ width: `${Math.min(usagePercent, 100)}%` }}
              />
            </div>
          </div>
        )
      }
    },
    {
      key: 'file_system' as keyof StorageDevice,
      label: 'File System',
      sortable: true,
      render: (value: any) => (
        <span className="status-badge bg-purple-500/20 text-purple-300 border-purple-500/30">
          {value.toUpperCase()}
        </span>
      )
    },
    {
      key: 'status' as keyof StorageDevice,
      label: 'Status',
      sortable: true,
      render: (value: any, item: StorageDevice) => (
        <div>
          <div className="flex items-center space-x-2">
            {value === 'healthy' ? (
              <CheckCircle className="h-4 w-4 text-green-400" />
            ) : value === 'warning' ? (
              <AlertCircle className="h-4 w-4 text-yellow-400" />
            ) : (
              <AlertCircle className="h-4 w-4 text-red-400" />
            )}
            <span className={cn(
              'capitalize',
              value === 'healthy' ? 'text-green-400' :
              value === 'warning' ? 'text-yellow-400' :
              'text-red-400'
            )}>
              {value}
            </span>
          </div>
          <div className="text-xs text-gray-400 mt-1">
            {item.is_mounted ? 'Mounted' : 'Not mounted'}
            {item.is_encrypted && ' • Encrypted'}
          </div>
        </div>
      )
    }
  ]

  const shareColumns = [
    {
      key: 'name' as keyof NetworkShare,
      label: 'Share Name',
      sortable: true,
      render: (value: any, item: NetworkShare) => (
        <div>
          <div className="flex items-center space-x-2">
            <Share className="h-4 w-4 text-blue-400" />
            <span className="font-medium text-white">{value}</span>
          </div>
          <div className="text-sm text-gray-400 mt-1">{item.path}</div>
        </div>
      )
    },
    {
      key: 'protocol' as keyof NetworkShare,
      label: 'Protocol',
      sortable: true,
      render: (value: any) => (
        <span className={cn(
          'status-badge',
          value === 'smb' ? 'bg-green-500/20 text-green-300 border-green-500/30' :
          value === 'nfs' ? 'bg-blue-500/20 text-blue-300 border-blue-500/30' :
          value === 'ftp' ? 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30' :
          'bg-purple-500/20 text-purple-300 border-purple-500/30'
        )}>
          {value.toUpperCase()}
        </span>
      )
    },
    {
      key: 'permissions' as keyof NetworkShare,
      label: 'Permissions',
      sortable: true,
      render: (value: any, item: NetworkShare) => (
        <div>
          <span className={cn(
            'status-badge',
            value === 'full' ? 'bg-green-500/20 text-green-300 border-green-500/30' :
            value === 'write' ? 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30' :
            'bg-gray-500/20 text-gray-300 border-gray-500/30'
          )}>
            {value}
          </span>
          <div className="text-xs text-gray-400 mt-1">
            {item.allowed_users.includes('*') ? 'Everyone' : `${item.allowed_users.length} users`}
          </div>
        </div>
      )
    },
    {
      key: 'access_count' as keyof NetworkShare,
      label: 'Usage',
      sortable: true,
      render: (value: any, item: NetworkShare) => (
        <div>
          <div className="font-medium text-white">{value} accesses</div>
          {item.last_accessed && (
            <div className="text-xs text-gray-400">
              Last: {new Date(item.last_accessed).toLocaleDateString()}
            </div>
          )}
        </div>
      )
    },
    {
      key: 'is_active' as keyof NetworkShare,
      label: 'Status',
      sortable: true,
      render: (value: any) => (
        <span className={value ? 'status-active' : 'status-inactive'}>
          {value ? 'Active' : 'Inactive'}
        </span>
      )
    }
  ]

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Storage Management</h1>
          <p className="text-gray-400">USB device and network share management</p>
        </div>
        
        <div className="flex items-center space-x-3">
          <Button
            variant="outline"
            onClick={loadStorageData}
            loading={loading}
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          
          <Button 
            variant="neon"
            onClick={() => setShowShareModal(true)}
          >
            <Plus className="h-4 w-4 mr-2" />
            Create Share
          </Button>
        </div>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard
          title="Storage Devices"
          value={totalDevices}
          subtitle={`${mountedDevices} mounted`}
          icon={HardDrive}
          color="info"
          loading={loading}
        />
        
        <MetricCard
          title="Total Storage"
          value={formatBytes(totalStorage)}
          subtitle={`${formatBytes(usedStorage)} used`}
          icon={Database}
          color="success"
          loading={loading}
        />
        
        <MetricCard
          title="Network Shares"
          value={networkShares.length}
          subtitle={`${activeShares} active`}
          icon={Share}
          color="info"
          loading={loading}
        />
        
        <MetricCard
          title="Usage Ratio"
          value={`${((usedStorage / totalStorage) * 100).toFixed(1)}%`}
          subtitle="Storage utilization"
          icon={Activity}
          color={usedStorage / totalStorage > 0.8 ? 'warning' : 'success'}
          loading={loading}
        />
      </div>

      {/* Tab Navigation */}
      <div className="flex space-x-1 glassmorphism-card bg-gray-800/30 p-1 rounded-lg w-fit">
        {[
          { id: 'devices', label: 'Storage Devices', icon: HardDrive },
          { id: 'shares', label: 'Network Shares', icon: Share },
          { id: 'analytics', label: 'Analytics', icon: BarChart3 }
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={cn(
              'flex items-center space-x-2 px-4 py-2 rounded-md transition-all duration-200',
              activeTab === tab.id
                ? 'bg-enterprise-neon/20 text-enterprise-neon border border-enterprise-neon/30'
                : 'text-gray-400 hover:text-white hover:bg-white/5'
            )}
          >
            <tab.icon className="h-4 w-4" />
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {/* Tab Content */}
      {activeTab === 'devices' && (
        <TableCard
          title="Storage Devices"
          data={storageDevices}
          columns={deviceColumns}
          loading={loading}
          actions={[
            {
              label: (item: StorageDevice) => item.is_mounted ? 'Unmount' : 'Mount',
              icon: (item: StorageDevice) => item.is_mounted ? ZapOff : Power,
              onClick: (item: StorageDevice) => handleMountDevice(item),
              variant: 'outline'
            },
            {
              label: 'Settings',
              icon: Settings,
              onClick: (item: StorageDevice) => setSelectedDevice(item),
              variant: 'outline'
            }
          ]}
        />
      )}

      {activeTab === 'shares' && (
        <TableCard
          title="Network Shares"
          data={networkShares}
          columns={shareColumns}
          loading={loading}
          actions={[
            {
              label: 'Open',
              icon: ExternalLink,
              onClick: (item: NetworkShare) => addNotification({ 
                type: 'info', 
                message: `Opening ${item.name}...` 
              }),
              variant: 'default'
            },
            {
              label: (item: NetworkShare) => item.is_active ? 'Disable' : 'Enable',
              icon: (item: NetworkShare) => item.is_active ? Unlock : Lock,
              onClick: (item: NetworkShare) => toggleShareStatus(item),
              variant: 'outline'
            },
            {
              label: 'Delete',
              icon: Trash2,
              onClick: (item: NetworkShare) => deleteShare(item),
              variant: 'destructive'
            }
          ]}
        />
      )}

      {activeTab === 'analytics' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <BarChart3 className="h-5 w-5 text-enterprise-neon" />
                <span>Storage Usage by Device</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-80 flex items-center justify-center glassmorphism-card bg-gray-500/10">
                <div className="text-center">
                  <BarChart3 className="h-12 w-12 text-enterprise-neon mx-auto mb-4" />
                  <p className="text-gray-300">Storage Usage Chart</p>
                  <p className="text-gray-500 text-sm">Device capacity analysis</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Share className="h-5 w-5 text-blue-400" />
                <span>Share Protocol Distribution</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-80 flex items-center justify-center glassmorphism-card bg-gray-500/10">
                <div className="text-center">
                  <Share className="h-12 w-12 text-blue-400 mx-auto mb-4" />
                  <p className="text-gray-300">Share Protocol Chart</p>
                  <p className="text-gray-500 text-sm">Protocol distribution analysis</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Create Network Share Modal */}
      <Modal
        isOpen={showShareModal}
        onClose={() => setShowShareModal(false)}
        title="Create Network Share"
      >
        <div className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Share Name
            </label>
            <input
              type="text"
              value={shareForm.name}
              onChange={(e) => setShareForm(prev => ({ ...prev, name: e.target.value }))}
              className="input-field"
              placeholder="Enter share name..."
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Protocol
              </label>
              <select
                value={shareForm.protocol}
                onChange={(e) => setShareForm(prev => ({ 
                  ...prev, 
                  protocol: e.target.value as 'smb' | 'nfs' | 'ftp' | 'sftp'
                }))}
                className="input-field"
              >
                <option value="smb">SMB/CIFS</option>
                <option value="nfs">NFS</option>
                <option value="ftp">FTP</option>
                <option value="sftp">SFTP</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Permissions
              </label>
              <select
                value={shareForm.permissions}
                onChange={(e) => setShareForm(prev => ({ 
                  ...prev, 
                  permissions: e.target.value as 'read' | 'write' | 'full'
                }))}
                className="input-field"
              >
                <option value="read">Read Only</option>
                <option value="write">Read/Write</option>
                <option value="full">Full Control</option>
              </select>
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Storage Device
            </label>
            <select
              value={shareForm.storage_device_id}
              onChange={(e) => setShareForm(prev => ({ ...prev, storage_device_id: e.target.value }))}
              className="input-field"
            >
              <option value="">Select device...</option>
              {storageDevices.filter(d => d.is_mounted).map(device => (
                <option key={device.id} value={device.id}>
                  {device.name} ({device.mount_point})
                </option>
              ))}
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Share Path
            </label>
            <input
              type="text"
              value={shareForm.path}
              onChange={(e) => setShareForm(prev => ({ ...prev, path: e.target.value }))}
              className="input-field"
              placeholder="/media/usb1/shared"
            />
          </div>
          
          <div className="flex justify-end space-x-3">
            <Button variant="outline" onClick={() => setShowShareModal(false)}>
              Cancel
            </Button>
            <Button variant="neon" onClick={handleCreateShare}>
              Create Share
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  )
}

export default Storage