import React, { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import {
  Zap,
  Plus,
  Play,
  Pause,
  Edit,
  Trash2,
  Clock,
  Send,
  Webhook,
  MessageSquare,
  Settings,
  RefreshCw,
  CheckCircle,
  AlertTriangle,
  Activity
} from 'lucide-react'
import { useUIStore } from '@/lib/store'
import { AutomationService } from '@/lib/services'
import { supabase } from '@/lib/supabase'
import { Button } from '@/components/ui/button'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card'
import TableCard from '@/components/ui/table-card'
import MetricCard from '@/components/ui/metric-card'
import Modal from '@/components/ui/modal'
import { cn } from '@/lib/utils'

// Import types from the service
import type { AutomationRule, AutomationAction } from '@/lib/services'

interface TelegramConfig {
  bot_token: string
  chat_id: string
  message_template: string
}

interface WebhookConfig {
  url: string
  method: 'GET' | 'POST' | 'PUT'
  headers: Record<string, string>
  body_template: string
}

const Automations: React.FC = () => {
  const { addNotification } = useUIStore()
  const [loading, setLoading] = useState(true)
  const [rules, setRules] = useState<AutomationRule[]>([])
  const [showRuleModal, setShowRuleModal] = useState(false)
  const [showTestModal, setShowTestModal] = useState(false)
  const [selectedRule, setSelectedRule] = useState<AutomationRule | null>(null)
  const [telegramSettings, setTelegramSettings] = useState({ bot_token: '', default_chat_id: '' })
  
  const [ruleForm, setRuleForm] = useState<Partial<AutomationRule>>({
    name: '',
    description: '',
    enabled: true,
    trigger_type: 'event',
    trigger_config: {},
    actions: [],
    execution_count: 0
  })

  useEffect(() => {
    loadAutomations()
    loadSettings()
  }, [])

  const loadAutomations = async () => {
    try {
      setLoading(true)
      
      // Load automation rules from the database
      const rules = await AutomationService.getAllRules()
      setRules(rules)
    } catch (error) {
      console.error('Error loading automation rules:', error)
      addNotification({ type: 'error', message: 'Failed to load automation rules' })
    } finally {
      setLoading(false)
    }
  }

  const loadSettings = async () => {
    try {
      // Load Telegram bot settings
      const { data: settings } = await supabase
        .from('device_configurations')
        .select('*')
        .eq('category', 'telegram')
        .single()
      
      if (settings && settings.config_json) {
        setTelegramSettings(settings.config_json)
      }
    } catch (error) {
      console.log('No Telegram settings found')
    }
  }

  const handleCreateRule = async () => {
    try {
      await AutomationService.createRule(ruleForm as Omit<AutomationRule, 'id' | 'created_at' | 'execution_count'>)
      
      setShowRuleModal(false)
      setRuleForm({
        name: '',
        description: '',
        enabled: true,
        trigger_type: 'event',
        trigger_config: {},
        actions: [],
        execution_count: 0
      })
      
      await loadAutomations()
      addNotification({ type: 'success', message: 'Automation rule created successfully' })
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to create automation rule' })
    }
  }

  const toggleRuleStatus = async (rule: AutomationRule) => {
    try {
      await AutomationService.updateRule(rule.id, { enabled: !rule.enabled })
      
      await loadAutomations()
      addNotification({ 
        type: 'success', 
        message: `Rule ${rule.enabled ? 'disabled' : 'enabled'}` 
      })
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to update rule status' })
    }
  }

  const deleteRule = async (rule: AutomationRule) => {
    try {
      await AutomationService.deleteRule(rule.id)
      
      await loadAutomations()
      addNotification({ type: 'success', message: 'Automation rule deleted' })
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to delete rule' })
    }
  }

  const testTelegramConnection = async () => {
    try {
      addNotification({ type: 'info', message: 'Testing Telegram connection...' })
      
      await AutomationService.testTelegramConnection(
        telegramSettings.bot_token, 
        telegramSettings.default_chat_id
      )
      
      addNotification({ type: 'success', message: 'Telegram test message sent successfully' })
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to send Telegram test message' })
    }
  }

  const testWebhook = async (url: string) => {
    try {
      addNotification({ type: 'info', message: 'Testing webhook...' })
      
      await AutomationService.testWebhook(url)
      
      addNotification({ type: 'success', message: 'Webhook test completed successfully' })
    } catch (error) {
      addNotification({ type: 'error', message: 'Webhook test failed' })
    }
  }

  const executeRule = async (rule: AutomationRule) => {
    try {
      addNotification({ type: 'info', message: `Executing rule: ${rule.name}...` })
      
      await AutomationService.executeRule(rule.id)
      
      await loadAutomations()
      addNotification({ type: 'success', message: 'Rule executed successfully' })
    } catch (error) {
      addNotification({ type: 'error', message: 'Failed to execute rule' })
    }
  }

  const enabledRules = rules.filter(r => r.enabled).length
  const disabledRules = rules.filter(r => !r.enabled).length
  const totalExecutions = rules.reduce((sum, r) => sum + r.execution_count, 0)
  const recentExecutions = rules.filter(r => 
    r.last_executed && new Date(r.last_executed) > new Date(Date.now() - 86400000)
  ).length

  const ruleColumns = [
    {
      key: 'name' as keyof AutomationRule,
      label: 'Rule Name',
      sortable: true,
      render: (value: any, item: AutomationRule) => (
        <div>
          <div className="flex items-center space-x-2">
            <div className={cn(
              'w-2 h-2 rounded-full',
              item.enabled ? 'bg-green-400' : 'bg-gray-400'
            )} />
            <span className="font-medium text-white">{value}</span>
          </div>
          <div className="text-sm text-gray-400 mt-1">{item.description}</div>
        </div>
      )
    },
    {
      key: 'trigger_type' as keyof AutomationRule,
      label: 'Trigger',
      sortable: true,
      render: (value: any, item: AutomationRule) => (
        <div>
          <span className={cn(
            'status-badge',
            value === 'event' ? 'bg-blue-500/20 text-blue-300 border-blue-500/30' :
            value === 'schedule' ? 'bg-purple-500/20 text-purple-300 border-purple-500/30' :
            'bg-orange-500/20 text-orange-300 border-orange-500/30'
          )}>
            {value}
          </span>
          {value === 'schedule' && item.trigger_config.cron && (
            <div className="text-xs text-gray-400 mt-1 font-mono">
              {item.trigger_config.cron}
            </div>
          )}
        </div>
      )
    },
    {
      key: 'actions' as keyof AutomationRule,
      label: 'Actions',
      render: (value: AutomationAction[]) => (
        <div className="flex space-x-2">
          {value.map((action, index) => (
            <span key={index} className={cn(
              'status-badge text-xs',
              action.type === 'telegram' ? 'bg-green-500/20 text-green-300 border-green-500/30' :
              action.type === 'webhook' ? 'bg-blue-500/20 text-blue-300 border-blue-500/30' :
              action.type === 'email' ? 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30' :
              'bg-gray-500/20 text-gray-300 border-gray-500/30'
            )}>
              {action.type}
            </span>
          ))}
        </div>
      )
    },
    {
      key: 'execution_count' as keyof AutomationRule,
      label: 'Executions',
      sortable: true,
      render: (value: any, item: AutomationRule) => (
        <div>
          <div className="font-medium text-white">{value}</div>
          {item.last_executed && (
            <div className="text-xs text-gray-400">
              Last: {new Date(item.last_executed).toLocaleDateString()}
            </div>
          )}
        </div>
      )
    },
    {
      key: 'enabled' as keyof AutomationRule,
      label: 'Status',
      sortable: true,
      render: (value: any) => (
        <span className={value ? 'status-active' : 'status-inactive'}>
          {value ? 'Enabled' : 'Disabled'}
        </span>
      )
    }
  ]

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Automation Rules</h1>
          <p className="text-gray-400">Rule engine with Telegram and webhook integrations</p>
        </div>
        
        <div className="flex items-center space-x-3">
          <Button
            variant="outline"
            onClick={loadAutomations}
            loading={loading}
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          
          <Button 
            variant="neon"
            onClick={() => setShowRuleModal(true)}
          >
            <Plus className="h-4 w-4 mr-2" />
            Create Rule
          </Button>
        </div>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard
          title="Total Rules"
          value={rules.length}
          subtitle="Automation rules"
          icon={Zap}
          color="info"
          loading={loading}
        />
        
        <MetricCard
          title="Active Rules"
          value={enabledRules}
          subtitle={`${disabledRules} disabled`}
          icon={Activity}
          color="success"
          loading={loading}
        />
        
        <MetricCard
          title="Total Executions"
          value={totalExecutions}
          subtitle="All time"
          icon={CheckCircle}
          color="info"
          loading={loading}
        />
        
        <MetricCard
          title="Recent Activity"
          value={recentExecutions}
          subtitle="Last 24 hours"
          icon={Clock}
          color="success"
          loading={loading}
        />
      </div>

      {/* Integration Settings */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <MessageSquare className="h-5 w-5 text-green-400" />
              <span>Telegram Bot Settings</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Bot Token
                </label>
                <div className="flex space-x-2">
                  <input
                    type="password"
                    value={telegramSettings.bot_token}
                    onChange={(e) => setTelegramSettings(prev => ({
                      ...prev, bot_token: e.target.value
                    }))}
                    className="input-field flex-1"
                    placeholder="Enter bot token..."
                  />
                  <Button variant="outline" size="sm" onClick={testTelegramConnection}>
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Default Chat ID
                </label>
                <input
                  type="text"
                  value={telegramSettings.default_chat_id}
                  onChange={(e) => setTelegramSettings(prev => ({
                    ...prev, default_chat_id: e.target.value
                  }))}
                  className="input-field"
                  placeholder="Enter chat ID..."
                />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Webhook className="h-5 w-5 text-blue-400" />
              <span>Webhook Testing</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Webhook URL
                </label>
                <div className="flex space-x-2">
                  <input
                    type="url"
                    className="input-field flex-1"
                    placeholder="https://api.example.com/webhook"
                  />
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={() => testWebhook('https://api.example.com/webhook')}
                  >
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              
              <div className="p-4 glassmorphism-card bg-blue-500/10">
                <div className="flex items-center space-x-2 mb-2">
                  <AlertTriangle className="h-4 w-4 text-blue-400" />
                  <span className="text-blue-300 text-sm font-medium">Webhook Format</span>
                </div>
                <pre className="text-xs text-gray-400 font-mono">
{`POST /webhook HTTP/1.1
Content-Type: application/json

{
  "event": "device_connected",
  "data": { "device_name": "...", "ip": "..." },
  "timestamp": "2024-01-01T00:00:00Z"
}`}
                </pre>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Automation Rules Table */}
      <TableCard
        title="Automation Rules"
        data={rules}
        columns={ruleColumns}
        loading={loading}
        actions={[
          {
            label: 'Execute',
            icon: Play,
            onClick: (item: AutomationRule) => executeRule(item),
            variant: 'default'
          },
          {
            label: (item: AutomationRule) => item.enabled ? 'Disable' : 'Enable',
            icon: (item: AutomationRule) => item.enabled ? Pause : Play,
            onClick: (item: AutomationRule) => toggleRuleStatus(item),
            variant: 'outline'
          },
          {
            label: 'Delete',
            icon: Trash2,
            onClick: (item: AutomationRule) => deleteRule(item),
            variant: 'destructive'
          }
        ]}
      />

      {/* Create Rule Modal */}
      <Modal
        isOpen={showRuleModal}
        onClose={() => setShowRuleModal(false)}
        title="Create Automation Rule"
      >
        <div className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Rule Name
            </label>
            <input
              type="text"
              value={ruleForm.name}
              onChange={(e) => setRuleForm(prev => ({ ...prev, name: e.target.value }))}
              className="input-field"
              placeholder="Enter rule name..."
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Description
            </label>
            <textarea
              value={ruleForm.description}
              onChange={(e) => setRuleForm(prev => ({ ...prev, description: e.target.value }))}
              className="input-field h-20"
              placeholder="Describe what this rule does..."
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Trigger Type
            </label>
            <select
              value={ruleForm.trigger_type}
              onChange={(e) => setRuleForm(prev => ({ 
                ...prev, 
                trigger_type: e.target.value as 'event' | 'schedule' | 'condition'
              }))}
              className="input-field"
            >
              <option value="event">Event-based</option>
              <option value="schedule">Scheduled</option>
              <option value="condition">Condition-based</option>
            </select>
          </div>
          
          <div className="flex items-center space-x-3">
            <input
              type="checkbox"
              id="enabled"
              checked={ruleForm.enabled}
              onChange={(e) => setRuleForm(prev => ({ ...prev, enabled: e.target.checked }))}
              className="checkbox"
            />
            <label htmlFor="enabled" className="text-gray-300">
              Enable rule immediately
            </label>
          </div>
          
          <div className="flex justify-end space-x-3">
            <Button variant="outline" onClick={() => setShowRuleModal(false)}>
              Cancel
            </Button>
            <Button variant="neon" onClick={handleCreateRule}>
              Create Rule
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  )
}

export default Automations