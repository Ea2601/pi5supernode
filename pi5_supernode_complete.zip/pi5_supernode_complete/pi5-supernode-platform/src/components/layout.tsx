import React, { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Bell, Search, RefreshCw, Menu, X } from 'lucide-react'
import { useUIStore } from '@/lib/store'
import { Button } from '@/components/ui/button'
import Navigation from '@/components/ui/navigation'
import NotificationCenter from '@/components/ui/notification-center'
import Breadcrumbs from '@/components/ui/breadcrumbs'
import { NotificationService } from '@/lib/services/notificationService'
import usePageTitle from '@/hooks/usePageTitle'
import { cn } from '@/lib/utils'

export interface LayoutProps {
  children: React.ReactNode
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const { sidebarCollapsed } = useUIStore()
  const [showNotifications, setShowNotifications] = useState(false)
  const [notificationCount, setNotificationCount] = useState(0)
  const [mobileNavOpen, setMobileNavOpen] = useState(false)
  const [isMobile, setIsMobile] = useState(false)
  
  // Set page titles dynamically based on route
  usePageTitle()

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768)
    }
    
    checkMobile()
    window.addEventListener('resize', checkMobile)
    
    return () => window.removeEventListener('resize', checkMobile)
  }, [])

  // Close mobile nav when route changes
  useEffect(() => {
    setMobileNavOpen(false)
  }, [location.pathname])

  // Prevent body scroll when mobile nav is open
  useEffect(() => {
    if (mobileNavOpen && isMobile) {
      document.body.style.overflow = 'hidden'
    } else {
      document.body.style.overflow = 'unset'
    }
    
    return () => {
      document.body.style.overflow = 'unset'
    }
  }, [mobileNavOpen, isMobile])

  return (
    <div className="flex min-h-screen bg-enterprise-dark">
      {/* Desktop Navigation */}
      <div className="hidden md:block">
        <Navigation />
      </div>
      
      {/* Mobile Navigation Overlay */}
      <AnimatePresence>
        {mobileNavOpen && isMobile && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="mobile-nav-overlay"
              onClick={() => setMobileNavOpen(false)}
            />
            <motion.div
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="mobile-nav"
            >
              <Navigation onMobileClose={() => setMobileNavOpen(false)} />
            </motion.div>
          </>
        )}
      </AnimatePresence>
      
      <div className="flex-1 flex flex-col min-w-0">
        {/* Mobile Header */}
        <div className="mobile-header">
          <div className="flex items-center space-x-3">
            <button
              className="hamburger-button touch-target"
              onClick={() => setMobileNavOpen(true)}
              aria-label="Open navigation menu"
            >
              <Menu className="h-6 w-6 text-white" />
            </button>
            <h1 className="text-lg font-semibold text-white">Pi5 Supernode</h1>
          </div>
          
          <div className="flex items-center space-x-2">
            <Button 
              variant="outline" 
              size="icon" 
              className="touch-target"
              onClick={() => setShowNotifications(true)}
            >
              <Bell className="h-4 w-4" />
              {notificationCount > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 rounded-full text-xs text-white flex items-center justify-center">
                  {notificationCount > 9 ? '9+' : notificationCount}
                </span>
              )}
            </Button>
          </div>
        </div>
        
        {/* Desktop Header */}
        <header className="hidden md:block glassmorphism border-b border-white/10 px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <h1 className="text-xl font-semibold text-white">Pi5 Supernode</h1>
            </div>
            
            <div className="flex items-center space-x-4">
              {/* Global Search */}
              <div className="relative hidden lg:block">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search..."
                  className="pl-10 pr-4 py-2 w-64 enterprise-input rounded-lg"
                />
              </div>
              
              {/* Refresh Button */}
              <Button variant="outline" size="icon" className="touch-target">
                <RefreshCw className="h-4 w-4" />
              </Button>
              
              {/* Notifications */}
              <Button 
                variant="outline" 
                size="icon" 
                className="relative touch-target"
                onClick={() => setShowNotifications(true)}
              >
                <Bell className="h-4 w-4" />
                {notificationCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 rounded-full text-xs text-white flex items-center justify-center">
                    {notificationCount > 99 ? '99+' : notificationCount}
                  </span>
                )}
              </Button>
            </div>
          </div>
        </header>
        
        {/* Breadcrumbs - Hidden on mobile */}
        <div className="hidden md:block border-b border-white/10 px-6 py-3">
          <Breadcrumbs />
        </div>
        
        {/* Main Content */}
        <main className={cn(
          'flex-1 overflow-auto transition-all duration-300',
          sidebarCollapsed ? 'ml-0' : 'ml-0'
        )}>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
            className="p-4 sm:p-6"
          >
            {children}
          </motion.div>
        </main>
        
        {/* Notification Center */}
        <NotificationCenter
          isOpen={showNotifications}
          onClose={() => setShowNotifications(false)}
          onNotificationCountChange={setNotificationCount}
        />
      </div>
    </div>
  )
}

export default Layout