import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  Server,
  Wifi,
  Network,
  Search,
  Plus,
  RefreshCw,
  Edit,
  Trash2,
} from 'lucide-react';

interface DHCPLease {
  id: string;
  hostname: string;
  mac_address: string;
  ip_address: string;
  status: string;
}

interface WiFiNetwork {
  id: string;
  ssid: string;
  security_type: string;
  is_enabled: boolean;
  is_guest: boolean;
}

export function NetworkManagement() {
  const [activeTab, setActiveTab] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const [dhcpLeases, setDhcpLeases] = useState<DHCPLease[]>([]);
  const [wifiNetworks, setWifiNetworks] = useState<WiFiNetwork[]>([]);
  const [vlans, setVlans] = useState<any[]>([]);
  const [networkDevices, setNetworkDevices] = useState<any[]>([]);

  const tabs = [
    { label: 'DHCP', icon: Server },
    { label: 'WiFi', icon: Wifi },
    { label: 'VLANs', icon: Network },
    { label: 'Discovery', icon: Search },
  ];

  useEffect(() => {
    loadNetworkData();
  }, []);

  const loadNetworkData = async () => {
    setIsLoading(true);
    try {
      const [dhcpResponse, wifiResponse, vlansResponse] = await Promise.all([
        fetch('/functions/v1/comprehensive-network-manager/dhcp/leases'),
        fetch('/functions/v1/comprehensive-network-manager/wifi/networks'),
        fetch('/functions/v1/comprehensive-network-manager/vlans'),
      ]);
      
      const dhcpResult = await dhcpResponse.json();
      const wifiResult = await wifiResponse.json();
      const vlansResult = await vlansResponse.json();
      
      if (dhcpResult.data) setDhcpLeases(dhcpResult.data);
      if (wifiResult.data) setWifiNetworks(wifiResult.data);
      if (vlansResult.data) setVlans(vlansResult.data);
    } catch (error) {
      console.error('Failed to load network data:', error);
    }
    setIsLoading(false);
  };

  const scanNetwork = async () => {
    setIsLoading(true);
    try {
      const response = await fetch('/functions/v1/comprehensive-network-manager/network/scan');
      const result = await response.json();
      if (result.data) {
        setNetworkDevices(result.data);
      }
    } catch (error) {
      console.error('Failed to scan network:', error);
    }
    setIsLoading(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white mb-2">Network Management</h2>
          <p className="text-gray-400">Manage DHCP, WiFi, VLANs, and network discovery</p>
        </div>
        <div className="flex items-center space-x-3">
          <Button onClick={loadNetworkData} disabled={isLoading}>
            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh
          </Button>
        </div>
      </div>

      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div>
                <p className="text-sm text-gray-400">DHCP Leases</p>
                <p className="text-2xl font-bold text-white">{dhcpLeases.length}</p>
              </div>
              <Server className="h-8 w-8 text-blue-500 ml-auto" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div>
                <p className="text-sm text-gray-400">WiFi Networks</p>
                <p className="text-2xl font-bold text-white">{wifiNetworks.length}</p>
              </div>
              <Wifi className="h-8 w-8 text-green-500 ml-auto" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div>
                <p className="text-sm text-gray-400">VLANs</p>
                <p className="text-2xl font-bold text-white">{vlans.length}</p>
              </div>
              <Network className="h-8 w-8 text-yellow-500 ml-auto" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div>
                <p className="text-sm text-gray-400">Devices</p>
                <p className="text-2xl font-bold text-white">{networkDevices.length}</p>
              </div>
              <Search className="h-8 w-8 text-purple-500 ml-auto" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tab Navigation */}
      <div className="flex space-x-1 bg-gray-800/30 p-1 rounded-lg w-fit">
        {tabs.map((tab, index) => {
          const TabIcon = tab.icon;
          return (
            <button
              key={index}
              onClick={() => setActiveTab(index)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-md transition-all duration-200 ${
                activeTab === index
                  ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <TabIcon className="h-4 w-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tab Content */}
      {activeTab === 0 && (
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>DHCP Server Configuration</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-semibold text-white">Enable DHCP Server</h3>
                  <p className="text-sm text-gray-400">Automatically assign IP addresses to devices</p>
                </div>
                <input type="checkbox" className="w-5 h-5" defaultChecked />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">IP Range Start</label>
                  <input
                    type="text"
                    className="w-full bg-gray-800/50 border border-gray-600 rounded-lg px-3 py-2 text-white"
                    placeholder="192.168.1.100"
                    defaultValue="192.168.1.100"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">IP Range End</label>
                  <input
                    type="text"
                    className="w-full bg-gray-800/50 border border-gray-600 rounded-lg px-3 py-2 text-white"
                    placeholder="192.168.1.200"
                    defaultValue="192.168.1.200"
                  />
                </div>
              </div>
              
              <div className="pt-4 border-t border-gray-700">
                <Button>
                  Save DHCP Configuration
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Active DHCP Leases</CardTitle>
                <Button size="sm">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Reservation
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-700">
                      <th className="text-left py-3 px-4 text-gray-300">Hostname</th>
                      <th className="text-left py-3 px-4 text-gray-300">IP Address</th>
                      <th className="text-left py-3 px-4 text-gray-300">MAC Address</th>
                      <th className="text-left py-3 px-4 text-gray-300">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {dhcpLeases.map((lease) => (
                      <tr key={lease.id} className="border-b border-gray-800">
                        <td className="py-3 px-4 font-medium text-white">{lease.hostname}</td>
                        <td className="py-3 px-4 text-white">{lease.ip_address}</td>
                        <td className="py-3 px-4 font-mono text-sm text-gray-300">{lease.mac_address}</td>
                        <td className="py-3 px-4">
                          <span className={`px-2 py-1 rounded text-xs ${
                            lease.status === 'active' ? 'bg-green-500/20 text-green-400' : 'bg-gray-500/20 text-gray-400'
                          }`}>
                            {lease.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {activeTab === 1 && (
        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>WiFi Networks</CardTitle>
              <Button>
                <Plus className="w-4 h-4 mr-2" />
                Add Network
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-700">
                    <th className="text-left py-3 px-4 text-gray-300">SSID</th>
                    <th className="text-left py-3 px-4 text-gray-300">Security</th>
                    <th className="text-left py-3 px-4 text-gray-300">Type</th>
                    <th className="text-left py-3 px-4 text-gray-300">Status</th>
                    <th className="text-left py-3 px-4 text-gray-300">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {wifiNetworks.map((network) => (
                    <tr key={network.id} className="border-b border-gray-800">
                      <td className="py-3 px-4 font-medium text-white">{network.ssid}</td>
                      <td className="py-3 px-4">
                        <span className="px-2 py-1 bg-blue-500/20 text-blue-400 rounded text-xs">
                          {network.security_type.toUpperCase()}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <span className={`px-2 py-1 rounded text-xs ${
                          network.is_guest ? 'bg-yellow-500/20 text-yellow-400' : 'bg-purple-500/20 text-purple-400'
                        }`}>
                          {network.is_guest ? 'Guest' : 'Main'}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <span className={`px-2 py-1 rounded text-xs ${
                          network.is_enabled ? 'bg-green-500/20 text-green-400' : 'bg-gray-500/20 text-gray-400'
                        }`}>
                          {network.is_enabled ? 'Active' : 'Disabled'}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex space-x-2">
                          <Button size="sm" variant="outline">
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button size="sm" variant="outline">
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      {activeTab === 2 && (
        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>VLAN Configuration</CardTitle>
              <Button>
                <Plus className="w-4 h-4 mr-2" />
                Add VLAN
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-center py-8">
              <Network className="w-16 h-16 text-gray-500 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-white mb-2">VLAN Management</h3>
              <p className="text-gray-400 mb-4">
                Configure and manage Virtual LANs for network segmentation.
              </p>
              <Button>
                Create First VLAN
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {activeTab === 3 && (
        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>Network Device Discovery</CardTitle>
              <Button onClick={scanNetwork} disabled={isLoading}>
                {isLoading ? (
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Search className="w-4 h-4 mr-2" />
                )}
                {isLoading ? 'Scanning...' : 'Scan Network'}
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="text-center py-8">
                <RefreshCw className="w-8 h-8 animate-spin mx-auto mb-4 text-blue-400" />
                <p className="text-gray-400">Scanning network for active devices...</p>
              </div>
            ) : networkDevices.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-700">
                      <th className="text-left py-3 px-4 text-gray-300">Device</th>
                      <th className="text-left py-3 px-4 text-gray-300">IP Address</th>
                      <th className="text-left py-3 px-4 text-gray-300">MAC Address</th>
                      <th className="text-left py-3 px-4 text-gray-300">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {networkDevices.map((device) => (
                      <tr key={device.id} className="border-b border-gray-800">
                        <td className="py-3 px-4">
                          <div>
                            <p className="font-medium text-white">{device.hostname}</p>
                            <p className="text-sm text-gray-400 capitalize">{device.device_type}</p>
                          </div>
                        </td>
                        <td className="py-3 px-4 font-mono text-white">{device.ip_address}</td>
                        <td className="py-3 px-4 font-mono text-sm text-gray-300">{device.mac_address}</td>
                        <td className="py-3 px-4">
                          <span className={`px-2 py-1 rounded text-xs ${
                            device.online ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'
                          }`}>
                            {device.online ? 'Online' : 'Offline'}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="text-center py-8">
                <Search className="w-16 h-16 text-gray-500 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-white mb-2">Network Discovery</h3>
                <p className="text-gray-400 mb-4">
                  Scan your network to discover connected devices and their information.
                </p>
                <Button onClick={scanNetwork}>
                  <Search className="w-4 h-4 mr-2" />
                  Start Network Scan
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}

export default NetworkManagement;