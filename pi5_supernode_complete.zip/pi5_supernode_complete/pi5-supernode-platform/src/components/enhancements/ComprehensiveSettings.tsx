import React, { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Settings,
  Shield,
  Database,
  Code,
  Users,
  Cpu,
  HardDrive,
  Thermometer,
  Activity,
  Download,
  Upload,
  RefreshCw,
  Save,
  AlertTriangle,
  CheckCircle,
  X,
  Eye,
  EyeOff,
  Plus,
  Edit,
  Trash2,
  Key,
  Lock,
  Unlock,
  Monitor,
  Zap,
  FileText,
  Clock
} from 'lucide-react'
import { Button } from '../ui/button'
import { Card, CardHeader, CardTitle, CardContent } from '../ui/card'
import { supabase } from '@/lib/supabase'
import { cn } from '@/lib/utils'

interface SystemStatus {
  cpu_usage: number
  memory_usage: number
  storage_usage: number
  temperature: number
  uptime: number
  network_rx: number
  network_tx: number
}

interface User {
  id: string
  email: string
  role: string
  status: string
  last_login: string | null
  created_at: string
}

interface Backup {
  id: string
  name: string
  description: string
  created_at: string
  size_bytes: number
  snapshot_data: any
}

export const ComprehensiveSettings: React.FC = () => {
  const [activeTab, setActiveTab] = useState('system')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [systemStatus, setSystemStatus] = useState<SystemStatus | null>(null)
  const [users, setUsers] = useState<User[]>([])
  const [backups, setBackups] = useState<Backup[]>([])
  const [showPassword, setShowPassword] = useState(false)
  const [showCreateUser, setShowCreateUser] = useState(false)
  
  // Settings state
  const [systemSettings, setSystemSettings] = useState<any>({})
  const [securitySettings, setSecuritySettings] = useState<any>({})
  const [advancedSettings, setAdvancedSettings] = useState<any>({})
  const [newUser, setNewUser] = useState({ email: '', role: 'user', password: '' })
  
  useEffect(() => {
    loadInitialData()
  }, [])
  
  useEffect(() => {
    if (activeTab === 'system') {
      loadSystemData()
    } else if (activeTab === 'security') {
      loadSecurityData()
    } else if (activeTab === 'backup') {
      loadBackupData()
    } else if (activeTab === 'users') {
      loadUserData()
    } else if (activeTab === 'advanced') {
      loadAdvancedData()
    }
  }, [activeTab])

  const loadInitialData = async () => {
    try {
      setLoading(true)
      const { data, error } = await supabase.functions.invoke('comprehensive-settings-management', {
        body: { action: 'get_system_settings' }
      })

      if (error) throw error
      setSystemSettings(data.data.settings)
      setSystemStatus(data.data.system_status)
    } catch (error) {
      console.error('Error loading initial data:', error)
      setError('Failed to load system data')
    } finally {
      setLoading(false)
    }
  }

  const loadSystemData = async () => {
    // System data already loaded in loadInitialData
  }

  const loadSecurityData = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('comprehensive-settings-management', {
        body: { action: 'get_security_policies' }
      })

      if (error) throw error
      setSecuritySettings(data.data.policies || [])
    } catch (error) {
      console.error('Error loading security data:', error)
    }
  }

  const loadBackupData = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('comprehensive-settings-management', {
        body: { action: 'get_backups' }
      })

      if (error) throw error
      setBackups(data.data.backups || [])
    } catch (error) {
      console.error('Error loading backup data:', error)
    }
  }

  const loadUserData = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('comprehensive-settings-management', {
        body: { action: 'get_user_accounts' }
      })

      if (error) throw error
      setUsers(data.data.users || [])
    } catch (error) {
      console.error('Error loading user data:', error)
    }
  }

  const loadAdvancedData = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('comprehensive-settings-management', {
        body: { action: 'get_advanced_settings' }
      })

      if (error) throw error
      setAdvancedSettings(data.data.advanced_settings || {})
    } catch (error) {
      console.error('Error loading advanced data:', error)
    }
  }

  const saveSystemSettings = async () => {
    try {
      setLoading(true)
      const { data, error } = await supabase.functions.invoke('comprehensive-settings-management', {
        body: {
          action: 'update_system_settings',
          settings: systemSettings
        }
      })

      if (error) throw error
      setError(null)
      // Show success message
    } catch (error) {
      console.error('Error saving settings:', error)
      setError('Failed to save system settings')
    } finally {
      setLoading(false)
    }
  }

  const createBackup = async (type: string) => {
    try {
      setLoading(true)
      const { data, error } = await supabase.functions.invoke('comprehensive-settings-management', {
        body: {
          action: 'create_backup',
          backup_type: type,
          include_settings: true,
          include_rules: true
        }
      })

      if (error) throw error
      await loadBackupData() // Refresh backup list
    } catch (error) {
      console.error('Error creating backup:', error)
      setError('Failed to create backup')
    } finally {
      setLoading(false)
    }
  }

  const createUser = async () => {
    try {
      setLoading(true)
      const { data, error } = await supabase.functions.invoke('comprehensive-settings-management', {
        body: {
          action: 'create_user',
          ...newUser
        }
      })

      if (error) throw error
      setShowCreateUser(false)
      setNewUser({ email: '', role: 'user', password: '' })
      await loadUserData() // Refresh user list
    } catch (error) {
      console.error('Error creating user:', error)
      setError('Failed to create user')
    } finally {
      setLoading(false)
    }
  }

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 Bytes'
    const k = 1024
    const sizes = ['Bytes', 'KB', 'MB', 'GB']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
  }

  const formatUptime = (seconds: number) => {
    const days = Math.floor(seconds / 86400)
    const hours = Math.floor((seconds % 86400) / 3600)
    const minutes = Math.floor((seconds % 3600) / 60)
    return `${days}d ${hours}h ${minutes}m`
  }

  const tabs = [
    { id: 'system', label: 'System', icon: Settings },
    { id: 'security', label: 'Security', icon: Shield },
    { id: 'backup', label: 'Backup/Restore', icon: Database },
    { id: 'advanced', label: 'Advanced', icon: Code },
    { id: 'users', label: 'User Management', icon: Users }
  ]

  const renderSystemTab = () => (
    <div className="space-y-6">
      {/* System Status */}
      {systemStatus && (
        <Card className="bg-white/5 border-white/10">
          <CardHeader>
            <CardTitle className="text-white flex items-center space-x-2">
              <Monitor className="h-5 w-5" />
              <span>System Status</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center">
                <Cpu className="h-8 w-8 mx-auto text-blue-400 mb-2" />
                <div className="text-2xl font-bold text-white">{systemStatus.cpu_usage.toFixed(1)}%</div>
                <div className="text-sm text-gray-400">CPU Usage</div>
              </div>
              
              <div className="text-center">
                <Activity className="h-8 w-8 mx-auto text-green-400 mb-2" />
                <div className="text-2xl font-bold text-white">{systemStatus.memory_usage.toFixed(1)}%</div>
                <div className="text-sm text-gray-400">Memory</div>
              </div>
              
              <div className="text-center">
                <HardDrive className="h-8 w-8 mx-auto text-yellow-400 mb-2" />
                <div className="text-2xl font-bold text-white">{systemStatus.storage_usage.toFixed(1)}%</div>
                <div className="text-sm text-gray-400">Storage</div>
              </div>
              
              <div className="text-center">
                <Thermometer className="h-8 w-8 mx-auto text-red-400 mb-2" />
                <div className="text-2xl font-bold text-white">{systemStatus.temperature.toFixed(1)}°C</div>
                <div className="text-sm text-gray-400">Temperature</div>
              </div>
            </div>
            
            <div className="mt-6 pt-6 border-t border-white/10">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                <div>
                  <span className="text-gray-400">Uptime:</span>
                  <span className="ml-2 text-white font-medium">{formatUptime(systemStatus.uptime)}</span>
                </div>
                <div>
                  <span className="text-gray-400">Network RX:</span>
                  <span className="ml-2 text-white font-medium">{formatBytes(systemStatus.network_rx)}</span>
                </div>
                <div>
                  <span className="text-gray-400">Network TX:</span>
                  <span className="ml-2 text-white font-medium">{formatBytes(systemStatus.network_tx)}</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
      
      {/* System Configuration */}
      <Card className="bg-white/5 border-white/10">
        <CardHeader>
          <CardTitle className="text-white">System Configuration</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                System Hostname
              </label>
              <input
                type="text"
                value={systemSettings.hostname || 'pi5-supernode'}
                onChange={(e) => setSystemSettings(prev => ({ ...prev, hostname: e.target.value }))}
                className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Time Zone
              </label>
              <select
                value={systemSettings.timezone || 'UTC'}
                onChange={(e) => setSystemSettings(prev => ({ ...prev, timezone: e.target.value }))}
                className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
              >
                <option value="UTC">UTC</option>
                <option value="America/New_York">Eastern Time</option>
                <option value="America/Chicago">Central Time</option>
                <option value="America/Denver">Mountain Time</option>
                <option value="America/Los_Angeles">Pacific Time</option>
                <option value="Europe/London">GMT</option>
                <option value="Europe/Paris">CET</option>
              </select>
            </div>
          </div>
          
          <div className="space-y-3">
            <label className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={systemSettings.auto_updates || false}
                onChange={(e) => setSystemSettings(prev => ({ ...prev, auto_updates: e.target.checked }))}
                className="rounded border-white/10 bg-white/5 text-enterprise-neon focus:ring-enterprise-neon"
              />
              <span className="text-gray-300">Enable Automatic Updates</span>
            </label>
            
            <label className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={systemSettings.monitoring_enabled || true}
                onChange={(e) => setSystemSettings(prev => ({ ...prev, monitoring_enabled: e.target.checked }))}
                className="rounded border-white/10 bg-white/5 text-enterprise-neon focus:ring-enterprise-neon"
              />
              <span className="text-gray-300">Enable System Monitoring</span>
            </label>
            
            <label className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={systemSettings.log_retention || true}
                onChange={(e) => setSystemSettings(prev => ({ ...prev, log_retention: e.target.checked }))}
                className="rounded border-white/10 bg-white/5 text-enterprise-neon focus:ring-enterprise-neon"
              />
              <span className="text-gray-300">Enable Log Retention (30 days)</span>
            </label>
          </div>
          
          <div className="flex justify-end pt-4">
            <Button onClick={saveSystemSettings} disabled={loading}>
              {loading ? (
                <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <Save className="h-4 w-4 mr-2" />
              )}
              Save Settings
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )

  const renderSecurityTab = () => (
    <div className="space-y-6">
      <Card className="bg-white/5 border-white/10">
        <CardHeader>
          <CardTitle className="text-white flex items-center space-x-2">
            <Shield className="h-5 w-5" />
            <span>Security Policies</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-4">
            <div>
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={true}
                  className="rounded border-white/10 bg-white/5 text-enterprise-neon focus:ring-enterprise-neon"
                />
                <span className="text-gray-300">Enable Firewall</span>
              </label>
              <p className="text-sm text-gray-500 ml-6">Block unauthorized incoming connections</p>
            </div>
            
            <div>
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={true}
                  className="rounded border-white/10 bg-white/5 text-enterprise-neon focus:ring-enterprise-neon"
                />
                <span className="text-gray-300">Enable Intrusion Detection</span>
              </label>
              <p className="text-sm text-gray-500 ml-6">Monitor and detect suspicious activities</p>
            </div>
            
            <div>
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={false}
                  className="rounded border-white/10 bg-white/5 text-enterprise-neon focus:ring-enterprise-neon"
                />
                <span className="text-gray-300">Enable SSH Access</span>
              </label>
              <p className="text-sm text-gray-500 ml-6">Allow remote SSH connections (security risk)</p>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Session Timeout (minutes)
              </label>
              <input
                type="number"
                value={30}
                min={5}
                max={1440}
                className="w-32 px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Maximum Login Attempts
              </label>
              <input
                type="number"
                value={5}
                min={1}
                max={10}
                className="w-32 px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
              />
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Card className="bg-white/5 border-white/10">
        <CardHeader>
          <CardTitle className="text-white flex items-center space-x-2">
            <Key className="h-5 w-5" />
            <span>Access Control</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Admin Password Policy
            </label>
            <div className="space-y-2">
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={true}
                  className="rounded border-white/10 bg-white/5 text-enterprise-neon focus:ring-enterprise-neon"
                />
                <span className="text-gray-300">Require 12+ characters</span>
              </label>
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={true}
                  className="rounded border-white/10 bg-white/5 text-enterprise-neon focus:ring-enterprise-neon"
                />
                <span className="text-gray-300">Require special characters</span>
              </label>
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={false}
                  className="rounded border-white/10 bg-white/5 text-enterprise-neon focus:ring-enterprise-neon"
                />
                <span className="text-gray-300">Require password change every 90 days</span>
              </label>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )

  const renderBackupTab = () => (
    <div className="space-y-6">
      <Card className="bg-white/5 border-white/10">
        <CardHeader>
          <CardTitle className="text-white flex items-center space-x-2">
            <Database className="h-5 w-5" />
            <span>Create Backup</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Button
              onClick={() => createBackup('configuration')}
              disabled={loading}
              className="flex flex-col items-center p-6 h-auto"
              variant="outline"
            >
              <Settings className="h-8 w-8 mb-2" />
              <span className="font-medium">Configuration Only</span>
              <span className="text-sm text-gray-400 mt-1">Settings and rules</span>
            </Button>
            
            <Button
              onClick={() => createBackup('partial')}
              disabled={loading}
              className="flex flex-col items-center p-6 h-auto"
              variant="outline"
            >
              <Shield className="h-8 w-8 mb-2" />
              <span className="font-medium">Partial Backup</span>
              <span className="text-sm text-gray-400 mt-1">Config + user data</span>
            </Button>
            
            <Button
              onClick={() => createBackup('full')}
              disabled={loading}
              className="flex flex-col items-center p-6 h-auto"
            >
              <Database className="h-8 w-8 mb-2" />
              <span className="font-medium">Full System</span>
              <span className="text-sm text-gray-400 mt-1">Complete backup</span>
            </Button>
          </div>
        </CardContent>
      </Card>
      
      <Card className="bg-white/5 border-white/10">
        <CardHeader>
          <CardTitle className="text-white">Backup History</CardTitle>
        </CardHeader>
        <CardContent>
          {backups.length === 0 ? (
            <div className="text-center py-8">
              <Database className="h-12 w-12 mx-auto text-gray-400 mb-4" />
              <p className="text-gray-400">No backups found</p>
              <p className="text-sm text-gray-500 mt-1">Create your first backup above</p>
            </div>
          ) : (
            <div className="space-y-3">
              {backups.map((backup) => (
                <div key={backup.id} className="bg-white/5 rounded-lg p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium text-white">{backup.name}</h4>
                      <p className="text-sm text-gray-400">{backup.description}</p>
                      <div className="flex items-center space-x-4 mt-2 text-xs text-gray-500">
                        <span>Size: {formatBytes(backup.size_bytes)}</span>
                        <span>Created: {new Date(backup.created_at).toLocaleDateString()}</span>
                      </div>
                    </div>
                    <div className="flex space-x-2">
                      <Button size="sm" variant="outline">
                        <Download className="h-4 w-4" />
                      </Button>
                      <Button size="sm" variant="outline">
                        <Upload className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )

  const renderUserTab = () => (
    <div className="space-y-6">
      <Card className="bg-white/5 border-white/10">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-white flex items-center space-x-2">
              <Users className="h-5 w-5" />
              <span>User Accounts</span>
            </CardTitle>
            <Button onClick={() => setShowCreateUser(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Add User
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {users.map((user) => (
              <div key={user.id} className="bg-white/5 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium text-white">{user.email}</h4>
                    <div className="flex items-center space-x-4 mt-1">
                      <span className={cn(
                        "px-2 py-1 rounded-full text-xs font-medium",
                        user.role === 'administrator' 
                          ? "bg-red-500/20 text-red-300 border border-red-500/30"
                          : "bg-blue-500/20 text-blue-300 border border-blue-500/30"
                      )}>
                        {user.role}
                      </span>
                      <span className={cn(
                        "px-2 py-1 rounded-full text-xs font-medium",
                        user.status === 'active'
                          ? "bg-green-500/20 text-green-300 border border-green-500/30"
                          : "bg-gray-500/20 text-gray-300 border border-gray-500/30"
                      )}>
                        {user.status}
                      </span>
                      <span className="text-xs text-gray-500">
                        Last login: {user.last_login ? new Date(user.last_login).toLocaleDateString() : 'Never'}
                      </span>
                    </div>
                  </div>
                  <div className="flex space-x-2">
                    <Button size="sm" variant="outline">
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="outline">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
      
      {/* Create User Modal */}
      <AnimatePresence>
        {showCreateUser && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-gray-900/95 backdrop-blur-sm border border-white/10 rounded-xl p-6 w-full max-w-md"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-white">Add New User</h3>
                <button 
                  onClick={() => setShowCreateUser(false)}
                  className="text-gray-400 hover:text-white"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Email Address
                  </label>
                  <input
                    type="email"
                    value={newUser.email}
                    onChange={(e) => setNewUser(prev => ({ ...prev, email: e.target.value }))}
                    className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
                    placeholder="user@example.com"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Role
                  </label>
                  <select
                    value={newUser.role}
                    onChange={(e) => setNewUser(prev => ({ ...prev, role: e.target.value }))}
                    className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
                  >
                    <option value="user">User</option>
                    <option value="administrator">Administrator</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Password
                  </label>
                  <div className="relative">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={newUser.password}
                      onChange={(e) => setNewUser(prev => ({ ...prev, password: e.target.value }))}
                      className="w-full px-3 py-2 pr-10 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
                      placeholder="Strong password"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-white"
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </div>
              </div>

              <div className="flex space-x-3 mt-6">
                <Button 
                  onClick={createUser}
                  disabled={!newUser.email || !newUser.password || loading}
                  className="flex-1"
                >
                  {loading ? (
                    <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <Plus className="h-4 w-4 mr-2" />
                  )}
                  Create User
                </Button>
                <Button 
                  variant="outline"
                  onClick={() => setShowCreateUser(false)}
                >
                  Cancel
                </Button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )

  const renderAdvancedTab = () => (
    <div className="space-y-6">
      <Card className="bg-white/5 border-white/10">
        <CardHeader>
          <CardTitle className="text-white flex items-center space-x-2">
            <Code className="h-5 w-5" />
            <span>API & Developer Settings</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={advancedSettings.api_access?.enabled || false}
                className="rounded border-white/10 bg-white/5 text-enterprise-neon focus:ring-enterprise-neon"
              />
              <span className="text-gray-300">Enable REST API Access</span>
            </label>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              API Rate Limit (requests/hour)
            </label>
            <input
              type="number"
              value={advancedSettings.api_access?.rate_limit || 1000}
              className="w-32 px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
            />
          </div>
          
          <div>
            <label className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={advancedSettings.experimental?.debug_mode || false}
                className="rounded border-white/10 bg-white/5 text-enterprise-neon focus:ring-enterprise-neon"
              />
              <span className="text-gray-300">Enable Debug Mode</span>
            </label>
          </div>
        </CardContent>
      </Card>
      
      <Card className="bg-white/5 border-white/10">
        <CardHeader>
          <CardTitle className="text-white flex items-center space-x-2">
            <Zap className="h-5 w-5" />
            <span>Performance Optimization</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              CPU Governor
            </label>
            <select
              value={advancedSettings.performance?.cpu_governor || 'ondemand'}
              className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
            >
              <option value="ondemand">On-demand (Balanced)</option>
              <option value="performance">Performance (High power)</option>
              <option value="powersave">Power Save (Low power)</option>
              <option value="conservative">Conservative</option>
            </select>
          </div>
          
          <div>
            <label className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={advancedSettings.performance?.memory_optimization || false}
                className="rounded border-white/10 bg-white/5 text-enterprise-neon focus:ring-enterprise-neon"
              />
              <span className="text-gray-300">Enable Memory Optimization</span>
            </label>
          </div>
          
          <div>
            <label className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={advancedSettings.experimental?.hardware_acceleration || false}
                className="rounded border-white/10 bg-white/5 text-enterprise-neon focus:ring-enterprise-neon"
              />
              <span className="text-gray-300">Enable Hardware Acceleration (Experimental)</span>
            </label>
          </div>
        </CardContent>
      </Card>
      
      <Card className="bg-white/5 border-white/10">
        <CardHeader>
          <CardTitle className="text-white flex items-center space-x-2">
            <FileText className="h-5 w-5" />
            <span>Logging & Monitoring</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Log Level
            </label>
            <select
              value={advancedSettings.logging?.level || 'info'}
              className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
            >
              <option value="debug">Debug (Verbose)</option>
              <option value="info">Info (Standard)</option>
              <option value="warning">Warning (Minimal)</option>
              <option value="error">Error (Critical only)</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Log Retention (days)
            </label>
            <input
              type="number"
              value={advancedSettings.logging?.retention_days || 30}
              min={1}
              max={365}
              className="w-32 px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
            />
          </div>
        </CardContent>
      </Card>
    </div>
  )

  const renderTabContent = () => {
    switch (activeTab) {
      case 'system':
        return renderSystemTab()
      case 'security':
        return renderSecurityTab()
      case 'backup':
        return renderBackupTab()
      case 'users':
        return renderUserTab()
      case 'advanced':
        return renderAdvancedTab()
      default:
        return renderSystemTab()
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white flex items-center space-x-2">
            <Settings className="h-6 w-6 text-enterprise-neon" />
            <span>System Settings</span>
          </h2>
          <p className="text-gray-400 mt-1">
            Configure system, security, backup, and advanced settings
          </p>
        </div>
      </div>

      {/* Error Display */}
      {error && (
        <div className="bg-red-900/20 border border-red-500/50 rounded-lg p-4">
          <div className="flex items-center space-x-2 text-red-400">
            <AlertTriangle className="h-5 w-5" />
            <span>{error}</span>
            <button 
              onClick={() => setError(null)}
              className="ml-auto hover:text-red-300"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>
      )}

      {/* Tab Navigation */}
      <Card className="bg-white/5 border-white/10">
        <CardHeader>
          <div className="flex space-x-1 bg-gray-800 p-1 rounded-lg">
            {tabs.map((tab) => {
              const Icon = tab.icon
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={cn(
                    'flex items-center space-x-2 px-4 py-2 rounded-md text-sm font-medium transition-all',
                    activeTab === tab.id
                      ? 'bg-enterprise-neon text-enterprise-dark'
                      : 'text-gray-400 hover:text-white hover:bg-white/5'
                  )}
                >
                  <Icon className="h-4 w-4" />
                  <span>{tab.label}</span>
                </button>
              )
            })}
          </div>
        </CardHeader>
        
        <CardContent>
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
            >
              {renderTabContent()}
            </motion.div>
          </AnimatePresence>
        </CardContent>
      </Card>
    </div>
  )
}