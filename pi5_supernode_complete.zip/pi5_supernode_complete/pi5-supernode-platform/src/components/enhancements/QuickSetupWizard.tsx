import React, { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Wifi,
  Network,
  Shield,
  Settings,
  CheckCircle,
  ArrowRight,
  ArrowLeft,
  Play,
  RefreshCw,
  AlertTriangle,
  Globe,
  Router,
  Zap,
  Eye,
  EyeOff,
  Download,
  Upload
} from 'lucide-react'
import { Button } from '../ui/button'
import { Card, CardHeader, CardTitle, CardContent } from '../ui/card'
import { supabase } from '@/lib/supabase'
import { cn } from '@/lib/utils'

interface SetupStep {
  id: string
  title: string
  description: string
  component: React.ComponentType<any>
  icon: React.ComponentType<any>
}

interface NetworkInterface {
  name: string
  type: string
  status: string
  ip?: string
  gateway?: string
  dns?: string[]
}

interface SetupConfiguration {
  profile_id?: string
  wan: {
    type: string
    interface: string
    static_config?: {
      ip: string
      netmask: string
      gateway: string
      dns: string[]
    }
    pppoe_config?: {
      username: string
      password: string
    }
    backup_connection?: boolean
  }
  lan: {
    subnet: string
    dhcp_enabled: boolean
    dhcp_range: {
      start: string
      end: string
    }
  }
  wifi: {
    enabled: boolean
    ssid: string
    password: string
    security: string
    channel: number
    guest_network: boolean
  }
  security: {
    firewall_enabled: boolean
    vpn_enabled: boolean
    default_passwords: boolean
  }
  advanced: {
    reboot_after_setup: boolean
    enable_monitoring: boolean
    auto_updates: boolean
  }
}

export const QuickSetupWizard: React.FC = () => {
  const [currentStep, setCurrentStep] = useState(0)
  const [networkData, setNetworkData] = useState<any>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [setupComplete, setSetupComplete] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const [validationResults, setValidationResults] = useState<any>(null)
  
  const [configuration, setConfiguration] = useState<SetupConfiguration>({
    wan: {
      type: 'dhcp',
      interface: 'eth0'
    },
    lan: {
      subnet: '192.168.100.0/24',
      dhcp_enabled: true,
      dhcp_range: {
        start: '192.168.100.10',
        end: '192.168.100.200'
      }
    },
    wifi: {
      enabled: true,
      ssid: 'Pi5-Supernode',
      password: 'SuperSecure123!',
      security: 'WPA3',
      channel: 6,
      guest_network: false
    },
    security: {
      firewall_enabled: true,
      vpn_enabled: false,
      default_passwords: false
    },
    advanced: {
      reboot_after_setup: true,
      enable_monitoring: true,
      auto_updates: true
    }
  })

  useEffect(() => {
    detectNetwork()
  }, [])

  const detectNetwork = async () => {
    try {
      setLoading(true)
      const { data, error } = await supabase.functions.invoke('quick-setup-system', {
        body: { action: 'detect_network' }
      })

      if (error) throw error
      setNetworkData(data.data)
      
      // Auto-configure based on detection
      if (data.data.suggested_config) {
        setConfiguration(prev => ({
          ...prev,
          wan: {
            ...prev.wan,
            type: data.data.suggested_config.wan_type
          },
          lan: {
            ...prev.lan,
            subnet: data.data.suggested_config.lan_subnet
          }
        }))
      }
    } catch (error) {
      console.error('Network detection failed:', error)
      setError('Failed to detect network configuration')
    } finally {
      setLoading(false)
    }
  }

  const validateConfiguration = async () => {
    try {
      setLoading(true)
      const { data, error } = await supabase.functions.invoke('quick-setup-system', {
        body: {
          action: 'execute_setup',
          configuration,
          validate_only: true
        }
      })

      if (error) throw error
      setValidationResults(data.data.validation_results)
      return data.data.validation_passed
    } catch (error) {
      console.error('Validation failed:', error)
      setError('Failed to validate configuration')
      return false
    } finally {
      setLoading(false)
    }
  }

  const executeSetup = async () => {
    try {
      setLoading(true)
      const { data, error } = await supabase.functions.invoke('quick-setup-system', {
        body: {
          action: 'execute_setup',
          configuration
        }
      })

      if (error) throw error
      setSetupComplete(true)
      return data.data
    } catch (error) {
      console.error('Setup execution failed:', error)
      setError('Failed to execute setup')
      return null
    } finally {
      setLoading(false)
    }
  }

  // Step Components
  const WelcomeStep = () => (
    <div className="text-center space-y-6">
      <div className="mx-auto w-16 h-16 bg-enterprise-neon/20 rounded-full flex items-center justify-center">
        <Zap className="h-8 w-8 text-enterprise-neon" />
      </div>
      <div>
        <h3 className="text-2xl font-bold text-white mb-2">Welcome to Pi5 Supernode Setup</h3>
        <p className="text-gray-400">
          This wizard will guide you through the initial configuration of your Pi5 Supernode system.
          The setup process typically takes 2-3 minutes.
        </p>
      </div>
      
      {networkData && (
        <div className="bg-white/5 rounded-lg p-4 space-y-3">
          <h4 className="font-medium text-white">Network Detection Results</h4>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-gray-400">Internet Connectivity:</span>
              <span className={cn(
                "ml-2 font-medium",
                networkData.internet_connectivity ? "text-green-400" : "text-red-400"
              )}>
                {networkData.internet_connectivity ? 'Connected' : 'Disconnected'}
              </span>
            </div>
            <div>
              <span className="text-gray-400">Gateway:</span>
              <span className="ml-2 font-mono text-white">
                {networkData.detected_gateway}
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  )

  const NetworkStep = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-xl font-bold text-white mb-2">Network Configuration</h3>
        <p className="text-gray-400">Configure your WAN and LAN settings</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* WAN Configuration */}
        <Card className="bg-white/5 border-white/10">
          <CardHeader>
            <CardTitle className="text-white flex items-center space-x-2">
              <Globe className="h-5 w-5" />
              <span>WAN Settings</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Connection Type
              </label>
              <select
                value={configuration.wan.type}
                onChange={(e) => setConfiguration(prev => ({
                  ...prev,
                  wan: { ...prev.wan, type: e.target.value }
                }))}
                className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
              >
                <option value="dhcp">DHCP (Automatic)</option>
                <option value="static">Static IP</option>
                <option value="pppoe">PPPoE</option>
              </select>
            </div>
            
            {configuration.wan.type === 'static' && (
              <div className="space-y-3">
                <input
                  type="text"
                  placeholder="IP Address (e.g., 192.168.1.100)"
                  className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
                />
                <input
                  type="text"
                  placeholder="Gateway (e.g., 192.168.1.1)"
                  className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
                />
              </div>
            )}
            
            {configuration.wan.type === 'pppoe' && (
              <div className="space-y-3">
                <input
                  type="text"
                  placeholder="Username"
                  className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
                />
                <input
                  type="password"
                  placeholder="Password"
                  className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
                />
              </div>
            )}
          </CardContent>
        </Card>
        
        {/* LAN Configuration */}
        <Card className="bg-white/5 border-white/10">
          <CardHeader>
            <CardTitle className="text-white flex items-center space-x-2">
              <Router className="h-5 w-5" />
              <span>LAN Settings</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                LAN Subnet
              </label>
              <select
                value={configuration.lan.subnet}
                onChange={(e) => setConfiguration(prev => ({
                  ...prev,
                  lan: { ...prev.lan, subnet: e.target.value }
                }))}
                className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
              >
                <option value="192.168.100.0/24">192.168.100.0/24</option>
                <option value="192.168.1.0/24">192.168.1.0/24</option>
                <option value="10.0.0.0/24">10.0.0.0/24</option>
                <option value="172.16.0.0/24">172.16.0.0/24</option>
              </select>
            </div>
            
            <div>
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={configuration.lan.dhcp_enabled}
                  onChange={(e) => setConfiguration(prev => ({
                    ...prev,
                    lan: { ...prev.lan, dhcp_enabled: e.target.checked }
                  }))}
                  className="rounded border-white/10 bg-white/5 text-enterprise-neon focus:ring-enterprise-neon"
                />
                <span className="text-gray-300">Enable DHCP Server</span>
              </label>
            </div>
            
            {configuration.lan.dhcp_enabled && (
              <div className="grid grid-cols-2 gap-3">
                <input
                  type="text"
                  value={configuration.lan.dhcp_range.start}
                  onChange={(e) => setConfiguration(prev => ({
                    ...prev,
                    lan: {
                      ...prev.lan,
                      dhcp_range: { ...prev.lan.dhcp_range, start: e.target.value }
                    }
                  }))}
                  placeholder="DHCP Start"
                  className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
                />
                <input
                  type="text"
                  value={configuration.lan.dhcp_range.end}
                  onChange={(e) => setConfiguration(prev => ({
                    ...prev,
                    lan: {
                      ...prev.lan,
                      dhcp_range: { ...prev.lan.dhcp_range, end: e.target.value }
                    }
                  }))}
                  placeholder="DHCP End"
                  className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
                />
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )

  const WiFiStep = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-xl font-bold text-white mb-2">WiFi Configuration</h3>
        <p className="text-gray-400">Set up your wireless network</p>
      </div>
      
      <Card className="bg-white/5 border-white/10">
        <CardHeader>
          <CardTitle className="text-white flex items-center space-x-2">
            <Wifi className="h-5 w-5" />
            <span>WiFi Settings</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={configuration.wifi.enabled}
                onChange={(e) => setConfiguration(prev => ({
                  ...prev,
                  wifi: { ...prev.wifi, enabled: e.target.checked }
                }))}
                className="rounded border-white/10 bg-white/5 text-enterprise-neon focus:ring-enterprise-neon"
              />
              <span className="text-gray-300">Enable WiFi Access Point</span>
            </label>
          </div>
          
          {configuration.wifi.enabled && (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Network Name (SSID)
                </label>
                <input
                  type="text"
                  value={configuration.wifi.ssid}
                  onChange={(e) => setConfiguration(prev => ({
                    ...prev,
                    wifi: { ...prev.wifi, ssid: e.target.value }
                  }))}
                  className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
                  placeholder="Pi5-Supernode"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  WiFi Password
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={configuration.wifi.password}
                    onChange={(e) => setConfiguration(prev => ({
                      ...prev,
                      wifi: { ...prev.wifi, password: e.target.value }
                    }))}
                    className="w-full px-3 py-2 pr-10 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
                    placeholder="Strong password (8+ characters)"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-white"
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Security
                  </label>
                  <select
                    value={configuration.wifi.security}
                    onChange={(e) => setConfiguration(prev => ({
                      ...prev,
                      wifi: { ...prev.wifi, security: e.target.value }
                    }))}
                    className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
                  >
                    <option value="WPA3">WPA3 (Recommended)</option>
                    <option value="WPA2">WPA2</option>
                    <option value="WPA">WPA</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Channel
                  </label>
                  <select
                    value={configuration.wifi.channel}
                    onChange={(e) => setConfiguration(prev => ({
                      ...prev,
                      wifi: { ...prev.wifi, channel: parseInt(e.target.value) }
                    }))}
                    className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
                  >
                    <option value={1}>1 (2.4GHz)</option>
                    <option value={6}>6 (2.4GHz)</option>
                    <option value={11}>11 (2.4GHz)</option>
                    <option value={36}>36 (5GHz)</option>
                    <option value={44}>44 (5GHz)</option>
                  </select>
                </div>
              </div>
              
              <div>
                <label className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    checked={configuration.wifi.guest_network}
                    onChange={(e) => setConfiguration(prev => ({
                      ...prev,
                      wifi: { ...prev.wifi, guest_network: e.target.checked }
                    }))}
                    className="rounded border-white/10 bg-white/5 text-enterprise-neon focus:ring-enterprise-neon"
                  />
                  <span className="text-gray-300">Enable Guest Network</span>
                </label>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )

  const SecurityStep = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-xl font-bold text-white mb-2">Security Configuration</h3>
        <p className="text-gray-400">Configure security and protection settings</p>
      </div>
      
      <Card className="bg-white/5 border-white/10">
        <CardHeader>
          <CardTitle className="text-white flex items-center space-x-2">
            <Shield className="h-5 w-5" />
            <span>Security Settings</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={configuration.security.firewall_enabled}
                onChange={(e) => setConfiguration(prev => ({
                  ...prev,
                  security: { ...prev.security, firewall_enabled: e.target.checked }
                }))}
                className="rounded border-white/10 bg-white/5 text-enterprise-neon focus:ring-enterprise-neon"
              />
              <span className="text-gray-300">Enable Firewall (Recommended)</span>
            </label>
            <p className="text-sm text-gray-500 ml-6">Blocks unauthorized incoming connections</p>
          </div>
          
          <div>
            <label className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={configuration.security.vpn_enabled}
                onChange={(e) => setConfiguration(prev => ({
                  ...prev,
                  security: { ...prev.security, vpn_enabled: e.target.checked }
                }))}
                className="rounded border-white/10 bg-white/5 text-enterprise-neon focus:ring-enterprise-neon"
              />
              <span className="text-gray-300">Enable VPN Server</span>
            </label>
            <p className="text-sm text-gray-500 ml-6">Allow secure remote access to your network</p>
          </div>
          
          <div>
            <label className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={!configuration.security.default_passwords}
                onChange={(e) => setConfiguration(prev => ({
                  ...prev,
                  security: { ...prev.security, default_passwords: !e.target.checked }
                }))}
                className="rounded border-white/10 bg-white/5 text-enterprise-neon focus:ring-enterprise-neon"
              />
              <span className="text-gray-300">Change Default Passwords (Recommended)</span>
            </label>
            <p className="text-sm text-gray-500 ml-6">Updates admin and system passwords for security</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )

  const ReviewStep = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-xl font-bold text-white mb-2">Review Configuration</h3>
        <p className="text-gray-400">Please review your settings before applying</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Configuration Summary */}
        <Card className="bg-white/5 border-white/10">
          <CardHeader>
            <CardTitle className="text-white">Configuration Summary</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-400">WAN Type:</span>
              <span className="text-white font-medium">{configuration.wan.type.toUpperCase()}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">LAN Subnet:</span>
              <span className="text-white font-mono">{configuration.lan.subnet}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">WiFi:</span>
              <span className="text-white">
                {configuration.wifi.enabled ? configuration.wifi.ssid : 'Disabled'}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Firewall:</span>
              <span className={cn(
                "font-medium",
                configuration.security.firewall_enabled ? "text-green-400" : "text-red-400"
              )}>
                {configuration.security.firewall_enabled ? 'Enabled' : 'Disabled'}
              </span>
            </div>
          </CardContent>
        </Card>
        
        {/* Validation Results */}
        {validationResults && (
          <Card className="bg-white/5 border-white/10">
            <CardHeader>
              <CardTitle className="text-white">Validation Results</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {Object.entries(validationResults).map(([key, result]: [string, any]) => (
                <div key={key} className="flex items-center justify-between">
                  <span className="text-gray-400 capitalize">
                    {key.replace('_', ' ')}
                  </span>
                  <div className="flex items-center space-x-2">
                    {result.valid ? (
                      <CheckCircle className="h-4 w-4 text-green-400" />
                    ) : (
                      <AlertTriangle className="h-4 w-4 text-red-400" />
                    )}
                    <span className={cn(
                      "text-sm",
                      result.valid ? "text-green-400" : "text-red-400"
                    )}>
                      {result.valid ? 'Valid' : 'Issues'}
                    </span>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        )}
      </div>
      
      {!validationResults && (
        <Button
          onClick={validateConfiguration}
          disabled={loading}
          className="w-full"
        >
          {loading ? (
            <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
          ) : (
            <CheckCircle className="h-4 w-4 mr-2" />
          )}
          Validate Configuration
        </Button>
      )}
    </div>
  )

  const SetupExecutionStep = () => (
    <div className="space-y-6">
      <div className="text-center">
        <h3 className="text-xl font-bold text-white mb-2">Setup Execution</h3>
        <p className="text-gray-400">Applying your configuration...</p>
      </div>
      
      {setupComplete ? (
        <div className="text-center space-y-4">
          <div className="mx-auto w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center">
            <CheckCircle className="h-8 w-8 text-green-400" />
          </div>
          <div>
            <h4 className="text-lg font-medium text-white mb-2">Setup Complete!</h4>
            <p className="text-gray-400">
              Your Pi5 Supernode has been successfully configured.
            </p>
          </div>
          <div className="bg-white/5 rounded-lg p-4">
            <h5 className="font-medium text-white mb-2">What's Next?</h5>
            <ul className="text-sm text-gray-400 space-y-1">
              <li>• Access your network using the configured WiFi</li>
              <li>• Visit the admin panel to make advanced configurations</li>
              <li>• Set up VPN clients for remote access</li>
              <li>• Configure traffic rules for optimal performance</li>
            </ul>
          </div>
        </div>
      ) : (
        <div className="space-y-4">
          <div className="text-center">
            <RefreshCw className="h-12 w-12 mx-auto text-enterprise-neon animate-spin mb-4" />
            <p className="text-white">Configuring your system...</p>
          </div>
          
          <div className="space-y-2">
            {[
              'Network interfaces',
              'WAN configuration',
              'LAN configuration',
              'WiFi setup',
              'Security configuration',
              'Service restart'
            ].map((step, index) => (
              <div key={step} className="flex items-center space-x-3">
                <div className="w-6 h-6 rounded-full bg-enterprise-neon/20 flex items-center justify-center">
                  <div className="w-2 h-2 rounded-full bg-enterprise-neon animate-pulse" />
                </div>
                <span className="text-gray-300">{step}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )

  const steps: SetupStep[] = [
    {
      id: 'welcome',
      title: 'Welcome',
      description: 'Introduction and network detection',
      component: WelcomeStep,
      icon: Zap
    },
    {
      id: 'network',
      title: 'Network',
      description: 'WAN and LAN configuration',
      component: NetworkStep,
      icon: Network
    },
    {
      id: 'wifi',
      title: 'WiFi',
      description: 'Wireless network setup',
      component: WiFiStep,
      icon: Wifi
    },
    {
      id: 'security',
      title: 'Security',
      description: 'Security and protection settings',
      component: SecurityStep,
      icon: Shield
    },
    {
      id: 'review',
      title: 'Review',
      description: 'Review and validate configuration',
      component: ReviewStep,
      icon: CheckCircle
    },
    {
      id: 'execute',
      title: 'Execute',
      description: 'Apply configuration',
      component: SetupExecutionStep,
      icon: Play
    }
  ]

  const handleNext = async () => {
    if (currentStep === steps.length - 2) {
      // Execute setup on the last step
      const result = await executeSetup()
      if (result) {
        setCurrentStep(currentStep + 1)
      }
    } else {
      setCurrentStep(currentStep + 1)
    }
  }

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1)
    }
  }

  const CurrentStepComponent = steps[currentStep].component

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Progress Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white">Quick Setup Wizard</h2>
          <p className="text-gray-400">Step {currentStep + 1} of {steps.length}</p>
        </div>
        
        {/* Progress Bar */}
        <div className="flex items-center space-x-2">
          {steps.map((step, index) => {
            const Icon = step.icon
            return (
              <div
                key={step.id}
                className={cn(
                  "flex items-center justify-center w-8 h-8 rounded-full transition-colors",
                  index <= currentStep
                    ? "bg-enterprise-neon text-black"
                    : "bg-white/10 text-gray-400"
                )}
              >
                <Icon className="h-4 w-4" />
              </div>
            )
          })}
        </div>
      </div>

      {/* Step Content */}
      <Card className="bg-white/5 border-white/10">
        <CardHeader>
          <CardTitle className="text-white">
            {steps[currentStep].title} - {steps[currentStep].description}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <AnimatePresence mode="wait">
            <motion.div
              key={currentStep}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
            >
              <CurrentStepComponent />
            </motion.div>
          </AnimatePresence>
        </CardContent>
      </Card>

      {/* Error Display */}
      {error && (
        <div className="bg-red-900/20 border border-red-500/50 rounded-lg p-4">
          <div className="flex items-center space-x-2 text-red-400">
            <AlertTriangle className="h-5 w-5" />
            <span>{error}</span>
          </div>
        </div>
      )}

      {/* Navigation */}
      <div className="flex justify-between">
        <Button
          variant="outline"
          onClick={handlePrevious}
          disabled={currentStep === 0 || loading}
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Previous
        </Button>
        
        <Button
          onClick={handleNext}
          disabled={loading || setupComplete || (currentStep === steps.length - 1)}
        >
          {loading ? (
            <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
          ) : currentStep === steps.length - 2 ? (
            <Play className="h-4 w-4 mr-2" />
          ) : (
            <ArrowRight className="h-4 w-4 mr-2" />
          )}
          {currentStep === steps.length - 2 ? 'Execute Setup' : 'Next'}
        </Button>
      </div>
    </div>
  )
}