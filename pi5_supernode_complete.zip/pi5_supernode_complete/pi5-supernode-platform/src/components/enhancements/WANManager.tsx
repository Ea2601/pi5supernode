import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  Wifi,
  Server,
  BarChart3,
  Settings,
  Plus,
  RefreshCw,
  Play,
  Edit,
  Trash2,
} from 'lucide-react';

interface WANInterface {
  id: string;
  name: string;
  interface_name: string;
  connection_type: string;
  priority: number;
  weight: number;
  is_enabled: boolean;
  is_primary: boolean;
}

export function WANManager() {
  const [activeTab, setActiveTab] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const [wanInterfaces, setWanInterfaces] = useState<WANInterface[]>([]);
  const [wanStatus, setWanStatus] = useState<any>(null);

  const tabs = [
    { label: 'Interfaces', icon: Wifi },
    { label: 'Load Balancing', icon: BarChart3 },
    { label: 'Monitoring', icon: Server },
    { label: 'Advanced', icon: Settings },
  ];

  useEffect(() => {
    loadWANData();
  }, []);

  const loadWANData = async () => {
    setIsLoading(true);
    try {
      const [interfacesResponse, statusResponse] = await Promise.all([
        fetch('/functions/v1/comprehensive-wan-manager/wan-interfaces'),
        fetch('/functions/v1/comprehensive-wan-manager/wan-status'),
      ]);
      
      const interfacesResult = await interfacesResponse.json();
      const statusResult = await statusResponse.json();
      
      if (interfacesResult.data) {
        setWanInterfaces(interfacesResult.data);
      }
      if (statusResult.data) {
        setWanStatus(statusResult.data);
      }
    } catch (error) {
      console.error('Failed to load WAN data:', error);
    }
    setIsLoading(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white mb-2">Multi-WAN Management</h2>
          <p className="text-gray-400">Configure and monitor multiple WAN connections with load balancing and failover</p>
        </div>
        <div className="flex items-center space-x-3">
          <Button onClick={loadWANData} disabled={isLoading}>
            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh
          </Button>
          <Button>
            <Plus className="w-4 h-4 mr-2" />
            Add WAN
          </Button>
        </div>
      </div>

      {/* Overview Cards */}
      {wanStatus && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <div>
                  <p className="text-sm text-gray-400">Total Interfaces</p>
                  <p className="text-2xl font-bold text-white">{wanStatus.total_interfaces}</p>
                </div>
                <Server className="h-8 w-8 text-blue-500 ml-auto" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <div>
                  <p className="text-sm text-gray-400">Active Connections</p>
                  <p className="text-2xl font-bold text-white">{wanStatus.active_interfaces}</p>
                </div>
                <Wifi className="h-8 w-8 text-green-500 ml-auto" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <div>
                  <p className="text-sm text-gray-400">Load Balancing</p>
                  <p className="text-2xl font-bold text-white">{wanStatus.load_balancing.enabled ? 'ON' : 'OFF'}</p>
                </div>
                <BarChart3 className="h-8 w-8 text-purple-500 ml-auto" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <div>
                  <p className="text-sm text-gray-400">Failover Status</p>
                  <p className="text-2xl font-bold text-white">{wanStatus.failover.active_failovers}</p>
                </div>
                <Settings className="h-8 w-8 text-yellow-500 ml-auto" />
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Tab Navigation */}
      <div className="flex space-x-1 bg-gray-800/30 p-1 rounded-lg w-fit">
        {tabs.map((tab, index) => {
          const TabIcon = tab.icon;
          return (
            <button
              key={index}
              onClick={() => setActiveTab(index)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-md transition-all duration-200 ${
                activeTab === index
                  ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <TabIcon className="h-4 w-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tab Content */}
      {activeTab === 0 && (
        <Card>
          <CardHeader>
            <CardTitle>WAN Interface Configuration</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-700">
                    <th className="text-left py-3 px-4 text-gray-300">Interface</th>
                    <th className="text-left py-3 px-4 text-gray-300">Type</th>
                    <th className="text-left py-3 px-4 text-gray-300">Status</th>
                    <th className="text-left py-3 px-4 text-gray-300">Priority</th>
                    <th className="text-left py-3 px-4 text-gray-300">Weight</th>
                    <th className="text-left py-3 px-4 text-gray-300">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {wanInterfaces.map((wan) => (
                    <tr key={wan.id} className="border-b border-gray-800">
                      <td className="py-3 px-4">
                        <div>
                          <p className="font-semibold text-white">{wan.name}</p>
                          <p className="text-sm text-gray-400">{wan.interface_name}</p>
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <span className="px-2 py-1 bg-blue-500/20 text-blue-400 rounded text-xs">
                          {wan.connection_type}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex items-center space-x-2">
                          <span className={`px-2 py-1 rounded text-xs ${
                            wan.is_enabled ? 'bg-green-500/20 text-green-400' : 'bg-gray-500/20 text-gray-400'
                          }`}>
                            {wan.is_enabled ? 'Enabled' : 'Disabled'}
                          </span>
                          {wan.is_primary && (
                            <span className="px-2 py-1 bg-purple-500/20 text-purple-400 rounded text-xs">
                              Primary
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="py-3 px-4 text-white">{wan.priority}</td>
                      <td className="py-3 px-4 text-white">{wan.weight}</td>
                      <td className="py-3 px-4">
                        <div className="flex space-x-2">
                          <Button size="sm" variant="outline">
                            <Play className="w-4 h-4" />
                          </Button>
                          <Button size="sm" variant="outline">
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button size="sm" variant="outline">
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      {activeTab === 1 && (
        <Card>
          <CardHeader>
            <CardTitle>Load Balancing Configuration</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold text-white">Enable Load Balancing</h3>
                <p className="text-sm text-gray-400">Distribute traffic across multiple WAN connections</p>
              </div>
              <input type="checkbox" className="w-5 h-5" defaultChecked />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Load Balancing Algorithm</label>
              <select className="w-full bg-gray-800/50 border border-gray-600 rounded-lg px-3 py-2 text-white">
                <option value="round_robin">Round Robin</option>
                <option value="weighted">Weighted Round Robin</option>
                <option value="least_connections">Least Connections</option>
                <option value="source_hash">Source Hash</option>
              </select>
            </div>
            
            <div className="pt-4 border-t border-gray-700">
              <Button>
                Save Load Balancing Settings
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {activeTab === 2 && (
        <Card>
          <CardHeader>
            <CardTitle>WAN Connection Monitoring</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center py-8">
              <BarChart3 className="w-16 h-16 text-gray-500 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-white mb-2">Real-time Monitoring</h3>
              <p className="text-gray-400 mb-4">
                Monitor WAN connection performance, traffic distribution, and failover events.
              </p>
              <Button>
                View Detailed Metrics
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {activeTab === 3 && (
        <Card>
          <CardHeader>
            <CardTitle>Advanced WAN Configuration</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-4 mb-6">
              <h3 className="font-semibold text-blue-400 mb-2">Advanced Settings</h3>
              <p className="text-gray-300">
                Advanced WAN management features including custom routing rules, 
                QoS policies, and connection aggregation.
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium text-white">Connection Aggregation</h3>
                  <p className="text-sm text-gray-400">Combine multiple WAN connections for increased bandwidth</p>
                </div>
                <input type="checkbox" className="w-5 h-5" />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium text-white">Adaptive Load Balancing</h3>
                  <p className="text-sm text-gray-400">Automatically adjust traffic distribution based on performance</p>
                </div>
                <input type="checkbox" className="w-5 h-5" />
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

export default WANManager;