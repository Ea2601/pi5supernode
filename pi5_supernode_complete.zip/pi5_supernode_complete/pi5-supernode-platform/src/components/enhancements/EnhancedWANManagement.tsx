import React, { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Globe,
  Wifi,
  Router,
  Activity,
  Plus,
  Edit,
  Trash2,
  Play,
  Pause,
  TestTube,
  Settings,
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  CheckCircle,
  RefreshCw,
  Zap,
  Signal,
  Download,
  Upload,
  Clock,
  BarChart3,
  Shield,
  X,
  Save,
  Eye
} from 'lucide-react'
import { Button } from '../ui/button'
import { Card, CardHeader, CardTitle, CardContent } from '../ui/card'
import { supabase } from '@/lib/supabase'
import { cn } from '@/lib/utils'

interface WANConnection {
  id: string
  name: string
  description: string
  type_id: string
  interface_name: string
  configuration: any
  priority: number
  weight: number
  is_enabled: boolean
  failover_group: string
  bandwidth_limit_mbps: number
  status?: {
    is_connected: boolean
    response_time_ms: number
    bandwidth_down_mbps: number
    bandwidth_up_mbps: number
    last_error: string
    checked_at: string
  }
  wan_connection_types?: {
    name: string
    description: string
    default_config: any
  }
}

interface ConnectionType {
  id: string
  name: string
  description: string
  category: string
  default_config: any
  configuration_schema: any
}

export const EnhancedWANManagement: React.FC = () => {
  const [activeTab, setActiveTab] = useState('connections')
  const [connections, setConnections] = useState<WANConnection[]>([])
  const [connectionTypes, setConnectionTypes] = useState<ConnectionType[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [showCreateModal, setShowCreateModal] = useState(false)
  const [selectedConnection, setSelectedConnection] = useState<WANConnection | null>(null)
  const [statistics, setStatistics] = useState<any>(null)
  const [loadBalancing, setLoadBalancing] = useState<any>(null)
  
  const [connectionForm, setConnectionForm] = useState({
    name: '',
    description: '',
    type_id: '',
    interface_name: 'eth0',
    priority: 100,
    weight: 1,
    is_enabled: true,
    failover_group: 'default',
    bandwidth_limit_mbps: 0,
    configuration: {}
  })

  useEffect(() => {
    loadInitialData()
  }, [])

  useEffect(() => {
    if (activeTab === 'connections') {
      loadConnections()
    } else if (activeTab === 'load-balancing') {
      loadLoadBalancing()
    } else if (activeTab === 'statistics') {
      loadStatistics()
    }
  }, [activeTab])

  const loadInitialData = async () => {
    try {
      setLoading(true)
      const [connectionsResult, typesResult] = await Promise.all([
        supabase.functions.invoke('enhanced-wan-management', {
          body: { action: 'get_wan_connections' }
        }),
        supabase.functions.invoke('enhanced-wan-management', {
          body: { action: 'get_connection_types' }
        })
      ])

      if (connectionsResult.error) throw connectionsResult.error
      if (typesResult.error) throw typesResult.error

      setConnections(connectionsResult.data.data.connections)
      setConnectionTypes(typesResult.data.data.connection_types)
    } catch (error) {
      console.error('Error loading data:', error)
      setError('Failed to load WAN data')
    } finally {
      setLoading(false)
    }
  }

  const loadConnections = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('enhanced-wan-management', {
        body: { action: 'get_wan_connections' }
      })

      if (error) throw error
      setConnections(data.data.connections)
    } catch (error) {
      console.error('Error loading connections:', error)
    }
  }

  const loadLoadBalancing = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('enhanced-wan-management', {
        body: { action: 'get_load_balancing' }
      })

      if (error) throw error
      setLoadBalancing(data.data.load_balancing)
    } catch (error) {
      console.error('Error loading load balancing:', error)
    }
  }

  const loadStatistics = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('enhanced-wan-management', {
        body: { action: 'get_wan_statistics' }
      })

      if (error) throw error
      setStatistics(data.data.statistics)
    } catch (error) {
      console.error('Error loading statistics:', error)
    }
  }

  const createConnection = async () => {
    try {
      setLoading(true)
      const { data, error } = await supabase.functions.invoke('enhanced-wan-management', {
        body: {
          action: 'create_wan_connection',
          connection: connectionForm
        }
      })

      if (error) throw error
      
      setShowCreateModal(false)
      resetForm()
      await loadConnections()
    } catch (error) {
      console.error('Error creating connection:', error)
      setError('Failed to create WAN connection')
    } finally {
      setLoading(false)
    }
  }

  const updateConnection = async (connectionId: string, updates: Partial<WANConnection>) => {
    try {
      const { data, error } = await supabase.functions.invoke('enhanced-wan-management', {
        body: {
          action: 'update_wan_connection',
          connectionId,
          updates
        }
      })

      if (error) throw error
      await loadConnections()
    } catch (error) {
      console.error('Error updating connection:', error)
      setError('Failed to update connection')
    }
  }

  const deleteConnection = async (connectionId: string) => {
    if (!confirm('Are you sure you want to delete this WAN connection?')) return
    
    try {
      const { data, error } = await supabase.functions.invoke('enhanced-wan-management', {
        body: {
          action: 'delete_wan_connection',
          connectionId
        }
      })

      if (error) throw error
      await loadConnections()
    } catch (error) {
      console.error('Error deleting connection:', error)
      setError('Failed to delete connection')
    }
  }

  const testConnection = async (connectionId: string) => {
    try {
      setLoading(true)
      const { data, error } = await supabase.functions.invoke('enhanced-wan-management', {
        body: {
          action: 'test_connection',
          connectionId
        }
      })

      if (error) throw error
      
      // Show test results
      const results = data.data.test_results
      alert(`Connection Test Results:\n\nStatus: ${results.is_connected ? 'Connected' : 'Failed'}\nResponse Time: ${results.response_time_ms}ms\nDownload: ${results.bandwidth_test.download_mbps} Mbps\nUpload: ${results.bandwidth_test.upload_mbps} Mbps\nLatency: ${results.bandwidth_test.latency_ms}ms`)
      
      await loadConnections()
    } catch (error) {
      console.error('Error testing connection:', error)
      setError('Failed to test connection')
    } finally {
      setLoading(false)
    }
  }

  const resetForm = () => {
    setConnectionForm({
      name: '',
      description: '',
      type_id: '',
      interface_name: 'eth0',
      priority: 100,
      weight: 1,
      is_enabled: true,
      failover_group: 'default',
      bandwidth_limit_mbps: 0,
      configuration: {}
    })
  }

  const getConnectionTypeConfig = (typeId: string) => {
    const type = connectionTypes.find(t => t.id === typeId)
    return type?.configuration_schema || {}
  }

  const getStatusColor = (isConnected: boolean) => {
    return isConnected ? 'text-green-400' : 'text-red-400'
  }

  const formatBytes = (mbps: number) => {
    if (mbps >= 1000) {
      return `${(mbps / 1000).toFixed(1)} Gbps`
    }
    return `${mbps} Mbps`
  }

  const tabs = [
    { id: 'connections', label: 'WAN Connections', icon: Globe },
    { id: 'load-balancing', label: 'Load Balancing', icon: Zap },
    { id: 'statistics', label: 'Statistics & Monitoring', icon: BarChart3 },
    { id: 'failover', label: 'Failover Configuration', icon: Shield }
  ]

  const renderConnectionsTab = () => (
    <div className="space-y-6">
      {/* Connection Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-white/5 border-white/10">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Globe className="h-5 w-5 text-blue-400" />
              <div>
                <p className="text-sm text-gray-400">Total Connections</p>
                <p className="text-xl font-bold text-white">{connections.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-white/5 border-white/10">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <CheckCircle className="h-5 w-5 text-green-400" />
              <div>
                <p className="text-sm text-gray-400">Active</p>
                <p className="text-xl font-bold text-white">
                  {connections.filter(c => c.status?.is_connected).length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-white/5 border-white/10">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <TrendingUp className="h-5 w-5 text-purple-400" />
              <div>
                <p className="text-sm text-gray-400">Total Bandwidth</p>
                <p className="text-xl font-bold text-white">
                  {formatBytes(connections.reduce((sum, c) => sum + (c.status?.bandwidth_down_mbps || 0), 0))}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-white/5 border-white/10">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Clock className="h-5 w-5 text-yellow-400" />
              <div>
                <p className="text-sm text-gray-400">Avg Latency</p>
                <p className="text-xl font-bold text-white">
                  {Math.round(connections.reduce((sum, c) => sum + (c.status?.response_time_ms || 0), 0) / connections.length || 0)}ms
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Create Connection Button */}
      <div className="flex justify-between items-center">
        <h3 className="text-xl font-semibold text-white">WAN Connections</h3>
        <Button onClick={() => {
          resetForm()
          setShowCreateModal(true)
        }}>
          <Plus className="h-4 w-4 mr-2" />
          Add Connection
        </Button>
      </div>

      {/* Connections List */}
      <div className="space-y-4">
        {connections.map((connection) => (
          <motion.div
            key={connection.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white/5 rounded-lg p-6 hover:bg-white/10 transition-colors"
          >
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <div className="flex items-center space-x-4">
                  <h4 className="font-medium text-white">{connection.name}</h4>
                  <span className={cn(
                    "px-2 py-1 rounded-full text-xs font-medium",
                    connection.status?.is_connected
                      ? "bg-green-500/20 text-green-300 border border-green-500/30"
                      : "bg-red-500/20 text-red-300 border border-red-500/30"
                  )}>
                    {connection.status?.is_connected ? 'Connected' : 'Disconnected'}
                  </span>
                  <span className="text-xs text-gray-400">Priority: {connection.priority}</span>
                  <span className="text-xs text-gray-400">Weight: {connection.weight}</span>
                </div>
                
                <div className="mt-2 flex items-center space-x-6 text-sm text-gray-400">
                  <div className="flex items-center space-x-2">
                    <Router className="h-4 w-4" />
                    <span>{connection.wan_connection_types?.name || 'Unknown Type'}</span>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Activity className="h-4 w-4" />
                    <span>{connection.interface_name}</span>
                  </div>
                  
                  {connection.status?.bandwidth_down_mbps && (
                    <div className="flex items-center space-x-2">
                      <Download className="h-4 w-4" />
                      <span>{formatBytes(connection.status.bandwidth_down_mbps)}</span>
                    </div>
                  )}
                  
                  {connection.status?.bandwidth_up_mbps && (
                    <div className="flex items-center space-x-2">
                      <Upload className="h-4 w-4" />
                      <span>{formatBytes(connection.status.bandwidth_up_mbps)}</span>
                    </div>
                  )}
                  
                  {connection.status?.response_time_ms && (
                    <div className="flex items-center space-x-2">
                      <Clock className="h-4 w-4" />
                      <span>{connection.status.response_time_ms}ms</span>
                    </div>
                  )}
                </div>
                
                {connection.description && (
                  <p className="text-sm text-gray-500 mt-1">{connection.description}</p>
                )}
              </div>
              
              <div className="flex items-center space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => testConnection(connection.id)}
                  disabled={loading}
                >
                  <TestTube className="h-4 w-4" />
                </Button>
                
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => updateConnection(connection.id, { is_enabled: !connection.is_enabled })}
                >
                  {connection.is_enabled ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                </Button>
                
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    setSelectedConnection(connection)
                    setConnectionForm({
                      name: connection.name,
                      description: connection.description,
                      type_id: connection.type_id,
                      interface_name: connection.interface_name,
                      priority: connection.priority,
                      weight: connection.weight,
                      is_enabled: connection.is_enabled,
                      failover_group: connection.failover_group,
                      bandwidth_limit_mbps: connection.bandwidth_limit_mbps,
                      configuration: connection.configuration
                    })
                    setShowCreateModal(true)
                  }}
                >
                  <Edit className="h-4 w-4" />
                </Button>
                
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => deleteConnection(connection.id)}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  )

  const renderLoadBalancingTab = () => (
    <div className="space-y-6">
      <Card className="bg-white/5 border-white/10">
        <CardHeader>
          <CardTitle className="text-white flex items-center space-x-2">
            <Zap className="h-5 w-5" />
            <span>Load Balancing Algorithm</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Algorithm Type
            </label>
            <select className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-enterprise-neon">
              <option value="round_robin">Round Robin</option>
              <option value="weighted">Weighted Round Robin</option>
              <option value="least_connections">Least Connections</option>
              <option value="bandwidth_based">Bandwidth Based</option>
              <option value="latency_based">Latency Based</option>
            </select>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Health Check Interval (seconds)
              </label>
              <input
                type="number"
                value={30}
                min={10}
                max={300}
                className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Failover Threshold
              </label>
              <input
                type="number"
                value={3}
                min={1}
                max={10}
                className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Recovery Threshold
              </label>
              <input
                type="number"
                value={2}
                min={1}
                max={10}
                className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
              />
            </div>
          </div>
          
          <div className="space-y-3">
            <label className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={true}
                className="rounded border-white/10 bg-white/5 text-enterprise-neon focus:ring-enterprise-neon"
              />
              <span className="text-gray-300">Enable automatic failover</span>
            </label>
            
            <label className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={true}
                className="rounded border-white/10 bg-white/5 text-enterprise-neon focus:ring-enterprise-neon"
              />
              <span className="text-gray-300">Enable automatic recovery</span>
            </label>
            
            <label className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={false}
                className="rounded border-white/10 bg-white/5 text-enterprise-neon focus:ring-enterprise-neon"
              />
              <span className="text-gray-300">Sticky sessions (maintain connection affinity)</span>
            </label>
          </div>
        </CardContent>
      </Card>
      
      <Card className="bg-white/5 border-white/10">
        <CardHeader>
          <CardTitle className="text-white">Failover Groups</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {['Primary', 'Backup', 'Emergency'].map((group, index) => (
              <div key={group} className="bg-white/5 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium text-white">{group} Group</h4>
                    <p className="text-sm text-gray-400">
                      Priority: {index + 1} • 
                      Connections: {connections.filter(c => c.failover_group === group.toLowerCase()).length}
                    </p>
                  </div>
                  <Button variant="outline" size="sm">
                    <Settings className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )

  const renderStatisticsTab = () => (
    <div className="space-y-6">
      {statistics && (
        <>
          {/* Current Usage */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card className="bg-white/5 border-white/10">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <TrendingUp className="h-5 w-5 text-blue-400" />
                  <div>
                    <p className="text-sm text-gray-400">Total Bandwidth</p>
                    <p className="text-xl font-bold text-white">
                      {formatBytes(statistics.current_usage.total_bandwidth)}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-white/5 border-white/10">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Activity className="h-5 w-5 text-green-400" />
                  <div>
                    <p className="text-sm text-gray-400">Active Connections</p>
                    <p className="text-xl font-bold text-white">
                      {statistics.current_usage.active_connections}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-white/5 border-white/10">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Clock className="h-5 w-5 text-yellow-400" />
                  <div>
                    <p className="text-sm text-gray-400">Avg Latency</p>
                    <p className="text-xl font-bold text-white">
                      {statistics.performance_metrics.avg_latency}ms
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-white/5 border-white/10">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <CheckCircle className="h-5 w-5 text-purple-400" />
                  <div>
                    <p className="text-sm text-gray-400">Uptime</p>
                    <p className="text-xl font-bold text-white">
                      {statistics.performance_metrics.uptime_percentage}%
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Historical Chart Placeholder */}
          <Card className="bg-white/5 border-white/10">
            <CardHeader>
              <CardTitle className="text-white">Bandwidth Usage (24 Hours)</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64 flex items-center justify-center border border-white/10 rounded-lg">
                <div className="text-center">
                  <BarChart3 className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                  <p className="text-gray-400">Bandwidth usage chart</p>
                  <p className="text-sm text-gray-500 mt-1">Historical data visualization</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  )

  const renderFailoverTab = () => (
    <div className="space-y-6">
      <Card className="bg-white/5 border-white/10">
        <CardHeader>
          <CardTitle className="text-white flex items-center space-x-2">
            <Shield className="h-5 w-5" />
            <span>Failover Configuration</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-3">
            <label className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={true}
                className="rounded border-white/10 bg-white/5 text-enterprise-neon focus:ring-enterprise-neon"
              />
              <span className="text-gray-300">Enable automatic failover</span>
            </label>
            
            <label className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={true}
                className="rounded border-white/10 bg-white/5 text-enterprise-neon focus:ring-enterprise-neon"
              />
              <span className="text-gray-300">Send notifications on failover events</span>
            </label>
            
            <label className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={false}
                className="rounded border-white/10 bg-white/5 text-enterprise-neon focus:ring-enterprise-neon"
              />
              <span className="text-gray-300">Preemptive failover (fail before complete loss)</span>
            </label>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Failover Delay (seconds)
              </label>
              <input
                type="number"
                value={5}
                min={1}
                max={60}
                className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Recovery Delay (seconds)
              </label>
              <input
                type="number"
                value={30}
                min={10}
                max={300}
                className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
              />
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Card className="bg-white/5 border-white/10">
        <CardHeader>
          <CardTitle className="text-white">Failover Events</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[
              {
                timestamp: '2025-01-07 12:30:45',
                event: 'Primary connection failed',
                action: 'Switched to backup connection',
                duration: '2.3 seconds'
              },
              {
                timestamp: '2025-01-07 08:15:20',
                event: 'Backup connection recovered',
                action: 'Restored primary connection',
                duration: '1.8 seconds'
              }
            ].map((event, index) => (
              <div key={index} className="bg-white/5 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium text-white">{event.event}</h4>
                    <p className="text-sm text-gray-400">{event.action}</p>
                    <p className="text-xs text-gray-500 mt-1">
                      {event.timestamp} • Duration: {event.duration}
                    </p>
                  </div>
                  <Button variant="outline" size="sm">
                    <Eye className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )

  const renderTabContent = () => {
    switch (activeTab) {
      case 'connections':
        return renderConnectionsTab()
      case 'load-balancing':
        return renderLoadBalancingTab()
      case 'statistics':
        return renderStatisticsTab()
      case 'failover':
        return renderFailoverTab()
      default:
        return renderConnectionsTab()
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white flex items-center space-x-2">
            <Globe className="h-6 w-6 text-enterprise-neon" />
            <span>Enhanced WAN Management</span>
          </h2>
          <p className="text-gray-400 mt-1">
            Multi-WAN load balancing, failover, and performance monitoring
          </p>
        </div>
      </div>

      {/* Error Display */}
      {error && (
        <div className="bg-red-900/20 border border-red-500/50 rounded-lg p-4">
          <div className="flex items-center space-x-2 text-red-400">
            <AlertTriangle className="h-5 w-5" />
            <span>{error}</span>
            <button 
              onClick={() => setError(null)}
              className="ml-auto hover:text-red-300"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>
      )}

      {/* Tab Navigation */}
      <Card className="bg-white/5 border-white/10">
        <CardHeader>
          <div className="flex space-x-1 bg-gray-800 p-1 rounded-lg">
            {tabs.map((tab) => {
              const Icon = tab.icon
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={cn(
                    'flex items-center space-x-2 px-4 py-2 rounded-md text-sm font-medium transition-all',
                    activeTab === tab.id
                      ? 'bg-enterprise-neon text-enterprise-dark'
                      : 'text-gray-400 hover:text-white hover:bg-white/5'
                  )}
                >
                  <Icon className="h-4 w-4" />
                  <span>{tab.label}</span>
                </button>
              )
            })}
          </div>
        </CardHeader>
        
        <CardContent>
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
            >
              {renderTabContent()}
            </motion.div>
          </AnimatePresence>
        </CardContent>
      </Card>

      {/* Create/Edit Connection Modal */}
      <AnimatePresence>
        {showCreateModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-gray-900/95 backdrop-blur-sm border border-white/10 rounded-xl p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-white">
                  {selectedConnection ? 'Edit WAN Connection' : 'Create WAN Connection'}
                </h3>
                <button 
                  onClick={() => {
                    setShowCreateModal(false)
                    setSelectedConnection(null)
                  }}
                  className="text-gray-400 hover:text-white"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              <div className="space-y-4">
                {/* Connection Name */}
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Connection Name *
                  </label>
                  <input
                    type="text"
                    value={connectionForm.name}
                    onChange={(e) => setConnectionForm(prev => ({ ...prev, name: e.target.value }))}
                    className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
                    placeholder="Primary Internet Connection"
                  />
                </div>

                {/* Description */}
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Description
                  </label>
                  <textarea
                    value={connectionForm.description}
                    onChange={(e) => setConnectionForm(prev => ({ ...prev, description: e.target.value }))}
                    className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
                    placeholder="Main ISP connection for primary traffic"
                    rows={3}
                  />
                </div>

                {/* Connection Type */}
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Connection Type *
                  </label>
                  <select
                    value={connectionForm.type_id}
                    onChange={(e) => setConnectionForm(prev => ({ ...prev, type_id: e.target.value }))}
                    className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
                  >
                    <option value="">Select connection type</option>
                    {connectionTypes.map(type => (
                      <option key={type.id} value={type.id}>
                        {type.name} - {type.description}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Interface and Priority */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Interface
                    </label>
                    <select
                      value={connectionForm.interface_name}
                      onChange={(e) => setConnectionForm(prev => ({ ...prev, interface_name: e.target.value }))}
                      className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
                    >
                      <option value="eth0">eth0 (Ethernet)</option>
                      <option value="wlan0">wlan0 (WiFi)</option>
                      <option value="usb0">usb0 (USB)</option>
                      <option value="ppp0">ppp0 (PPP)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Priority
                    </label>
                    <input
                      type="number"
                      value={connectionForm.priority}
                      onChange={(e) => setConnectionForm(prev => ({ ...prev, priority: parseInt(e.target.value) || 100 }))}
                      className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
                      min={1}
                      max={1000}
                    />
                  </div>
                </div>

                {/* Weight and Bandwidth Limit */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Load Balancing Weight
                    </label>
                    <input
                      type="number"
                      value={connectionForm.weight}
                      onChange={(e) => setConnectionForm(prev => ({ ...prev, weight: parseInt(e.target.value) || 1 }))}
                      className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
                      min={1}
                      max={100}
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Bandwidth Limit (Mbps)
                    </label>
                    <input
                      type="number"
                      value={connectionForm.bandwidth_limit_mbps}
                      onChange={(e) => setConnectionForm(prev => ({ ...prev, bandwidth_limit_mbps: parseInt(e.target.value) || 0 }))}
                      className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
                      placeholder="0 = unlimited"
                    />
                  </div>
                </div>

                {/* Failover Group */}
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Failover Group
                  </label>
                  <select
                    value={connectionForm.failover_group}
                    onChange={(e) => setConnectionForm(prev => ({ ...prev, failover_group: e.target.value }))}
                    className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
                  >
                    <option value="primary">Primary</option>
                    <option value="backup">Backup</option>
                    <option value="emergency">Emergency</option>
                    <option value="default">Default</option>
                  </select>
                </div>

                {/* Enable Checkbox */}
                <div>
                  <label className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      checked={connectionForm.is_enabled}
                      onChange={(e) => setConnectionForm(prev => ({ ...prev, is_enabled: e.target.checked }))}
                      className="rounded border-white/10 bg-white/5 text-enterprise-neon focus:ring-enterprise-neon"
                    />
                    <span className="text-gray-300">Enable this connection</span>
                  </label>
                </div>
              </div>

              <div className="flex space-x-3 mt-6">
                <Button 
                  onClick={selectedConnection ? () => {
                    updateConnection(selectedConnection.id, connectionForm)
                    setSelectedConnection(null)
                    setShowCreateModal(false)
                  } : createConnection}
                  disabled={!connectionForm.name || !connectionForm.type_id || loading}
                  className="flex-1"
                >
                  {loading ? (
                    <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <Save className="h-4 w-4 mr-2" />
                  )}
                  {selectedConnection ? 'Update Connection' : 'Create Connection'}
                </Button>
                <Button 
                  variant="outline"
                  onClick={() => {
                    setShowCreateModal(false)
                    setSelectedConnection(null)
                  }}
                >
                  Cancel
                </Button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}