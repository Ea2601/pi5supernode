import React, { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Network,
  Wifi,
  Router,
  Layers,
  Users,
  Plus,
  Edit,
  Trash2,
  Play,
  Pause,
  RefreshCw,
  Search,
  Settings,
  Shield,
  Activity,
  Globe,
  Smartphone,
  Laptop,
  Monitor,
  Printer,
  Camera,
  Speaker,
  X,
  Save,
  Eye,
  EyeOff,
  Signal,
  AlertTriangle,
  CheckCircle,
  Clock,
  Download,
  Upload,
  Zap,
  Lock,
  Unlock
} from 'lucide-react'
import { Button } from '../ui/button'
import { Card, CardHeader, CardTitle, CardContent } from '../ui/card'
import { supabase } from '@/lib/supabase'
import { cn } from '@/lib/utils'

interface DHCPPool {
  id: string
  name: string
  description: string
  range_start: string
  range_end: string
  subnet_mask: string
  gateway: string
  dns_servers: string[]
  lease_duration: number
  vlan_id?: number
  is_enabled: boolean
}

interface WiFiNetwork {
  id: string
  ssid: string
  description: string
  security_type: string
  passphrase: string
  band: string
  channel: number
  bandwidth: string
  max_clients: number
  vlan_id?: number
  priority: number
  is_hidden: boolean
  is_guest_network: boolean
  is_enabled: boolean
}

interface VLAN {
  id: string
  vlan_id: number
  name: string
  description: string
  subnet: string
  gateway: string
  interface_assignment: string[]
  isolation_level: string
  priority: number
  is_management: boolean
  is_enabled: boolean
}

interface NetworkDevice {
  id: string
  mac_address: string
  hostname: string
  ip_address: string
  vendor: string
  device_type: string
  connection_type: string
  vlan_id: number
  first_seen: string
  last_seen: string
  is_online: boolean
  is_authorized: boolean
}

export const EnhancedNetworkManagement: React.FC = () => {
  const [activeTab, setActiveTab] = useState('dhcp')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [showCreateModal, setShowCreateModal] = useState(false)
  const [selectedItem, setSelectedItem] = useState<any>(null)
  const [searchTerm, setSearchTerm] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  
  // Data states
  const [dhcpPools, setDhcpPools] = useState<DHCPPool[]>([])
  const [dhcpLeases, setDhcpLeases] = useState<any[]>([])
  const [wifiNetworks, setWifiNetworks] = useState<WiFiNetwork[]>([])
  const [wifiClients, setWifiClients] = useState<any[]>([])
  const [vlans, setVlans] = useState<VLAN[]>([])
  const [networkDevices, setNetworkDevices] = useState<NetworkDevice[]>([])
  const [statistics, setStatistics] = useState<any>(null)
  
  // Form states
  const [dhcpForm, setDhcpForm] = useState({
    name: '',
    description: '',
    range_start: '',
    range_end: '',
    subnet_mask: '255.255.255.0',
    gateway: '',
    dns_servers: ['8.8.8.8', '8.8.4.4'],
    lease_duration: 86400,
    vlan_id: '',
    is_enabled: true
  })
  
  const [wifiForm, setWifiForm] = useState({
    ssid: '',
    description: '',
    security_type: 'WPA3',
    passphrase: '',
    band: '2.4GHz',
    channel: 6,
    bandwidth: '20MHz',
    max_clients: 50,
    vlan_id: '',
    priority: 100,
    is_hidden: false,
    is_guest_network: false,
    is_enabled: true
  })
  
  const [vlanForm, setVlanForm] = useState({
    vlan_id: 10,
    name: '',
    description: '',
    subnet: '',
    gateway: '',
    interface_assignment: [],
    isolation_level: 'standard',
    priority: 0,
    is_management: false,
    is_enabled: true
  })

  useEffect(() => {
    loadData()
  }, [])

  useEffect(() => {
    if (activeTab === 'dhcp') {
      loadDHCPData()
    } else if (activeTab === 'wifi') {
      loadWiFiData()
    } else if (activeTab === 'vlans') {
      loadVLANData()
    } else if (activeTab === 'devices') {
      loadDeviceData()
    }
  }, [activeTab])

  const loadData = async () => {
    try {
      setLoading(true)
      const { data, error } = await supabase.functions.invoke('enhanced-network-management', {
        body: { action: 'get_network_statistics' }
      })

      if (error) throw error
      setStatistics(data.data.statistics)
    } catch (error) {
      console.error('Error loading data:', error)
      setError('Failed to load network data')
    } finally {
      setLoading(false)
    }
  }

  const loadDHCPData = async () => {
    try {
      const [poolsResult, leasesResult] = await Promise.all([
        supabase.functions.invoke('enhanced-network-management', {
          body: { action: 'get_dhcp_pools' }
        }),
        supabase.functions.invoke('enhanced-network-management', {
          body: { action: 'get_dhcp_leases' }
        })
      ])

      if (poolsResult.error) throw poolsResult.error
      if (leasesResult.error) throw leasesResult.error

      setDhcpPools(poolsResult.data.data.pools)
      setDhcpLeases(leasesResult.data.data.leases)
    } catch (error) {
      console.error('Error loading DHCP data:', error)
    }
  }

  const loadWiFiData = async () => {
    try {
      const [networksResult, clientsResult] = await Promise.all([
        supabase.functions.invoke('enhanced-network-management', {
          body: { action: 'get_wifi_networks' }
        }),
        supabase.functions.invoke('enhanced-network-management', {
          body: { action: 'get_wifi_clients' }
        })
      ])

      if (networksResult.error) throw networksResult.error
      if (clientsResult.error) throw clientsResult.error

      setWifiNetworks(networksResult.data.data.networks)
      setWifiClients(clientsResult.data.data.clients)
    } catch (error) {
      console.error('Error loading WiFi data:', error)
    }
  }

  const loadVLANData = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('enhanced-network-management', {
        body: { action: 'get_vlans' }
      })

      if (error) throw error
      setVlans(data.data.vlans)
    } catch (error) {
      console.error('Error loading VLAN data:', error)
    }
  }

  const loadDeviceData = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('enhanced-network-management', {
        body: { action: 'get_network_devices' }
      })

      if (error) throw error
      setNetworkDevices(data.data.devices)
    } catch (error) {
      console.error('Error loading device data:', error)
    }
  }

  const createDHCPPool = async () => {
    try {
      setLoading(true)
      const { data, error } = await supabase.functions.invoke('enhanced-network-management', {
        body: {
          action: 'create_dhcp_pool',
          pool: dhcpForm
        }
      })

      if (error) throw error
      
      setShowCreateModal(false)
      resetForms()
      await loadDHCPData()
    } catch (error) {
      console.error('Error creating DHCP pool:', error)
      setError('Failed to create DHCP pool')
    } finally {
      setLoading(false)
    }
  }

  const createWiFiNetwork = async () => {
    try {
      setLoading(true)
      const { data, error } = await supabase.functions.invoke('enhanced-network-management', {
        body: {
          action: 'create_wifi_network',
          network: wifiForm
        }
      })

      if (error) throw error
      
      setShowCreateModal(false)
      resetForms()
      await loadWiFiData()
    } catch (error) {
      console.error('Error creating WiFi network:', error)
      setError('Failed to create WiFi network')
    } finally {
      setLoading(false)
    }
  }

  const createVLAN = async () => {
    try {
      setLoading(true)
      const { data, error } = await supabase.functions.invoke('enhanced-network-management', {
        body: {
          action: 'create_vlan',
          vlan: vlanForm
        }
      })

      if (error) throw error
      
      setShowCreateModal(false)
      resetForms()
      await loadVLANData()
    } catch (error) {
      console.error('Error creating VLAN:', error)
      setError('Failed to create VLAN')
    } finally {
      setLoading(false)
    }
  }

  const resetForms = () => {
    setDhcpForm({
      name: '',
      description: '',
      range_start: '',
      range_end: '',
      subnet_mask: '255.255.255.0',
      gateway: '',
      dns_servers: ['8.8.8.8', '8.8.4.4'],
      lease_duration: 86400,
      vlan_id: '',
      is_enabled: true
    })
    
    setWifiForm({
      ssid: '',
      description: '',
      security_type: 'WPA3',
      passphrase: '',
      band: '2.4GHz',
      channel: 6,
      bandwidth: '20MHz',
      max_clients: 50,
      vlan_id: '',
      priority: 100,
      is_hidden: false,
      is_guest_network: false,
      is_enabled: true
    })
    
    setVlanForm({
      vlan_id: 10,
      name: '',
      description: '',
      subnet: '',
      gateway: '',
      interface_assignment: [],
      isolation_level: 'standard',
      priority: 0,
      is_management: false,
      is_enabled: true
    })
  }

  const getDeviceIcon = (deviceType: string) => {
    switch (deviceType) {
      case 'laptop': return Laptop
      case 'smartphone': return Smartphone
      case 'desktop': return Monitor
      case 'printer': return Printer
      case 'camera': return Camera
      case 'speaker': return Speaker
      default: return Router
    }
  }

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 Bytes'
    const k = 1024
    const sizes = ['Bytes', 'KB', 'MB', 'GB']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
  }

  const tabs = [
    { id: 'dhcp', label: 'DHCP Management', icon: Router },
    { id: 'wifi', label: 'WiFi Networks', icon: Wifi },
    { id: 'vlans', label: 'VLAN Configuration', icon: Layers },
    { id: 'devices', label: 'Network Devices', icon: Network }
  ]

  const renderDHCPTab = () => (
    <div className="space-y-6">
      {/* DHCP Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-white/5 border-white/10">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Router className="h-5 w-5 text-blue-400" />
              <div>
                <p className="text-sm text-gray-400">DHCP Pools</p>
                <p className="text-xl font-bold text-white">{statistics?.dhcp?.total_pools || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-white/5 border-white/10">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Users className="h-5 w-5 text-green-400" />
              <div>
                <p className="text-sm text-gray-400">Active Leases</p>
                <p className="text-xl font-bold text-white">{statistics?.dhcp?.active_leases || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-white/5 border-white/10">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Globe className="h-5 w-5 text-purple-400" />
              <div>
                <p className="text-sm text-gray-400">Available IPs</p>
                <p className="text-xl font-bold text-white">{statistics?.dhcp?.available_addresses || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-white/5 border-white/10">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Activity className="h-5 w-5 text-yellow-400" />
              <div>
                <p className="text-sm text-gray-400">Utilization</p>
                <p className="text-xl font-bold text-white">{statistics?.dhcp?.lease_utilization || '0%'}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* DHCP Pools */}
      <Card className="bg-white/5 border-white/10">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-white">DHCP Pools</CardTitle>
            <Button onClick={() => {
              resetForms()
              setShowCreateModal(true)
            }}>
              <Plus className="h-4 w-4 mr-2" />
              Add Pool
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {dhcpPools.map((pool) => (
              <div key={pool.id} className="bg-white/5 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium text-white">{pool.name}</h4>
                    <div className="flex items-center space-x-4 mt-1 text-sm text-gray-400">
                      <span>Range: {pool.range_start} - {pool.range_end}</span>
                      <span>Gateway: {pool.gateway}</span>
                      <span>Lease: {Math.floor(pool.lease_duration / 3600)}h</span>
                    </div>
                    {pool.description && (
                      <p className="text-sm text-gray-500 mt-1">{pool.description}</p>
                    )}
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className={cn(
                      "px-2 py-1 rounded-full text-xs font-medium",
                      pool.is_enabled
                        ? "bg-green-500/20 text-green-300 border border-green-500/30"
                        : "bg-gray-500/20 text-gray-300 border border-gray-500/30"
                    )}>
                      {pool.is_enabled ? 'Active' : 'Inactive'}
                    </span>
                    <Button variant="outline" size="sm">
                      <Edit className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Active DHCP Leases */}
      <Card className="bg-white/5 border-white/10">
        <CardHeader>
          <CardTitle className="text-white">Active DHCP Leases</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {dhcpLeases.map((lease) => (
              <div key={lease.id} className="bg-white/5 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium text-white">{lease.hostname}</h4>
                    <div className="flex items-center space-x-4 mt-1 text-sm text-gray-400">
                      <span>IP: {lease.ip_address}</span>
                      <span>MAC: {lease.mac_address}</span>
                      <span>Vendor: {lease.vendor}</span>
                      <span>Expires: {new Date(lease.lease_end).toLocaleDateString()}</span>
                    </div>
                  </div>
                  <span className={cn(
                    "px-2 py-1 rounded-full text-xs font-medium",
                    lease.is_active
                      ? "bg-green-500/20 text-green-300 border border-green-500/30"
                      : "bg-gray-500/20 text-gray-300 border border-gray-500/30"
                  )}>
                    {lease.is_active ? 'Active' : 'Expired'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )

  const renderWiFiTab = () => (
    <div className="space-y-6">
      {/* WiFi Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-white/5 border-white/10">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Wifi className="h-5 w-5 text-blue-400" />
              <div>
                <p className="text-sm text-gray-400">WiFi Networks</p>
                <p className="text-xl font-bold text-white">{statistics?.wifi?.total_networks || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-white/5 border-white/10">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Users className="h-5 w-5 text-green-400" />
              <div>
                <p className="text-sm text-gray-400">Connected Clients</p>
                <p className="text-xl font-bold text-white">{statistics?.wifi?.connected_clients || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-white/5 border-white/10">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Activity className="h-5 w-5 text-purple-400" />
              <div>
                <p className="text-sm text-gray-400">Bandwidth Usage</p>
                <p className="text-xl font-bold text-white">{statistics?.wifi?.total_bandwidth_usage || 0} Mbps</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-white/5 border-white/10">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Signal className="h-5 w-5 text-yellow-400" />
              <div>
                <p className="text-sm text-gray-400">Avg Signal</p>
                <p className="text-xl font-bold text-white">{statistics?.wifi?.avg_signal_strength || 0} dBm</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* WiFi Networks */}
      <Card className="bg-white/5 border-white/10">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-white">WiFi Networks</CardTitle>
            <Button onClick={() => {
              resetForms()
              setShowCreateModal(true)
            }}>
              <Plus className="h-4 w-4 mr-2" />
              Add Network
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {wifiNetworks.map((network) => (
              <div key={network.id} className="bg-white/5 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center space-x-3">
                      <h4 className="font-medium text-white">{network.ssid}</h4>
                      {network.is_hidden && (
                        <span className="px-2 py-1 rounded-full text-xs font-medium bg-gray-500/20 text-gray-300 border border-gray-500/30">
                          Hidden
                        </span>
                      )}
                      {network.is_guest_network && (
                        <span className="px-2 py-1 rounded-full text-xs font-medium bg-blue-500/20 text-blue-300 border border-blue-500/30">
                          Guest
                        </span>
                      )}
                    </div>
                    <div className="flex items-center space-x-4 mt-1 text-sm text-gray-400">
                      <span>Security: {network.security_type}</span>
                      <span>Band: {network.band}</span>
                      <span>Channel: {network.channel}</span>
                      <span>Max Clients: {network.max_clients}</span>
                    </div>
                    {network.description && (
                      <p className="text-sm text-gray-500 mt-1">{network.description}</p>
                    )}
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className={cn(
                      "px-2 py-1 rounded-full text-xs font-medium",
                      network.is_enabled
                        ? "bg-green-500/20 text-green-300 border border-green-500/30"
                        : "bg-gray-500/20 text-gray-300 border border-gray-500/30"
                    )}>
                      {network.is_enabled ? 'Broadcasting' : 'Disabled'}
                    </span>
                    <Button variant="outline" size="sm">
                      <Edit className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Connected WiFi Clients */}
      <Card className="bg-white/5 border-white/10">
        <CardHeader>
          <CardTitle className="text-white">Connected WiFi Clients</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {wifiClients.map((client) => (
              <div key={client.id} className="bg-white/5 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium text-white">{client.hostname}</h4>
                    <div className="flex items-center space-x-4 mt-1 text-sm text-gray-400">
                      <span>IP: {client.ip_address}</span>
                      <span>SSID: {client.ssid}</span>
                      <span>Signal: {client.signal_strength} dBm</span>
                      <span>Connected: {new Date(client.connected_at).toLocaleTimeString()}</span>
                    </div>
                    <div className="flex items-center space-x-4 mt-1 text-xs text-gray-500">
                      <span>↓ {formatBytes(client.data_usage.rx)}</span>
                      <span>↑ {formatBytes(client.data_usage.tx)}</span>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button variant="outline" size="sm">
                      {client.is_blocked ? <Unlock className="h-4 w-4" /> : <Lock className="h-4 w-4" />}
                    </Button>
                    <Button variant="outline" size="sm">
                      <Eye className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )

  const renderVLANsTab = () => (
    <div className="space-y-6">
      {/* VLANs Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-white/5 border-white/10">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Layers className="h-5 w-5 text-blue-400" />
              <div>
                <p className="text-sm text-gray-400">Total VLANs</p>
                <p className="text-xl font-bold text-white">{statistics?.vlans?.total_vlans || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-white/5 border-white/10">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <CheckCircle className="h-5 w-5 text-green-400" />
              <div>
                <p className="text-sm text-gray-400">Active VLANs</p>
                <p className="text-xl font-bold text-white">{statistics?.vlans?.active_vlans || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-white/5 border-white/10">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Activity className="h-5 w-5 text-purple-400" />
              <div>
                <p className="text-sm text-gray-400">Inter-VLAN Traffic</p>
                <p className="text-xl font-bold text-white">{statistics?.vlans?.inter_vlan_traffic || 0} Mbps</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-white/5 border-white/10">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Shield className="h-5 w-5 text-yellow-400" />
              <div>
                <p className="text-sm text-gray-400">Isolation Violations</p>
                <p className="text-xl font-bold text-white">{statistics?.vlans?.isolation_violations || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* VLANs List */}
      <Card className="bg-white/5 border-white/10">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-white">VLAN Configuration</CardTitle>
            <Button onClick={() => {
              resetForms()
              setShowCreateModal(true)
            }}>
              <Plus className="h-4 w-4 mr-2" />
              Add VLAN
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {vlans.map((vlan) => (
              <div key={vlan.id} className="bg-white/5 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center space-x-3">
                      <h4 className="font-medium text-white">VLAN {vlan.vlan_id} - {vlan.name}</h4>
                      {vlan.is_management && (
                        <span className="px-2 py-1 rounded-full text-xs font-medium bg-red-500/20 text-red-300 border border-red-500/30">
                          Management
                        </span>
                      )}
                    </div>
                    <div className="flex items-center space-x-4 mt-1 text-sm text-gray-400">
                      <span>Subnet: {vlan.subnet}</span>
                      <span>Gateway: {vlan.gateway}</span>
                      <span>Isolation: {vlan.isolation_level}</span>
                      <span>Priority: {vlan.priority}</span>
                    </div>
                    {vlan.description && (
                      <p className="text-sm text-gray-500 mt-1">{vlan.description}</p>
                    )}
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className={cn(
                      "px-2 py-1 rounded-full text-xs font-medium",
                      vlan.is_enabled
                        ? "bg-green-500/20 text-green-300 border border-green-500/30"
                        : "bg-gray-500/20 text-gray-300 border border-gray-500/30"
                    )}>
                      {vlan.is_enabled ? 'Active' : 'Inactive'}
                    </span>
                    <Button variant="outline" size="sm">
                      <Edit className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )

  const renderDevicesTab = () => (
    <div className="space-y-6">
      {/* Devices Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-white/5 border-white/10">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Network className="h-5 w-5 text-blue-400" />
              <div>
                <p className="text-sm text-gray-400">Total Devices</p>
                <p className="text-xl font-bold text-white">{statistics?.devices?.total_discovered || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-white/5 border-white/10">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <CheckCircle className="h-5 w-5 text-green-400" />
              <div>
                <p className="text-sm text-gray-400">Online</p>
                <p className="text-xl font-bold text-white">{statistics?.devices?.online_devices || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-white/5 border-white/10">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <AlertTriangle className="h-5 w-5 text-red-400" />
              <div>
                <p className="text-sm text-gray-400">Unauthorized</p>
                <p className="text-xl font-bold text-white">{statistics?.devices?.unauthorized_devices || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-white/5 border-white/10">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Clock className="h-5 w-5 text-yellow-400" />
              <div>
                <p className="text-sm text-gray-400">New (24h)</p>
                <p className="text-xl font-bold text-white">{statistics?.devices?.new_devices_24h || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Device Search */}
      <div className="flex items-center space-x-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <input
            type="text"
            placeholder="Search devices..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
          />
        </div>
        <Button variant="outline">
          <RefreshCw className="h-4 w-4 mr-2" />
          Scan Network
        </Button>
      </div>

      {/* Network Devices */}
      <Card className="bg-white/5 border-white/10">
        <CardHeader>
          <CardTitle className="text-white">Network Devices</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {networkDevices
              .filter(device => 
                searchTerm === '' || 
                device.hostname.toLowerCase().includes(searchTerm.toLowerCase()) ||
                device.ip_address.includes(searchTerm) ||
                device.mac_address.toLowerCase().includes(searchTerm.toLowerCase())
              )
              .map((device) => {
                const DeviceIcon = getDeviceIcon(device.device_type)
                return (
                  <div key={device.id} className="bg-white/5 rounded-lg p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <DeviceIcon className="h-8 w-8 text-gray-400" />
                        <div>
                          <div className="flex items-center space-x-3">
                            <h4 className="font-medium text-white">{device.hostname}</h4>
                            <span className={cn(
                              "px-2 py-1 rounded-full text-xs font-medium",
                              device.is_online
                                ? "bg-green-500/20 text-green-300 border border-green-500/30"
                                : "bg-gray-500/20 text-gray-300 border border-gray-500/30"
                            )}>
                              {device.is_online ? 'Online' : 'Offline'}
                            </span>
                            {!device.is_authorized && (
                              <span className="px-2 py-1 rounded-full text-xs font-medium bg-red-500/20 text-red-300 border border-red-500/30">
                                Unauthorized
                              </span>
                            )}
                          </div>
                          <div className="flex items-center space-x-4 mt-1 text-sm text-gray-400">
                            <span>IP: {device.ip_address}</span>
                            <span>MAC: {device.mac_address}</span>
                            <span>Vendor: {device.vendor}</span>
                            <span>VLAN: {device.vlan_id}</span>
                            <span>Type: {device.connection_type}</span>
                          </div>
                          <div className="flex items-center space-x-4 mt-1 text-xs text-gray-500">
                            <span>First seen: {new Date(device.first_seen).toLocaleDateString()}</span>
                            <span>Last seen: {new Date(device.last_seen).toLocaleDateString()}</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Button variant="outline" size="sm">
                          {device.is_authorized ? <Lock className="h-4 w-4" /> : <CheckCircle className="h-4 w-4" />}
                        </Button>
                        <Button variant="outline" size="sm">
                          <Eye className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                )
              })}
          </div>
        </CardContent>
      </Card>
    </div>
  )

  const renderCreateModal = () => {
    const modalTitle = activeTab === 'dhcp' ? 'Create DHCP Pool' :
                      activeTab === 'wifi' ? 'Create WiFi Network' :
                      activeTab === 'vlans' ? 'Create VLAN' : 'Create Item'
                      
    const handleCreate = activeTab === 'dhcp' ? createDHCPPool :
                        activeTab === 'wifi' ? createWiFiNetwork :
                        activeTab === 'vlans' ? createVLAN : () => {}

    return (
      <AnimatePresence>
        {showCreateModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-gray-900/95 backdrop-blur-sm border border-white/10 rounded-xl p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-white">{modalTitle}</h3>
                <button 
                  onClick={() => setShowCreateModal(false)}
                  className="text-gray-400 hover:text-white"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              {/* Dynamic form content based on active tab */}
              {activeTab === 'dhcp' && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Pool Name *
                    </label>
                    <input
                      type="text"
                      value={dhcpForm.name}
                      onChange={(e) => setDhcpForm(prev => ({ ...prev, name: e.target.value }))}
                      className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
                      placeholder="Main Network Pool"
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">
                        Range Start *
                      </label>
                      <input
                        type="text"
                        value={dhcpForm.range_start}
                        onChange={(e) => setDhcpForm(prev => ({ ...prev, range_start: e.target.value }))}
                        className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
                        placeholder="192.168.1.100"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">
                        Range End *
                      </label>
                      <input
                        type="text"
                        value={dhcpForm.range_end}
                        onChange={(e) => setDhcpForm(prev => ({ ...prev, range_end: e.target.value }))}
                        className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
                        placeholder="192.168.1.200"
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">
                        Subnet Mask
                      </label>
                      <input
                        type="text"
                        value={dhcpForm.subnet_mask}
                        onChange={(e) => setDhcpForm(prev => ({ ...prev, subnet_mask: e.target.value }))}
                        className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">
                        Gateway
                      </label>
                      <input
                        type="text"
                        value={dhcpForm.gateway}
                        onChange={(e) => setDhcpForm(prev => ({ ...prev, gateway: e.target.value }))}
                        className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
                        placeholder="192.168.1.1"
                      />
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'wifi' && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Network Name (SSID) *
                    </label>
                    <input
                      type="text"
                      value={wifiForm.ssid}
                      onChange={(e) => setWifiForm(prev => ({ ...prev, ssid: e.target.value }))}
                      className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
                      placeholder="Pi5-SuperNode-Guest"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Password
                    </label>
                    <div className="relative">
                      <input
                        type={showPassword ? 'text' : 'password'}
                        value={wifiForm.passphrase}
                        onChange={(e) => setWifiForm(prev => ({ ...prev, passphrase: e.target.value }))}
                        className="w-full px-3 py-2 pr-10 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
                        placeholder="Strong password (8+ characters)"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-white"
                      >
                        {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </button>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">
                        Security Type
                      </label>
                      <select
                        value={wifiForm.security_type}
                        onChange={(e) => setWifiForm(prev => ({ ...prev, security_type: e.target.value }))}
                        className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
                      >
                        <option value="WPA3">WPA3 (Recommended)</option>
                        <option value="WPA2">WPA2</option>
                        <option value="WPA">WPA</option>
                        <option value="Open">Open (No Security)</option>
                      </select>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">
                        Band
                      </label>
                      <select
                        value={wifiForm.band}
                        onChange={(e) => setWifiForm(prev => ({ ...prev, band: e.target.value }))}
                        className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
                      >
                        <option value="2.4GHz">2.4 GHz</option>
                        <option value="5GHz">5 GHz</option>
                        <option value="6GHz">6 GHz</option>
                      </select>
                    </div>
                  </div>
                  
                  <div className="space-y-3">
                    <label className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        checked={wifiForm.is_hidden}
                        onChange={(e) => setWifiForm(prev => ({ ...prev, is_hidden: e.target.checked }))}
                        className="rounded border-white/10 bg-white/5 text-enterprise-neon focus:ring-enterprise-neon"
                      />
                      <span className="text-gray-300">Hidden Network (Don't broadcast SSID)</span>
                    </label>
                    
                    <label className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        checked={wifiForm.is_guest_network}
                        onChange={(e) => setWifiForm(prev => ({ ...prev, is_guest_network: e.target.checked }))}
                        className="rounded border-white/10 bg-white/5 text-enterprise-neon focus:ring-enterprise-neon"
                      />
                      <span className="text-gray-300">Guest Network (Isolated from main network)</span>
                    </label>
                  </div>
                </div>
              )}

              {activeTab === 'vlans' && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">
                        VLAN ID *
                      </label>
                      <input
                        type="number"
                        value={vlanForm.vlan_id}
                        onChange={(e) => setVlanForm(prev => ({ ...prev, vlan_id: parseInt(e.target.value) || 10 }))}
                        className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
                        min={2}
                        max={4094}
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">
                        VLAN Name *
                      </label>
                      <input
                        type="text"
                        value={vlanForm.name}
                        onChange={(e) => setVlanForm(prev => ({ ...prev, name: e.target.value }))}
                        className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
                        placeholder="Guest Network"
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">
                        Subnet *
                      </label>
                      <input
                        type="text"
                        value={vlanForm.subnet}
                        onChange={(e) => setVlanForm(prev => ({ ...prev, subnet: e.target.value }))}
                        className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
                        placeholder="192.168.10.0/24"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">
                        Gateway
                      </label>
                      <input
                        type="text"
                        value={vlanForm.gateway}
                        onChange={(e) => setVlanForm(prev => ({ ...prev, gateway: e.target.value }))}
                        className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
                        placeholder="192.168.10.1"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Isolation Level
                    </label>
                    <select
                      value={vlanForm.isolation_level}
                      onChange={(e) => setVlanForm(prev => ({ ...prev, isolation_level: e.target.value }))}
                      className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-enterprise-neon"
                    >
                      <option value="none">No Isolation</option>
                      <option value="standard">Standard Isolation</option>
                      <option value="strict">Strict Isolation</option>
                      <option value="complete">Complete Isolation</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        checked={vlanForm.is_management}
                        onChange={(e) => setVlanForm(prev => ({ ...prev, is_management: e.target.checked }))}
                        className="rounded border-white/10 bg-white/5 text-enterprise-neon focus:ring-enterprise-neon"
                      />
                      <span className="text-gray-300">Management VLAN (Administrative access)</span>
                    </label>
                  </div>
                </div>
              )}

              <div className="flex space-x-3 mt-6">
                <Button 
                  onClick={handleCreate}
                  disabled={loading}
                  className="flex-1"
                >
                  {loading ? (
                    <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <Save className="h-4 w-4 mr-2" />
                  )}
                  Create {activeTab === 'dhcp' ? 'Pool' : activeTab === 'wifi' ? 'Network' : 'VLAN'}
                </Button>
                <Button 
                  variant="outline"
                  onClick={() => setShowCreateModal(false)}
                >
                  Cancel
                </Button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    )
  }

  const renderTabContent = () => {
    switch (activeTab) {
      case 'dhcp':
        return renderDHCPTab()
      case 'wifi':
        return renderWiFiTab()
      case 'vlans':
        return renderVLANsTab()
      case 'devices':
        return renderDevicesTab()
      default:
        return renderDHCPTab()
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white flex items-center space-x-2">
            <Network className="h-6 w-6 text-enterprise-neon" />
            <span>Network Management</span>
          </h2>
          <p className="text-gray-400 mt-1">
            Comprehensive DHCP, WiFi, VLAN, and device management
          </p>
        </div>
      </div>

      {/* Error Display */}
      {error && (
        <div className="bg-red-900/20 border border-red-500/50 rounded-lg p-4">
          <div className="flex items-center space-x-2 text-red-400">
            <AlertTriangle className="h-5 w-5" />
            <span>{error}</span>
            <button 
              onClick={() => setError(null)}
              className="ml-auto hover:text-red-300"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>
      )}

      {/* Tab Navigation */}
      <Card className="bg-white/5 border-white/10">
        <CardHeader>
          <div className="flex space-x-1 bg-gray-800 p-1 rounded-lg">
            {tabs.map((tab) => {
              const Icon = tab.icon
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={cn(
                    'flex items-center space-x-2 px-4 py-2 rounded-md text-sm font-medium transition-all',
                    activeTab === tab.id
                      ? 'bg-enterprise-neon text-enterprise-dark'
                      : 'text-gray-400 hover:text-white hover:bg-white/5'
                  )}
                >
                  <Icon className="h-4 w-4" />
                  <span>{tab.label}</span>
                </button>
              )
            })}
          </div>
        </CardHeader>
        
        <CardContent>
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
            >
              {renderTabContent()}
            </motion.div>
          </AnimatePresence>
        </CardContent>
      </Card>

      {/* Create Modal */}
      {renderCreateModal()}
    </div>
  )
}