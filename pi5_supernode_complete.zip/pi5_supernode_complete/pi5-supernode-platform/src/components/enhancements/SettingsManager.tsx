import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  Settings,
  Shield,
  Database,
  Key,
  Users,
  RefreshCw,
  Save,
} from 'lucide-react';

export function SettingsManager() {
  const [activeTab, setActiveTab] = useState('system');
  const [isLoading, setIsLoading] = useState(false);
  const [systemSettings, setSystemSettings] = useState({
    hostname: 'pi5-supernode',
    timezone: 'UTC',
    ssh_enabled: true,
    ssh_port: 22,
    auto_updates: true,
  });
  const [securitySettings, setSecuritySettings] = useState({
    firewall_enabled: true,
    fail2ban_enabled: true,
    two_factor_enabled: false,
    session_timeout: 3600,
  });

  const tabs = [
    { id: 'system', label: 'System', icon: Settings },
    { id: 'security', label: 'Security', icon: Shield },
    { id: 'backup', label: 'Backup', icon: Database },
    { id: 'api', label: 'API Keys', icon: Key },
    { id: 'users', label: 'Users', icon: Users },
  ];

  const saveSystemSettings = async () => {
    setIsLoading(true);
    try {
      const response = await fetch('/functions/v1/comprehensive-settings-manager/system-settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(systemSettings),
      });
      const result = await response.json();
      if (result.data?.success) {
        console.log('System settings saved successfully');
      }
    } catch (error) {
      console.error('Failed to save system settings:', error);
    }
    setIsLoading(false);
  };

  const saveSecuritySettings = async () => {
    setIsLoading(true);
    try {
      const response = await fetch('/functions/v1/comprehensive-settings-manager/security-settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(securitySettings),
      });
      const result = await response.json();
      if (result.data?.success) {
        console.log('Security settings saved successfully');
      }
    } catch (error) {
      console.error('Failed to save security settings:', error);
    }
    setIsLoading(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white mb-2">Comprehensive Settings</h2>
          <p className="text-gray-400">Manage all system settings, security, users, and API access</p>
        </div>
        <div className="flex items-center space-x-3">
          <Button onClick={() => window.location.reload()} disabled={isLoading}>
            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh All
          </Button>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="flex space-x-1 bg-gray-800/30 p-1 rounded-lg w-fit">
        {tabs.map((tab) => {
          const TabIcon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-md transition-all duration-200 ${
                activeTab === tab.id
                  ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <TabIcon className="h-4 w-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tab Content */}
      {activeTab === 'system' && (
        <Card>
          <CardHeader>
            <CardTitle>System Configuration</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Hostname</label>
                <input
                  type="text"
                  className="w-full bg-gray-800/50 border border-gray-600 rounded-lg px-3 py-2 text-white"
                  value={systemSettings.hostname}
                  onChange={(e) => 
                    setSystemSettings(prev => ({ ...prev, hostname: e.target.value }))
                  }
                  placeholder="pi5-supernode"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Timezone</label>
                <select
                  className="w-full bg-gray-800/50 border border-gray-600 rounded-lg px-3 py-2 text-white"
                  value={systemSettings.timezone}
                  onChange={(e) => 
                    setSystemSettings(prev => ({ ...prev, timezone: e.target.value }))
                  }
                >
                  <option value="UTC">UTC</option>
                  <option value="America/New_York">Eastern Time</option>
                  <option value="America/Chicago">Central Time</option>
                  <option value="America/Denver">Mountain Time</option>
                  <option value="America/Los_Angeles">Pacific Time</option>
                  <option value="Europe/London">London</option>
                  <option value="Asia/Tokyo">Tokyo</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">SSH Port</label>
                <input
                  type="number"
                  className="w-full bg-gray-800/50 border border-gray-600 rounded-lg px-3 py-2 text-white"
                  value={systemSettings.ssh_port}
                  onChange={(e) => 
                    setSystemSettings(prev => ({ ...prev, ssh_port: parseInt(e.target.value) || 22 }))
                  }
                  placeholder="22"
                />
              </div>
            </div>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium text-white">SSH Access</h3>
                  <p className="text-sm text-gray-400">Enable remote SSH access</p>
                </div>
                <input
                  type="checkbox"
                  checked={systemSettings.ssh_enabled}
                  onChange={(e) => 
                    setSystemSettings(prev => ({ ...prev, ssh_enabled: e.target.checked }))
                  }
                  className="w-5 h-5"
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium text-white">Automatic Updates</h3>
                  <p className="text-sm text-gray-400">Install security updates automatically</p>
                </div>
                <input
                  type="checkbox"
                  checked={systemSettings.auto_updates}
                  onChange={(e) => 
                    setSystemSettings(prev => ({ ...prev, auto_updates: e.target.checked }))
                  }
                  className="w-5 h-5"
                />
              </div>
            </div>
            
            <div className="pt-4 border-t border-gray-700">
              <Button onClick={saveSystemSettings} disabled={isLoading}>
                <Save className="w-4 h-4 mr-2" />
                Save System Settings
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {activeTab === 'security' && (
        <Card>
          <CardHeader>
            <CardTitle>Security Configuration</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium text-white">Firewall Protection</h3>
                  <p className="text-sm text-gray-400">Enable network firewall</p>
                </div>
                <input
                  type="checkbox"
                  checked={securitySettings.firewall_enabled}
                  onChange={(e) => 
                    setSecuritySettings(prev => ({ ...prev, firewall_enabled: e.target.checked }))
                  }
                  className="w-5 h-5"
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium text-white">Fail2Ban Protection</h3>
                  <p className="text-sm text-gray-400">Block malicious IP addresses</p>
                </div>
                <input
                  type="checkbox"
                  checked={securitySettings.fail2ban_enabled}
                  onChange={(e) => 
                    setSecuritySettings(prev => ({ ...prev, fail2ban_enabled: e.target.checked }))
                  }
                  className="w-5 h-5"
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium text-white">Two-Factor Authentication</h3>
                  <p className="text-sm text-gray-400">Require 2FA for admin access</p>
                </div>
                <input
                  type="checkbox"
                  checked={securitySettings.two_factor_enabled}
                  onChange={(e) => 
                    setSecuritySettings(prev => ({ ...prev, two_factor_enabled: e.target.checked }))
                  }
                  className="w-5 h-5"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Session Timeout (seconds)</label>
                <input
                  type="number"
                  className="w-full bg-gray-800/50 border border-gray-600 rounded-lg px-3 py-2 text-white"
                  value={securitySettings.session_timeout}
                  onChange={(e) => 
                    setSecuritySettings(prev => ({ 
                      ...prev, 
                      session_timeout: parseInt(e.target.value) || 3600 
                    }))
                  }
                  placeholder="3600"
                />
              </div>
            </div>
            
            <div className="pt-4 border-t border-gray-700">
              <Button onClick={saveSecuritySettings} disabled={isLoading}>
                <Save className="w-4 h-4 mr-2" />
                Save Security Settings
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {activeTab === 'backup' && (
        <Card>
          <CardHeader>
            <CardTitle>System Backup</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-4">
              <h3 className="font-semibold text-blue-400 mb-2">Backup Information</h3>
              <p className="text-gray-300">
                System backups include configuration files, user data, network settings, 
                VPN configurations, and application data.
              </p>
            </div>
            
            <div className="flex items-center space-x-4">
              <Button>
                <Database className="w-4 h-4 mr-2" />
                Create Backup Now
              </Button>
              <Button variant="outline">
                Download Latest
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {activeTab === 'api' && (
        <Card>
          <CardHeader>
            <CardTitle>API Key Management</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="text-center py-8">
              <Key className="w-16 h-16 text-gray-500 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-white mb-2">API Keys</h3>
              <p className="text-gray-400 mb-4">
                Manage API keys for external integrations and automation.
              </p>
              <Button>
                Generate New API Key
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {activeTab === 'users' && (
        <Card>
          <CardHeader>
            <CardTitle>User Management</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="text-center py-8">
              <Users className="w-16 h-16 text-gray-500 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-white mb-2">User Accounts</h3>
              <p className="text-gray-400 mb-4">
                Manage system users and their permissions.
              </p>
              <Button>
                Add New User
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

export default SettingsManager;