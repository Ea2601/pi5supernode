import { useEffect, useRef, useState } from 'react'
import { io, Socket } from 'socket.io-client'
import { useNetworkStore, useVPNStore, useUIStore } from '@/lib/store'
import { supabase } from '@/lib/supabase'

export interface SystemMetrics {
  cpu: number
  memory: number
  network: {
    upload: number
    download: number
  }
  temperature: number
  uptime: number
  timestamp: number
}

export interface DeviceStatus {
  mac_address: string
  is_active: boolean
  last_seen: string
  bytes_sent: number
  bytes_received: number
}

export interface VPNStatus {
  server_id: string
  client_id: string
  is_connected: boolean
  last_handshake: string
  bytes_sent: number
  bytes_received: number
}

export const useRealTimeUpdates = () => {
  const socketRef = useRef<Socket | null>(null)
  const [isConnected, setIsConnected] = useState(false)
  const [systemMetrics, setSystemMetrics] = useState<SystemMetrics | null>(null)
  
  const { updateDevice } = useNetworkStore()
  const { updateClient } = useVPNStore()
  const { addNotification } = useUIStore()

  useEffect(() => {
    // Initialize WebSocket connection
    // In a real implementation, this would connect to your Pi5 WebSocket server
    // For demo purposes, we'll simulate real-time updates
    
    const simulateRealTimeUpdates = () => {
      // Simulate system metrics updates every 5 seconds
      const metricsInterval = setInterval(() => {
        const newMetrics: SystemMetrics = {
          cpu: Math.random() * 100,
          memory: Math.random() * 100,
          network: {
            upload: Math.random() * 1000,
            download: Math.random() * 2000
          },
          temperature: 40 + Math.random() * 20,
          uptime: Date.now() / 1000,
          timestamp: Date.now()
        }
        setSystemMetrics(newMetrics)
      }, 5000)

      // Simulate device status updates every 10 seconds
      const deviceInterval = setInterval(async () => {
        try {
          const { data: devices } = await supabase
            .from('network_devices')
            .select('mac_address')
            .limit(5)
          
          if (devices && devices.length > 0) {
            const randomDevice = devices[Math.floor(Math.random() * devices.length)]
            const statusUpdate: DeviceStatus = {
              mac_address: randomDevice.mac_address,
              is_active: Math.random() > 0.2, // 80% chance of being active
              last_seen: new Date().toISOString(),
              bytes_sent: Math.floor(Math.random() * 1000000),
              bytes_received: Math.floor(Math.random() * 5000000)
            }
            
            // Update device in store
            updateDevice(statusUpdate.mac_address, {
              is_active: statusUpdate.is_active,
              last_seen: statusUpdate.last_seen
            })
          }
        } catch (error) {
          console.error('Error simulating device updates:', error)
        }
      }, 10000)

      return () => {
        clearInterval(metricsInterval)
        clearInterval(deviceInterval)
      }
    }

    const cleanup = simulateRealTimeUpdates()
    setIsConnected(true)

    return cleanup
  }, [])

  // Set up Supabase real-time subscriptions
  useEffect(() => {
    // Subscribe to network device changes
    const deviceSubscription = supabase
      .channel('network_devices')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'network_devices'
      }, (payload) => {
        console.log('Device change detected:', payload)
        
        if (payload.eventType === 'UPDATE' && payload.new) {
          updateDevice(payload.new.mac_address, payload.new)
          addNotification({
            type: 'info',
            message: `Device ${payload.new.device_name || payload.new.mac_address} updated`
          })
        }
      })
      .subscribe()

    // Subscribe to traffic rule changes
    const trafficRuleSubscription = supabase
      .channel('traffic_rules')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'traffic_rules'
      }, (payload) => {
        console.log('Traffic rule change detected:', payload)
        
        if (payload.eventType === 'INSERT') {
          addNotification({
            type: 'success',
            message: `New traffic rule '${payload.new.name}' created`
          })
        } else if (payload.eventType === 'UPDATE') {
          addNotification({
            type: 'info',
            message: `Traffic rule '${payload.new.name}' updated`
          })
        }
      })
      .subscribe()

    // Subscribe to VPN client changes
    const vpnSubscription = supabase
      .channel('wireguard_clients')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'wireguard_clients'
      }, (payload) => {
        console.log('VPN client change detected:', payload)
        
        if (payload.eventType === 'UPDATE' && payload.new) {
          updateClient(payload.new.id, payload.new)
          
          const statusMessage = payload.new.is_active 
            ? `Client ${payload.new.client_name} connected`
            : `Client ${payload.new.client_name} disconnected`
          
          addNotification({
            type: payload.new.is_active ? 'success' : 'warning',
            message: statusMessage
          })
        }
      })
      .subscribe()

    // Cleanup subscriptions
    return () => {
      supabase.removeChannel(deviceSubscription)
      supabase.removeChannel(trafficRuleSubscription)
      supabase.removeChannel(vpnSubscription)
    }
  }, [])

  const sendCommand = (command: string, data?: any) => {
    if (socketRef.current && isConnected) {
      socketRef.current.emit(command, data)
    } else {
      console.warn('WebSocket not connected')
    }
  }

  const subscribeToMetrics = (callback: (metrics: SystemMetrics) => void) => {
    useEffect(() => {
      if (systemMetrics) {
        callback(systemMetrics)
      }
    }, [systemMetrics, callback])
  }

  return {
    isConnected,
    systemMetrics,
    sendCommand,
    subscribeToMetrics
  }
}

// Hook for monitoring system health
export const useSystemHealth = () => {
  const [healthStatus, setHealthStatus] = useState({
    cpu_healthy: true,
    memory_healthy: true,
    disk_healthy: true,
    network_healthy: true,
    temperature_healthy: true,
    overall_status: 'healthy' as 'healthy' | 'warning' | 'critical'
  })

  const { systemMetrics } = useRealTimeUpdates()

  useEffect(() => {
    if (systemMetrics) {
      const newHealthStatus = {
        cpu_healthy: systemMetrics.cpu < 80,
        memory_healthy: systemMetrics.memory < 85,
        disk_healthy: true, // Would need disk metrics
        network_healthy: true, // Would need network health checks
        temperature_healthy: systemMetrics.temperature < 70
      }

      const healthyCount = Object.values(newHealthStatus).filter(Boolean).length
      const totalChecks = Object.keys(newHealthStatus).length
      
      let overall_status: 'healthy' | 'warning' | 'critical'
      if (healthyCount === totalChecks) {
        overall_status = 'healthy'
      } else if (healthyCount >= totalChecks * 0.7) {
        overall_status = 'warning'
      } else {
        overall_status = 'critical'
      }

      setHealthStatus({
        ...newHealthStatus,
        overall_status
      })
    }
  }, [systemMetrics])

  return healthStatus
}

// Hook for network monitoring
export const useNetworkMonitoring = () => {
  const [networkStats, setNetworkStats] = useState({
    total_devices: 0,
    active_devices: 0,
    blocked_devices: 0,
    bandwidth_usage: 0,
    packet_loss: 0,
    latency: 0
  })

  const { devices } = useNetworkStore()

  useEffect(() => {
    const stats = {
      total_devices: devices.length,
      active_devices: devices.filter(d => d.is_active).length,
      blocked_devices: devices.filter(d => !d.is_active).length,
      bandwidth_usage: Math.random() * 1000, // Simulated
      packet_loss: Math.random() * 5, // Simulated
      latency: 10 + Math.random() * 20 // Simulated
    }
    
    setNetworkStats(stats)
  }, [devices])

  return networkStats
}

// Hook for VPN monitoring
export const useVPNMonitoring = () => {
  const [vpnStats, setVpnStats] = useState({
    active_servers: 0,
    connected_clients: 0,
    total_throughput: 0,
    average_latency: 0,
    connection_uptime: 0
  })

  const { servers, clients } = useVPNStore()

  useEffect(() => {
    const stats = {
      active_servers: servers.filter(s => s.status === 'active').length,
      connected_clients: clients.filter(c => c.is_active).length,
      total_throughput: clients.reduce((sum, c) => sum + c.bytes_sent + c.bytes_received, 0),
      average_latency: 25 + Math.random() * 50, // Simulated
      connection_uptime: 99.5 + Math.random() * 0.5 // Simulated
    }
    
    setVpnStats(stats)
  }, [servers, clients])

  return vpnStats
}