import { useEffect } from 'react'
import { useLocation } from 'react-router-dom'

// Route title mappings
const routeTitles: Record<string, string> = {
  '/': 'Pi5 Supernode - Network Management Dashboard',
  '/dashboard': 'Dashboard - Pi5 Supernode',
  '/speed-testing': 'Network Speed Testing - Pi5 Supernode',
  '/traffic-rules': 'Traffic Rules Management - Pi5 Supernode',
  '/network-management': 'Network Management - Pi5 Supernode',
  '/network-management/dhcp': 'DHCP Management - Pi5 Supernode',
  '/network-management/wifi': 'WiFi Management - Pi5 Supernode',
  '/network-management/vlans': 'VLAN Management - Pi5 Supernode',
  '/wan-settings': 'WAN Settings - Pi5 Supernode',
  '/vpn-management': 'VPN Management - Pi5 Supernode',
  '/automations': 'Automation Rules - Pi5 Supernode',
  '/settings': 'System Settings - Pi5 Supernode',
  '/settings/system': 'System Configuration - Pi5 Supernode',
  '/settings/security': 'Security Settings - Pi5 Supernode',
  '/settings/backup': 'Backup & Restore - Pi5 Supernode',
  '/settings/users': 'User Management - Pi5 Supernode',
  '/settings/advanced': 'Advanced Settings - Pi5 Supernode'
}

const usePageTitle = () => {
  const location = useLocation()
  
  useEffect(() => {
    const title = routeTitles[location.pathname] || 'Pi5 Supernode - Network Management'
    document.title = title
    
    // Update meta description based on route
    let description = 'Professional network management platform for Pi5 Supernode'
    
    if (location.pathname.includes('/speed-testing')) {
      description = 'Test and monitor network speed and performance with Pi5 Supernode'
    } else if (location.pathname.includes('/traffic-rules')) {
      description = 'Configure advanced traffic rules and bandwidth management'
    } else if (location.pathname.includes('/network-management')) {
      description = 'Manage DHCP, WiFi, and VLAN configurations'
    } else if (location.pathname.includes('/wan-settings')) {
      description = 'Configure multi-WAN connections and load balancing'
    } else if (location.pathname.includes('/vpn-management')) {
      description = 'Setup and manage VPN and WireGuard connections'
    } else if (location.pathname.includes('/automations')) {
      description = 'Create automation rules with Telegram and webhook integrations'
    } else if (location.pathname.includes('/settings')) {
      description = 'Configure system settings, security, and user management'
    }
    
    // Update meta description
    const metaDescription = document.querySelector('meta[name="description"]')
    if (metaDescription) {
      metaDescription.setAttribute('content', description)
    }
    
  }, [location.pathname])
}

export default usePageTitle