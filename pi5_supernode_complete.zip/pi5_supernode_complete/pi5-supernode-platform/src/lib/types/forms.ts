// Consolidated form data types to reduce duplication

// Device-related form data
export interface DeviceFormData {
  device_name: string
  device_type: string
  ip_address: string
  mac_address: string
  description?: string
}

// Network-related form data
export interface TrafficRuleFormData {
  name: string
  description: string
  priority: number
  enabled: boolean
  conditions: {
    source_ip?: string
    destination_ip?: string
    protocol?: string
    port?: string
    time_range?: string
  }
  actions: {
    allow?: boolean
    block?: boolean
    bandwidth_limit?: number
    redirect_to?: string
  }
}

export interface DNSServerFormData {
  name: string
  ip_address: string
  port: number
  type: string
  is_primary: boolean
  is_active: boolean
}

// VPN-related form data
export interface VPNServerFormData {
  server_name: string
  listen_port: number
  network: string
  endpoint: string
  max_clients: number
}

export interface VPNClientFormData {
  client_name: string
  server_id: string
  allowed_ips: string[]
}

// Automation-related form data
export interface AutomationRuleFormData {
  name: string
  description: string
  trigger: {
    type: string
    conditions: Record<string, any>
  }
  actions: {
    type: string
    parameters: Record<string, any>
  }[]
  enabled: boolean
}

// Storage-related form data
export interface StorageVolumeFormData {
  name: string
  mount_point: string
  device_path: string
  filesystem: string
  auto_mount: boolean
}

// Common form validation patterns
export interface FormValidationResult {
  isValid: boolean
  errors: Record<string, string>
}

// Common form state
export interface FormState<T> {
  data: T
  loading: boolean
  errors: Record<string, string>
  touched: Record<string, boolean>
}
