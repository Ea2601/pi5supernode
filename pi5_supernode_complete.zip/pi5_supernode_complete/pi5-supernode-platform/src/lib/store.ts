import { create } from 'zustand'
import { devtools, persist } from 'zustand/middleware'

// Authentication Store
interface AuthState {
  user: any | null
  session: any | null
  loading: boolean
  setUser: (user: any) => void
  setSession: (session: any) => void
  setLoading: (loading: boolean) => void
  signOut: () => void
}

export const useAuthStore = create<AuthState>()
  (devtools(
    persist(
      (set) => ({
        user: null,
        session: null,
        loading: false,
        setUser: (user) => set({ user }),
        setSession: (session) => set({ session }),
        setLoading: (loading) => set({ loading }),
        signOut: () => set({ user: null, session: null })
      }),
      { name: 'auth-store' }
    ),
    { name: 'auth-store' }
  ))

// Network Management Store
export interface NetworkDevice {
  mac_address: string
  ip_address: string
  device_name: string
  device_type: string
  device_brand: string
  last_seen: string
  is_active: boolean
  first_discovered: string
  dhcp_lease_expires?: string
  vendor_info?: string
  created_at: string
  updated_at: string
}

export interface TrafficRule {
  id: string
  name: string
  description?: string
  priority: number
  enabled: boolean
  conditions: Record<string, any>
  actions: Record<string, any>
  client_group_id?: string
  created_at: string
  updated_at: string
}

interface NetworkState {
  devices: NetworkDevice[]
  trafficRules: TrafficRule[]
  selectedDevice: NetworkDevice | null
  isDiscovering: boolean
  setDevices: (devices: NetworkDevice[]) => void
  addDevice: (device: NetworkDevice) => void
  updateDevice: (mac: string, updates: Partial<NetworkDevice>) => void
  removeDevice: (mac: string) => void
  setSelectedDevice: (device: NetworkDevice | null) => void
  setTrafficRules: (rules: TrafficRule[]) => void
  addTrafficRule: (rule: TrafficRule) => void
  updateTrafficRule: (id: string, updates: Partial<TrafficRule>) => void
  removeTrafficRule: (id: string) => void
  setDiscovering: (discovering: boolean) => void
}

export const useNetworkStore = create<NetworkState>()
  (devtools(
    (set, get) => ({
      devices: [],
      trafficRules: [],
      selectedDevice: null,
      isDiscovering: false,
      setDevices: (devices) => set({ devices }),
      addDevice: (device) => set((state) => ({ devices: [...state.devices, device] })),
      updateDevice: (mac, updates) => set((state) => ({
        devices: state.devices.map(device => 
          device.mac_address === mac ? { ...device, ...updates } : device
        )
      })),
      removeDevice: (mac) => set((state) => ({
        devices: state.devices.filter(device => device.mac_address !== mac)
      })),
      setSelectedDevice: (device) => set({ selectedDevice: device }),
      setTrafficRules: (rules) => set({ trafficRules: rules }),
      addTrafficRule: (rule) => set((state) => ({ trafficRules: [...state.trafficRules, rule] })),
      updateTrafficRule: (id, updates) => set((state) => ({
        trafficRules: state.trafficRules.map(rule => 
          rule.id === id ? { ...rule, ...updates } : rule
        )
      })),
      removeTrafficRule: (id) => set((state) => ({
        trafficRules: state.trafficRules.filter(rule => rule.id !== id)
      })),
      setDiscovering: (discovering) => set({ isDiscovering: discovering })
    }),
    { name: 'network-store' }
  ))

// VPN Management Store
export interface WireGuardServer {
  id: string
  server_name: string
  public_key: string
  private_key: string
  listen_port: number
  endpoint: string
  network: string
  status: 'active' | 'inactive' | 'stopped'
  client_count: number
  max_clients: number
  created_at: string
  updated_at: string
}

export interface WireGuardClient {
  id: string
  server_id: string
  client_name: string
  public_key: string
  private_key: string
  assigned_ip: string
  allowed_ips: string[]
  preshared_key?: string
  is_active: boolean
  last_handshake?: string
  bytes_received: number
  bytes_sent: number
  config_downloaded_at?: string
  created_at: string
}

interface VPNState {
  servers: WireGuardServer[]
  clients: WireGuardClient[]
  selectedServer: WireGuardServer | null
  selectedClient: WireGuardClient | null
  setServers: (servers: WireGuardServer[]) => void
  addServer: (server: WireGuardServer) => void
  updateServer: (id: string, updates: Partial<WireGuardServer>) => void
  removeServer: (id: string) => void
  setSelectedServer: (server: WireGuardServer | null) => void
  setClients: (clients: WireGuardClient[]) => void
  addClient: (client: WireGuardClient) => void
  updateClient: (id: string, updates: Partial<WireGuardClient>) => void
  removeClient: (id: string) => void
  setSelectedClient: (client: WireGuardClient | null) => void
}

export const useVPNStore = create<VPNState>()
  (devtools(
    (set) => ({
      servers: [],
      clients: [],
      selectedServer: null,
      selectedClient: null,
      setServers: (servers) => set({ servers }),
      addServer: (server) => set((state) => ({ servers: [...state.servers, server] })),
      updateServer: (id, updates) => set((state) => ({
        servers: state.servers.map(server => 
          server.id === id ? { ...server, ...updates } : server
        )
      })),
      removeServer: (id) => set((state) => ({
        servers: state.servers.filter(server => server.id !== id)
      })),
      setSelectedServer: (server) => set({ selectedServer: server }),
      setClients: (clients) => set({ clients }),
      addClient: (client) => set((state) => ({ clients: [...state.clients, client] })),
      updateClient: (id, updates) => set((state) => ({
        clients: state.clients.map(client => 
          client.id === id ? { ...client, ...updates } : client
        )
      })),
      removeClient: (id) => set((state) => ({
        clients: state.clients.filter(client => client.id !== id)
      })),
      setSelectedClient: (client) => set({ selectedClient: client })
    }),
    { name: 'vpn-store' }
  ))

// UI State Store
interface UIState {
  sidebarCollapsed: boolean
  currentView: string
  notifications: Array<{ id: string; type: 'success' | 'error' | 'warning' | 'info'; message: string; timestamp: Date }>
  setSidebarCollapsed: (collapsed: boolean) => void
  setCurrentView: (view: string) => void
  addNotification: (notification: Omit<UIState['notifications'][0], 'id' | 'timestamp'>) => void
  removeNotification: (id: string) => void
  clearNotifications: () => void
}

export const useUIStore = create<UIState>()
  (devtools(
    persist(
      (set) => ({
        sidebarCollapsed: false,
        currentView: 'dashboard',
        notifications: [],
        setSidebarCollapsed: (collapsed) => set({ sidebarCollapsed: collapsed }),
        setCurrentView: (view) => set({ currentView: view }),
        addNotification: (notification) => set((state) => ({
          notifications: [
            ...state.notifications,
            {
              ...notification,
              id: Math.random().toString(36).substring(2),
              timestamp: new Date()
            }
          ]
        })),
        removeNotification: (id) => set((state) => ({
          notifications: state.notifications.filter(n => n.id !== id)
        })),
        clearNotifications: () => set({ notifications: [] })
      }),
      { name: 'ui-store' }
    ),
    { name: 'ui-store' }
  ))