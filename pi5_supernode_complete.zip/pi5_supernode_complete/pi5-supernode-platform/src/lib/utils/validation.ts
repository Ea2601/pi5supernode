// Consolidated validation utilities to reduce code duplication

import { FormValidationResult } from '../types/forms'

// Common validation patterns
export const VALIDATION_PATTERNS = {
  IP_ADDRESS: /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/,
  MAC_ADDRESS: /^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$/,
  DOMAIN_NAME: /^(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*)?$/,
  CIDR_NETWORK: /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\/(?:[0-9]|[1-2][0-9]|3[0-2])$/,
  EMAIL: /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/,
  HOSTNAME: /^[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?$/
}

// Generic validation functions
export const validateRequired = (value: any, fieldName: string): string | null => {
  if (!value || (typeof value === 'string' && value.trim() === '')) {
    return `${fieldName} is required`
  }
  return null
}

export const validateIPAddress = (ip: string): string | null => {
  if (!VALIDATION_PATTERNS.IP_ADDRESS.test(ip)) {
    return 'Invalid IP address format'
  }
  return null
}

export const validateMACAddress = (mac: string): string | null => {
  if (!VALIDATION_PATTERNS.MAC_ADDRESS.test(mac)) {
    return 'Invalid MAC address format'
  }
  return null
}

export const validatePort = (port: number): string | null => {
  if (!Number.isInteger(port) || port < 1 || port > 65535) {
    return 'Port must be between 1 and 65535'
  }
  return null
}

export const validateCIDRNetwork = (network: string): string | null => {
  if (!VALIDATION_PATTERNS.CIDR_NETWORK.test(network)) {
    return 'Invalid CIDR network format (e.g., 192.168.1.0/24)'
  }
  return null
}

export const validateEmail = (email: string): string | null => {
  if (!VALIDATION_PATTERNS.EMAIL.test(email)) {
    return 'Invalid email address format'
  }
  return null
}

export const validateHostname = (hostname: string): string | null => {
  if (!VALIDATION_PATTERNS.HOSTNAME.test(hostname)) {
    return 'Invalid hostname format'
  }
  return null
}

export const validateStringLength = (value: string, min: number, max: number, fieldName: string): string | null => {
  if (value.length < min) {
    return `${fieldName} must be at least ${min} characters`
  }
  if (value.length > max) {
    return `${fieldName} must be no more than ${max} characters`
  }
  return null
}

export const validateNumberRange = (value: number, min: number, max: number, fieldName: string): string | null => {
  if (value < min || value > max) {
    return `${fieldName} must be between ${min} and ${max}`
  }
  return null
}

// Compound validation functions for common use cases
export const validateDeviceForm = (data: any): FormValidationResult => {
  const errors: Record<string, string> = {}
  
  // Device name validation
  const nameError = validateRequired(data.device_name, 'Device name') ||
                   validateStringLength(data.device_name, 1, 50, 'Device name')
  if (nameError) errors.device_name = nameError
  
  // IP address validation
  if (data.ip_address) {
    const ipError = validateIPAddress(data.ip_address)
    if (ipError) errors.ip_address = ipError
  }
  
  // MAC address validation
  const macError = validateRequired(data.mac_address, 'MAC address') ||
                   validateMACAddress(data.mac_address)
  if (macError) errors.mac_address = macError
  
  return {
    isValid: Object.keys(errors).length === 0,
    errors
  }
}

export const validateNetworkForm = (data: any): FormValidationResult => {
  const errors: Record<string, string> = {}
  
  // Name validation
  const nameError = validateRequired(data.name, 'Name') ||
                   validateStringLength(data.name, 1, 100, 'Name')
  if (nameError) errors.name = nameError
  
  // Priority validation
  if (data.priority !== undefined) {
    const priorityError = validateNumberRange(data.priority, 1, 1000, 'Priority')
    if (priorityError) errors.priority = priorityError
  }
  
  return {
    isValid: Object.keys(errors).length === 0,
    errors
  }
}

export const validateVPNServerForm = (data: any): FormValidationResult => {
  const errors: Record<string, string> = {}
  
  // Server name validation
  const nameError = validateRequired(data.server_name, 'Server name') ||
                   validateStringLength(data.server_name, 1, 50, 'Server name')
  if (nameError) errors.server_name = nameError
  
  // Port validation
  const portError = validateRequired(data.listen_port, 'Listen port') ||
                   validatePort(data.listen_port)
  if (portError) errors.listen_port = portError
  
  // Network validation
  const networkError = validateRequired(data.network, 'Network') ||
                      validateCIDRNetwork(data.network)
  if (networkError) errors.network = networkError
  
  // Endpoint validation
  if (data.endpoint) {
    const endpointError = validateHostname(data.endpoint) ||
                         validateIPAddress(data.endpoint)
    if (endpointError) errors.endpoint = 'Invalid endpoint (must be hostname or IP)'
  }
  
  return {
    isValid: Object.keys(errors).length === 0,
    errors
  }
}

export const validateDNSServerForm = (data: any): FormValidationResult => {
  const errors: Record<string, string> = {}
  
  // Name validation
  const nameError = validateRequired(data.name, 'Server name') ||
                   validateStringLength(data.name, 1, 50, 'Server name')
  if (nameError) errors.name = nameError
  
  // IP address validation
  const ipError = validateRequired(data.ip_address, 'IP address') ||
                 validateIPAddress(data.ip_address)
  if (ipError) errors.ip_address = ipError
  
  // Port validation
  const portError = validateRequired(data.port, 'Port') ||
                   validatePort(data.port)
  if (portError) errors.port = portError
  
  return {
    isValid: Object.keys(errors).length === 0,
    errors
  }
}
