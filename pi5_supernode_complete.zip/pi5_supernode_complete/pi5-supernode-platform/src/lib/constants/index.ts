// Consolidated constants to reduce duplication and improve maintainability

// Common form field configurations
export const FORM_FIELD_SIZES = {
  SMALL: 'sm',
  MEDIUM: 'md', 
  LARGE: 'lg'
} as const

// Common validation constraints
export const VALIDATION_CONSTRAINTS = {
  DEVICE_NAME_MAX_LENGTH: 50,
  DESCRIPTION_MAX_LENGTH: 255,
  HOSTNAME_MAX_LENGTH: 63,
  PORT_MIN: 1,
  PORT_MAX: 65535,
  PRIORITY_MIN: 1,
  PRIORITY_MAX: 1000,
  PASSWORD_MIN_LENGTH: 8,
  USERNAME_MIN_LENGTH: 3
} as const

// Default network configurations
export const NETWORK_DEFAULTS = {
  CIDR_RANGES: [
    '10.0.0.0/8',
    '172.16.0.0/12', 
    '192.168.0.0/16'
  ],
  DNS_SERVERS: [
    '1.1.1.1',
    '8.8.8.8',
    '9.9.9.9',
    '208.67.222.222'
  ],
  VPN_PORTS: [51820, 51821, 51822],
  DEFAULT_VPN_NETWORK: '10.8.0.0/24',
  DEFAULT_SSH_PORT: 22,
  DEFAULT_DNS_PORT: 53
} as const

// Common device types
export const DEVICE_TYPES = [
  'Router',
  'Switch', 
  'Access Point',
  'Computer',
  'Laptop',
  'Smartphone',
  'Tablet',
  'IoT Device',
  'Game Console',
  'Smart TV',
  'Network Attached Storage',
  'Security Camera',
  'Printer',
  'Unknown'
] as const

// VPN related constants
export const VPN_CONFIG = {
  SERVER_TYPES: ['WireGuard', 'OpenVPN', 'IPSec'],
  ENCRYPTION_TYPES: ['ChaCha20-Poly1305', 'AES-256-GCM'],
  DEFAULT_KEEPALIVE: 25,
  DEFAULT_MTU: 1420,
  ALLOWED_IPS_PRESETS: {
    FULL_TUNNEL: ['0.0.0.0/0'],
    LOCAL_ONLY: ['192.168.0.0/16', '10.0.0.0/8', '172.16.0.0/12'],
    CUSTOM: []
  }
} as const

// Storage and filesystem constants
export const STORAGE_CONFIG = {
  FILESYSTEMS: ['ext4', 'btrfs', 'xfs', 'ntfs', 'exfat'],
  MOUNT_OPTIONS: {
    DEFAULT: 'defaults',
    READ_ONLY: 'ro',
    NO_EXEC: 'noexec',
    NO_SUID: 'nosuid'
  },
  SIZE_THRESHOLDS: {
    WARNING: 0.8,
    CRITICAL: 0.95
  }
} as const

// Security and firewall constants
export const SECURITY_CONFIG = {
  PROTOCOLS: ['tcp', 'udp', 'icmp', 'any'],
  FIREWALL_ACTIONS: ['allow', 'block', 'reject'],
  LOG_LEVELS: ['emergency', 'alert', 'critical', 'error', 'warning', 'notice', 'info', 'debug'],
  SESSION_TIMEOUT_OPTIONS: [300, 900, 1800, 3600, 7200, 14400] // in seconds
} as const

// Time and scheduling constants
export const TIME_CONFIG = {
  TIMEZONES: [
    'UTC',
    'America/New_York',
    'America/Chicago', 
    'America/Denver',
    'America/Los_Angeles',
    'Europe/London',
    'Europe/Paris',
    'Europe/Berlin',
    'Asia/Tokyo',
    'Asia/Shanghai',
    'Australia/Sydney'
  ],
  CRON_PRESETS: {
    HOURLY: '0 * * * *',
    DAILY: '0 2 * * *',
    WEEKLY: '0 2 * * 0',
    MONTHLY: '0 2 1 * *'
  },
  UPDATE_INTERVALS: {
    REAL_TIME: 1000,
    FAST: 5000,
    NORMAL: 30000,
    SLOW: 60000
  }
} as const

// API and pagination constants
export const API_CONFIG = {
  DEFAULT_PAGE_SIZE: 25,
  MAX_PAGE_SIZE: 100,
  REQUEST_TIMEOUT: 30000,
  RETRY_ATTEMPTS: 3,
  RETRY_DELAY: 1000
} as const

// UI and display constants
export const UI_CONFIG = {
  TOAST_DURATION: 5000,
  MODAL_ANIMATION_DURATION: 200,
  SIDEBAR_COLLAPSE_BREAKPOINT: 768,
  TABLE_ROWS_PER_PAGE_OPTIONS: [10, 25, 50, 100],
  CHART_REFRESH_INTERVAL: 30000,
  SEARCH_DEBOUNCE_DELAY: 300
} as const

// Status and health check constants
export const STATUS_CONFIG = {
  HEALTH_CHECK_INTERVAL: 60000,
  CONNECTION_TIMEOUT: 5000,
  SYSTEM_THRESHOLDS: {
    CPU_WARNING: 70,
    CPU_CRITICAL: 90,
    MEMORY_WARNING: 80,
    MEMORY_CRITICAL: 95,
    DISK_WARNING: 80,
    DISK_CRITICAL: 95,
    TEMPERATURE_WARNING: 70,
    TEMPERATURE_CRITICAL: 85
  }
} as const

// Export type helpers for better TypeScript support
export type DeviceType = typeof DEVICE_TYPES[number]
export type Protocol = typeof SECURITY_CONFIG.PROTOCOLS[number]
export type FirewallAction = typeof SECURITY_CONFIG.FIREWALL_ACTIONS[number]
export type LogLevel = typeof SECURITY_CONFIG.LOG_LEVELS[number]
export type Timezone = typeof TIME_CONFIG.TIMEZONES[number]
export type Filesystem = typeof STORAGE_CONFIG.FILESYSTEMS[number]
