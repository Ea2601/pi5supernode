import { supabase, callEdgeFunction } from '../supabase'
import { NetworkDevice } from '../store'

export class DeviceService {
  static async discoverDevices(): Promise<NetworkDevice[]> {
    try {
      // Call network discovery via edge function
      const result = await callEdgeFunction('device-management', {
        action: 'discover_devices',
        scan_type: 'full',
        timeout: 30
      })
      
      const devices = result.data || []
      
      // Store discovered devices in database
      const { data, error } = await supabase
        .from('network_devices')
        .upsert(devices, { onConflict: 'mac_address' })
        .select()
      
      if (error) throw error
      return data || []
    } catch (error) {
      console.error('Device discovery error:', error)
      throw error
    }
  }

  static async getAllDevices(): Promise<NetworkDevice[]> {
    try {
      const { data, error } = await supabase
        .from('network_devices')
        .select('*')
        .order('last_seen', { ascending: false })
      
      if (error) throw error
      return data || []
    } catch (error) {
      console.error('Error loading devices:', error)
      throw error
    }
  }

  static async updateDevice(macAddress: string, updates: Partial<NetworkDevice>): Promise<void> {
    try {
      const { error } = await supabase
        .from('network_devices')
        .update({ ...updates, updated_at: new Date().toISOString() })
        .eq('mac_address', macAddress)
      
      if (error) throw error
    } catch (error) {
      console.error('Error updating device:', error)
      throw error
    }
  }

  static async deleteDevice(macAddress: string): Promise<void> {
    try {
      const { error } = await supabase
        .from('network_devices')
        .delete()
        .eq('mac_address', macAddress)
      
      if (error) throw error
    } catch (error) {
      console.error('Error deleting device:', error)
      throw error
    }
  }

  static async wakeDevice(macAddress: string): Promise<void> {
    try {
      await callEdgeFunction('device-management', {
        action: 'wake_device',
        mac_address: macAddress
      })
    } catch (error) {
      console.error('Wake device error:', error)
      throw error
    }
  }

  static async addDevice(deviceData: Omit<NetworkDevice, 'created_at' | 'updated_at'>): Promise<void> {
    try {
      const { error } = await supabase
        .from('network_devices')
        .insert([{
          ...deviceData,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        }])
      
      if (error) throw error
    } catch (error) {
      console.error('Error adding device:', error)
      throw error
    }
  }

  static async blockDevice(macAddress: string, blocked: boolean = true): Promise<void> {
    try {
      // Update device status in database
      await this.updateDevice(macAddress, { is_active: !blocked })
      
      // Apply firewall rule via edge function
      await callEdgeFunction('device-management', {
        action: 'firewall_rule',
        mac_address: macAddress,
        rule_action: blocked ? 'block' : 'allow'
      })
    } catch (error) {
      console.error('Block device error:', error)
      throw error
    }
  }

  static subscribeToDeviceChanges(callback: (payload: any) => void) {
    return supabase
      .channel('network_devices_changes')
      .on('postgres_changes', 
        { event: '*', schema: 'public', table: 'network_devices' },
        callback
      )
      .subscribe()
  }
}

export default DeviceService