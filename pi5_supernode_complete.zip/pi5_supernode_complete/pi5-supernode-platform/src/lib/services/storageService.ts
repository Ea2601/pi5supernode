import { supabase, callEdgeFunction } from '../supabase'

export interface StorageDevice {
  id: string
  name: string
  type: 'usb' | 'sata' | 'nvme' | 'sd'
  device_path: string
  mount_point?: string
  total_size: number
  used_size: number
  file_system: string
  is_mounted: boolean
  is_encrypted: boolean
  status: 'healthy' | 'warning' | 'error'
  last_check: string
  created_at: string
}

export interface NetworkShare {
  id: string
  name: string
  protocol: 'smb' | 'nfs' | 'ftp' | 'sftp'
  path: string
  permissions: 'read' | 'write' | 'full'
  is_active: boolean
  allowed_users: string[]
  storage_device_id: string
  created_at: string
  access_count: number
  last_accessed?: string
}

export class StorageService {
  static async getAllStorageDevices(): Promise<StorageDevice[]> {
    try {
      // Get database records
      const { data: dbDevices, error: dbError } = await supabase
        .from('storage_devices')
        .select('*')
        .order('created_at', { ascending: false })
      
      if (dbError) throw dbError
      
      // Get real-time device information from edge function
      const result = await callEdgeFunction('storage-management', {
        action: 'get_devices'
      })
      
      if (result && result.data) {
        const systemDevices = result.data
        
        // Merge database and system information
        const mergedDevices = this.mergeDeviceData(dbDevices || [], systemDevices)
        return mergedDevices
      }
      
      return dbDevices || []
    } catch (error) {
      console.error('Error loading storage devices:', error)
      throw error
    }
  }

  static async getAllNetworkShares(): Promise<NetworkShare[]> {
    try {
      const { data, error } = await supabase
        .from('network_shares')
        .select(`
          *,
          storage_devices:storage_device_id (
            name,
            mount_point
          )
        `)
        .order('created_at', { ascending: false })
      
      if (error) throw error
      return data || []
    } catch (error) {
      console.error('Error loading network shares:', error)
      throw error
    }
  }

  static async refreshDevices(): Promise<StorageDevice[]> {
    try {
      // Scan for new devices via edge function
      const result = await callEdgeFunction('storage-management', {
        action: 'scan_devices'
      })
      
      const devices = result.data || []
      
      // Update database with discovered devices
      for (const device of devices) {
        await supabase
          .from('storage_devices')
          .upsert({
            ...device,
            created_at: device.created_at || new Date().toISOString(),
            last_check: new Date().toISOString()
          }, { onConflict: 'device_path' })
      }
      
      return await this.getAllStorageDevices()
    } catch (error) {
      console.error('Error refreshing devices:', error)
      throw error
    }
  }

  static async mountDevice(deviceId: string, mountPoint?: string): Promise<void> {
    try {
      const result = await callEdgeFunction('storage-management', {
        action: 'mount_device',
        device_id: deviceId,
        mount_point: mountPoint
      })
      
      // Update database
      const mountResult = result.data
      await supabase
        .from('storage_devices')
        .update({
          is_mounted: true,
          mount_point: mountResult.mount_point,
          last_check: new Date().toISOString()
        })
        .eq('id', deviceId)
      
    } catch (error) {
      console.error('Error mounting device:', error)
      throw error
    }
  }

  static async unmountDevice(deviceId: string): Promise<void> {
    try {
      await callEdgeFunction('storage-management', {
        action: 'unmount_device',
        device_id: deviceId
      })
      
      // Update database
      await supabase
        .from('storage_devices')
        .update({
          is_mounted: false,
          mount_point: null,
          last_check: new Date().toISOString()
        })
        .eq('id', deviceId)
      
    } catch (error) {
      console.error('Error unmounting device:', error)
      throw error
    }
  }

  static async createNetworkShare(shareData: Omit<NetworkShare, 'id' | 'created_at' | 'access_count'>): Promise<void> {
    try {
      // Create share in database
      const { data: newShare, error: dbError } = await supabase
        .from('network_shares')
        .insert([{
          ...shareData,
          access_count: 0,
          created_at: new Date().toISOString()
        }])
        .select()
        .single()
      
      if (dbError) throw dbError
      if (!newShare) throw new Error('Failed to create share')
      
      // Create actual network share via edge function
      try {
        await callEdgeFunction('storage-management', {
          action: 'create_share',
          shareData
        })
      } catch (error) {
        // Rollback database entry
        await supabase
          .from('network_shares')
          .delete()
          .eq('id', newShare.id)
        throw new Error('Network share creation failed')
      }
      
    } catch (error) {
      console.error('Error creating network share:', error)
      throw error
    }
  }

  static async updateNetworkShare(shareId: string, updates: Partial<NetworkShare>): Promise<void> {
    try {
      // Update database
      const { error: dbError } = await supabase
        .from('network_shares')
        .update(updates)
        .eq('id', shareId)
      
      if (dbError) throw dbError
      
      // Update system configuration via edge function
      try {
        await callEdgeFunction('storage-management', {
          action: 'update_share',
          shareId,
          updates
        })
      } catch (error) {
        console.warn('Failed to update system share configuration')
      }
      
    } catch (error) {
      console.error('Error updating network share:', error)
      throw error
    }
  }

  static async deleteNetworkShare(shareId: string): Promise<void> {
    try {
      // Delete from system first via edge function
      try {
        await callEdgeFunction('storage-management', {
          action: 'delete_share',
          shareId
        })
      } catch (error) {
        console.warn('Failed to delete system share')
      }
      
      // Delete from database
      const { error } = await supabase
        .from('network_shares')
        .delete()
        .eq('id', shareId)
      
      if (error) throw error
      
    } catch (error) {
      console.error('Error deleting network share:', error)
      throw error
    }
  }

  static async toggleShareStatus(shareId: string): Promise<void> {
    try {
      // Get current status
      const { data: share, error: fetchError } = await supabase
        .from('network_shares')
        .select('is_active')
        .eq('id', shareId)
        .single()
      
      if (fetchError) throw fetchError
      if (!share) throw new Error('Share not found')
      
      const newStatus = !share.is_active
      
      // Update system configuration via edge function
      await callEdgeFunction('storage-management', {
        action: 'toggle_share',
        shareId,
        active: newStatus
      })
      
      // Update database
      await supabase
        .from('network_shares')
        .update({ is_active: newStatus })
        .eq('id', shareId)
      
    } catch (error) {
      console.error('Error toggling share status:', error)
      throw error
    }
  }

  static async getDeviceUsage(deviceId: string): Promise<{
    total_size: number
    used_size: number
    free_size: number
    usage_percent: number
  }> {
    try {
      const result = await callEdgeFunction('storage-management', {
        action: 'get_device_usage',
        deviceId
      })
      return result.data
    } catch (error) {
      console.error('Error loading device usage:', error)
      throw error
    }
  }

  static async checkDeviceHealth(deviceId: string): Promise<{
    status: 'healthy' | 'warning' | 'error'
    smart_data?: Record<string, any>
    errors?: string[]
  }> {
    try {
      const result = await callEdgeFunction('storage-management', {
        action: 'check_device_health',
        deviceId
      })
      return result.data
    } catch (error) {
      console.error('Error checking device health:', error)
      throw error
    }
  }

  static async formatDevice(deviceId: string, fileSystem: string): Promise<void> {
    try {
      await callEdgeFunction('storage-management', {
        action: 'format_device',
        deviceId,
        file_system: fileSystem
      })
      
      // Update database
      await supabase
        .from('storage_devices')
        .update({
          file_system: fileSystem,
          used_size: 0,
          last_check: new Date().toISOString()
        })
        .eq('id', deviceId)
      
    } catch (error) {
      console.error('Error formatting device:', error)
      throw error
    }
  }

  static async getShareAccessLogs(shareId: string, limit: number = 50): Promise<Array<{
    timestamp: string
    user: string
    action: string
    file_path?: string
    client_ip?: string
  }>> {
    try {
      const result = await callEdgeFunction('storage-management', {
        action: 'get_share_logs',
        shareId,
        limit
      })
      return result.data
    } catch (error) {
      console.error('Error loading share access logs:', error)
      throw error
    }
  }

  private static mergeDeviceData(dbDevices: any[], systemDevices: any[]): StorageDevice[] {
    const mergedMap = new Map()
    
    // Add database devices
    dbDevices.forEach(device => {
      mergedMap.set(device.device_path, { ...device, source: 'db' })
    })
    
    // Merge with system devices
    systemDevices.forEach(sysDevice => {
      const existing = mergedMap.get(sysDevice.device_path)
      if (existing) {
        // Update with real-time data
        mergedMap.set(sysDevice.device_path, {
          ...existing,
          ...sysDevice,
          id: existing.id, // Keep database ID
          last_check: new Date().toISOString()
        })
      } else {
        // New device found
        mergedMap.set(sysDevice.device_path, {
          ...sysDevice,
          id: sysDevice.id || `temp_${Date.now()}`,
          created_at: new Date().toISOString(),
          last_check: new Date().toISOString()
        })
      }
    })
    
    return Array.from(mergedMap.values())
  }

  static subscribeToDeviceChanges(callback: (payload: any) => void) {
    return supabase
      .channel('storage_devices_changes')
      .on('postgres_changes', 
        { event: '*', schema: 'public', table: 'storage_devices' },
        callback
      )
      .subscribe()
  }

  static subscribeToShareChanges(callback: (payload: any) => void) {
    return supabase
      .channel('network_shares_changes')
      .on('postgres_changes', 
        { event: '*', schema: 'public', table: 'network_shares' },
        callback
      )
      .subscribe()
  }
}

export default StorageService