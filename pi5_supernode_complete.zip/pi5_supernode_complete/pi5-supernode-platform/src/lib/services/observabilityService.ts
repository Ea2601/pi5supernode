import { supabase, callEdgeFunction } from '../supabase'

export interface SystemMetrics {
  timestamp: string
  cpu_percent: number
  memory_percent: number
  temperature_celsius: number
  disk_usage_percent: number
  network_bytes_sent: number
  network_bytes_received: number
}

export interface AlertItem {
  id: string
  type: 'critical' | 'warning' | 'info'
  title: string
  description: string
  source: 'system' | 'network' | 'vpn' | 'automation'
  timestamp: string
  acknowledged: boolean
  metadata?: Record<string, any>
}

export interface ServiceHealth {
  service_name: string
  status: 'healthy' | 'warning' | 'critical'
  uptime_seconds: number
  last_check: string
  response_time_ms?: number
  error_message?: string
}

export class ObservabilityService {
  static async getSystemMetrics(timeRange: string = '1h'): Promise<SystemMetrics[]> {
    try {
      const { data, error } = await supabase
        .from('system_metrics')
        .select('*')
        .gte('timestamp', this.getTimeRangeStart(timeRange))
        .order('timestamp', { ascending: true })
      
      if (error) throw error
      return data || []
    } catch (error) {
      console.error('Error loading system metrics:', error)
      throw error
    }
  }

  static async getCurrentSystemHealth(): Promise<{
    overall_status: 'healthy' | 'warning' | 'critical'
    cpu_percent: number
    memory_percent: number
    temperature_celsius: number
    uptime_seconds: number
  }> {
    try {
      const result = await callEdgeFunction('system-monitoring', {
        action: 'get_system_health'
      })
      return result.data
    } catch (error) {
      console.error('Error loading system health:', error)
      throw error
    }
  }

  static async getNetworkStats(): Promise<{
    active_devices: number
    total_devices: number
    bytes_sent_per_sec: number
    bytes_received_per_sec: number
  }> {
    try {
      const result = await callEdgeFunction('system-monitoring', {
        action: 'get_network_stats'
      })
      return result.data
    } catch (error) {
      console.error('Error loading network stats:', error)
      throw error
    }
  }

  static async getVPNStats(): Promise<{
    active_servers: number
    total_clients: number
    connected_clients: number
    total_traffic_mb: number
  }> {
    try {
      const result = await callEdgeFunction('system-monitoring', {
        action: 'get_vpn_stats'
      })
      return result.data
    } catch (error) {
      console.error('Error loading VPN stats:', error)
      throw error
    }
  }

  static async getAlerts(): Promise<AlertItem[]> {
    try {
      const { data, error } = await supabase
        .from('audit_logs')
        .select('*')
        .eq('event_type', 'alert')
        .order('timestamp', { ascending: false })
        .limit(50)
      
      if (error) throw error
      
      return (data || []).map(log => ({
        id: log.id,
        type: log.metadata?.severity || 'info',
        title: log.event_description || 'System Alert',
        description: log.metadata?.description || '',
        source: log.metadata?.source || 'system',
        timestamp: log.timestamp,
        acknowledged: log.metadata?.acknowledged || false,
        metadata: log.metadata
      }))
    } catch (error) {
      console.error('Error loading alerts:', error)
      throw error
    }
  }

  static async acknowledgeAlert(alertId: string): Promise<void> {
    try {
      const { error } = await supabase
        .from('audit_logs')
        .update({ 
          metadata: { acknowledged: true, acknowledged_at: new Date().toISOString() }
        })
        .eq('id', alertId)
      
      if (error) throw error
    } catch (error) {
      console.error('Error acknowledging alert:', error)
      throw error
    }
  }

  static async dismissAlert(alertId: string): Promise<void> {
    try {
      const { error } = await supabase
        .from('audit_logs')
        .delete()
        .eq('id', alertId)
      
      if (error) throw error
    } catch (error) {
      console.error('Error dismissing alert:', error)
      throw error
    }
  }

  static async getServiceHealth(): Promise<ServiceHealth[]> {
    try {
      const result = await callEdgeFunction('system-monitoring', {
        action: 'get_service_health'
      })
      return result.data
    } catch (error) {
      console.error('Error loading service health:', error)
      throw error
    }
  }

  static async getNetworkTrafficData(timeRange: string = '1h'): Promise<Array<{
    timestamp: string
    bytes_sent: number
    bytes_received: number
    packets_sent: number
    packets_received: number
  }>> {
    try {
      const result = await callEdgeFunction('system-monitoring', {
        action: 'get_network_traffic',
        timeRange
      })
      return result.data
    } catch (error) {
      console.error('Error loading network traffic data:', error)
      throw error
    }
  }

  static async createAlert(alertData: Omit<AlertItem, 'id' | 'timestamp'>): Promise<void> {
    try {
      const { error } = await supabase
        .from('audit_logs')
        .insert([{
          event_type: 'alert',
          event_description: alertData.title,
          timestamp: new Date().toISOString(),
          metadata: {
            severity: alertData.type,
            description: alertData.description,
            source: alertData.source,
            acknowledged: false,
            ...alertData.metadata
          }
        }])
      
      if (error) throw error
    } catch (error) {
      console.error('Error creating alert:', error)
      throw error
    }
  }

  private static getTimeRangeStart(timeRange: string): string {
    const now = new Date()
    switch (timeRange) {
      case '1h':
        return new Date(now.getTime() - 60 * 60 * 1000).toISOString()
      case '6h':
        return new Date(now.getTime() - 6 * 60 * 60 * 1000).toISOString()
      case '24h':
        return new Date(now.getTime() - 24 * 60 * 60 * 1000).toISOString()
      case '7d':
        return new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000).toISOString()
      default:
        return new Date(now.getTime() - 60 * 60 * 1000).toISOString()
    }
  }

  static subscribeToMetrics(callback: (payload: any) => void) {
    return supabase
      .channel('system_metrics_changes')
      .on('postgres_changes', 
        { event: '*', schema: 'public', table: 'system_metrics' },
        callback
      )
      .subscribe()
  }

  static subscribeToAlerts(callback: (payload: any) => void) {
    return supabase
      .channel('audit_logs_changes')
      .on('postgres_changes', 
        { event: 'INSERT', schema: 'public', table: 'audit_logs', filter: 'event_type=eq.alert' },
        callback
      )
      .subscribe()
  }
}

export default ObservabilityService