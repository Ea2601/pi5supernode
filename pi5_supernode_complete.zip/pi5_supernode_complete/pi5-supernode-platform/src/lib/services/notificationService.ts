import { supabase } from '../supabase'

export interface Notification {
  id: string
  notification_type: string
  severity: 'critical' | 'high' | 'medium' | 'low' | 'info'
  title: string
  message: string
  details: Record<string, any>
  target_roles: string[]
  channels: string[]
  action_buttons: Array<{
    label: string
    action: string
    variant?: 'primary' | 'secondary' | 'danger'
  }>
  action_url?: string
  is_persistent: boolean
  expires_at?: string
  is_read: boolean
  read_at?: string
  is_acknowledged: boolean
  acknowledged_at?: string
  acknowledged_by?: string
  created_at: string
}

export class NotificationService {
  static async getNotifications(options: {
    limit?: number
    offset?: number
    severity?: string
    type?: string
    unreadOnly?: boolean
    targetRole?: string
  } = {}): Promise<{ notifications: Notification[]; count: number }> {
    try {
      const { data, error } = await supabase.functions.invoke('notification-system', {
        body: {
          action: 'get_notifications',
          ...options
        }
      })

      if (error) throw error
      return data.data
    } catch (error) {
      console.error('Error getting notifications:', error)
      throw error
    }
  }

  static async createNotification(notification: {
    type?: string
    severity?: string
    title: string
    message: string
    details?: Record<string, any>
    targetRoles?: string[]
    channels?: string[]
    actionButtons?: Array<{ label: string; action: string; variant?: string }>
    actionUrl?: string
    isPersistent?: boolean
    expiresAt?: string
  }): Promise<Notification> {
    try {
      const { data, error } = await supabase.functions.invoke('notification-system', {
        body: {
          action: 'create_notification',
          ...notification
        }
      })

      if (error) throw error
      return data.data.notification
    } catch (error) {
      console.error('Error creating notification:', error)
      throw error
    }
  }

  static async markAsRead(notificationId: string): Promise<void> {
    try {
      const { error } = await supabase.functions.invoke('notification-system', {
        body: {
          action: 'mark_read',
          notificationId
        }
      })

      if (error) throw error
    } catch (error) {
      console.error('Error marking notification as read:', error)
      throw error
    }
  }

  static async acknowledge(notificationId: string, acknowledgedBy?: string): Promise<void> {
    try {
      const { error } = await supabase.functions.invoke('notification-system', {
        body: {
          action: 'mark_acknowledged',
          notificationId,
          acknowledgedBy
        }
      })

      if (error) throw error
    } catch (error) {
      console.error('Error acknowledging notification:', error)
      throw error
    }
  }

  static async deleteNotification(notificationId: string): Promise<void> {
    try {
      const { error } = await supabase.functions.invoke('notification-system', {
        body: {
          action: 'delete_notification',
          notificationId
        }
      })

      if (error) throw error
    } catch (error) {
      console.error('Error deleting notification:', error)
      throw error
    }
  }

  static async getSystemAlerts(): Promise<{
    alerts: Array<{
      type: string
      severity: string
      title: string
      message: string
      component?: string
      timestamp: string
    }>
  }> {
    try {
      const { data, error } = await supabase.functions.invoke('notification-system', {
        body: {
          action: 'get_system_alerts'
        }
      })

      if (error) throw error
      return data.data
    } catch (error) {
      console.error('Error getting system alerts:', error)
      throw error
    }
  }

  // Real-time notification subscription
  static subscribeToNotifications(
    callback: (notification: Notification) => void,
    targetRole: string = 'admin'
  ) {
    return supabase
      .channel('notifications')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'notifications',
          filter: `target_roles.cs.{${targetRole}}`
        },
        (payload) => {
          callback(payload.new as Notification)
        }
      )
      .subscribe()
  }

  // Utility function to get severity color
  static getSeverityColor(severity: string): string {
    switch (severity) {
      case 'critical':
        return 'bg-red-500'
      case 'high':
        return 'bg-red-400'
      case 'medium':
        return 'bg-yellow-500'
      case 'low':
        return 'bg-yellow-400'
      case 'info':
      default:
        return 'bg-blue-500'
    }
  }

  // Utility function to get severity icon
  static getSeverityIcon(severity: string): string {
    switch (severity) {
      case 'critical':
      case 'high':
        return 'AlertTriangle'
      case 'medium':
      case 'low':
        return 'AlertCircle'
      case 'info':
      default:
        return 'Info'
    }
  }
}