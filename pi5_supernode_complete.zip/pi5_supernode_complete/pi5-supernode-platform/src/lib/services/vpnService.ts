import { supabase, callEdgeFunction } from '../supabase'
import { WireGuardServer, WireGuardClient } from '../store'

export class VPNService {
  static async getAllServers(): Promise<WireGuardServer[]> {
    try {
      const { data, error } = await supabase
        .from('wireguard_servers')
        .select('*')
        .order('created_at', { ascending: false })
      
      if (error) throw error
      return data || []
    } catch (error) {
      console.error('Error loading VPN servers:', error)
      throw error
    }
  }

  static async getAllClients(): Promise<WireGuardClient[]> {
    try {
      const { data, error } = await supabase
        .from('wireguard_clients')
        .select('*')
        .order('created_at', { ascending: false })
      
      if (error) throw error
      return data || []
    } catch (error) {
      console.error('Error loading VPN clients:', error)
      throw error
    }
  }

  static async getClientsByServer(serverId: string): Promise<WireGuardClient[]> {
    try {
      const { data, error } = await supabase
        .from('wireguard_clients')
        .select('*')
        .eq('server_id', serverId)
        .order('created_at', { ascending: false })
      
      if (error) throw error
      return data || []
    } catch (error) {
      console.error('Error loading server clients:', error)
      throw error
    }
  }

  static async createServer(serverData: {
    server_name: string
    listen_port: number
    network: string
  }): Promise<WireGuardServer> {
    try {
      // Generate server keys
      const keyPair = await this.generateKeyPair()
      
      const { data, error } = await supabase
        .from('wireguard_servers')
        .insert([{
          ...serverData,
          public_key: keyPair.publicKey,
          private_key: keyPair.privateKey,
          endpoint: 'auto-detect',
          status: 'stopped',
          client_count: 0,
          max_clients: 100,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        }])
        .select()
        .single()
      
      if (error) throw error
      if (!data) throw new Error('Failed to create server')
      
      return data
    } catch (error) {
      console.error('Error creating VPN server:', error)
      throw error
    }
  }

  static async createClient(serverData: WireGuardServer, clientData: {
    client_name: string
    assigned_ip?: string
  }): Promise<WireGuardClient> {
    try {
      // Generate client keys
      const keyPair = await this.generateKeyPair()
      
      // Auto-assign IP if not provided
      let assignedIp = clientData.assigned_ip
      if (!assignedIp) {
        assignedIp = await this.getNextAvailableIP(serverData.id, serverData.network)
      }
      
      const { data, error } = await supabase
        .from('wireguard_clients')
        .insert([{
          server_id: serverData.id,
          client_name: clientData.client_name,
          public_key: keyPair.publicKey,
          private_key: keyPair.privateKey,
          assigned_ip: assignedIp,
          allowed_ips: ['0.0.0.0/0'],
          is_active: true,
          bytes_received: 0,
          bytes_sent: 0,
          created_at: new Date().toISOString()
        }])
        .select()
        .single()
      
      if (error) throw error
      if (!data) throw new Error('Failed to create client')
      
      // Update server client count
      await this.updateServerClientCount(serverData.id)
      
      return data
    } catch (error) {
      console.error('Error creating VPN client:', error)
      throw error
    }
  }

  static async updateServerStatus(serverId: string, status: 'active' | 'inactive' | 'stopped'): Promise<void> {
    try {
      const { error } = await supabase
        .from('wireguard_servers')
        .update({ 
          status,
          updated_at: new Date().toISOString()
        })
        .eq('id', serverId)
      
      if (error) throw error
      
      // Apply server configuration via edge function
      if (status === 'active') {
        await callEdgeFunction('WIREGUARD_SYNC', { serverIds: [serverId] })
      }
    } catch (error) {
      console.error('Error updating server status:', error)
      throw error
    }
  }

  static async updateClient(clientId: string, updates: Partial<WireGuardClient>): Promise<void> {
    try {
      const { error } = await supabase
        .from('wireguard_clients')
        .update(updates)
        .eq('id', clientId)
      
      if (error) throw error
    } catch (error) {
      console.error('Error updating client:', error)
      throw error
    }
  }

  static async deleteServer(serverId: string): Promise<void> {
    try {
      // First delete all clients
      await supabase
        .from('wireguard_clients')
        .delete()
        .eq('server_id', serverId)
      
      // Then delete server
      const { error } = await supabase
        .from('wireguard_servers')
        .delete()
        .eq('id', serverId)
      
      if (error) throw error
    } catch (error) {
      console.error('Error deleting server:', error)
      throw error
    }
  }

  static async deleteClient(clientId: string, serverId?: string): Promise<void> {
    try {
      const { error } = await supabase
        .from('wireguard_clients')
        .delete()
        .eq('id', clientId)
      
      if (error) throw error
      
      // Update server client count
      if (serverId) {
        await this.updateServerClientCount(serverId)
      }
    } catch (error) {
      console.error('Error deleting client:', error)
      throw error
    }
  }

  // Additional method aliases that components expect
  static async toggleWireGuardServer(serverId: string, enabled: string | boolean): Promise<void> {
    const isEnabled = typeof enabled === 'string' ? enabled === 'active' : enabled
    return this.updateServerStatus(serverId, isEnabled ? 'active' : 'stopped')
  }

  static async deleteWireGuardServer(serverId: string): Promise<void> {
    return this.deleteServer(serverId)
  }

  static async deleteWireGuardClient(clientId: string, serverId?: string): Promise<void> {
    return this.deleteClient(clientId, serverId)
  }

  static async updateWireGuardClient(clientId: string, updates: Partial<WireGuardClient>): Promise<void> {
    return this.updateClient(clientId, updates)
  }

  static async createWireGuardClient(serverData: WireGuardServer, clientData: { client_name: string; assigned_ip?: string }): Promise<WireGuardClient> {
    return this.createClient(serverData, clientData)
  }

  static async generateClientConfig(clientId: string): Promise<string> {
    try {
      const { data: client, error: clientError } = await supabase
        .from('wireguard_clients')
        .select(`
          *,
          wireguard_servers:server_id (
            public_key,
            endpoint,
            listen_port,
            network
          )
        `)
        .eq('id', clientId)
        .single()
      
      if (clientError) throw clientError
      if (!client) throw new Error('Client not found')
      
      const server = client.wireguard_servers
      if (!server) throw new Error('Server not found')
      
      return `[Interface]
PrivateKey = ${client.private_key}
Address = ${client.assigned_ip}/24
DNS = 8.8.8.8

[Peer]
PublicKey = ${server.public_key}
Endpoint = ${server.endpoint}:${server.listen_port}
AllowedIPs = ${client.allowed_ips.join(', ')}
PersistentKeepalive = 25`
    } catch (error) {
      console.error('Error generating client config:', error)
      throw error
    }
  }

  static async syncServerConfiguration(serverId: string): Promise<void> {
    try {
      await callEdgeFunction('WIREGUARD_SYNC', { 
        serverIds: [serverId],
        syncType: 'full'
      })
    } catch (error) {
      console.error('Error syncing server configuration:', error)
      throw error
    }
  }

  static async getConnectionStats(clientId: string): Promise<{
    bytes_sent: number
    bytes_received: number
    last_handshake?: string
    connection_time?: number
  }> {
    try {
      const result = await callEdgeFunction('vpn-management', {
        action: 'get_connection_stats',
        clientId
      })
      return result.data
    } catch (error) {
      console.error('Error loading connection stats:', error)
      throw error
    }
  }

  private static async generateKeyPair(): Promise<{ publicKey: string; privateKey: string }> {
    try {
      const result = await callEdgeFunction('vpn-management', {
        action: 'generate_keys'
      })
      return result.data
    } catch (error) {
      console.error('Error generating key pair:', error)
      // Fallback to mock keys for development
      return {
        publicKey: 'mock_public_key_' + Math.random().toString(36).substring(2, 15),
        privateKey: 'mock_private_key_' + Math.random().toString(36).substring(2, 15)
      }
    }
  }

  private static async getNextAvailableIP(serverId: string, network: string): Promise<string> {
    try {
      const { data: clients, error } = await supabase
        .from('wireguard_clients')
        .select('assigned_ip')
        .eq('server_id', serverId)
      
      if (error) throw error
      
      const usedIPs = new Set(clients?.map(c => c.assigned_ip) || [])
      const baseIP = network.split('/')[0].split('.').slice(0, 3).join('.')
      
      // Start from .2 (avoiding .1 for gateway)
      for (let i = 2; i < 255; i++) {
        const ip = `${baseIP}.${i}`
        if (!usedIPs.has(ip)) {
          return ip
        }
      }
      
      throw new Error('No available IP addresses')
    } catch (error) {
      console.error('Error getting next available IP:', error)
      // Fallback IP
      return network.replace(/\/\d+$/, '').replace(/\d+$/, '10')
    }
  }

  private static async updateServerClientCount(serverId: string): Promise<void> {
    try {
      const { data: clients, error: countError } = await supabase
        .from('wireguard_clients')
        .select('id')
        .eq('server_id', serverId)
        .eq('is_active', true)
      
      if (countError) throw countError
      
      const { error: updateError } = await supabase
        .from('wireguard_servers')
        .update({ 
          client_count: clients?.length || 0,
          updated_at: new Date().toISOString()
        })
        .eq('id', serverId)
      
      if (updateError) throw updateError
    } catch (error) {
      console.error('Error updating server client count:', error)
    }
  }

  static subscribeToServerChanges(callback: (payload: any) => void) {
    return supabase
      .channel('wireguard_servers_changes')
      .on('postgres_changes', 
        { event: '*', schema: 'public', table: 'wireguard_servers' },
        callback
      )
      .subscribe()
  }

  static subscribeToClientChanges(callback: (payload: any) => void) {
    return supabase
      .channel('wireguard_clients_changes')
      .on('postgres_changes', 
        { event: '*', schema: 'public', table: 'wireguard_clients' },
        callback
      )
      .subscribe()
  }

  // Additional method aliases that components expect
  static async getWireGuardServers(): Promise<WireGuardServer[]> {
    return this.getAllServers()
  }

  static async getWireGuardClients(): Promise<WireGuardClient[]> {
    return this.getAllClients()
  }

  static async createWireGuardServer(serverData: {
    server_name: string
    listen_port: number
    network: string
  }): Promise<WireGuardServer> {
    return this.createServer(serverData)
  }

  static async updateWireGuardServer(serverId: string, updates: Partial<WireGuardServer>): Promise<void> {
    try {
      const { error } = await supabase
        .from('wireguard_servers')
        .update({
          ...updates,
          updated_at: new Date().toISOString()
        })
        .eq('id', serverId)
      
      if (error) throw error
    } catch (error) {
      console.error('Error updating WireGuard server:', error)
      throw error
    }
  }
}

export default VPNService