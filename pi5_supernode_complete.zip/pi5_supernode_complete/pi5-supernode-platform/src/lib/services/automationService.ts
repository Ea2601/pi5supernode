import { supabase, callEdgeFunction } from '../supabase'

export interface AutomationRule {
  id: string
  name: string
  description: string
  enabled: boolean
  trigger_type: 'event' | 'schedule' | 'condition'
  trigger_config: Record<string, any>
  actions: AutomationAction[]
  created_at: string
  last_executed?: string
  execution_count: number
}

export interface AutomationAction {
  type: 'telegram' | 'webhook' | 'email'
  config: Record<string, any>
  enabled: boolean
}

export class AutomationService {
  static async getAllRules(): Promise<AutomationRule[]> {
    try {
      const { data, error } = await supabase
        .from('automation_rules')
        .select('*')
        .order('created_at', { ascending: false })
      
      if (error) throw error
      return data || []
    } catch (error) {
      console.error('Error loading automation rules:', error)
      throw error
    }
  }

  static async createRule(ruleData: Omit<AutomationRule, 'id' | 'created_at' | 'execution_count'>): Promise<void> {
    try {
      const { error } = await supabase
        .from('automation_rules')
        .insert([{
          ...ruleData,
          execution_count: 0,
          created_at: new Date().toISOString()
        }])
      
      if (error) throw error
    } catch (error) {
      console.error('Error creating automation rule:', error)
      throw error
    }
  }

  static async updateRule(ruleId: string, updates: Partial<AutomationRule>): Promise<void> {
    try {
      const { error } = await supabase
        .from('automation_rules')
        .update(updates)
        .eq('id', ruleId)
      
      if (error) throw error
    } catch (error) {
      console.error('Error updating automation rule:', error)
      throw error
    }
  }

  static async deleteRule(ruleId: string): Promise<void> {
    try {
      const { error } = await supabase
        .from('automation_rules')
        .delete()
        .eq('id', ruleId)
      
      if (error) throw error
    } catch (error) {
      console.error('Error deleting automation rule:', error)
      throw error
    }
  }

  static async executeRule(ruleId: string): Promise<void> {
    try {
      // Get rule details
      const { data: rule, error: fetchError } = await supabase
        .from('automation_rules')
        .select('*')
        .eq('id', ruleId)
        .single()
      
      if (fetchError) throw fetchError
      if (!rule) throw new Error('Rule not found')

      // Execute rule actions
      for (const action of rule.actions) {
        if (!action.enabled) continue

        switch (action.type) {
          case 'telegram':
            await this.executeTelegramAction(action.config)
            break
          case 'webhook':
            await this.executeWebhookAction(action.config)
            break
          case 'email':
            await this.executeEmailAction(action.config)
            break
        }
      }

      // Update execution count
      await supabase
        .from('automation_rules')
        .update({
          execution_count: rule.execution_count + 1,
          last_executed: new Date().toISOString()
        })
        .eq('id', ruleId)

    } catch (error) {
      console.error('Error executing automation rule:', error)
      throw error
    }
  }

  static async executeTelegramAction(config: any): Promise<void> {
    try {
      await callEdgeFunction('telegram-bot-handler', {
        action: 'send_message',
        config
      })
    } catch (error) {
      console.error('Telegram action error:', error)
      throw error
    }
  }

  static async executeWebhookAction(config: any): Promise<void> {
    try {
      await callEdgeFunction('webhook-handler', {
        action: 'execute_webhook',
        config
      })
    } catch (error) {
      console.error('Webhook action error:', error)
      throw error
    }
  }

  static async executeEmailAction(config: any): Promise<void> {
    try {
      await callEdgeFunction('email-handler', {
        action: 'send_email',
        config
      })
    } catch (error) {
      console.error('Email action error:', error)
      throw error
    }
  }

  static async testTelegramConnection(botToken: string, chatId: string): Promise<void> {
    try {
      await callEdgeFunction('telegram-bot-handler', {
        action: 'test_connection',
        config: { bot_token: botToken, chat_id: chatId }
      })
    } catch (error) {
      console.error('Telegram test error:', error)
      throw error
    }
  }

  static async testWebhook(webhookUrl: string): Promise<void> {
    try {
      await callEdgeFunction('webhook-handler', {
        action: 'test_webhook',
        config: { webhook_url: webhookUrl }
      })
    } catch (error) {
      console.error('Webhook test error:', error)
      throw error
    }
  }

  static subscribeToRuleChanges(callback: (payload: any) => void) {
    return supabase
      .channel('automation_rules_changes')
      .on('postgres_changes', 
        { event: '*', schema: 'public', table: 'automation_rules' },
        callback
      )
      .subscribe()
  }
}

export default AutomationService