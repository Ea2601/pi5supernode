// Service exports for centralized API management
export { DeviceService } from './deviceService'
export { AutomationService } from './automationService'
export { ObservabilityService } from './observabilityService'
export { VPNService } from './vpnService'
export { VPSService } from './vps.service'
export { StorageService } from './storageService'
export { NetworkService } from './networkService'
export { SettingsService } from './settingsService'
export { NotificationService } from './notificationService'

// Re-export types for convenience
export type { NetworkDevice, TrafficRule, WireGuardServer, WireGuardClient } from '../store'
export type { AutomationRule, AutomationAction } from './automationService'
export type { SystemMetrics, AlertItem, ServiceHealth } from './observabilityService'
export type { StorageDevice, NetworkShare } from './storageService'
export type { DNSServer, DHCPPool, WiFiNetwork, VLAN } from './networkService'
export type { SystemSettings, SecuritySettings, NotificationSettings } from './settingsService'
export type { VPSServer, VPSInstallationStep, VPSStatusResponse, CreateVPSServerData, InstallWireGuardData } from './vps.service'

// Export consolidated utilities
export * from '../types/forms'
export * from '../utils/validation'
export * from '../hooks/useForm'
export * from '../constants'

// API Configuration
export const API_CONFIG = {
  BASE_URL: import.meta.env.VITE_API_BASE_URL || '/api',
  TIMEOUT: 30000,
  RETRY_ATTEMPTS: 3
}

// Common error handler
export class APIError extends Error {
  constructor(
    message: string,
    public statusCode?: number,
    public details?: any
  ) {
    super(message)
    this.name = 'APIError'
  }
}

// Utility functions
export const formatBytes = (bytes: number): string => {
  if (bytes === 0) return '0 Bytes'
  const k = 1024
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB']
  const i = Math.floor(Math.log(bytes) / Math.log(k))
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
}

export const formatUptime = (seconds: number): string => {
  const days = Math.floor(seconds / 86400)
  const hours = Math.floor((seconds % 86400) / 3600)
  const minutes = Math.floor((seconds % 3600) / 60)
  
  if (days > 0) return `${days}d ${hours}h ${minutes}m`
  if (hours > 0) return `${hours}h ${minutes}m`
  return `${minutes}m`
}

export const parseIPNetwork = (network: string): { baseIP: string; cidr: number; networkSize: number } => {
  const [ip, cidr] = network.split('/')
  const cidrNum = parseInt(cidr, 10)
  const networkSize = Math.pow(2, 32 - cidrNum)
  
  return {
    baseIP: ip,
    cidr: cidrNum,
    networkSize
  }
}

// Validation helpers
export const validateIPAddress = (ip: string): boolean => {
  const regex = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/
  return regex.test(ip)
}

export const validateMACAddress = (mac: string): boolean => {
  const regex = /^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$/
  return regex.test(mac)
}

export const validatePort = (port: number): boolean => {
  return Number.isInteger(port) && port >= 1 && port <= 65535
}
