import { supabase } from '../supabase'

export interface VPSServer {
  id: string
  vps_name: string
  vps_ip: string
  ssh_username: string
  ssh_port: number
  ssh_key_type: 'password' | 'key'
  wireguard_server_id?: string
  status: 'pending' | 'connecting' | 'installing' | 'completed' | 'failed'
  installation_log?: string
  error_message?: string
  server_specs?: {
    cpu?: string
    ram?: string
    storage?: string
    location?: string
  }
  installation_started_at?: string
  installation_completed_at?: string
  created_at: string
  updated_at: string
}

export interface VPSInstallationStep {
  id: string
  vps_server_id: string
  step_name: string
  step_description: string
  status: 'pending' | 'running' | 'completed' | 'failed'
  started_at?: string
  completed_at?: string
  output?: string
  error_message?: string
  step_order: number
  created_at: string
}

export interface VPSCredentials {
  ssh_password?: string
  ssh_private_key?: string
}

export interface VPSStatusResponse {
  vpsServer: {
    id: string
    vpsName: string
    vpsIp: string
    sshUsername: string
    status: string
    installationStartedAt?: string
    installationCompletedAt?: string
    errorMessage?: string
    installationLog?: string
  }
  installationProgress: {
    totalSteps: number
    completedSteps: number
    failedSteps: number
    runningSteps: number
    progressPercentage: number
    currentStep?: {
      name: string
      description: string
      status: string
      output?: string
      errorMessage?: string
    } | null
  }
  installationSteps: Array<{
    id: string
    name: string
    description: string
    status: string
    order: number
    startedAt?: string
    completedAt?: string
    output?: string
    errorMessage?: string
  }>
  wireguardServer?: {
    id: string
    serverName: string
    publicKey: string
    endpoint: string
    network: string
    status: string
    clientCount: number
    maxClients: number
  } | null
  healthStatus: 'healthy' | 'unhealthy' | 'unknown'
  lastChecked: string
}

export interface CreateVPSServerData {
  vps_name: string
  vps_ip: string
  ssh_username: string
  ssh_port?: number
  ssh_key_type?: 'password' | 'key'
  server_specs?: {
    cpu?: string
    ram?: string
    storage?: string
    location?: string
  }
}

export interface InstallWireGuardData {
  vpsServerId: string
  vpsIp: string
  sshUsername: string
  sshPassword: string
  wgServerName: string
}

export class VPSService {
  static async getAllVPSServers(): Promise<VPSServer[]> {
    const { data, error } = await supabase
      .from('vps_servers')
      .select('*')
      .order('created_at', { ascending: false })
    
    if (error) {
      console.error('Error fetching VPS servers:', error)
      throw error
    }
    
    return data || []
  }

  static async getVPSServer(id: string): Promise<VPSServer> {
    const { data, error } = await supabase
      .from('vps_servers')
      .select('*')
      .eq('id', id)
      .single()
    
    if (error) {
      console.error('Error fetching VPS server:', error)
      throw error
    }
    
    return data
  }

  static async createVPSServer(serverData: CreateVPSServerData): Promise<VPSServer> {
    const { data, error } = await supabase
      .from('vps_servers')
      .insert({
        ...serverData,
        ssh_port: serverData.ssh_port || 22,
        ssh_key_type: serverData.ssh_key_type || 'password',
        status: 'pending'
      })
      .select()
      .single()
    
    if (error) {
      console.error('Error creating VPS server:', error)
      throw error
    }
    
    return data
  }

  static async updateVPSServer(id: string, updates: Partial<CreateVPSServerData>): Promise<VPSServer> {
    const { data, error } = await supabase
      .from('vps_servers')
      .update({
        ...updates,
        updated_at: new Date().toISOString()
      })
      .eq('id', id)
      .select()
      .single()
    
    if (error) {
      console.error('Error updating VPS server:', error)
      throw error
    }
    
    return data
  }

  static async deleteVPSServer(id: string): Promise<void> {
    const { error } = await supabase
      .from('vps_servers')
      .delete()
      .eq('id', id)
    
    if (error) {
      console.error('Error deleting VPS server:', error)
      throw error
    }
  }

  static async installWireGuard(installData: InstallWireGuardData): Promise<{ success: boolean, message: string }> {
    try {
      const response = await fetch('/functions/v1/vps-wireguard-installer', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${(await supabase.auth.getSession()).data.session?.access_token}`
        },
        body: JSON.stringify(installData)
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error?.message || 'Installation failed')
      }

      const result = await response.json()
      return {
        success: true,
        message: result.data?.message || 'WireGuard installation started successfully'
      }
    } catch (error) {
      console.error('Error installing WireGuard:', error)
      return {
        success: false,
        message: error instanceof Error ? error.message : 'Installation failed'
      }
    }
  }

  static async getVPSStatus(vpsServerId: string): Promise<VPSStatusResponse> {
    try {
      const response = await fetch(`/functions/v1/vps-status-check?vpsServerId=${vpsServerId}`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${(await supabase.auth.getSession()).data.session?.access_token}`
        }
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error?.message || 'Failed to fetch VPS status')
      }

      const result = await response.json()
      return result.data
    } catch (error) {
      console.error('Error fetching VPS status:', error)
      throw error
    }
  }

  static async getInstallationSteps(vpsServerId: string): Promise<VPSInstallationStep[]> {
    const { data, error } = await supabase
      .from('vps_installation_steps')
      .select('*')
      .eq('vps_server_id', vpsServerId)
      .order('step_order', { ascending: true })
    
    if (error) {
      console.error('Error fetching installation steps:', error)
      throw error
    }
    
    return data || []
  }

  static async storeVPSCredentials(vpsServerId: string, credentials: VPSCredentials): Promise<void> {
    // In a real implementation, credentials should be encrypted before storage
    const { error } = await supabase
      .from('vps_credentials')
      .upsert({
        vps_server_id: vpsServerId,
        ssh_password_encrypted: credentials.ssh_password ? btoa(credentials.ssh_password) : null,
        ssh_private_key_encrypted: credentials.ssh_private_key ? btoa(credentials.ssh_private_key) : null,
        updated_at: new Date().toISOString()
      })
    
    if (error) {
      console.error('Error storing VPS credentials:', error)
      throw error
    }
  }

  static async getVPSCredentials(vpsServerId: string): Promise<VPSCredentials | null> {
    const { data, error } = await supabase
      .from('vps_credentials')
      .select('ssh_password_encrypted, ssh_private_key_encrypted')
      .eq('vps_server_id', vpsServerId)
      .single()
    
    if (error) {
      if (error.code === 'PGRST116') {
        // No credentials found
        return null
      }
      console.error('Error fetching VPS credentials:', error)
      throw error
    }

    return {
      ssh_password: data.ssh_password_encrypted ? atob(data.ssh_password_encrypted) : undefined,
      ssh_private_key: data.ssh_private_key_encrypted ? atob(data.ssh_private_key_encrypted) : undefined
    }
  }

  static async testVPSConnection(vpsIp: string, sshUsername: string, sshPassword: string, sshPort: number = 22): Promise<{ success: boolean, message: string }> {
    // This would typically test SSH connectivity to the VPS
    // For now, we'll simulate a connection test
    try {
      // Simulate network delay
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      // Basic IP validation
      const ipRegex = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/
      if (!ipRegex.test(vpsIp)) {
        return {
          success: false,
          message: 'Invalid IP address format'
        }
      }

      // Simulate success/failure (90% success rate for demo)
      const success = Math.random() > 0.1
      
      return {
        success,
        message: success 
          ? 'SSH connection test successful' 
          : 'SSH connection failed - check credentials and network connectivity'
      }
    } catch (error) {
      return {
        success: false,
        message: 'Connection test failed'
      }
    }
  }
}

export default VPSService