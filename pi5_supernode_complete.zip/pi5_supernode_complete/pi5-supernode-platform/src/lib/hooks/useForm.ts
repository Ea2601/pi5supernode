// Consolidated form handling hooks to reduce code duplication

import { useState, useCallback } from 'react'
import { FormState, FormValidationResult } from '../types/forms'

// Generic form hook with validation
export function useForm<T extends Record<string, any>>(
  initialData: T,
  validator?: (data: T) => FormValidationResult
) {
  const [formState, setFormState] = useState<FormState<T>>({
    data: initialData,
    loading: false,
    errors: {},
    touched: {}
  })

  const setData = useCallback((data: Partial<T>) => {
    setFormState(prev => ({
      ...prev,
      data: { ...prev.data, ...data }
    }))
  }, [])

  const setField = useCallback((field: keyof T, value: any) => {
    setFormState(prev => ({
      ...prev,
      data: { ...prev.data, [field]: value },
      touched: { ...prev.touched, [field]: true }
    }))
  }, [])

  const setLoading = useCallback((loading: boolean) => {
    setFormState(prev => ({ ...prev, loading }))
  }, [])

  const setErrors = useCallback((errors: Record<string, string>) => {
    setFormState(prev => ({ ...prev, errors }))
  }, [])

  const validate = useCallback(() => {
    if (!validator) return { isValid: true, errors: {} }
    
    const result = validator(formState.data)
    setErrors(result.errors)
    return result
  }, [formState.data, validator])

  const reset = useCallback(() => {
    setFormState({
      data: initialData,
      loading: false,
      errors: {},
      touched: {}
    })
  }, [initialData])

  const submit = useCallback(async (
    onSubmit: (data: T) => Promise<void>,
    skipValidation = false
  ) => {
    if (!skipValidation) {
      const validationResult = validate()
      if (!validationResult.isValid) {
        return false
      }
    }

    try {
      setLoading(true)
      await onSubmit(formState.data)
      return true
    } catch (error) {
      console.error('Form submission error:', error)
      return false
    } finally {
      setLoading(false)
    }
  }, [formState.data, validate])

  return {
    data: formState.data,
    loading: formState.loading,
    errors: formState.errors,
    touched: formState.touched,
    setData,
    setField,
    setLoading,
    setErrors,
    validate,
    reset,
    submit
  }
}

// Modal form hook - combines form state with modal visibility
export function useModalForm<T extends Record<string, any>>(
  initialData: T,
  validator?: (data: T) => FormValidationResult
) {
  const [isOpen, setIsOpen] = useState(false)
  const form = useForm(initialData, validator)

  const open = useCallback(() => {
    setIsOpen(true)
    form.reset()
  }, [form])

  const close = useCallback(() => {
    setIsOpen(false)
    form.reset()
  }, [form])

  const submitAndClose = useCallback(async (
    onSubmit: (data: T) => Promise<void>,
    skipValidation = false
  ) => {
    const success = await form.submit(onSubmit, skipValidation)
    if (success) {
      close()
    }
    return success
  }, [form, close])

  return {
    ...form,
    isOpen,
    open,
    close,
    submitAndClose
  }
}

// List management hook - for handling CRUD operations on lists
export function useListManager<T extends { id: string }>() {
  const [items, setItems] = useState<T[]>([])
  const [loading, setLoading] = useState(false)
  const [selectedItem, setSelectedItem] = useState<T | null>(null)

  const setItemsData = useCallback((newItems: T[]) => {
    setItems(newItems)
  }, [])

  const addItem = useCallback((item: T) => {
    setItems(prev => [item, ...prev])
  }, [])

  const updateItem = useCallback((id: string, updates: Partial<T>) => {
    setItems(prev => prev.map(item => 
      item.id === id ? { ...item, ...updates } : item
    ))
  }, [])

  const removeItem = useCallback((id: string) => {
    setItems(prev => prev.filter(item => item.id !== id))
    if (selectedItem?.id === id) {
      setSelectedItem(null)
    }
  }, [selectedItem])

  const selectItem = useCallback((item: T | null) => {
    setSelectedItem(item)
  }, [])

  const refresh = useCallback(async (loadFn: () => Promise<T[]>) => {
    try {
      setLoading(true)
      const newItems = await loadFn()
      setItemsData(newItems)
    } catch (error) {
      console.error('Failed to refresh items:', error)
      throw error
    } finally {
      setLoading(false)
    }
  }, [])

  return {
    items,
    loading,
    selectedItem,
    setItems: setItemsData,
    addItem,
    updateItem,
    removeItem,
    selectItem,
    setLoading,
    refresh
  }
}
