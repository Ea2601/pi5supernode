import { createClient } from '@supabase/supabase-js'

const supabaseUrl = 'https://xrzgvabqukbdvbpbkfqh.supabase.co'
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inhyemd2YWJxdWtiZHZicGJrZnFoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTY4MDI0MzcsImV4cCI6MjA3MjM3ODQzN30.vaPqO3zjlTMbdL9mLpzXe5nF2bShKR_KeAeEVf_Q5n0'

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Edge Function caller utility
export const callEdgeFunction = async (functionName: string, payload: any = {}) => {
  try {
    const { data, error } = await supabase.functions.invoke(functionName, {
      body: payload,
      headers: {
        'Content-Type': 'application/json',
      },
    })

    if (error) {
      console.error(`Edge function ${functionName} error:`, error)
      throw new Error(`Edge function failed: ${error.message}`)
    }

    return data
  } catch (error) {
    console.error(`Error calling edge function ${functionName}:`, error)
    throw error
  }
}

// Network Management Edge Function caller
export const callNetworkFunction = async (endpoint: string, method: string = 'GET', data?: any) => {
  try {
    const { data: result, error } = await supabase.functions.invoke('comprehensive-network-manager', {
      body: {
        endpoint,
        method,
        data
      },
      headers: {
        'Content-Type': 'application/json',
      },
    })

    if (error) {
      console.error(`Network function ${endpoint} error:`, error)
      throw new Error(`Network function failed: ${error.message}`)
    }

    return result
  } catch (error) {
    console.error(`Error calling network function ${endpoint}:`, error)
    throw error
  }
}

// WAN Management Edge Function caller
export const callWANFunction = async (endpoint: string, method: string = 'GET', data?: any) => {
  try {
    const { data: result, error } = await supabase.functions.invoke('comprehensive-wan-manager', {
      body: {
        endpoint,
        method,
        data
      },
      headers: {
        'Content-Type': 'application/json',
      },
    })

    if (error) {
      console.error(`WAN function ${endpoint} error:`, error)
      throw new Error(`WAN function failed: ${error.message}`)
    }

    return result
  } catch (error) {
    console.error(`Error calling WAN function ${endpoint}:`, error)
    throw error
  }
}

// Interface Management Edge Function caller
export const callInterfaceFunction = async (payload: any = {}) => {
  try {
    const { data, error } = await supabase.functions.invoke('interface-management', {
      body: payload,
      headers: {
        'Content-Type': 'application/json',
      },
    })

    if (error) {
      console.error(`Interface management function error:`, error)
      throw new Error(`Interface management function failed: ${error.message}`)
    }

    return data
  } catch (error) {
    console.error(`Error calling interface management function:`, error)
    throw error
  }
}

// Speed Testing Edge Function caller
export const callSpeedTestFunction = async (action: string, payload: any = {}) => {
  try {
    const { data, error } = await supabase.functions.invoke('network-speed-testing', {
      body: {
        action,
        ...payload
      },
      headers: {
        'Content-Type': 'application/json',
      },
    })

    if (error) {
      console.error(`Speed test function ${action} error:`, error)
      throw new Error(`Speed test function failed: ${error.message}`)
    }

    return data
  } catch (error) {
    console.error(`Error calling speed test function ${action}:`, error)
    throw error
  }
}
