#!/bin/bash

# Pi5 VPN Services Installer
# Version: 1.0.0
# Description: VPN server setup (OpenVPN, WireGuard, IPsec)

set -e

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m'

log() {
    echo -e "${GREEN}[$(date +'%Y-%m-%d %H:%M:%S')]${NC} $1"
}

warn() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

error() {
    echo -e "${RED}[ERROR]${NC} $1"
    exit 1
}

echo -e "${BLUE}"
echo "Pi5 VPN Services Installer"
echo "=========================="necho -e "${NC}"

# Check requirements
if [[ $EUID -ne 0 ]]; then
   error "This script must be run as root (use sudo)"
fi

if ! command -v systemctl &> /dev/null; then
    error "systemd is required for this installer"
fi

# Get server IP
SERVER_IP=$(curl -s ifconfig.me || curl -s icanhazip.com || echo "YOUR_SERVER_IP")
log "Detected server IP: $SERVER_IP"

# Update system
log "Updating system packages..."
apt update && apt upgrade -y

# Install VPN packages
log "Installing VPN software packages..."
apt install -y openvpn easy-rsa
apt install -y wireguard wireguard-tools
apt install -y strongswan strongswan-pki
apt install -y iptables-persistent

# Configure OpenVPN
echo
read -p "Configure OpenVPN server? (y/N): " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    log "Configuring OpenVPN server..."
    
    # Set up PKI
    make-cadir /etc/openvpn/easy-rsa
    cd /etc/openvpn/easy-rsa
    
    # Create vars file
    cat > vars << EOF
set_var EASYRSA_REQ_COUNTRY    "US"
set_var EASYRSA_REQ_PROVINCE   "California"
set_var EASYRSA_REQ_CITY       "San Francisco"
set_var EASYRSA_REQ_ORG        "Pi5-Supernode"
set_var EASYRSA_REQ_EMAIL      "admin@pi5-supernode.local"
set_var EASYRSA_REQ_OU         "Pi5-Supernode VPN"
EOF
    
    # Build CA
    ./easyrsa init-pki
    ./easyrsa --batch build-ca nopass
    
    # Generate server certificate
    ./easyrsa --batch build-server-full server nopass
    
    # Generate DH parameters
    ./easyrsa gen-dh
    
    # Generate TLS-auth key
    openvpn --genkey --secret pki/ta.key
    
    # Copy certificates
    cp pki/ca.crt /etc/openvpn/
    cp pki/issued/server.crt /etc/openvpn/
    cp pki/private/server.key /etc/openvpn/
    cp pki/dh.pem /etc/openvpn/
    cp pki/ta.key /etc/openvpn/
    
    # Create server config
    cat > /etc/openvpn/server.conf << EOF
port 1194
proto udp
dev tun
ca ca.crt
cert server.crt
key server.key
dh dh.pem
tls-auth ta.key 0
server 10.8.0.0 255.255.255.0
ifconfig-pool-persist ipp.txt
push "redirect-gateway def1 bypass-dhcp"
push "dhcp-option DNS 8.8.8.8"
push "dhcp-option DNS 8.8.4.4"
keepalive 10 120
cipher AES-256-GCM
auth SHA256
user nobody
group nogroup
persist-key
persist-tun
status openvpn-status.log
verb 3
EOF
    
    # Enable and start OpenVPN
    systemctl enable openvpn@server
    systemctl start openvpn@server
    
    log "OpenVPN server configured and started"
fi

# Configure WireGuard
echo
read -p "Configure WireGuard server? (y/N): " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    log "Configuring WireGuard server..."
    
    # Generate server keys
    cd /etc/wireguard
    wg genkey | tee server_private.key | wg pubkey > server_public.key
    chmod 600 server_private.key
    
    SERVER_PRIVATE_KEY=$(cat server_private.key)
    
    # Create server config
    cat > /etc/wireguard/wg0.conf << EOF
[Interface]
PrivateKey = $SERVER_PRIVATE_KEY
Address = 10.66.66.1/24
ListenPort = 51820
PostUp = iptables -A FORWARD -i %i -j ACCEPT; iptables -A FORWARD -o %i -j ACCEPT; iptables -t nat -A POSTROUTING -o eth0 -j MASQUERADE
PostDown = iptables -D FORWARD -i %i -j ACCEPT; iptables -D FORWARD -o %i -j ACCEPT; iptables -t nat -D POSTROUTING -o eth0 -j MASQUERADE

# Client configurations will be added here
EOF
    
    # Enable WireGuard
    systemctl enable wg-quick@wg0
    systemctl start wg-quick@wg0
    
    log "WireGuard server configured and started"
fi

# Configure IPsec/StrongSwan
echo
read -p "Configure IPsec/StrongSwan server? (y/N): " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    log "Configuring IPsec/StrongSwan server..."
    
    # Generate certificates
    cd /etc/ipsec.d
    
    # Create CA
    ipsec pki --gen --type rsa --size 4096 --outform pem > private/ca-key.pem
    ipsec pki --self --ca --lifetime 3650 --in private/ca-key.pem --dn "CN=Pi5-Supernode CA" --outform pem > cacerts/ca-cert.pem
    
    # Create server certificate
    ipsec pki --gen --type rsa --size 4096 --outform pem > private/server-key.pem
    ipsec pki --pub --in private/server-key.pem --type rsa | ipsec pki --issue --lifetime 1825 --cacert cacerts/ca-cert.pem --cakey private/ca-key.pem --dn "CN=$SERVER_IP" --san="$SERVER_IP" --flag serverAuth --flag ikeIntermediate --outform pem > certs/server-cert.pem
    
    # Configure IPsec
    cat > /etc/ipsec.conf << EOF
config setup
    charondebug="ike 1, knl 1, cfg 0"
    uniqueids=no

conn ikev2-vpn
    auto=add
    compress=no
    type=tunnel
    keyexchange=ikev2
    fragmentation=yes
    forceencaps=yes
    dpdaction=clear
    dpddelay=300s
    rekey=no
    left=%any
    leftid=$SERVER_IP
    leftcert=server-cert.pem
    leftsendcert=always
    leftsubnet=0.0.0.0/0
    right=%any
    rightid=%any
    rightauth=eap-mschapv2
    rightsourceip=10.10.10.0/24
    rightdns=8.8.8.8,8.8.4.4
    rightsendcert=never
    eap_identity=%identity
EOF
    
    # Start StrongSwan
    systemctl enable strongswan
    systemctl start strongswan
    
    log "IPsec/StrongSwan server configured and started"
fi

# Configure firewall
log "Configuring firewall for VPN services..."

# Enable IP forwarding
echo 'net.ipv4.ip_forward=1' >> /etc/sysctl.conf
sysctl -p

# Configure UFW for VPN
ufw --force enable

# OpenVPN
ufw allow 1194/udp

# WireGuard
ufw allow 51820/udp

# IPsec
ufw allow 500/udp
ufw allow 4500/udp

# SSH (ensure we don't lock ourselves out)
ufw allow ssh

# Create client generation scripts
log "Creating client configuration scripts..."

# OpenVPN client script
cat > /usr/local/bin/create-openvpn-client << 'EOF'
#!/bin/bash
if [ -z "$1" ]; then
    echo "Usage: $0 <client-name>"
    exit 1
fi

CLIENT_NAME="$1"
cd /etc/openvpn/easy-rsa

# Generate client certificate
./easyrsa --batch build-client-full "$CLIENT_NAME" nopass

# Create client config
mkdir -p /root/openvpn-clients
cat > "/root/openvpn-clients/$CLIENT_NAME.ovpn" << EOL
client
dev tun
proto udp
remote YOUR_SERVER_IP 1194
resolv-retry infinite
nobind
persist-key
persist-tun
remote-cert-tls server
cipher AES-256-GCM
auth SHA256
verb 3
<ca>
$(cat /etc/openvpn/ca.crt)
</ca>
<cert>
$(cat pki/issued/$CLIENT_NAME.crt)
</cert>
<key>
$(cat pki/private/$CLIENT_NAME.key)
</key>
<tls-auth>
$(cat /etc/openvpn/ta.key)
</tls-auth>
key-direction 1
EOL

echo "Client configuration created: /root/openvpn-clients/$CLIENT_NAME.ovpn"
EOF
chmod +x /usr/local/bin/create-openvpn-client

# WireGuard client script
cat > /usr/local/bin/create-wireguard-client << 'EOF'
#!/bin/bash
if [ -z "$1" ]; then
    echo "Usage: $0 <client-name>"
    exit 1
fi

CLIENT_NAME="$1"
SERVER_PUBLIC_KEY=$(cat /etc/wireguard/server_public.key)
CLIENT_PRIVATE_KEY=$(wg genkey)
CLIENT_PUBLIC_KEY=$(echo "$CLIENT_PRIVATE_KEY" | wg pubkey)

# Get next available IP
LAST_IP=$(grep "AllowedIPs" /etc/wireguard/wg0.conf | tail -n1 | cut -d' ' -f3 | cut -d'/' -f1 | cut -d'.' -f4)
if [ -z "$LAST_IP" ]; then
    NEXT_IP=2
else
    NEXT_IP=$((LAST_IP + 1))
fi

CLIENT_IP="10.66.66.$NEXT_IP"

# Add client to server config
cat >> /etc/wireguard/wg0.conf << EOL

[Peer]
# $CLIENT_NAME
PublicKey = $CLIENT_PUBLIC_KEY
AllowedIPs = $CLIENT_IP/32
EOL

# Create client config
mkdir -p /root/wireguard-clients
cat > "/root/wireguard-clients/$CLIENT_NAME.conf" << EOL
[Interface]
PrivateKey = $CLIENT_PRIVATE_KEY
Address = $CLIENT_IP/24
DNS = 8.8.8.8

[Peer]
PublicKey = $SERVER_PUBLIC_KEY
Endpoint = YOUR_SERVER_IP:51820
AllowedIPs = 0.0.0.0/0
PersistentKeepalive = 25
EOL

# Restart WireGuard to apply changes
systemctl restart wg-quick@wg0

echo "Client configuration created: /root/wireguard-clients/$CLIENT_NAME.conf"
echo "Client IP: $CLIENT_IP"
EOF
chmod +x /usr/local/bin/create-wireguard-client

echo
echo -e "${GREEN}=============================="
echo "VPN Installation Complete!"
echo "==============================${NC}"
echo
echo "Server IP: $SERVER_IP"
echo
echo "Services configured:"
if systemctl is-active --quiet openvpn@server; then
    echo "  ✓ OpenVPN (port 1194/udp)"
fi
if systemctl is-active --quiet wg-quick@wg0; then
    echo "  ✓ WireGuard (port 51820/udp)"
fi
if systemctl is-active --quiet strongswan; then
    echo "  ✓ IPsec/StrongSwan (ports 500,4500/udp)"
fi
echo
echo "Client creation commands:"
echo "  create-openvpn-client <name>     - Create OpenVPN client"
echo "  create-wireguard-client <name>   - Create WireGuard client"
echo
echo "Client configs will be saved to:"
echo "  /root/openvpn-clients/"
echo "  /root/wireguard-clients/"
echo
echo -e "${YELLOW}Remember to:"
echo "1. Update YOUR_SERVER_IP in client configs"
echo "2. Configure port forwarding on your router"
echo "3. Update firewall rules if needed${NC}"
echo
log "VPN setup completed successfully!"