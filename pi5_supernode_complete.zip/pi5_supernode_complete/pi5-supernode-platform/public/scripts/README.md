# Pi5 Supernode Installation Scripts

This directory contains automated installation and maintenance scripts for the Pi5 Supernode platform.

## Available Scripts

### Main Installation Script
- **`pi5-supernode-install.sh`** - Complete automated installation with all packages and services
- **Size:** ~45KB
- **Time:** 15-30 minutes
- **Requirements:** Raspberry Pi 5, Internet connection, Root access

### Specialized Scripts
- **`pi5-network-tools.sh`** - Lightweight installation with just network management tools
- **`pi5-vpn-setup.sh`** - Dedicated VPN server setup (OpenVPN, WireGuard, IPsec)
- **`pi5-update.sh`** - Update existing installation and perform maintenance
- **`pi5-uninstall.sh`** - Safely remove Pi5 Supernode installation

## Quick Start

### One-Line Installation
```bash
curl -sSL https://install.pi5-supernode.com/install.sh | sudo bash
```

### Manual Download and Install
```bash
# Download the main installer
wget https://scripts.pi5-supernode.com/pi5-supernode-install.sh

# Make executable
chmod +x pi5-supernode-install.sh

# Review the script (recommended)
less pi5-supernode-install.sh

# Run the installation
sudo ./pi5-supernode-install.sh
```

## Script Descriptions

### pi5-supernode-install.sh
Complete automated installation that includes:
- Network management tools (iproute2, bridge-utils, vlan, ethtool)
- VPN software (OpenVPN, WireGuard, StrongSwan)
- Monitoring tools (iftop, nload, vnstat, tcpdump)
- Security packages (iptables, fail2ban)
- Web interface setup
- Service configuration
- Automatic system optimization

### pi5-network-tools.sh
Lightweight installation for basic network management:
- Essential network utilities only
- Suitable for minimal installations
- No web interface or advanced features
- Quick 5-10 minute installation

### pi5-vpn-setup.sh
Dedicated VPN server configuration:
- OpenVPN with certificate generation
- WireGuard with key management
- IPsec/StrongSwan setup
- Client configuration generators
- Firewall configuration

### pi5-update.sh
Maintenance and update script:
- System package updates
- Security patches
- Performance optimization
- Log cleanup
- Service health checks

### pi5-uninstall.sh
Safe removal script:
- Complete system cleanup
- Configuration backup
- Service removal
- User account cleanup
- Optional package removal

## Prerequisites

### Hardware Requirements
- Raspberry Pi 5 (recommended) or Pi 4 with 4GB+ RAM
- MicroSD card (32GB minimum, 64GB recommended)
- Stable internet connection
- Ethernet cable for initial setup

### Software Requirements
- Raspberry Pi OS Lite (64-bit) or full version
- SSH access enabled
- Root/sudo access

## Installation Process

1. **Preparation**
   - Flash Raspberry Pi OS to SD card
   - Enable SSH access
   - Boot Pi and connect to network
   - Update system: `sudo apt update && sudo apt upgrade -y`

2. **Download Script**
   - Choose appropriate script for your needs
   - Download using wget or curl
   - Review script contents before running

3. **Execute Installation**
   - Make script executable: `chmod +x script-name.sh`
   - Run with sudo: `sudo ./script-name.sh`
   - Follow interactive prompts

4. **Post-Installation**
   - Reboot system if prompted
   - Access web interface at `http://your-pi-ip:3000`
   - Complete initial configuration

## Security Considerations

### Before Running Scripts
- Always review script contents before execution
- Download only from trusted sources
- Verify checksums when provided
- Test on non-production systems first
- Backup existing configurations

### Script Safety Features
- Error handling and rollback capabilities
- Configuration backups before changes
- Service verification after installation
- Detailed logging for troubleshooting

## Troubleshooting

### Common Issues
1. **Permission Denied**
   - Ensure script is executable: `chmod +x script-name.sh`
   - Run with sudo: `sudo ./script-name.sh`

2. **Network Connectivity**
   - Check internet connection: `ping google.com`
   - Verify DNS resolution: `nslookup google.com`

3. **Package Installation Failures**
   - Update package lists: `sudo apt update`
   - Check disk space: `df -h`
   - Review error logs in script output

4. **Service Start Failures**
   - Check service status: `systemctl status pi5-supernode`
   - Review logs: `journalctl -u pi5-supernode -f`
   - Verify configuration files

### Getting Help
- Check documentation at: https://docs.pi5-supernode.com
- Review troubleshooting guide in web interface
- Check system logs: `journalctl -xe`
- Contact support with log files and error messages

## Maintenance

### Regular Updates
Run the update script monthly:
```bash
sudo pi5-supernode-update
```

### System Monitoring
Check service status:
```bash
systemctl status pi5-supernode
journalctl -u pi5-supernode -f
```

### Backup Creation
Create configuration backup:
```bash
sudo pi5-supernode-backup
```

## Advanced Usage

### Custom Configuration
- Modify scripts for specific requirements
- Create custom installation profiles
- Integrate with configuration management tools

### Automation
- Use scripts in CI/CD pipelines
- Create custom deployment workflows
- Integrate with infrastructure as code

## Support

For support and additional resources:
- Documentation: https://docs.pi5-supernode.com
- GitHub: https://github.com/pi5-supernode
- Community Forum: https://community.pi5-supernode.com
- Email: support@pi5-supernode.com

## License

These scripts are provided under the MIT License. See LICENSE file for details.

---

**Note:** These scripts are designed for Raspberry Pi 5 but may work on other ARM64 systems with modifications. Always test in a safe environment before production use.