#!/bin/bash

# Pi5 Supernode Update Script
# Version: 1.0.0
# Description: Update system and Pi5 Supernode components

set -e

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m'

log() {
    echo -e "${GREEN}[$(date +'%Y-%m-%d %H:%M:%S')]${NC} $1"
}

warn() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

error() {
    echo -e "${RED}[ERROR]${NC} $1"
    exit 1
}

echo -e "${BLUE}"
echo "Pi5 Supernode Update Script"
echo "==========================="
echo -e "${NC}"

# Check if running as root
if [[ $EUID -ne 0 ]]; then
   error "This script must be run as root (use sudo)"
fi

# Create backup before update
log "Creating backup before update..."
BACKUP_DIR="/var/backups/pi5-supernode"
mkdir -p $BACKUP_DIR
DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_FILE="$BACKUP_DIR/pre-update-backup-$DATE.tar.gz"

tar -czf "$BACKUP_FILE" \
    /etc/pi5-supernode \
    /var/lib/pi5-supernode \
    /opt/pi5-supernode/package.json \
    2>/dev/null || warn "Some backup files may not exist yet"

log "Backup created: $BACKUP_FILE"

# Update system packages
log "Updating system packages..."
apt update
apt list --upgradable

read -p "Proceed with system package updates? (Y/n): " -n 1 -r
echo
if [[ $REPLY =~ ^[Nn]$ ]]; then
    log "Skipping system package updates"
else
    apt upgrade -y
    apt autoremove -y
    apt autoclean
fi

# Update Node.js packages
if [ -d "/opt/pi5-supernode" ]; then
    log "Updating Pi5 Supernode Node.js packages..."
    
    # Stop service
    systemctl stop pi5-supernode || warn "Pi5 Supernode service not running"
    
    cd /opt/pi5-supernode
    
    # Update npm packages
    npm update
    npm audit fix --force || warn "Some npm vulnerabilities may require manual intervention"
    
    # Update Node.js if needed
    CURRENT_NODE=$(node --version)
    log "Current Node.js version: $CURRENT_NODE"
    
    # Restart service
    systemctl start pi5-supernode
    
    if systemctl is-active --quiet pi5-supernode; then
        log "Pi5 Supernode service restarted successfully"
    else
        error "Failed to restart Pi5 Supernode service. Check logs: journalctl -u pi5-supernode"
    fi
else
    warn "Pi5 Supernode installation directory not found"
fi

# Update network tools
log "Updating network tools..."
apt install --only-upgrade -y \
    iproute2 bridge-utils vlan ethtool \
    iftop nload vnstat tcpdump \
    openvpn wireguard strongswan \
    iptables fail2ban ufw

# Clean up old logs
log "Cleaning up old logs..."
journalctl --vacuum-time=30d
find /var/log -name "*.log" -mtime +30 -delete 2>/dev/null || true
find /var/log -name "*.gz" -mtime +90 -delete 2>/dev/null || true

# Update system configuration
log "Updating system configuration..."

# Ensure IP forwarding is enabled
if ! grep -q "net.ipv4.ip_forward=1" /etc/sysctl.conf; then
    echo "net.ipv4.ip_forward=1" >> /etc/sysctl.conf
    sysctl -p
fi

# Check service status
log "Checking service status..."
echo
echo "Service Status:"
echo "==============="

services=("pi5-supernode" "ssh" "ufw" "fail2ban" "vnstat")
for service in "${services[@]}"; do
    if systemctl is-active --quiet "$service" 2>/dev/null; then
        echo -e "  ✓ $service: ${GREEN}active${NC}"
    elif systemctl is-enabled --quiet "$service" 2>/dev/null; then
        echo -e "  ⚠ $service: ${YELLOW}enabled but not running${NC}"
    else
        echo -e "  ✗ $service: ${RED}not available${NC}"
    fi
done

echo
echo -e "${GREEN}=============================="
echo "Update Complete!"
echo "==============================${NC}"
echo
log "Update completed successfully!"