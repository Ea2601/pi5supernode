#!/bin/bash

# Pi5 Network Tools Installer
# Version: 1.0.0
# Description: Lightweight network tools installation

set -e

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

log() {
    echo -e "${GREEN}[$(date +'%Y-%m-%d %H:%M:%S')]${NC} $1"
}

warn() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

error() {
    echo -e "${RED}[ERROR]${NC} $1"
    exit 1
}

echo "Pi5 Network Tools Installer"
echo "============================"
echo

# Check root
if [[ $EUID -ne 0 ]]; then
   error "This script must be run as root (use sudo)"
fi

# Update packages
log "Updating package list..."
apt update

# Install core network utilities
log "Installing core network utilities..."
apt install -y iproute2 bridge-utils vlan ethtool
apt install -y net-tools iputils-ping iputils-tracepath
apt install -y dnsutils netcat-openbsd

# Install monitoring tools
log "Installing network monitoring tools..."
apt install -y iftop nload vnstat tcpdump
apt install -y mtr-tiny nmap

# Install wireless tools
log "Installing wireless tools..."
apt install -y wireless-tools wpasupplicant
apt install -y hostapd

# Install bonding/teaming
log "Installing link aggregation tools..."
apt install -y ifenslave-2.6

# Configure vnstat
log "Configuring vnstat..."
systemctl enable vnstat
systemctl start vnstat

# Create useful aliases
log "Creating network aliases..."
cat >> /etc/bash.bashrc << 'EOF'

# Pi5 Network Tools Aliases
alias netstat-listen='netstat -tlnp'
alias netstat-all='netstat -tulanp'
alias ports='netstat -tlnp | grep LISTEN'
alias network-interfaces='ip link show'
alias network-routes='ip route show'
alias network-stats='cat /proc/net/dev'
alias wifi-scan='iwlist scan | grep ESSID'
EOF

echo
log "Network tools installation complete!"
echo
echo "Installed tools:"
echo "  - iproute2 (ip command)"
echo "  - bridge-utils (brctl)"
echo "  - vlan tools"
echo "  - ethtool"
echo "  - iftop, nload, vnstat"
echo "  - tcpdump, nmap, mtr"
echo "  - wireless tools"
echo
echo "Useful commands:"
echo "  ip link show          - List network interfaces"
echo "  ip route show         - Show routing table"
echo "  iftop -i eth0         - Real-time bandwidth usage"
echo "  nload eth0            - Network load monitor"
echo "  vnstat -i eth0        - Network statistics"
echo "  tcpdump -i eth0       - Packet capture"
echo
log "Installation completed successfully!"