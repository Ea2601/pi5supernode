#!/bin/bash

# Pi5 Supernode Main Installer Script
# Version: 1.2.0
# Description: Complete automated installation for Pi5 Supernode
# Author: Pi5 Supernode Team
# Website: https://pi5-supernode.com

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Logging function
log() {
    echo -e "${GREEN}[$(date +'%Y-%m-%d %H:%M:%S')]${NC} $1"
}

warn() {
    echo -e "${YELLOW}[$(date +'%Y-%m-%d %H:%M:%S')] WARNING:${NC} $1"
}

error() {
    echo -e "${RED}[$(date +'%Y-%m-%d %H:%M:%S')] ERROR:${NC} $1"
    exit 1
}

# Banner
echo -e "${BLUE}"
cat << "EOF"
 ____  _ ____    ____                                      _      
|  _ \(_) ___|  / ___| _   _ _ __   ___ _ __ _ __   ___   __| | ___ 
| |_) | |___ \  \___ \| | | | '_ \ / _ \ '__| '_ \ / _ \ / _` |/ _ \
|  __/| |___) |  ___) | |_| | |_) |  __/ |  | | | | (_) | (_| |  __/
|_|   |_|____/  |____/ \__,_| .__/ \___|_|  |_| |_|\___/ \__,_|\___|
                           |_|                                    
EOF
echo -e "${NC}"
echo "Pi5 Supernode Installer v1.2.0"
echo "=============================="
echo

# Check if running as root
if [[ $EUID -ne 0 ]]; then
   error "This script must be run as root (use sudo)"
fi

# Check if running on Raspberry Pi
if ! grep -q "Raspberry Pi" /proc/cpuinfo 2>/dev/null; then
    warn "This script is optimized for Raspberry Pi hardware"
    read -p "Continue anyway? (y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

# Check internet connectivity
log "Checking internet connectivity..."
if ! ping -c 1 8.8.8.8 &> /dev/null; then
    error "No internet connection. Please check your network settings."
fi

# Update system
log "Updating system packages..."
apt update && apt upgrade -y

# Install essential packages
log "Installing essential packages..."
apt install -y curl wget git vim htop unzip jq
apt install -y software-properties-common apt-transport-https ca-certificates gnupg lsb-release

# Install network management tools
log "Installing network management tools..."
apt install -y iproute2 bridge-utils vlan ethtool wireless-tools
apt install -y ifenslave-2.6 ifupdown resolvconf
apt install -y net-tools iptables-persistent

# Install monitoring tools
log "Installing monitoring tools..."
apt install -y iftop nload vnstat tcpdump wireshark-common
apt install -y nethogs bandwidthd iperf3

# Install VPN software
log "Installing VPN software..."
apt install -y openvpn easy-rsa wireguard strongswan
apt install -y openconnect network-manager-openconnect

# Install security packages
log "Installing security packages..."
apt install -y iptables iptables-persistent fail2ban ufw
apt install -y nmap nftables

# Install development tools
log "Installing development tools..."
curl -fsSL https://deb.nodesource.com/setup_18.x | bash -
apt install -y nodejs
apt install -y python3 python3-pip python3-venv
apt install -y build-essential

# Install Docker (optional)
read -p "Install Docker for containerized services? (y/N): " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    log "Installing Docker..."
    curl -fsSL https://get.docker.com -o get-docker.sh
    sh get-docker.sh
    usermod -aG docker pi || true
    rm get-docker.sh
fi

# Create pi5-supernode user
log "Creating pi5-supernode user..."
useradd -r -s /bin/false pi5supernode || true

# Set up directories
log "Setting up directories..."
mkdir -p /opt/pi5-supernode
mkdir -p /var/log/pi5-supernode
mkdir -p /etc/pi5-supernode
mkdir -p /var/lib/pi5-supernode

# Download and install web interface
log "Installing Pi5 Supernode web interface..."
cd /opt/pi5-supernode

# Create a placeholder for the actual web interface
cat > /opt/pi5-supernode/package.json << 'EOF'
{
  "name": "pi5-supernode",
  "version": "1.0.0",
  "description": "Pi5 Supernode Network Management Platform",
  "main": "server.js",
  "scripts": {
    "start": "node server.js",
    "dev": "nodemon server.js"
  },
  "dependencies": {
    "express": "^4.18.2",
    "cors": "^2.8.5",
    "helmet": "^7.0.0",
    "morgan": "^1.10.0"
  }
}
EOF

# Install Node.js dependencies
log "Installing Node.js dependencies..."
npm install

# Create basic server
cat > /opt/pi5-supernode/server.js << 'EOF'
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(helmet());
app.use(cors());
app.use(morgan('combined'));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Basic API routes
app.get('/api/status', (req, res) => {
  res.json({ 
    status: 'online', 
    version: '1.0.0',
    uptime: process.uptime()
  });
});

app.get('/api/interfaces/discover', (req, res) => {
  const { exec } = require('child_process');
  exec('ip link show', (error, stdout, stderr) => {
    if (error) {
      return res.status(500).json({ error: error.message });
    }
    // Basic parsing - in production this would be more sophisticated
    const interfaces = stdout.split('\n')
      .filter(line => line.includes(': '))
      .map(line => {
        const match = line.match(/\d+: ([^:]+):/)
        return match ? { name: match[1], type: 'unknown', state: 'unknown' } : null
      })
      .filter(Boolean);
    res.json({ interfaces });
  });
});

// Serve documentation
app.get('/', (req, res) => {
  res.send(`
    <html>
      <head><title>Pi5 Supernode</title></head>
      <body>
        <h1>Pi5 Supernode</h1>
        <p>Network Management Platform</p>
        <p>Status: Online</p>
        <a href="/api/status">API Status</a> | 
        <a href="/api/interfaces/discover">Discover Interfaces</a>
      </body>
    </html>
  `);
});

app.listen(PORT, () => {
  console.log(`Pi5 Supernode server running on port ${PORT}`);
});
EOF

# Create systemd service
log "Setting up systemd service..."
cat > /etc/systemd/system/pi5-supernode.service << 'EOF'
[Unit]
Description=Pi5 Supernode Network Management Platform
After=network.target

[Service]
Type=simple
User=pi5supernode
WorkingDirectory=/opt/pi5-supernode
ExecStart=/usr/bin/node server.js
Restart=always
RestartSec=10
Environment=NODE_ENV=production
Environment=PORT=3000

# Logging
StandardOutput=journal
StandardError=journal
SyslogIdentifier=pi5-supernode

[Install]
WantedBy=multi-user.target
EOF

# Set permissions
chown -R pi5supernode:pi5supernode /opt/pi5-supernode
chown -R pi5supernode:pi5supernode /var/log/pi5-supernode
chown -R pi5supernode:pi5supernode /var/lib/pi5-supernode

# Configure firewall
log "Configuring firewall..."
ufw --force enable
ufw allow ssh
ufw allow 3000/tcp
ufw allow 80/tcp
ufw allow 443/tcp

# Enable and start services
log "Enabling services..."
systemctl daemon-reload
systemctl enable pi5-supernode
systemctl start pi5-supernode

# Configure network monitoring
log "Setting up network monitoring..."
systemctl enable vnstat
systemctl start vnstat

# Create update script
log "Creating update script..."
cat > /usr/local/bin/pi5-supernode-update << 'EOF'
#!/bin/bash
echo "Updating Pi5 Supernode..."
systemctl stop pi5-supernode
cd /opt/pi5-supernode
npm update
systemctl start pi5-supernode
echo "Update complete!"
EOF
chmod +x /usr/local/bin/pi5-supernode-update

# Create backup script
cat > /usr/local/bin/pi5-supernode-backup << 'EOF'
#!/bin/bash
BACKUP_DIR="/var/backups/pi5-supernode"
mkdir -p $BACKUP_DIR
DATE=$(date +%Y%m%d_%H%M%S)
tar -czf "$BACKUP_DIR/pi5-supernode-backup-$DATE.tar.gz" \
    /etc/pi5-supernode \
    /var/lib/pi5-supernode \
    /opt/pi5-supernode/package.json
echo "Backup created: $BACKUP_DIR/pi5-supernode-backup-$DATE.tar.gz"
EOF
chmod +x /usr/local/bin/pi5-supernode-backup

# Final checks
log "Performing final checks..."
if systemctl is-active --quiet pi5-supernode; then
    log "Pi5 Supernode service is running"
else
    warn "Pi5 Supernode service is not running. Check logs with: journalctl -u pi5-supernode"
fi

# Get local IP
LOCAL_IP=$(hostname -I | awk '{print $1}')

echo
echo -e "${GREEN}=============================="
echo "Installation Complete!"
echo "==============================${NC}"
echo
echo "Pi5 Supernode is now installed and running."
echo
echo "Web Interface: http://$LOCAL_IP:3000"
echo "API Endpoint:  http://$LOCAL_IP:3000/api"
echo
echo "Useful commands:"
echo "  - Check status:     systemctl status pi5-supernode"
echo "  - View logs:        journalctl -u pi5-supernode -f"
echo "  - Update system:    pi5-supernode-update"
echo "  - Create backup:    pi5-supernode-backup"
echo
echo "Documentation: https://docs.pi5-supernode.com"
echo
echo -e "${YELLOW}IMPORTANT: Please reboot the system to complete the installation.${NC}"
echo
read -p "Reboot now? (y/N): " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    log "Rebooting system..."
    reboot
fi

log "Installation completed successfully!"